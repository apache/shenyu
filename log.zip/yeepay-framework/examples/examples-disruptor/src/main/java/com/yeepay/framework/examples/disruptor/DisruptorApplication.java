package com.yeepay.framework.examples.disruptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The type Demo disruptor application.
 */
@SpringBootApplication
public class DisruptorApplication {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(final String[] args) {
        SpringApplication.run(DisruptorApplication.class, args);
    }
}
