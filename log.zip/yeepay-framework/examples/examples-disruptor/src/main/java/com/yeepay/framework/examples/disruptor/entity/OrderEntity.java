package com.yeepay.framework.examples.disruptor.entity;

import lombok.Data;

/**
 * The type Order entity.
 */
@Data
public class OrderEntity {

    private String number;

    private String address;
}
