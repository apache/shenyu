package com.yeepay.framework.examples.disruptor.entity;

import lombok.Data;

/**
 * The type User entity.
 */
@Data
public class UserEntity {

    private String id;

    private String name;
}
