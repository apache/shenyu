package com.yeepay.framework.examples.disruptor.entity;

import lombok.Data;

/**
 * The type Order entity.
 */
@Data
public class AccountEntity {

    private String id;

    private String address;
}
