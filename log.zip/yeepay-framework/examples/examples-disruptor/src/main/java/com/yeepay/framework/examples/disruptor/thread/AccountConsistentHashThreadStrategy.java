package com.yeepay.framework.examples.disruptor.thread;

import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.thread.AbstractConsistentHashThreadStrategy;
import com.yeepay.framework.examples.disruptor.entity.AccountEntity;
import org.springframework.stereotype.Component;

/**
 * 自定义一致性Hash.
 */
@Component
public class AccountConsistentHashThreadStrategy extends AbstractConsistentHashThreadStrategy<AccountEntity> {

    @Override
    protected String getHashCode(final DataEvent<AccountEntity> event) {
        return event.getData().getId();
    }
}
