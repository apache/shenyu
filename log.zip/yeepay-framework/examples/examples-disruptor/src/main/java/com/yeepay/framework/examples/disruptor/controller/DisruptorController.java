package com.yeepay.framework.examples.disruptor.controller;

import com.yeepay.framework.disruptor.publish.DisruptorPublisher;
import com.yeepay.framework.examples.disruptor.entity.AccountEntity;
import com.yeepay.framework.examples.disruptor.entity.OrderEntity;
import com.yeepay.framework.examples.disruptor.entity.UserEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The type Disruptor controller.
 */
@RestController
@RequestMapping("/disruptor")
@Slf4j
@RequiredArgsConstructor
public class DisruptorController {

    private final DisruptorPublisher<Object> disruptorPublisher;

    /**
     * Send order.
     */
    @GetMapping("/order")
    public void sendOrder() {
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setNumber("10000");
        disruptorPublisher.publishEvent(orderEntity);
    }

    /**
     * Send user.
     */
    @GetMapping("/user")
    public void sendUser() {
        UserEntity userEntity = new UserEntity();
        userEntity.setId("10000");
        disruptorPublisher.publishEvent(userEntity);
    }

    /**
     * Send user.
     */
    @GetMapping("/userOrderly")
    public void sendUserOrderly() {
        UserEntity userEntity1 = new UserEntity();
        userEntity1.setId("10000");
        userEntity1.setName("htx1");
        disruptorPublisher.publishEvent(userEntity1);
        UserEntity userEntity2 = new UserEntity();
        userEntity2.setId("10000");
        userEntity2.setName("htx2");
        disruptorPublisher.publishEvent(userEntity2);

        UserEntity userEntity3 = new UserEntity();
        userEntity3.setId("20000");
        userEntity3.setName("htx3");
        disruptorPublisher.publishEvent(userEntity3);
        disruptorPublisher.publishEvent(userEntity3);
        disruptorPublisher.publishEvent(userEntity3);
        disruptorPublisher.publishEvent(userEntity3);
    }

    /**
     * Order orderly.
     */
    @GetMapping("/orderOrderly")
    public void userOrderly() {
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setNumber("20000");
        orderEntity.setAddress("htx3");
        disruptorPublisher.publishEvent(orderEntity);
        disruptorPublisher.publishEvent(orderEntity);
        disruptorPublisher.publishEvent(orderEntity);
        disruptorPublisher.publishEvent(orderEntity);
    }

    /**
     * Account orderly.
     */
    @GetMapping("/accountOrderly")
    public void accountOrderly() {
        AccountEntity accountEntity = new AccountEntity();
        accountEntity.setId("20000");
        accountEntity.setAddress("hxxxxxxxx");
        disruptorPublisher.publishEvent(accountEntity);
        disruptorPublisher.publishEvent(accountEntity);
        disruptorPublisher.publishEvent(accountEntity);
        disruptorPublisher.publishEvent(accountEntity);
    }
}
