package com.yeepay.framework.examples.disruptor.subscriber;

import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import com.yeepay.framework.examples.disruptor.entity.AccountEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * The type User executor subscriber.
 */
@Slf4j
@Component
public class AccountExecutorSubscriber implements ExecutorSubscriber<AccountEntity> {

    @Override
    public void executor(final AccountEntity data) {
        log.info(data.toString());
    }
}
