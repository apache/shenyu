package com.yeepay.framework.examples.disruptor.subscriber;

import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import com.yeepay.framework.examples.disruptor.entity.UserEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * The type User executor subscriber.
 */
@Slf4j
@Component
public class UserExecutorSubscriber implements ExecutorSubscriber<UserEntity> {

    @Override
    public void executor(final UserEntity data) {
        log.info(data.toString());
    }
}
