package com.yeepay.framework.examples.disruptor.thread;

import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.executor.SingletonExecutor;
import com.yeepay.framework.disruptor.thread.ThreadSelectionStrategy;
import com.yeepay.framework.examples.disruptor.entity.UserEntity;
import org.springframework.stereotype.Component;

/**
 * 自定义哈希取模策略.
 */
@Component
public class UserHashModThreadStrategy implements ThreadSelectionStrategy<UserEntity> {

    private SingletonExecutor[] executors;

    @Override
    public void initialize(final SingletonExecutor[] virtualExecutors) {
        this.executors = virtualExecutors;
    }

    @Override
    public SingletonExecutor select(final DataEvent<UserEntity> event) {
        UserEntity data = event.getData();
        String id = data.getId();
        int index = Math.abs(id.hashCode()) % executors.length;
        return executors[index];
    }
}
