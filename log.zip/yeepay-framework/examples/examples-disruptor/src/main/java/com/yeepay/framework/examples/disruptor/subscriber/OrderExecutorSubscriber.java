package com.yeepay.framework.examples.disruptor.subscriber;

import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import com.yeepay.framework.examples.disruptor.entity.OrderEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * The type Order subscriber.
 */
@Slf4j
@Component
public class OrderExecutorSubscriber implements ExecutorSubscriber<OrderEntity> {

    @Override
    public void executor(final OrderEntity entity) {
        log.info(entity.toString());
        // do something xxxxxx
    }
}
