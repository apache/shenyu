package com.yeepay.framework.examples.disruptor.thread;

import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.thread.AbstractHashModThreadStrategy;
import com.yeepay.framework.examples.disruptor.entity.OrderEntity;
import org.springframework.stereotype.Component;

/**
 * 自定义哈希取模策略.
 */
@Component
public class OrderHashModThreadStrategy extends AbstractHashModThreadStrategy<OrderEntity> {

    @Override
    protected int getHashCode(final DataEvent<OrderEntity> event) {
        return event.getData().getNumber().hashCode();
    }
}
