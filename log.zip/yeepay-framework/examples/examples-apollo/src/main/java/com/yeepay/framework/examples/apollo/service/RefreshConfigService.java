package com.yeepay.framework.examples.apollo.service;

import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import com.yeepay.framework.examples.apollo.config.UserConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.context.scope.refresh.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * The type Refresh Config service.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RefreshConfigService {

    private final RefreshScope refreshScope;
    
    private final UserConfig userConfig;
    
    /**
     * Refresh auth.
     *
     * @param event the event
     */
    @ApolloConfigChangeListener(
            value = {"application.properties", "test.yaml"},
            interestedKeyPrefixes = {"user."})
    public void refreshAuth(ConfigChangeEvent event) {
        refreshScope.refresh("userConfig");
        log.info("refresh userConfig");
        log.info("userConfig={}", userConfig);
    }
}
