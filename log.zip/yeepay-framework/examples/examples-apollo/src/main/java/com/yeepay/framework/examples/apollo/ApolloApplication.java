package com.yeepay.framework.examples.apollo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The type Demo apollo application.
 */
@SpringBootApplication
public class ApolloApplication {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(final String[] args) {
        SpringApplication.run(ApolloApplication.class, args);
    }
}
