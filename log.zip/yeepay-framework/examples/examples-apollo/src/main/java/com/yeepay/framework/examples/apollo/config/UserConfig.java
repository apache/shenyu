package com.yeepay.framework.examples.apollo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@ConfigurationProperties("user")
@Component("userConfig")
@RefreshScope
@Data
public class UserConfig {
    
    private String username;
    
    private String password;
    
    private String token;
}
