package com.yeepay.framework.examples.apollo.config;

import com.yeepay.framework.springboot.starter.apollo.annotation.ApolloAutoRefreshConfigComponent;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;
import java.util.Set;

/**
 * The type Custom config.
 */
@ConfigurationProperties(prefix = "examples.custom")
@Data
@ApolloAutoRefreshConfigComponent
public class CustomConfig {

    private Map<String, Auth> resources;

    /**
     * The type Auth.
     */
    @Data
    public static class Auth {

        private Set<String> allow;

        private Set<String> forbid;
    }
}
