package com.yeepay.framework.examples.apollo.controller;

import com.yeepay.framework.examples.apollo.config.CustomConfig;
import com.yeepay.framework.examples.apollo.config.UserConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The type Apollo controller.
 */
@RestController
@RequiredArgsConstructor
@Slf4j
public class ApolloController {

    private final CustomConfig customConfig;
    
    private final UserConfig userConfig;
    
    /**
     * Test custom string.
     *
     * @return the string
     */
    @GetMapping("/apollo/custom")
    public String testCustom() {
        try {
            log.debug("request custom config");
            return customConfig.toString();
        } catch (Exception e) {
            return "Error config: " + e.getMessage();
        }
    }
    
    /**
     * Test user string.
     *
     * @return the string
     */
    @GetMapping("/apollo/user")
    public String testUser() {
        try {
            log.debug("request test config");
            return userConfig.toString();
        } catch (Exception e) {
            return "Error config: " + e.getMessage();
        }
    }
}
