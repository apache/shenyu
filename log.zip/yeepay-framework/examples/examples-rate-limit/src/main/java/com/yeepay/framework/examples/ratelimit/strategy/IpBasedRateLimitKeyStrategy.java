package com.yeepay.framework.examples.ratelimit.strategy;

import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Component
public class IpBasedRateLimitKeyStrategy implements RateLimitKeyStrategy {

    @Override
    public String buildKey(final JoinPoint joinPoint, final String[] keys) {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        String ip = (attrs != null) ? attrs.getRequest().getRemoteAddr() : "unknown";
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        return ip + ":" + signature.getMethod().getName();
    }
}
