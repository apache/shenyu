package com.yeepay.framework.examples.ratelimit.service;

import com.yeepay.framework.examples.ratelimit.strategy.GracefulRateLimitFailureStrategy;
import com.yeepay.framework.examples.ratelimit.strategy.IpBasedRateLimitKeyStrategy;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.springboot.starter.ratelimit.annotation.YeepayRateLimit;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class RateLimitAnnotationService {

    private final AtomicInteger counter = new AtomicInteger(0);

    @YeepayRateLimit(
            name = "order-query",
            keys = {"#orderId"},
            replenishRate = 5,
            burstCapacity = 10)
    public String queryOrder(String orderId) {
        int current = counter.incrementAndGet();
        log.info("Querying order: {}, counter: {}", orderId, current);
        return "Order " + orderId + " queried, counter=" + current;
    }

    @YeepayRateLimit(
            name = "payment",
            keys = {"#accountId"},
            algorithm = RateLimitAlgorithm.SLIDING_WINDOW,
            replenishRate = 2,
            burstCapacity = 5)
    public String pay(String accountId, long amount) {
        log.info("Processing payment: account={}, amount={}", accountId, amount);
        return "Payment of " + amount + " for account " + accountId + " succeeded";
    }

    @YeepayRateLimit(
            name = "sms",
            keys = {"#phone"},
            algorithm = RateLimitAlgorithm.LEAKY_BUCKET,
            replenishRate = 1,
            burstCapacity = 3)
    public String sendSms(String phone) {
        log.info("Sending SMS to: {}", phone);
        return "SMS sent to " + phone;
    }

    @YeepayRateLimit(
            name = "resource-access",
            keys = {"#resourceId"},
            algorithm = RateLimitAlgorithm.CONCURRENT_REQUEST,
            burstCapacity = 3)
    public String concurrentAccess(String resourceId) throws InterruptedException {
        log.info("Accessing resource: {}, start", resourceId);
        Thread.sleep(3000);
        log.info("Accessing resource: {}, done", resourceId);
        return "Resource " + resourceId + " accessed successfully";
    }

    @YeepayRateLimit(
            name = "api-call",
            keys = {"#apiName"},
            algorithm = RateLimitAlgorithm.TOKEN_BUCKET,
            replenishRate = 2,
            burstCapacity = 3,
            failStrategy = GracefulRateLimitFailureStrategy.class)
    public String apiCallGraceful(String apiName) {
        log.info("API call: {}", apiName);
        return "{\"success\":true,\"message\":\"API " + apiName + " called successfully\"}";
    }

    @YeepayRateLimit(
            name = "ip-limited",
            algorithm = RateLimitAlgorithm.TOKEN_BUCKET,
            replenishRate = 3,
            burstCapacity = 5,
            keyStrategy = IpBasedRateLimitKeyStrategy.class)
    public String ipRateLimited() {
        log.info("IP-rate-limited endpoint called");
        return "Request allowed (IP-based rate limiting)";
    }
}
