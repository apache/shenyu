package com.yeepay.framework.examples.ratelimit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The type Rate limit example application.
 */
@SpringBootApplication
public class RateLimitExampleApplication {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(RateLimitExampleApplication.class, args);
    }
}
