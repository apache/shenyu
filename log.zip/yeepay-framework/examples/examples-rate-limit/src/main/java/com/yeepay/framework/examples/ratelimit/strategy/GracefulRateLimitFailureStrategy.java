package com.yeepay.framework.examples.ratelimit.strategy;

import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

@Component
public class GracefulRateLimitFailureStrategy implements RateLimitFailureStrategy {

    @Override
    public Object execute(final String key, final RateLimitResult result, final ProceedingJoinPoint point) {
        return "{\"success\":false,\"message\":\"Rate limited\",\"key\":\"" + key + "\",\"tokensRemaining\":"
                + result.getTokensRemaining() + "}";
    }
}
