package com.yeepay.framework.examples.ratelimit.controller;

import com.yeepay.framework.examples.ratelimit.service.RateLimitAnnotationService;
import com.yeepay.framework.examples.ratelimit.service.RateLimitManagerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rate-limit")
@RequiredArgsConstructor
public class RateLimitExampleController {

    private final RateLimitAnnotationService annotationService;

    private final RateLimitManagerService managerService;

    // ==================== Annotation (@YeepayRateLimit) ====================

    @GetMapping("/annotation/order/{orderId}")
    public String annotationOrder(@PathVariable String orderId) {
        return annotationService.queryOrder(orderId);
    }

    @GetMapping("/annotation/payment/{accountId}")
    public String annotationPayment(@PathVariable String accountId, @RequestParam(defaultValue = "100") long amount) {
        return annotationService.pay(accountId, amount);
    }

    @GetMapping("/annotation/sms/{phone}")
    public String annotationSms(@PathVariable String phone) {
        return annotationService.sendSms(phone);
    }

    @GetMapping("/annotation/concurrent/{resourceId}")
    public String annotationConcurrent(@PathVariable String resourceId) throws InterruptedException {
        return annotationService.concurrentAccess(resourceId);
    }

    @GetMapping("/annotation/graceful/{apiName}")
    public String annotationGraceful(@PathVariable String apiName) {
        return annotationService.apiCallGraceful(apiName);
    }

    @GetMapping("/annotation/ip-limited")
    public String annotationIpLimited() {
        return annotationService.ipRateLimited();
    }

    // ==================== RateLimiterManager (Programmatic) ====================

    @GetMapping("/manager/allowed/{key}")
    public String managerAllowed(@PathVariable String key) {
        return managerService.isAllowedSimple(key);
    }

    @GetMapping("/manager/allowed-custom/{key}")
    public String managerAllowedCustom(
            @PathVariable String key,
            @RequestParam(defaultValue = "5") double rate,
            @RequestParam(defaultValue = "10") double capacity) {
        return managerService.isAllowedCustom(key, rate, capacity);
    }

    @GetMapping("/manager/acquire/{key}")
    public String managerAcquire(@PathVariable String key) {
        return managerService.tryAcquireRunnable(key);
    }

    @GetMapping("/manager/acquire-supplier/{key}")
    public String managerAcquireSupplier(@PathVariable String key) {
        return managerService.tryAcquireSupplier(key);
    }

    @GetMapping("/manager/sliding-window/{key}")
    public String managerSlidingWindow(@PathVariable String key) {
        return managerService.slidingWindowCheck(key);
    }

    @GetMapping("/manager/leaky-bucket/{key}")
    public String managerLeakyBucket(@PathVariable String key) {
        return managerService.leakyBucketCheck(key);
    }

    @GetMapping("/manager/concurrent/{key}")
    public String managerConcurrent(@PathVariable String key) {
        return managerService.concurrentRequestCheck(key);
    }
}
