package com.yeepay.framework.examples.ratelimit.service;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class RateLimitManagerService {

    private final RateLimiterManager rateLimiterManager;

    public String isAllowedSimple(String key) {
        RateLimitResult result = rateLimiterManager.isAllowed(key);
        log.info(
                "[isAllowed] key={}, allowed={}, tokensRemaining={}",
                key,
                result.isAllowed(),
                result.getTokensRemaining());
        return "key=" + key + ", allowed=" + result.isAllowed() + ", tokensRemaining=" + result.getTokensRemaining();
    }

    public String isAllowedCustom(String key, double rate, double capacity) {
        RateLimitResult result = rateLimiterManager.isAllowed(key, rate, capacity);
        log.info("[isAllowed] key={}, rate={}, capacity={}, allowed={}", key, rate, capacity, result.isAllowed());
        return "key=" + key + ", allowed=" + result.isAllowed() + ", tokensRemaining=" + result.getTokensRemaining();
    }

    public String tryAcquireRunnable(String key) {
        final String[] result = {"Rate limited for key=" + key};
        rateLimiterManager.tryAcquire(
                key,
                5,
                10,
                () -> {
                    log.info("[tryAcquire] Acquired token for key={}", key);
                    result[0] = "Acquired token for key=" + key;
                },
                rateLimitResult -> {
                    log.warn(
                            "[tryAcquire] Rate limited for key={}, tokensRemaining={}",
                            key,
                            rateLimitResult.getTokensRemaining());
                    result[0] =
                            "Rate limited for key=" + key + ", tokensRemaining=" + rateLimitResult.getTokensRemaining();
                });
        return result[0];
    }

    public String tryAcquireSupplier(String key) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key("supplier:" + key)
                .replenishRate(3)
                .burstCapacity(5)
                .requestCount(1)
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .build();
        return rateLimiterManager.tryAcquire(
                entity,
                () -> {
                    log.info("[tryAcquire(Supplier)] Acquired for key={}", key);
                    return "Acquired token for key=" + key;
                },
                () -> {
                    log.warn("[tryAcquire(Supplier)] Rate limited for key={}", key);
                    return "Rate limited for key=" + key;
                });
    }

    public String slidingWindowCheck(String key) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key("sw:" + key)
                .replenishRate(2)
                .burstCapacity(5)
                .algorithm(RateLimitAlgorithm.SLIDING_WINDOW)
                .build();
        RateLimitResult result = rateLimiterManager.isAllowed(entity);
        log.info(
                "[SLIDING_WINDOW] key={}, allowed={}, tokensRemaining={}",
                key,
                result.isAllowed(),
                result.getTokensRemaining());
        return "algorithm=SLIDING_WINDOW, key=" + key + ", allowed=" + result.isAllowed() + ", tokensRemaining="
                + result.getTokensRemaining();
    }

    public String leakyBucketCheck(String key) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key("lb:" + key)
                .replenishRate(1)
                .burstCapacity(3)
                .algorithm(RateLimitAlgorithm.LEAKY_BUCKET)
                .build();
        RateLimitResult result = rateLimiterManager.isAllowed(entity);
        log.info(
                "[LEAKY_BUCKET] key={}, allowed={}, tokensRemaining={}",
                key,
                result.isAllowed(),
                result.getTokensRemaining());
        return "algorithm=LEAKY_BUCKET, key=" + key + ", allowed=" + result.isAllowed() + ", tokensRemaining="
                + result.getTokensRemaining();
    }

    public String concurrentRequestCheck(String key) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key("cr:" + key)
                .burstCapacity(3)
                .algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST)
                .build();
        RateLimitResult result = rateLimiterManager.isAllowed(entity);
        log.info(
                "[CONCURRENT_REQUEST] key={}, allowed={}, tokensRemaining={}",
                key,
                result.isAllowed(),
                result.getTokensRemaining());
        return "algorithm=CONCURRENT_REQUEST, key=" + key + ", allowed=" + result.isAllowed() + ", tokensRemaining="
                + result.getTokensRemaining();
    }
}
