#!/bin/bash
# ============================================================================
# Yeepay Rate Limit Framework - Comprehensive Test Script
#
# Usage:
#   bash test-rate-limit.sh [base_url]
#
# Default base_url: http://localhost:8080
#
# Prerequisites:
#   1. Build the project:
#      mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip
#   2. Start the example service:
#      mvn spring-boot:run -pl examples/examples-rate-limit
#      (or specify profile: -Dspring-boot.run.profiles=resilience4j)
# ============================================================================

BASE_URL="${1:-http://localhost:8080}"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

# ---------------------------------------------------------------------------
# Helper: single request, print result
# Args: description, url
# ---------------------------------------------------------------------------
single_request() {
    local desc="$1"
    local url="$2"
    local tmpfile
    tmpfile=$(mktemp)
    local http_code
    http_code=$(curl -s -w '%{http_code}' -o "$tmpfile" "$url")
    local body
    body=$(cat "$tmpfile")
    rm -f "$tmpfile"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$http_code" -eq 200 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "  ${GREEN}[PASS]${NC} $desc -> HTTP $http_code | $body"
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo -e "  ${RED}[FAIL]${NC} $desc -> HTTP $http_code"
    fi
}

# ---------------------------------------------------------------------------
# Helper: burst requests sequentially, show pass/fail counts
# Args: description, url, count
# ---------------------------------------------------------------------------
burst_requests() {
    local desc="$1"
    local url="$2"
    local count="$3"
    local passed=0
    local limited=0

    echo -e "  ${CYAN}[BURST]${NC} $desc: sending $count rapid requests..."
    for i in $(seq 1 "$count"); do
        local http_code
        http_code=$(curl -s -o /dev/null -w '%{http_code}' "$url")
        if [ "$http_code" -eq 200 ]; then
            passed=$((passed + 1))
        else
            limited=$((limited + 1))
        fi
    done
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$limited" -gt 0 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "    ${GREEN}[PASS]${NC} $passed passed, ${YELLOW}$limited rate-limited${NC} (limit triggered as expected)"
    else
        echo -e "    ${YELLOW}[INFO]${NC} all $passed requests passed (limit not reached with $count requests)"
        PASS_COUNT=$((PASS_COUNT + 1))
    fi
}

# ---------------------------------------------------------------------------
# Helper: burst requests with body inspection (for graceful failure)
# Args: description, url, count
# ---------------------------------------------------------------------------
burst_requests_graceful() {
    local desc="$1"
    local url="$2"
    local count="$3"
    local passed=0
    local graceful=0

    echo -e "  ${CYAN}[BURST]${NC} $desc: sending $count rapid requests..."
    for i in $(seq 1 "$count"); do
        local body
        body=$(curl -s "$url")
        if echo "$body" | grep -q '"success":true'; then
            passed=$((passed + 1))
        elif echo "$body" | grep -q '"success":false'; then
            graceful=$((graceful + 1))
        fi
    done
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$graceful" -gt 0 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "    ${GREEN}[PASS]${NC} $passed succeeded, ${YELLOW}$graceful gracefully rejected${NC} (returned JSON error, not 500)"
    else
        echo -e "    ${YELLOW}[INFO]${NC} all $passed requests passed"
        PASS_COUNT=$((PASS_COUNT + 1))
    fi
}

# ---------------------------------------------------------------------------
# Helper: concurrent requests (background curl)
# Args: description, url, count
# ---------------------------------------------------------------------------
concurrent_requests() {
    local desc="$1"
    local url="$2"
    local count="$3"
    local tmpdir
    tmpdir=$(mktemp -d)

    echo -e "  ${CYAN}[CONCURRENT]${NC} $desc: sending $count concurrent requests..."
    for i in $(seq 1 "$count"); do
        curl -s -o "$tmpdir/body_$i" -w '%{http_code}' "$url" > "$tmpdir/code_$i" &
    done
    wait

    local passed=0
    local limited=0
    for i in $(seq 1 "$count"); do
        local code
        code=$(cat "$tmpdir/code_$i" 2>/dev/null)
        if [ "$code" = "200" ]; then
            passed=$((passed + 1))
        else
            limited=$((limited + 1))
        fi
    done
    rm -rf "$tmpdir"

    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$limited" -gt 0 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "    ${GREEN}[PASS]${NC} $passed passed, ${YELLOW}$limited rate-limited${NC} (concurrent limit triggered)"
    else
        echo -e "    ${YELLOW}[INFO]${NC} all $passed requests passed"
        PASS_COUNT=$((PASS_COUNT + 1))
    fi
}

section() {
    echo ""
    echo -e "${BOLD}$1${NC}"
    echo "  $2"
}

# ============================================================================
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Yeepay Rate Limit Framework - Test Suite${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Target: $BASE_URL"
echo ""

# Check service is up
echo -n "Checking service availability... "
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE_URL/rate-limit/manager/allowed/health-check" 2>/dev/null)
if [ "$HTTP_CODE" = "000" ]; then
    echo -e "${RED}FAILED${NC}"
    echo "  Cannot connect to $BASE_URL. Please start the service first:"
    echo "    mvn spring-boot:run -pl examples/examples-rate-limit"
    exit 1
fi
echo -e "${GREEN}OK${NC}"

# ===========================
# PART 1: Annotation-based
# ===========================
echo ""
echo -e "${BOLD}============ Part 1: Annotation-based (@YeepayRateLimit) ============${NC}"

# --- 1.1 Token Bucket ---
section "1.1 Token Bucket" "rate=5/s, capacity=10, key=orderId"
single_request "single request" "$BASE_URL/rate-limit/annotation/order/ORD001"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/annotation/order/ORD-BURST" 12

# --- 1.2 Sliding Window ---
section "1.2 Sliding Window" "rate=2/s, capacity=5, key=accountId, window=2.5s"
single_request "single request" "$BASE_URL/rate-limit/annotation/payment/ACC001?amount=100"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/annotation/payment/ACC-BURST?amount=50" 7

# --- 1.3 Leaky Bucket ---
section "1.3 Leaky Bucket" "rate=1/s, capacity=3, key=phone"
single_request "single request" "$BASE_URL/rate-limit/annotation/sms/13800001111"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/annotation/sms/13800009999" 5

# --- 1.4 Concurrent Request ---
section "1.4 Concurrent Request" "capacity=3, key=resourceId, handler sleeps 3s"
single_request "single request" "$BASE_URL/rate-limit/annotation/concurrent/RES-SINGLE"
sleep 1
concurrent_requests "concurrent test" "$BASE_URL/rate-limit/annotation/concurrent/RES-CONC" 5

# --- 1.5 Custom Failure Strategy ---
section "1.5 Custom Failure Strategy (Graceful)" "rate=2/s, capacity=3, returns JSON on rejection (not 500)"
single_request "single request" "$BASE_URL/rate-limit/annotation/graceful/user-api"
sleep 1
burst_requests_graceful "burst test (expect JSON error)" "$BASE_URL/rate-limit/annotation/graceful/burst-api" 5

# --- 1.6 IP-based Key Strategy ---
section "1.6 Custom Key Strategy (IP-based)" "rate=3/s, capacity=5, key=clientIP:method"
single_request "single request" "$BASE_URL/rate-limit/annotation/ip-limited"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/annotation/ip-limited" 7

# ===========================
# PART 2: Programmatic (RateLimiterManager)
# ===========================
echo ""
echo -e "${BOLD}============ Part 2: Programmatic (RateLimiterManager) ============${NC}"

# --- 2.1 Token Bucket (isAllowed simple) ---
section "2.1 Token Bucket - isAllowed (defaults)" "rate=10/s, capacity=20"
single_request "single request" "$BASE_URL/rate-limit/manager/allowed/tb-simple"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/manager/allowed/tb-burst" 22

# --- 2.2 Token Bucket (isAllowed custom) ---
section "2.2 Token Bucket - isAllowed (custom)" "rate=3/s, capacity=5"
single_request "single request" "$BASE_URL/rate-limit/manager/allowed-custom/tb-custom?rate=3&capacity=5"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/manager/allowed-custom/tb-custom-burst?rate=3&capacity=5" 7

# --- 2.3 Sliding Window ---
section "2.3 Sliding Window - isAllowed" "rate=2/s, capacity=5, window=2.5s"
single_request "single request" "$BASE_URL/rate-limit/manager/sliding-window/sw-test"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/manager/sliding-window/sw-burst" 7

# --- 2.4 Leaky Bucket ---
section "2.4 Leaky Bucket - isAllowed" "rate=1/s, capacity=3"
single_request "single request" "$BASE_URL/rate-limit/manager/leaky-bucket/lb-test"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/manager/leaky-bucket/lb-burst" 5

# --- 2.5 Concurrent Request ---
section "2.5 Concurrent Request - isAllowed" "capacity=3"
single_request "single request" "$BASE_URL/rate-limit/manager/concurrent/cr-test"
sleep 1
burst_requests "burst test (note: semaphore not released per call)" "$BASE_URL/rate-limit/manager/concurrent/cr-burst" 5

# --- 2.6 tryAcquire (Runnable) ---
section "2.6 tryAcquire (Runnable + Consumer)" "rate=5/s, capacity=10"
single_request "single request" "$BASE_URL/rate-limit/manager/acquire/acq-test"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/manager/acquire/acq-burst" 12

# --- 2.7 tryAcquire (Supplier) ---
section "2.7 tryAcquire (Supplier)" "rate=3/s, capacity=5, TOKEN_BUCKET"
single_request "single request" "$BASE_URL/rate-limit/manager/acquire-supplier/sup-test"
sleep 1
burst_requests "burst test" "$BASE_URL/rate-limit/manager/acquire-supplier/sup-burst" 7

# ===========================
# Summary
# ===========================
echo ""
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Summary${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Total test groups: $TOTAL_TESTS"
echo -e "  ${GREEN}Passed: $PASS_COUNT${NC}"
echo -e "  ${RED}Failed: $FAIL_COUNT${NC}"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo -e "  ${GREEN}All tests passed!${NC}"
else
    echo -e "  ${RED}Some tests failed. Check the output above for details.${NC}"
fi
echo ""
