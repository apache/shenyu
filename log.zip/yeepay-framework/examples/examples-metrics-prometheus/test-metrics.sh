#!/bin/bash
# ==============================================================================
#  Yeepay Metrics Prometheus 示例 - 全接口自动化测试脚本
#
#  端口说明:
#    业务端口: 8091（/metrics/* 等业务 API）
#    管理端口: 8989（/actuator/health、/actuator/prometheus）
#
#  使用方法:
#    1. 先启动应用: cd examples/examples-metrics-prometheus && mvn spring-boot:run
#    2. 执行脚本: bash test-metrics.sh
#
#  测试内容:
#    - 编程式 API: Counter / Gauge / Timer / Histogram 全部方法
#    - 注解式 AOP: @Count / @Time / @Gauge（含自动命名、异常场景）
#    - 组合注解: @Count + @Time + @Gauge
#    - 业务场景: 模拟订单处理
#    - Actuator: Prometheus 端点 + Health 端点
# ==============================================================================

BASE_URL="${1:-http://localhost:8091}"           # 业务 API 端口
MGMT_URL="${2:-http://localhost:8989}"           # Actuator 管理端口
PASS=0
FAIL=0
TOTAL=0

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ------------------------------------------------------------------------------
#  测试函数
# ------------------------------------------------------------------------------
test_endpoint() {
    local description="$1"
    local url="$2"
    local expect_success="${3:-true}"   # true=期望 2xx, false=期望非 2xx

    TOTAL=$((TOTAL + 1))
    local http_code
    local body
    body=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
    http_code=$body
    body=$(curl -s "$url" 2>/dev/null)

    if [ "$expect_success" = "true" ]; then
        if [[ "$http_code" =~ ^2 ]]; then
            PASS=$((PASS + 1))
            printf "  ${GREEN}✓ PASS${NC}  %-55s [%s] %s\n" "$description" "$http_code" "$body"
        else
            FAIL=$((FAIL + 1))
            printf "  ${RED}✗ FAIL${NC}  %-55s [%s] %s\n" "$description" "$http_code" "$body"
        fi
    else
        if [[ "$http_code" =~ ^[45] ]]; then
            PASS=$((PASS + 1))
            printf "  ${GREEN}✓ PASS${NC}  %-55s [%s] (expected error)\n" "$description" "$http_code"
        else
            FAIL=$((FAIL + 1))
            printf "  ${RED}✗ FAIL${NC}  %-55s [%s] expected error but got success\n" "$description" "$http_code"
        fi
    fi
}

# ------------------------------------------------------------------------------
#  前置检查：确认应用已启动（健康检查走管理端口 8989）
# ------------------------------------------------------------------------------
echo ""
echo -e "${CYAN}================================================================${NC}"
echo -e "${CYAN}  Yeepay Metrics Prometheus - 全接口自动化测试${NC}"
echo -e "${CYAN}================================================================${NC}"
echo ""
echo -e "  业务 API 端口: ${YELLOW}$BASE_URL${NC}"
echo -e "  Actuator 端口: ${YELLOW}$MGMT_URL${NC}"
echo ""
echo -e "${YELLOW}检查应用是否已启动...${NC}"

health_code=$(curl -s -o /dev/null -w "%{http_code}" "$MGMT_URL/actuator/health" 2>/dev/null)
if [ "$health_code" != "200" ]; then
    echo -e "${RED}错误: 应用未启动或无法连接${NC}"
    echo "  业务端口: $BASE_URL"
    echo "  管理端口: $MGMT_URL"
    echo "请先启动应用: cd examples/examples-metrics-prometheus && mvn spring-boot:run"
    exit 1
fi
echo -e "${GREEN}应用已启动，开始测试...${NC}"
echo ""

# ==============================================================================
#  一、Counter（计数器） → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 一、Counter（计数器） ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "incrementCounter: +1" \
    "$BASE_URL/metrics/counter/increment?name=test.counter.incr"

test_endpoint \
    "decrementCounter: -1" \
    "$BASE_URL/metrics/counter/decrement?name=test.counter.decr"

test_endpoint \
    "count(delta=5)" \
    "$BASE_URL/metrics/counter/delta/5?name=test.counter.delta"

test_endpoint \
    "count(delta=-3)" \
    "$BASE_URL/metrics/counter/delta/-3?name=test.counter.delta.neg"

test_endpoint \
    "count(delta=3.14, double)" \
    "$BASE_URL/metrics/counter/delta-double/3.14?name=test.counter.double"

test_endpoint \
    "count(delta=10, sampleRate=0.5)" \
    "$BASE_URL/metrics/counter/sampled/10?name=test.counter.sampled&sampleRate=0.5"

test_endpoint \
    "increment() 便捷方法" \
    "$BASE_URL/metrics/counter/incr?name=test.counter.incr.shorthand"

test_endpoint \
    "decrement() 便捷方法" \
    "$BASE_URL/metrics/counter/decr?name=test.counter.decr.shorthand"

echo ""

# ==============================================================================
#  二、Gauge（瞬时值） → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 二、Gauge（瞬时值） ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "recordGauge(42.5, double)" \
    "$BASE_URL/metrics/gauge/42.5?name=test.gauge.double"

test_endpoint \
    "recordGauge(0, 边界值)" \
    "$BASE_URL/metrics/gauge/0?name=test.gauge.zero"

test_endpoint \
    "recordGauge(-10.5, 负数)" \
    "$BASE_URL/metrics/gauge/-10.5?name=test.gauge.negative"

test_endpoint \
    "recordGaugeLong(1024, long)" \
    "$BASE_URL/metrics/gauge/long/1024?name=test.gauge.long"

test_endpoint \
    "recordGauge(99.9, sampleRate=0.8)" \
    "$BASE_URL/metrics/gauge/sampled/99.9?name=test.gauge.sampled&sampleRate=0.8"

test_endpoint \
    "gauge() 便捷方法" \
    "$BASE_URL/metrics/gauge/quick/128?name=test.gauge.quick"

echo ""

# ==============================================================================
#  三、Timer（耗时） → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 三、Timer（耗时） ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "recordExecutionTime(模拟耗时)" \
    "$BASE_URL/metrics/timer?name=test.timer.duration"

test_endpoint \
    "recordExecutionTime(sampleRate=0.5)" \
    "$BASE_URL/metrics/timer/sampled?name=test.timer.sampled&sampleRate=0.5"

test_endpoint \
    "time() 便捷方法" \
    "$BASE_URL/metrics/timer/quick?name=test.timer.quick"

echo ""

# ==============================================================================
#  四、Histogram（直方图） → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 四、Histogram（直方图） ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "recordHistogram(256.5, double)" \
    "$BASE_URL/metrics/histogram/256.5?name=test.histogram.double"

test_endpoint \
    "recordHistogramLong(512, long)" \
    "$BASE_URL/metrics/histogram/long/512?name=test.histogram.long"

test_endpoint \
    "recordHistogram(1024, sampleRate=0.5)" \
    "$BASE_URL/metrics/histogram/sampled/1024?name=test.histogram.sampled&sampleRate=0.5"

test_endpoint \
    "histogram() 便捷方法" \
    "$BASE_URL/metrics/histogram/quick/64?name=test.histogram.quick"

echo ""

# ==============================================================================
#  五、注解 @Count → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 五、注解 @Count ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "@Count(指定名称)" \
    "$BASE_URL/metrics/annotation/count"

test_endpoint \
    "@Count(自动命名)" \
    "$BASE_URL/metrics/annotation/count/auto"

test_endpoint \
    "@Count(正常执行, fail=false)" \
    "$BASE_URL/metrics/annotation/count/error?fail=false"

test_endpoint \
    "@Count(异常执行, fail=true → successful:false)" \
    "$BASE_URL/metrics/annotation/count/error?fail=true" \
    "false"

echo ""

# ==============================================================================
#  六、注解 @Time → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 六、注解 @Time ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "@Time(指定名称)" \
    "$BASE_URL/metrics/annotation/time"

test_endpoint \
    "@Time(自动命名)" \
    "$BASE_URL/metrics/annotation/time/auto"

test_endpoint \
    "@Time(longTask=true, 长时间任务)" \
    "$BASE_URL/metrics/annotation/time/long"

test_endpoint \
    "@Time(正常执行, fail=false)" \
    "$BASE_URL/metrics/annotation/time/error?fail=false"

test_endpoint \
    "@Time(异常执行, fail=true → successful:false)" \
    "$BASE_URL/metrics/annotation/time/error?fail=true" \
    "false"

echo ""

# ==============================================================================
#  七、注解 @Gauge → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 七、注解 @Gauge ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "@Gauge(指定名称)" \
    "$BASE_URL/metrics/annotation/gauge"

test_endpoint \
    "@Gauge(自动命名)" \
    "$BASE_URL/metrics/annotation/gauge/auto"

test_endpoint \
    "@Gauge(正常执行, fail=false)" \
    "$BASE_URL/metrics/annotation/gauge/error?fail=false"

test_endpoint \
    "@Gauge(异常执行, fail=true → successful:false)" \
    "$BASE_URL/metrics/annotation/gauge/error?fail=true" \
    "false"

echo ""

# ==============================================================================
#  八、组合注解 → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 八、组合注解 @Count + @Time + @Gauge ━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "组合注解: @Count + @Time + @Gauge" \
    "$BASE_URL/metrics/annotation/combo"

echo ""

# ==============================================================================
#  九、业务场景 → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 九、业务场景（模拟订单处理） ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

test_endpoint \
    "订单处理(amount=99.9)" \
    "$BASE_URL/metrics/business/order?amount=99.9"

test_endpoint \
    "订单处理(amount=1999.0)" \
    "$BASE_URL/metrics/business/order?amount=1999.0"

test_endpoint \
    "订单处理(amount=0.01, 小额)" \
    "$BASE_URL/metrics/business/order?amount=0.01"

echo ""

# ==============================================================================
#  十、Actuator 端点 → 管理端口 8989
# ==============================================================================
echo -e "${CYAN}━━━ 十、Actuator 端点（端口 $MGMT_URL） ━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

# Health 健康检查
test_endpoint \
    "Health 健康检查" \
    "$MGMT_URL/actuator/health"

# Prometheus 端点检查（只检查状态码，不打印全部内容）
TOTAL=$((TOTAL + 1))
prom_code=$(curl -s -o /dev/null -w "%{http_code}" "$MGMT_URL/actuator/prometheus" 2>/dev/null)
prom_lines=$(curl -s "$MGMT_URL/actuator/prometheus" 2>/dev/null | wc -l | tr -d ' ')
if [ "$prom_code" = "200" ]; then
    PASS=$((PASS + 1))
    printf "  ${GREEN}✓ PASS${NC}  %-55s [%s] %s lines of metrics\n" "Prometheus 指标端点" "$prom_code" "$prom_lines"
else
    FAIL=$((FAIL + 1))
    printf "  ${RED}✗ FAIL${NC}  %-55s [%s]\n" "Prometheus 指标端点" "$prom_code"
fi

# 检查 Prometheus 输出中是否包含自定义指标
TOTAL=$((TOTAL + 1))
prom_body=$(curl -s "$MGMT_URL/actuator/prometheus" 2>/dev/null)
custom_count=$(echo "$prom_body" | grep -c "example_" || true)
if [ "$custom_count" -gt 0 ]; then
    PASS=$((PASS + 1))
    printf "  ${GREEN}✓ PASS${NC}  %-55s 找到 %s 行自定义指标 (example_*)\n" "Prometheus 包含自定义指标" "$custom_count"
else
    FAIL=$((FAIL + 1))
    printf "  ${RED}✗ FAIL${NC}  %-55s 未找到自定义指标 (example_*)\n" "Prometheus 包含自定义指标"
fi

# Help 说明页面 → 业务端口
test_endpoint \
    "Help 说明页面" \
    "$BASE_URL/metrics/help"

echo ""

# ==============================================================================
#  批量压力测试 → 业务端口
# ==============================================================================
echo -e "${CYAN}━━━ 批量请求测试（模拟多次调用产生指标数据） ━━━━━━━━━━━━━━━━━━━━${NC}"

echo -n "  发送 20 次 counter 请求..."
for i in $(seq 1 20); do
    curl -s "$BASE_URL/metrics/counter/increment?name=stress.counter" > /dev/null 2>&1
done
echo -e " ${GREEN}完成${NC}"

echo -n "  发送 10 次 gauge 请求（模拟波动值）..."
for i in $(seq 1 10); do
    value=$((RANDOM % 100))
    curl -s "$BASE_URL/metrics/gauge/$value?name=stress.gauge" > /dev/null 2>&1
done
echo -e " ${GREEN}完成${NC}"

echo -n "  发送 10 次 timer 请求..."
for i in $(seq 1 10); do
    curl -s "$BASE_URL/metrics/timer?name=stress.timer" > /dev/null 2>&1
done
echo -e " ${GREEN}完成${NC}"

echo -n "  发送 10 次 histogram 请求（不同值分布）..."
for val in 10 50 100 200 500 1000 2000 5000 10000 50000; do
    curl -s "$BASE_URL/metrics/histogram/$val?name=stress.histogram" > /dev/null 2>&1
done
echo -e " ${GREEN}完成${NC}"

echo ""

# ==============================================================================
#  结果汇总
# ==============================================================================
echo -e "${CYAN}================================================================${NC}"
if [ "$FAIL" -eq 0 ]; then
    echo -e "  ${GREEN}全部通过!${NC}  总计: $TOTAL  通过: $PASS  失败: $FAIL"
else
    echo -e "  ${RED}存在失败!${NC}  总计: $TOTAL  通过: $PASS  失败: $FAIL"
fi
echo -e "${CYAN}================================================================${NC}"
echo ""
echo -e "  业务端口: ${YELLOW}$BASE_URL${NC}  (业务 API)"
echo -e "  管理端口: ${YELLOW}$MGMT_URL${NC}  (Actuator)"
echo ""
echo -e "提示: 运行完测试后，可访问 ${YELLOW}$MGMT_URL/actuator/prometheus${NC} 查看所有上报的指标"
echo ""

exit $FAIL
