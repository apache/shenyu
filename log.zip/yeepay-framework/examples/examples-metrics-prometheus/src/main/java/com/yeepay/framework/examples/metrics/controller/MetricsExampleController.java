package com.yeepay.framework.examples.metrics.controller;

import com.yeepay.framework.examples.metrics.service.MetricsService;
import com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion.Count;
import com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion.Gauge;
import com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion.Time;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Metrics 示例 Controller，演示 yeepay-framework 指标模块的所有用法.
 *
 * <p>包含两大类使用方式：
 * <ul>
 *   <li>编程式 API：通过注入 {@link MetricsService}（封装 StatsDClient）手动上报指标</li>
 *   <li>注解式 AOP：通过 {@code @Count}、{@code @Time}、{@code @Gauge} 注解声明式采集</li>
 * </ul>
 */
@RestController
@RequestMapping("/metrics")
@RequiredArgsConstructor
public class MetricsExampleController {

    private final MetricsService metricsService;

    // ==================================================================================
    //  一、编程式 API —— Counter（计数器）
    // ==================================================================================

    /**
     * 递增计数器 +1.
     * 示例: GET /metrics/counter/increment?name=order.created
     */
    @GetMapping("/counter/increment")
    public String incrementCounter(@RequestParam(defaultValue = "example.requests") String name) {
        metricsService.incrementCounter(name, "source:api", "action:increment");
        return "Counter '" + name + "' incremented by 1";
    }

    /**
     * 递减计数器 -1.
     * 示例: GET /metrics/counter/decrement?name=example.queue.pending
     */
    @GetMapping("/counter/decrement")
    public String decrementCounter(@RequestParam(defaultValue = "example.queue.pending") String name) {
        metricsService.decrementCounter(name, "source:api", "action:decrement");
        return "Counter '" + name + "' decremented by 1";
    }

    /**
     * 按指定 delta 增减计数器.
     * 示例: GET /metrics/counter/delta/5?name=example.batch.processed
     */
    @GetMapping("/counter/delta/{delta}")
    public String countByDelta(
            @RequestParam(defaultValue = "example.batch.processed") String name, @PathVariable long delta) {
        metricsService.count(name, delta, "source:api", "action:delta");
        return "Counter '" + name + "' adjusted by " + delta;
    }

    /**
     * 按 double 值增减计数器.
     * 示例: GET /metrics/counter/delta-double/3.14?name=example.score
     */
    @GetMapping("/counter/delta-double/{delta}")
    public String countByDoubleDelta(
            @RequestParam(defaultValue = "example.score") String name, @PathVariable double delta) {
        metricsService.countDouble(name, delta, "source:api", "action:delta_double");
        return "Counter '" + name + "' adjusted by " + delta + " (double)";
    }

    /**
     * 带采样率的计数.
     * 示例: GET /metrics/counter/sampled/10?name=example.sampled&sampleRate=0.5
     */
    @GetMapping("/counter/sampled/{delta}")
    public String countWithSampleRate(
            @RequestParam(defaultValue = "example.sampled") String name,
            @PathVariable long delta,
            @RequestParam(defaultValue = "0.5") double sampleRate) {
        metricsService.countWithSampleRate(name, delta, sampleRate, "source:api", "action:sampled");
        return "Counter '" + name + "' adjusted by " + delta + " (sampleRate=" + sampleRate + ")";
    }

    /**
     * 使用 increment() 便捷方法.
     * 示例: GET /metrics/counter/incr?name=example.page.views
     */
    @GetMapping("/counter/incr")
    public String incrementShorthand(@RequestParam(defaultValue = "example.page.views") String name) {
        metricsService.increment(name, "source:api", "method:increment");
        return "Counter '" + name + "' incremented via increment()";
    }

    /**
     * 使用 decrement() 便捷方法.
     * 示例: GET /metrics/counter/decr?name=example.active.sessions
     */
    @GetMapping("/counter/decr")
    public String decrementShorthand(@RequestParam(defaultValue = "example.active.sessions") String name) {
        metricsService.decrement(name, "source:api", "method:decrement");
        return "Counter '" + name + "' decremented via decrement()";
    }

    // ==================================================================================
    //  二、编程式 API —— Gauge（仪表盘 / 瞬时值）
    // ==================================================================================

    /**
     * 记录 Gauge 值（double）.
     * 示例: GET /metrics/gauge/42.5?name=example.cpu.usage
     */
    @GetMapping("/gauge/{value}")
    public String recordGauge(
            @RequestParam(defaultValue = "example.cpu.usage") String name, @PathVariable double value) {
        metricsService.recordGauge(name, value, "source:api", "type:double");
        return "Gauge '" + name + "' set to " + value;
    }

    /**
     * 记录 Gauge 值（long）.
     * 示例: GET /metrics/gauge/long/1024?name=example.memory.used
     */
    @GetMapping("/gauge/long/{value}")
    public String recordGaugeLong(
            @RequestParam(defaultValue = "example.memory.used") String name, @PathVariable long value) {
        metricsService.recordGaugeLong(name, value, "source:api", "type:long");
        return "Gauge '" + name + "' set to " + value + " (long)";
    }

    /**
     * 带采样率的 Gauge.
     * 示例: GET /metrics/gauge/sampled/99.9?name=example.disk.usage&sampleRate=0.8
     */
    @GetMapping("/gauge/sampled/{value}")
    public String recordGaugeWithSampleRate(
            @RequestParam(defaultValue = "example.disk.usage") String name,
            @PathVariable double value,
            @RequestParam(defaultValue = "0.8") double sampleRate) {
        metricsService.recordGaugeWithSampleRate(name, value, sampleRate, "source:api", "type:sampled");
        return "Gauge '" + name + "' set to " + value + " (sampleRate=" + sampleRate + ")";
    }

    /**
     * 使用 gauge() 便捷方法.
     * 示例: GET /metrics/gauge/quick/128?name=example.queue.size
     */
    @GetMapping("/gauge/quick/{value}")
    public String gaugeShorthand(
            @RequestParam(defaultValue = "example.queue.size") String name, @PathVariable double value) {
        metricsService.gauge(name, value, "source:api", "method:gauge");
        return "Gauge '" + name + "' set to " + value + " via gauge()";
    }

    // ==================================================================================
    //  三、编程式 API —— Timer（计时器 / 执行时间）
    // ==================================================================================

    /**
     * 记录执行时间（模拟耗时操作）.
     * 示例: GET /metrics/timer?name=example.request.duration
     */
    @GetMapping("/timer")
    public String recordTimer(@RequestParam(defaultValue = "example.request.duration") String name) {
        long start = System.currentTimeMillis();
        simulateWork(50, 150);
        long elapsed = System.currentTimeMillis() - start;
        metricsService.recordExecutionTime(name, elapsed, "source:api", "endpoint:timer");
        return "Timer '" + name + "' recorded " + elapsed + "ms";
    }

    /**
     * 带采样率的执行时间.
     * 示例: GET /metrics/timer/sampled?name=example.db.query&sampleRate=0.5
     */
    @GetMapping("/timer/sampled")
    public String recordTimerWithSampleRate(
            @RequestParam(defaultValue = "example.db.query") String name,
            @RequestParam(defaultValue = "0.5") double sampleRate) {
        long start = System.currentTimeMillis();
        simulateWork(30, 100);
        long elapsed = System.currentTimeMillis() - start;
        metricsService.recordExecutionTimeWithSampleRate(
                name, elapsed, sampleRate, "source:api", "endpoint:timer_sampled");
        return "Timer '" + name + "' recorded " + elapsed + "ms (sampleRate=" + sampleRate + ")";
    }

    /**
     * 使用 time() 便捷方法.
     * 示例: GET /metrics/timer/quick?name=example.cache.lookup
     */
    @GetMapping("/timer/quick")
    public String timeShorthand(@RequestParam(defaultValue = "example.cache.lookup") String name) {
        long start = System.currentTimeMillis();
        simulateWork(10, 50);
        long elapsed = System.currentTimeMillis() - start;
        metricsService.time(name, elapsed, "source:api", "method:time");
        return "Timer '" + name + "' recorded " + elapsed + "ms via time()";
    }

    // ==================================================================================
    //  四、编程式 API —— Histogram（直方图 / 分布统计）
    // ==================================================================================

    /**
     * 记录直方图值（double）.
     * 示例: GET /metrics/histogram/256.5?name=example.response.size
     */
    @GetMapping("/histogram/{value}")
    public String recordHistogram(
            @RequestParam(defaultValue = "example.response.size") String name, @PathVariable double value) {
        metricsService.recordHistogram(name, value, "source:api", "type:double");
        return "Histogram '" + name + "' recorded value " + value;
    }

    /**
     * 记录直方图值（long）.
     * 示例: GET /metrics/histogram/long/512?name=example.payload.bytes
     */
    @GetMapping("/histogram/long/{value}")
    public String recordHistogramLong(
            @RequestParam(defaultValue = "example.payload.bytes") String name, @PathVariable long value) {
        metricsService.recordHistogramLong(name, value, "source:api", "type:long");
        return "Histogram '" + name + "' recorded value " + value + " (long)";
    }

    /**
     * 带采样率的直方图.
     * 示例: GET /metrics/histogram/sampled/1024?name=example.file.size&sampleRate=0.5
     */
    @GetMapping("/histogram/sampled/{value}")
    public String recordHistogramWithSampleRate(
            @RequestParam(defaultValue = "example.file.size") String name,
            @PathVariable double value,
            @RequestParam(defaultValue = "0.5") double sampleRate) {
        metricsService.recordHistogramWithSampleRate(name, value, sampleRate, "source:api", "type:sampled");
        return "Histogram '" + name + "' recorded value " + value + " (sampleRate=" + sampleRate + ")";
    }

    /**
     * 使用 histogram() 便捷方法.
     * 示例: GET /metrics/histogram/quick/64?name=example.batch.size
     */
    @GetMapping("/histogram/quick/{value}")
    public String histogramShorthand(
            @RequestParam(defaultValue = "example.batch.size") String name, @PathVariable double value) {
        metricsService.histogram(name, value, "source:api", "method:histogram");
        return "Histogram '" + name + "' recorded value " + value + " via histogram()";
    }

    // ==================================================================================
    //  五、注解式 AOP —— @Count（调用次数统计）
    // ==================================================================================

    /**
     * 使用 @Count 注解统计方法调用次数（指定指标名称）.
     * 切面会在方法执行后自动调用 statsd.increment()，并附带 successful:true/false 标签.
     */
    @Count("example.annotation.count.named")
    @GetMapping("/annotation/count")
    public String annotationCount() {
        return "Method invocation counted via @Count('example.annotation.count.named')";
    }

    /**
     * 使用 @Count 注解（不指定名称，自动生成：ClassName.methodName）.
     */
    @Count
    @GetMapping("/annotation/count/auto")
    public String annotationCountAuto() {
        return "Method invocation counted via @Count (auto-named)";
    }

    /**
     * 使用 @Count 注解 —— 模拟异常场景，验证 successful:false 标签.
     */
    @Count("example.annotation.count.error")
    @GetMapping("/annotation/count/error")
    public String annotationCountError(@RequestParam(defaultValue = "false") boolean fail) {
        if (fail) {
            throw new RuntimeException("Simulated error for @Count annotation test");
        }
        return "Method invocation counted via @Count (error test, fail=" + fail + ")";
    }

    // ==================================================================================
    //  六、注解式 AOP —— @Time（执行时间统计）
    // ==================================================================================

    /**
     * 使用 @Time 注解记录方法执行时间（指定指标名称）.
     * 切面会在方法执行前后记录纳秒级耗时，并通过 statsd.histogram() 上报.
     */
    @Time("example.annotation.time.named")
    @GetMapping("/annotation/time")
    public String annotationTime() throws InterruptedException {
        Thread.sleep(50 + (long) (Math.random() * 100));
        return "Method execution time recorded via @Time('example.annotation.time.named')";
    }

    /**
     * 使用 @Time 注解（不指定名称，自动生成）.
     */
    @Time
    @GetMapping("/annotation/time/auto")
    public String annotationTimeAuto() throws InterruptedException {
        Thread.sleep(30 + (long) (Math.random() * 70));
        return "Method execution time recorded via @Time (auto-named)";
    }

    /**
     * 使用 @Time 注解 + longTask=true（标记为长时间任务）.
     */
    @Time(value = "example.annotation.time.long_task", longTask = true)
    @GetMapping("/annotation/time/long")
    public String annotationTimeLongTask() throws InterruptedException {
        Thread.sleep(200 + (long) (Math.random() * 300));
        return "Long task execution time recorded via @Time(longTask=true)";
    }

    /**
     * 使用 @Time 注解 —— 模拟异常场景，验证 successful:false 标签.
     */
    @Time("example.annotation.time.error")
    @GetMapping("/annotation/time/error")
    public String annotationTimeError(@RequestParam(defaultValue = "false") boolean fail) throws InterruptedException {
        Thread.sleep(20);
        if (fail) {
            throw new RuntimeException("Simulated error for @Time annotation test");
        }
        return "Method execution time recorded via @Time (error test, fail=" + fail + ")";
    }

    // ==================================================================================
    //  七、注解式 AOP —— @Gauge（并发执行数跟踪）
    // ==================================================================================

    /**
     * 使用 @Gauge 注解跟踪方法并发执行数（指定指标名称）.
     * 切面会在方法执行后通过 statsd.gauge() 上报并发状态.
     */
    @Gauge("example.annotation.gauge.named")
    @GetMapping("/annotation/gauge")
    public String annotationGauge() throws InterruptedException {
        Thread.sleep(100 + (long) (Math.random() * 100));
        return "Concurrent execution tracked via @Gauge('example.annotation.gauge.named')";
    }

    /**
     * 使用 @Gauge 注解（不指定名称，自动生成）.
     */
    @Gauge
    @GetMapping("/annotation/gauge/auto")
    public String annotationGaugeAuto() throws InterruptedException {
        Thread.sleep(80);
        return "Concurrent execution tracked via @Gauge (auto-named)";
    }

    /**
     * 使用 @Gauge 注解 —— 模拟异常场景，验证 successful:false 标签.
     */
    @Gauge("example.annotation.gauge.error")
    @GetMapping("/annotation/gauge/error")
    public String annotationGaugeError(@RequestParam(defaultValue = "false") boolean fail) throws InterruptedException {
        Thread.sleep(50);
        if (fail) {
            throw new RuntimeException("Simulated error for @Gauge annotation test");
        }
        return "Concurrent execution tracked via @Gauge (error test, fail=" + fail + ")";
    }

    // ==================================================================================
    //  八、组合注解 —— 同时使用多个指标注解
    // ==================================================================================

    /**
     * 同时使用 @Count + @Time + @Gauge 三个注解.
     * 一次请求同时采集：调用次数、执行耗时、并发数.
     */
    @Count("example.annotation.combo.count")
    @Time("example.annotation.combo.time")
    @Gauge("example.annotation.combo.gauge")
    @GetMapping("/annotation/combo")
    public String annotationCombo() throws InterruptedException {
        Thread.sleep(50 + (long) (Math.random() * 100));
        return "Combined metrics: @Count + @Time + @Gauge all recorded in one call";
    }

    // ==================================================================================
    //  九、综合场景 —— 模拟业务场景
    // ==================================================================================

    /**
     * 模拟订单处理：综合使用多种指标.
     * - Counter: 订单计数
     * - Timer: 处理耗时
     * - Gauge: 队列深度
     * - Histogram: 订单金额分布
     */
    @Count("business.order.count")
    @Time("business.order.duration")
    @GetMapping("/business/order")
    public String simulateOrderProcessing(@RequestParam(defaultValue = "100.0") double amount)
            throws InterruptedException {
        // 记录订单金额分布
        metricsService.recordHistogram("business.order.amount", amount, "source:order", "currency:CNY");

        // 模拟队列深度
        long queueDepth = (long) (Math.random() * 50);
        metricsService.recordGaugeLong("business.order.queue.depth", queueDepth, "source:order");

        // 模拟处理耗时
        Thread.sleep(100 + (long) (Math.random() * 200));

        return "Order processed: amount=" + amount + ", queueDepth=" + queueDepth;
    }

    /**
     * 查看 Prometheus 指标端点提示.
     */
    @GetMapping("/help")
    public String help() {
        return """
                Yeepay Metrics Prometheus Example
                ==================================
                查看所有 Prometheus 指标: GET /actuator/prometheus
                健康检查: GET /actuator/health

                === 编程式 API ===
                Counter:
                  GET /metrics/counter/increment?name=xxx     递增 +1
                  GET /metrics/counter/decrement?name=xxx     递减 -1
                  GET /metrics/counter/delta/{n}?name=xxx     增减指定值
                  GET /metrics/counter/delta-double/{n}       double 增减
                  GET /metrics/counter/sampled/{n}            带采样率
                  GET /metrics/counter/incr?name=xxx          increment() 便捷方法
                  GET /metrics/counter/decr?name=xxx          decrement() 便捷方法

                Gauge:
                  GET /metrics/gauge/{value}?name=xxx         设置 double 值
                  GET /metrics/gauge/long/{value}?name=xxx    设置 long 值
                  GET /metrics/gauge/sampled/{value}          带采样率
                  GET /metrics/gauge/quick/{value}            gauge() 便捷方法

                Timer:
                  GET /metrics/timer?name=xxx                 记录执行时间
                  GET /metrics/timer/sampled                  带采样率
                  GET /metrics/timer/quick                    time() 便捷方法

                Histogram:
                  GET /metrics/histogram/{value}?name=xxx     记录 double 值
                  GET /metrics/histogram/long/{value}         记录 long 值
                  GET /metrics/histogram/sampled/{value}      带采样率
                  GET /metrics/histogram/quick/{value}        histogram() 便捷方法

                === 注解式 AOP ===
                @Count:
                  GET /metrics/annotation/count               指定名称
                  GET /metrics/annotation/count/auto          自动命名
                  GET /metrics/annotation/count/error?fail=true  异常场景

                @Time:
                  GET /metrics/annotation/time                指定名称
                  GET /metrics/annotation/time/auto           自动命名
                  GET /metrics/annotation/time/long           longTask=true
                  GET /metrics/annotation/time/error?fail=true   异常场景

                @Gauge:
                  GET /metrics/annotation/gauge               指定名称
                  GET /metrics/annotation/gauge/auto          自动命名
                  GET /metrics/annotation/gauge/error?fail=true  异常场景

                === 组合注解 ===
                  GET /metrics/annotation/combo               @Count + @Time + @Gauge

                === 业务场景 ===
                  GET /metrics/business/order?amount=100      模拟订单处理
                """;
    }

    // ==================================================================================
    //  内部工具方法
    // ==================================================================================

    private void simulateWork(long minMs, long maxMs) {
        try {
            Thread.sleep(minMs + (long) (Math.random() * (maxMs - minMs)));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
