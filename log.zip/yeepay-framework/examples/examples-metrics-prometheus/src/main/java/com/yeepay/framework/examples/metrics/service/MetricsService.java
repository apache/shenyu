package com.yeepay.framework.examples.metrics.service;

import com.yeepay.framework.metrics.api.StatsDClient;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 指标服务，封装 StatsDClient 的所有 API 用法.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MetricsService {

    private final StatsDClient statsDClient;

    // ==================== Counter（计数器）====================

    public void incrementCounter(String name, String... tags) {
        log.info("[Counter] incrementCounter name={}, tags={}", name, Arrays.toString(tags));
        statsDClient.incrementCounter(name, tags);
    }

    public void decrementCounter(String name, String... tags) {
        log.info("[Counter] decrementCounter name={}, tags={}", name, Arrays.toString(tags));
        statsDClient.decrementCounter(name, tags);
    }

    public void count(String name, long delta, String... tags) {
        log.info("[Counter] count name={}, delta={}, tags={}", name, delta, Arrays.toString(tags));
        statsDClient.count(name, delta, tags);
    }

    public void countDouble(String name, double delta, String... tags) {
        log.info("[Counter] countDouble name={}, delta={}, tags={}", name, delta, Arrays.toString(tags));
        statsDClient.count(name, delta, tags);
    }

    public void countWithSampleRate(String name, long delta, double sampleRate, String... tags) {
        log.info(
                "[Counter] countWithSampleRate name={}, delta={}, sampleRate={}, tags={}",
                name,
                delta,
                sampleRate,
                Arrays.toString(tags));
        statsDClient.count(name, delta, sampleRate, tags);
    }

    // ==================== Gauge（仪表盘）====================

    public void recordGauge(String name, double value, String... tags) {
        log.info("[Gauge] recordGauge name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.recordGaugeValue(name, value, tags);
    }

    public void recordGaugeLong(String name, long value, String... tags) {
        log.info("[Gauge] recordGaugeLong name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.recordGaugeValue(name, value, tags);
    }

    public void recordGaugeWithSampleRate(String name, double value, double sampleRate, String... tags) {
        log.info(
                "[Gauge] recordGaugeWithSampleRate name={}, value={}, sampleRate={}, tags={}",
                name,
                value,
                sampleRate,
                Arrays.toString(tags));
        statsDClient.recordGaugeValue(name, value, sampleRate, tags);
    }

    // ==================== Timer（计时器）====================

    public void recordExecutionTime(String name, long timeInMs, String... tags) {
        log.info("[Timer] recordExecutionTime name={}, timeInMs={}, tags={}", name, timeInMs, Arrays.toString(tags));
        statsDClient.recordExecutionTime(name, timeInMs, tags);
    }

    public void recordExecutionTimeWithSampleRate(String name, long timeInMs, double sampleRate, String... tags) {
        log.info(
                "[Timer] recordExecutionTimeWithSampleRate name={}, timeInMs={}, sampleRate={}, tags={}",
                name,
                timeInMs,
                sampleRate,
                Arrays.toString(tags));
        statsDClient.recordExecutionTime(name, timeInMs, sampleRate, tags);
    }

    public void time(String name, long value, String... tags) {
        log.info("[Timer] time name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.time(name, value, tags);
    }

    // ==================== Histogram（直方图）====================

    public void recordHistogram(String name, double value, String... tags) {
        log.info("[Histogram] recordHistogram name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.recordHistogramValue(name, value, tags);
    }

    public void recordHistogramLong(String name, long value, String... tags) {
        log.info("[Histogram] recordHistogramLong name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.recordHistogramValue(name, value, tags);
    }

    public void recordHistogramWithSampleRate(String name, double value, double sampleRate, String... tags) {
        log.info(
                "[Histogram] recordHistogramWithSampleRate name={}, value={}, sampleRate={}, tags={}",
                name,
                value,
                sampleRate,
                Arrays.toString(tags));
        statsDClient.recordHistogramValue(name, value, sampleRate, tags);
    }

    // ==================== 便捷方法 ====================

    public void increment(String name, String... tags) {
        log.info("[Shorthand] increment name={}, tags={}", name, Arrays.toString(tags));
        statsDClient.increment(name, tags);
    }

    public void decrement(String name, String... tags) {
        log.info("[Shorthand] decrement name={}, tags={}", name, Arrays.toString(tags));
        statsDClient.decrement(name, tags);
    }

    public void gauge(String name, double value, String... tags) {
        log.info("[Shorthand] gauge name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.gauge(name, value, tags);
    }

    public void histogram(String name, double value, String... tags) {
        log.info("[Shorthand] histogram name={}, value={}, tags={}", name, value, Arrays.toString(tags));
        statsDClient.histogram(name, value, tags);
    }
}
