package com.yeepay.framework.examples.metrics.tag;

import com.yeepay.framework.metrics.api.CommonTagCustom;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * 自定义公共标签示例.
 *
 * <p>实现 {@link CommonTagCustom} 接口，在应用启动时向所有指标注入自定义标签.
 * 这些标签会作为全局标签附加到每一个上报的指标中，可用于区分应用版本、部署区域等.
 *
 * <p>使用方式：只需实现接口并注册为 Spring Bean，框架会自动发现并应用.
 */
@Component
public class AppVersionTagCustom implements CommonTagCustom {

    @Override
    public void custom(Map<String, String> tags) {
        // 应用版本号，用于区分不同版本的指标
        tags.put("version", "1.0.0");
        // 部署区域
        tags.put("region", "cn-north-1");
        // 实例标识（示例）
        tags.put("instance", "demo-01");
    }
}
