package com.yeepay.framework.examples.globalid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Global ID 示例应用.
 */
@SpringBootApplication
public class GlobalIdExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(GlobalIdExampleApplication.class, args);
    }
}
