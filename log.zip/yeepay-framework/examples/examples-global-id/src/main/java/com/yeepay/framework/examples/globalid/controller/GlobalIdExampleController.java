package com.yeepay.framework.examples.globalid.controller;

import com.yeepay.framework.global.id.api.UidGenerator;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Global ID 示例 Controller.
 */
@RestController
@RequestMapping("/global-id")
@RequiredArgsConstructor
public class GlobalIdExampleController {

    private UidGenerator uidGenerator;

    @Autowired
    public GlobalIdExampleController(final UidGenerator uidGenerator) {
        this.uidGenerator = uidGenerator;
    }

    @GetMapping("/generate")
    public long generate() {
        return uidGenerator.getUID();
    }

    @GetMapping("/batch")
    public List<Long> batch(@RequestParam(defaultValue = "10") int count) {
        List<Long> ids = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            ids.add(uidGenerator.getUID());
        }
        return ids;
    }

    @GetMapping("/parse/{uid}")
    public String parse(@PathVariable long uid) {
        return uidGenerator.parseUID(uid);
    }
}
