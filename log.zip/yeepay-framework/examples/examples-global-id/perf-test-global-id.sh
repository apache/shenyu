#!/bin/bash
# ============================================================================
# Yeepay Global ID Framework - Performance & Uniqueness Test Script
#
# Usage:
#   bash perf-test-global-id.sh [base_url]
#
# Default base_url: http://localhost:9082
#
# Prerequisites:
#   1. Build the project:
#      mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip
#   2. Start the example service:
#      mvn spring-boot:run -pl examples/examples-global-id
#      (or specify profile: -Dspring-boot.run.profiles=database|redis|zookeeper)
#
# Test Dimensions:
#   - Single-request latency (serial)
#   - Batch generation throughput
#   - Concurrent throughput (multi-process)
#   - Uniqueness guarantee under concurrency
#   - Large-scale uniqueness verification
# ============================================================================

set -euo pipefail

BASE_URL="${1:-http://localhost:9082}"
GENERATE_URL="$BASE_URL/global-id/generate"
BATCH_URL="$BASE_URL/global-id/batch"

# Test parameters
SERIAL_COUNT=200          # serial single-request iterations
BATCH_SIZES=(100 500 1000 5000)
CONCURRENT_WORKERS=50     # parallel curl processes
CONCURRENT_REQS_PER_WORKER=100
LARGE_UNIQUE_TOTAL=100000 # total IDs for large-scale uniqueness check

# Temp directory for collecting results
WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

# ---- Portable nanosecond timer ----------------------------------------------
# macOS date doesn't support %N — detect and fall back to python3
if [[ "$(date +%s%N)" == *N ]]; then
    now_ns() { python3 -c 'import time; print(int(time.time()*1e9))'; }
else
    now_ns() { date +%s%N; }
fi

# ---- Colors & helpers -------------------------------------------------------
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

pass() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    PASS_COUNT=$((PASS_COUNT + 1))
    echo -e "  ${GREEN}[PASS]${NC} $1"
}

fail() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    FAIL_COUNT=$((FAIL_COUNT + 1))
    echo -e "  ${RED}[FAIL]${NC} $1"
}

info() {
    echo -e "  ${CYAN}[INFO]${NC} $1"
}

section() {
    echo ""
    echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}  $1${NC}"
    echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "  ${YELLOW}$2${NC}"
}

# Calculate percentile from a sorted file. $1=file $2=percentile (e.g. 50, 95, 99)
percentile() {
    local file="$1"
    local pct="$2"
    local total
    total=$(wc -l < "$file" | tr -d ' ')
    local idx=$(( (total * pct + 99) / 100 ))
    [ "$idx" -lt 1 ] && idx=1
    sed -n "${idx}p" "$file"
}

# ---- Pre-flight check -------------------------------------------------------
echo -e "${BOLD}╔═════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║  Yeepay Global ID - Performance & Uniqueness Test      ║${NC}"
echo -e "${BOLD}╚═════════════════════════════════════════════════════════╝${NC}"
echo -e "  Target: $BASE_URL"
echo -e "  Date:   $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

echo -n "  Checking service availability... "
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$GENERATE_URL" 2>/dev/null || true)
if [ "$HTTP_CODE" != "200" ]; then
    echo -e "${RED}FAILED (HTTP $HTTP_CODE)${NC}"
    echo "  Cannot connect to $BASE_URL. Please start the service first:"
    echo "    mvn spring-boot:run -pl examples/examples-global-id"
    exit 1
fi
echo -e "${GREEN}OK${NC}"

# Warm up
echo -n "  Warming up (50 requests)... "
for _i in $(seq 1 50); do
    curl -s "$GENERATE_URL" > /dev/null &
done
wait
echo -e "${GREEN}done${NC}"

# =============================================================================
# TEST 1: Serial Single-Request Latency
# =============================================================================
section "TEST 1: Serial Single-Request Latency" \
    "$SERIAL_COUNT sequential GET /global-id/generate — measuring per-request latency"

LATENCY_FILE="$WORK_DIR/serial_latencies.txt"
ID_FILE="$WORK_DIR/serial_ids.txt"
: > "$LATENCY_FILE"
: > "$ID_FILE"

START_NS=$(now_ns)
for _i in $(seq 1 "$SERIAL_COUNT"); do
    REQ_START=$(now_ns)
    ID=$(curl -s "$GENERATE_URL")
    REQ_END=$(now_ns)
    ELAPSED_US=$(( (REQ_END - REQ_START) / 1000 ))
    echo "$ELAPSED_US" >> "$LATENCY_FILE"
    echo "$ID" >> "$ID_FILE"
done
END_NS=$(now_ns)

TOTAL_MS=$(( (END_NS - START_NS) / 1000000 ))
TOTAL_SEC_X100=$(( (END_NS - START_NS) / 10000000 ))
if [ "$TOTAL_SEC_X100" -gt 0 ]; then
    TPS=$(( SERIAL_COUNT * 100 * 100 / TOTAL_SEC_X100 ))
else
    TPS=999999
fi

sort -n "$LATENCY_FILE" > "$WORK_DIR/sorted_latencies.txt"
AVG_US=$(awk '{s+=$1} END {printf "%.0f", s/NR}' "$LATENCY_FILE")
MIN_US=$(head -1 "$WORK_DIR/sorted_latencies.txt")
MAX_US=$(tail -1 "$WORK_DIR/sorted_latencies.txt")
P50=$(percentile "$WORK_DIR/sorted_latencies.txt" 50)
P95=$(percentile "$WORK_DIR/sorted_latencies.txt" 95)
P99=$(percentile "$WORK_DIR/sorted_latencies.txt" 99)

info "Total time:  ${TOTAL_MS} ms"
info "Throughput:  ~${TPS} req/s (serial)"
info "Latency:     avg=${AVG_US}us  min=${MIN_US}us  max=${MAX_US}us"
info "Percentiles: p50=${P50}us  p95=${P95}us  p99=${P99}us"

# Uniqueness check for serial IDs
SERIAL_TOTAL=$(grep -c '[0-9]' "$ID_FILE" || true)
SERIAL_UNIQUE=$(sort -u "$ID_FILE" | grep -c '[0-9]' || true)
if [ "$SERIAL_UNIQUE" -eq "$SERIAL_TOTAL" ]; then
    pass "all $SERIAL_TOTAL serial IDs are unique"
else
    DUPS=$((SERIAL_TOTAL - SERIAL_UNIQUE))
    fail "$DUPS duplicate IDs among $SERIAL_TOTAL serial requests"
fi

# Monotonically increasing check
MONO_OK=true
PREV_ID=""
while IFS= read -r line; do
    line=$(echo "$line" | tr -d '[:space:]')
    if [ -n "$PREV_ID" ] && [ -n "$line" ]; then
        if [ "$line" -le "$PREV_ID" ] 2>/dev/null; then
            MONO_OK=false
            break
        fi
    fi
    PREV_ID="$line"
done < "$ID_FILE"
if [ "$MONO_OK" = true ]; then
    pass "all serial IDs are monotonically increasing"
else
    fail "serial IDs are NOT monotonically increasing"
fi

# =============================================================================
# TEST 2: Batch Generation Throughput
# =============================================================================
section "TEST 2: Batch Generation Throughput" \
    "GET /global-id/batch?count=N — measuring batch sizes ${BATCH_SIZES[*]}"

for BSIZE in "${BATCH_SIZES[@]}"; do
    BATCH_START=$(now_ns)
    BATCH_RESP=$(curl -s "$BATCH_URL?count=$BSIZE")
    BATCH_END=$(now_ns)
    BATCH_MS=$(( (BATCH_END - BATCH_START) / 1000000 ))

    BATCH_IDS_FILE="$WORK_DIR/batch_${BSIZE}.txt"
    echo "$BATCH_RESP" | tr -d '[]' | tr ',' '\n' | sed 's/^[[:space:]]*//;/^$/d' > "$BATCH_IDS_FILE"

    ACTUAL_COUNT=$(grep -c '[0-9]' "$BATCH_IDS_FILE" || true)
    UNIQUE_COUNT=$(sort -u "$BATCH_IDS_FILE" | grep -c '[0-9]' || true)

    if [ "$BATCH_MS" -gt 0 ]; then
        BATCH_TPS=$(( BSIZE * 1000 / BATCH_MS ))
    else
        BATCH_TPS=999999
    fi

    info "batch(count=$BSIZE): ${BATCH_MS}ms, ~${BATCH_TPS} IDs/s"

    if [ "$ACTUAL_COUNT" -eq "$BSIZE" ]; then
        pass "batch(count=$BSIZE) returned $BSIZE IDs"
    else
        fail "batch(count=$BSIZE) returned $ACTUAL_COUNT IDs (expected $BSIZE)"
    fi

    if [ "$UNIQUE_COUNT" -eq "$ACTUAL_COUNT" ]; then
        pass "batch(count=$BSIZE) all IDs unique"
    else
        DUPS=$((ACTUAL_COUNT - UNIQUE_COUNT))
        fail "batch(count=$BSIZE) has $DUPS duplicates"
    fi
done

# =============================================================================
# TEST 3: Concurrent Throughput
# =============================================================================
TOTAL_CONCURRENT=$((CONCURRENT_WORKERS * CONCURRENT_REQS_PER_WORKER))
section "TEST 3: Concurrent Throughput" \
    "$CONCURRENT_WORKERS workers x $CONCURRENT_REQS_PER_WORKER reqs = $TOTAL_CONCURRENT total requests"

CONC_DIR="$WORK_DIR/concurrent"
mkdir -p "$CONC_DIR"

CONC_START=$(now_ns)

for w in $(seq 1 "$CONCURRENT_WORKERS"); do
    (
        for _r in $(seq 1 "$CONCURRENT_REQS_PER_WORKER"); do
            curl -s "$GENERATE_URL"
            echo ""
        done > "$CONC_DIR/worker_${w}.txt"
    ) &
done
wait

CONC_END=$(now_ns)
CONC_TOTAL_MS=$(( (CONC_END - CONC_START) / 1000000 ))
CONC_TOTAL_SEC_X100=$(( (CONC_END - CONC_START) / 10000000 ))

# Merge all worker results (explicit newline per file to prevent ID merging at boundaries)
ALL_CONC_IDS="$WORK_DIR/all_concurrent_ids.txt"
for f in "$CONC_DIR"/worker_*.txt; do
    cat "$f"
    printf '\n'
done | sed -n '/[0-9]/p' > "$ALL_CONC_IDS"

CONC_VALID=$(grep -c '[0-9]' "$ALL_CONC_IDS" || true)
CONC_UNIQUE=$(sort -u "$ALL_CONC_IDS" | grep -c '[0-9]' || true)

if [ "$CONC_TOTAL_SEC_X100" -gt 0 ]; then
    CONC_TPS=$(( CONC_VALID * 100 * 100 / CONC_TOTAL_SEC_X100 ))
else
    CONC_TPS=999999
fi

info "Total time:     ${CONC_TOTAL_MS} ms"
info "Valid responses: ${CONC_VALID} / ${TOTAL_CONCURRENT}"
info "Throughput:     ~${CONC_TPS} req/s (concurrent)"

if [ "$CONC_VALID" -eq "$TOTAL_CONCURRENT" ]; then
    pass "all $TOTAL_CONCURRENT concurrent requests returned valid IDs"
else
    fail "only $CONC_VALID of $TOTAL_CONCURRENT returned valid IDs"
fi

if [ "$CONC_UNIQUE" -eq "$CONC_VALID" ]; then
    pass "all $CONC_VALID concurrent IDs are unique — zero duplicates"
else
    DUPS=$((CONC_VALID - CONC_UNIQUE))
    fail "$DUPS duplicate IDs found among $CONC_VALID concurrent requests"

    # Show duplicate details
    echo -e "  ${RED}Duplicate details:${NC}"
    sort "$ALL_CONC_IDS" | uniq -d | head -20 | while read -r dup_id; do
        dup_count=$(grep -c "^${dup_id}$" "$ALL_CONC_IDS")
        echo -e "    ID=$dup_id appeared $dup_count times"
    done
fi

# =============================================================================
# TEST 4: Large-Scale Uniqueness Verification
# =============================================================================
section "TEST 4: Large-Scale Uniqueness Verification" \
    "Generating $LARGE_UNIQUE_TOTAL IDs via batch API, verifying zero duplicates"

LARGE_IDS_FILE="$WORK_DIR/large_unique_ids.txt"
: > "$LARGE_IDS_FILE"

BATCH_SIZE=5000
REMAINING=$LARGE_UNIQUE_TOTAL
BATCH_NUM=0

LARGE_START=$(now_ns)

while [ "$REMAINING" -gt 0 ]; do
    FETCH_SIZE=$BATCH_SIZE
    if [ "$REMAINING" -lt "$BATCH_SIZE" ]; then
        FETCH_SIZE=$REMAINING
    fi

    RESP=$(curl -s "$BATCH_URL?count=$FETCH_SIZE")
    echo "$RESP" | tr -d '[]' | tr ',' '\n' | sed 's/^[[:space:]]*//;/^$/d' >> "$LARGE_IDS_FILE"

    REMAINING=$((REMAINING - FETCH_SIZE))
    BATCH_NUM=$((BATCH_NUM + 1))
    echo -ne "  \r  ${CYAN}[INFO]${NC} Fetched batch $BATCH_NUM ... ($((LARGE_UNIQUE_TOTAL - REMAINING))/$LARGE_UNIQUE_TOTAL)"
done
echo ""

LARGE_END=$(now_ns)
LARGE_MS=$(( (LARGE_END - LARGE_START) / 1000000 ))
LARGE_SEC_X100=$(( (LARGE_END - LARGE_START) / 10000000 ))

LARGE_TOTAL=$(grep -c '[0-9]' "$LARGE_IDS_FILE" || true)
LARGE_UNIQUE=$(sort -u "$LARGE_IDS_FILE" | grep -c '[0-9]' || true)

if [ "$LARGE_SEC_X100" -gt 0 ]; then
    LARGE_TPS=$(( LARGE_TOTAL * 100 * 100 / LARGE_SEC_X100 ))
else
    LARGE_TPS=999999
fi

info "Total time:  ${LARGE_MS} ms"
info "Total IDs:   ${LARGE_TOTAL}"
info "Throughput:  ~${LARGE_TPS} IDs/s (batch generation)"

if [ "$LARGE_TOTAL" -ge "$LARGE_UNIQUE_TOTAL" ]; then
    pass "generated $LARGE_TOTAL IDs (target: $LARGE_UNIQUE_TOTAL)"
else
    fail "only generated $LARGE_TOTAL IDs (target: $LARGE_UNIQUE_TOTAL)"
fi

if [ "$LARGE_UNIQUE" -eq "$LARGE_TOTAL" ]; then
    pass "all $LARGE_TOTAL IDs are globally unique — zero duplicates in ${LARGE_UNIQUE_TOTAL} IDs"
else
    DUPS=$((LARGE_TOTAL - LARGE_UNIQUE))
    fail "$DUPS duplicate IDs found among $LARGE_TOTAL total IDs"
    echo -e "  ${RED}Duplicate sample (up to 10):${NC}"
    sort "$LARGE_IDS_FILE" | uniq -d | head -10 | while read -r dup_id; do
        dup_count=$(grep -c "^${dup_id}$" "$LARGE_IDS_FILE")
        echo -e "    ID=$dup_id appeared $dup_count times"
    done
fi

# =============================================================================
# TEST 5: Concurrent Batch Uniqueness (Cross-Worker)
# =============================================================================
section "TEST 5: Concurrent Batch Requests" \
    "10 workers each requesting batch(1000) simultaneously — 10,000 IDs must be globally unique"

CONC_BATCH_DIR="$WORK_DIR/conc_batch"
mkdir -p "$CONC_BATCH_DIR"

CONC_BATCH_START=$(now_ns)

for w in $(seq 1 10); do
    (
        curl -s "$BATCH_URL?count=1000" | tr -d '[]' | tr ',' '\n' | sed 's/^[[:space:]]*//;/^$/d' \
            > "$CONC_BATCH_DIR/batch_${w}.txt"
    ) &
done
wait

CONC_BATCH_END=$(now_ns)
CONC_BATCH_MS=$(( (CONC_BATCH_END - CONC_BATCH_START) / 1000000 ))

ALL_CONC_BATCH="$WORK_DIR/all_conc_batch.txt"
for f in "$CONC_BATCH_DIR"/batch_*.txt; do
    cat "$f"
    printf '\n'
done | sed -n '/[0-9]/p' > "$ALL_CONC_BATCH"

CB_TOTAL=$(grep -c '[0-9]' "$ALL_CONC_BATCH" || true)
CB_UNIQUE=$(sort -u "$ALL_CONC_BATCH" | grep -c '[0-9]' || true)

info "Total time: ${CONC_BATCH_MS} ms for 10 concurrent batch(1000) requests"

if [ "$CB_TOTAL" -eq 10000 ]; then
    pass "10 concurrent batches returned 10,000 IDs total"
else
    fail "10 concurrent batches returned $CB_TOTAL IDs (expected 10,000)"
fi

if [ "$CB_UNIQUE" -eq "$CB_TOTAL" ]; then
    pass "all $CB_TOTAL IDs across concurrent batches are unique"
else
    DUPS=$((CB_TOTAL - CB_UNIQUE))
    fail "$DUPS duplicate IDs across concurrent batches"
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo -e "${BOLD}╔═════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║  Summary                                               ║${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║${NC}  Total tests:  ${BOLD}$TOTAL_TESTS${NC}"
echo -e "${BOLD}║${NC}  ${GREEN}Passed:       $PASS_COUNT${NC}"
echo -e "${BOLD}║${NC}  ${RED}Failed:       $FAIL_COUNT${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  Performance Metrics                                   ║${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║${NC}  Serial throughput:     ~${TPS} req/s"
echo -e "${BOLD}║${NC}  Serial latency (avg):  ${AVG_US} us"
echo -e "${BOLD}║${NC}  Serial latency (p99):  ${P99} us"
echo -e "${BOLD}║${NC}  Concurrent throughput: ~${CONC_TPS} req/s"
echo -e "${BOLD}║${NC}  Batch throughput:      ~${LARGE_TPS} IDs/s"
echo -e "${BOLD}╚═════════════════════════════════════════════════════════╝${NC}"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo -e "  ${GREEN}${BOLD}ALL TESTS PASSED${NC} — ID generation is fast and globally unique."
else
    echo -e "  ${RED}${BOLD}$FAIL_COUNT TEST(S) FAILED${NC} — check output above for details."
    exit 1
fi
echo ""
