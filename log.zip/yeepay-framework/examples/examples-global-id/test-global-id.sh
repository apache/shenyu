#!/bin/bash
# ============================================================================
# Yeepay Global ID Framework - Test Script
#
# Usage:
#   bash test-global-id.sh [base_url]
#
# Default base_url: http://localhost:9082
#
# Prerequisites:
#   1. Build the project:
#      mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip
#   2. Start the example service:
#      mvn spring-boot:run -pl examples/examples-global-id
#      (or specify profile: -Dspring-boot.run.profiles=database|redis|zookeeper)
# ============================================================================

BASE_URL="${1:-http://localhost:9082}"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

pass() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    PASS_COUNT=$((PASS_COUNT + 1))
    echo -e "  ${GREEN}[PASS]${NC} $1"
}

fail() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    FAIL_COUNT=$((FAIL_COUNT + 1))
    echo -e "  ${RED}[FAIL]${NC} $1"
}

section() {
    echo ""
    echo -e "${BOLD}$1${NC}"
    echo "  $2"
}

# ============================================================================
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Yeepay Global ID Framework - Test Suite${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Target: $BASE_URL"
echo ""

# Check service is up
echo -n "Checking service availability... "
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE_URL/global-id/generate" 2>/dev/null)
if [ "$HTTP_CODE" = "000" ]; then
    echo -e "${RED}FAILED${NC}"
    echo "  Cannot connect to $BASE_URL. Please start the service first:"
    echo "    mvn spring-boot:run -pl examples/examples-global-id"
    exit 1
fi
echo -e "${GREEN}OK${NC}"

# ===========================
# PART 1: Single ID Generation
# ===========================
section "1. Single ID Generation" "GET /global-id/generate"

# 1.1 Basic generation
ID=$(curl -s "$BASE_URL/global-id/generate")
if [ -n "$ID" ] && [ "$ID" -gt 0 ] 2>/dev/null; then
    pass "generate returns positive number: $ID"
else
    fail "generate returned invalid value: $ID"
fi

# 1.2 Two consecutive IDs are different
ID1=$(curl -s "$BASE_URL/global-id/generate")
ID2=$(curl -s "$BASE_URL/global-id/generate")
if [ "$ID1" != "$ID2" ]; then
    pass "consecutive IDs are unique: $ID1 != $ID2"
else
    fail "consecutive IDs are identical: $ID1 == $ID2"
fi

# 1.3 IDs are monotonically increasing
if [ "$ID2" -gt "$ID1" ] 2>/dev/null; then
    pass "IDs are monotonically increasing: $ID1 < $ID2"
else
    fail "IDs are not increasing: $ID1 >= $ID2"
fi

# ===========================
# PART 2: Batch ID Generation
# ===========================
section "2. Batch ID Generation" "GET /global-id/batch?count=N"

# 2.1 Default batch (10 IDs)
BATCH=$(curl -s "$BASE_URL/global-id/batch")
COUNT=$(echo "$BATCH" | tr ',' '\n' | wc -l | tr -d ' ')
if [ "$COUNT" -eq 10 ]; then
    pass "default batch returns 10 IDs"
else
    fail "default batch returned $COUNT IDs (expected 10)"
fi

# 2.2 Custom batch size
BATCH_50=$(curl -s "$BASE_URL/global-id/batch?count=50")
COUNT_50=$(echo "$BATCH_50" | tr -d '[]' | tr ',' '\n' | wc -l | tr -d ' ')
if [ "$COUNT_50" -eq 50 ]; then
    pass "batch?count=50 returns 50 IDs"
else
    fail "batch?count=50 returned $COUNT_50 IDs (expected 50)"
fi

# 2.3 All IDs in batch are unique
UNIQUE_COUNT=$(echo "$BATCH_50" | tr -d '[]' | tr ',' '\n' | sort -u | wc -l | tr -d ' ')
if [ "$UNIQUE_COUNT" -eq "$COUNT_50" ]; then
    pass "all 50 IDs in batch are unique"
else
    DUPS=$((COUNT_50 - UNIQUE_COUNT))
    fail "$DUPS duplicate IDs found in batch of 50"
fi

# 2.4 All IDs in batch are strictly increasing
ALL_INCREASING=true
PREV=0
while IFS= read -r id; do
    id=$(echo "$id" | tr -d ' ')
    if [ -n "$id" ] && [ "$PREV" -ne 0 ] 2>/dev/null; then
        if [ "$id" -le "$PREV" ] 2>/dev/null; then
            ALL_INCREASING=false
            break
        fi
    fi
    PREV="$id"
done <<< "$(echo "$BATCH_50" | tr -d '[]' | tr ',' '\n')"

if [ "$ALL_INCREASING" = true ]; then
    pass "all IDs in batch are strictly increasing"
else
    fail "batch IDs are not strictly increasing"
fi

# 2.5 Batch of 1
BATCH_1=$(curl -s "$BASE_URL/global-id/batch?count=1")
COUNT_1=$(echo "$BATCH_1" | tr -d '[]' | tr ',' '\n' | grep -c '[0-9]')
if [ "$COUNT_1" -eq 1 ]; then
    pass "batch?count=1 returns exactly 1 ID"
else
    fail "batch?count=1 returned $COUNT_1 IDs (expected 1)"
fi

# ===========================
# PART 3: Parse UID
# ===========================
section "3. Parse UID" "GET /global-id/parse/{uid}"

# 3.1 Parse a generated ID
PARSE_ID=$(curl -s "$BASE_URL/global-id/generate")
PARSE_RESULT=$(curl -s "$BASE_URL/global-id/parse/$PARSE_ID")
if echo "$PARSE_RESULT" | grep -q '"UID"' && echo "$PARSE_RESULT" | grep -q '"timestamp"' \
    && echo "$PARSE_RESULT" | grep -q '"workerId"' && echo "$PARSE_RESULT" | grep -q '"sequence"'; then
    pass "parse returns all fields (UID, timestamp, workerId, sequence)"
    echo -e "        ${CYAN}$PARSE_RESULT${NC}"
else
    fail "parse response missing fields: $PARSE_RESULT"
fi

# 3.2 Parsed UID matches original
PARSED_UID=$(echo "$PARSE_RESULT" | grep -o '"UID":"[^"]*"' | cut -d'"' -f4)
if [ "$PARSED_UID" = "$PARSE_ID" ]; then
    pass "parsed UID matches original: $PARSED_UID"
else
    fail "parsed UID mismatch: expected $PARSE_ID, got $PARSED_UID"
fi

# 3.3 Timestamp is a valid date string (YYYY-MM-DD format check)
PARSED_TS=$(echo "$PARSE_RESULT" | grep -o '"timestamp":"[^"]*"' | cut -d'"' -f4)
if echo "$PARSED_TS" | grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}'; then
    pass "timestamp is a valid date: $PARSED_TS"
else
    fail "timestamp format invalid: $PARSED_TS"
fi

# 3.4 WorkerId is a non-negative number
PARSED_WORKER=$(echo "$PARSE_RESULT" | grep -o '"workerId":"[^"]*"' | cut -d'"' -f4)
if [ "$PARSED_WORKER" -ge 0 ] 2>/dev/null; then
    pass "workerId is non-negative: $PARSED_WORKER"
else
    fail "workerId invalid: $PARSED_WORKER"
fi

# ===========================
# PART 4: Uniqueness Under Concurrency
# ===========================
section "4. Uniqueness Under Concurrency" "100 concurrent requests, all IDs must be unique"

TMPDIR=$(mktemp -d)
CONCURRENT_COUNT=100

echo -e "  ${CYAN}[CONCURRENT]${NC} sending $CONCURRENT_COUNT concurrent requests..."
for i in $(seq 1 "$CONCURRENT_COUNT"); do
    curl -s "$BASE_URL/global-id/generate" > "$TMPDIR/id_$i" &
done
wait

ALL_IDS="$TMPDIR/all_ids.txt"
> "$ALL_IDS"
VALID_COUNT=0
for i in $(seq 1 "$CONCURRENT_COUNT"); do
    ID_VAL=$(cat "$TMPDIR/id_$i" 2>/dev/null)
    if [ -n "$ID_VAL" ] && [ "$ID_VAL" -gt 0 ] 2>/dev/null; then
        echo "$ID_VAL" >> "$ALL_IDS"
        VALID_COUNT=$((VALID_COUNT + 1))
    fi
done

UNIQUE_CONCURRENT=$(sort -u "$ALL_IDS" | wc -l | tr -d ' ')

if [ "$VALID_COUNT" -eq "$CONCURRENT_COUNT" ]; then
    pass "all $CONCURRENT_COUNT concurrent requests returned valid IDs"
else
    fail "only $VALID_COUNT of $CONCURRENT_COUNT returned valid IDs"
fi

if [ "$UNIQUE_CONCURRENT" -eq "$VALID_COUNT" ]; then
    pass "all $VALID_COUNT concurrent IDs are unique (zero duplicates)"
else
    DUPS=$((VALID_COUNT - UNIQUE_CONCURRENT))
    fail "$DUPS duplicate IDs found among $VALID_COUNT concurrent results"
fi

rm -rf "$TMPDIR"

# ===========================
# PART 5: Large Batch Uniqueness
# ===========================
section "5. Large Batch Uniqueness" "GET /global-id/batch?count=1000"

LARGE_BATCH=$(curl -s "$BASE_URL/global-id/batch?count=1000")
LARGE_COUNT=$(echo "$LARGE_BATCH" | tr -d '[]' | tr ',' '\n' | grep -c '[0-9]')
LARGE_UNIQUE=$(echo "$LARGE_BATCH" | tr -d '[]' | tr ',' '\n' | sort -u | grep -c '[0-9]')

if [ "$LARGE_COUNT" -eq 1000 ]; then
    pass "batch?count=1000 returns 1000 IDs"
else
    fail "batch?count=1000 returned $LARGE_COUNT IDs (expected 1000)"
fi

if [ "$LARGE_UNIQUE" -eq "$LARGE_COUNT" ]; then
    pass "all 1000 IDs are unique"
else
    DUPS=$((LARGE_COUNT - LARGE_UNIQUE))
    fail "$DUPS duplicate IDs in batch of 1000"
fi

# ===========================
# PART 6: Cross-Batch Uniqueness
# ===========================
section "6. Cross-Batch Uniqueness" "IDs from different batches must not collide"

BATCH_A=$(curl -s "$BASE_URL/global-id/batch?count=100")
BATCH_B=$(curl -s "$BASE_URL/global-id/batch?count=100")

COMBINED_FILE=$(mktemp)
echo "$BATCH_A" | tr -d '[]' | tr ',' '\n' > "$COMBINED_FILE"
echo "$BATCH_B" | tr -d '[]' | tr ',' '\n' >> "$COMBINED_FILE"

COMBINED_TOTAL=$(grep -c '[0-9]' "$COMBINED_FILE")
COMBINED_UNIQUE=$(sort -u "$COMBINED_FILE" | grep -c '[0-9]')

if [ "$COMBINED_UNIQUE" -eq "$COMBINED_TOTAL" ]; then
    pass "no collisions across 2 batches of 100 (200 total IDs all unique)"
else
    DUPS=$((COMBINED_TOTAL - COMBINED_UNIQUE))
    fail "$DUPS collisions found across 2 batches"
fi
rm -f "$COMBINED_FILE"

# ===========================
# Summary
# ===========================
echo ""
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Summary${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Total tests: $TOTAL_TESTS"
echo -e "  ${GREEN}Passed: $PASS_COUNT${NC}"
echo -e "  ${RED}Failed: $FAIL_COUNT${NC}"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo -e "  ${GREEN}All tests passed!${NC}"
else
    echo -e "  ${RED}Some tests failed. Check the output above for details.${NC}"
fi
echo ""
