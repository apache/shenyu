#!/bin/bash
# =============================================================================
# examples-web 完整功能测试脚本
# 覆盖 web 模块所有功能: Result / Response / BigDecimal 校验 / XSS / 异常处理
#
# 用法:
#   启动应用后执行:   ./test-web.sh
#   指定端口:          PORT=8081 ./test-web.sh
#   只跑指定分组:       ./test-web.sh result bigdecimal
# =============================================================================

set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8080}"
PASS=0
FAIL=0

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# =============================================================================
# 断言函数
# =============================================================================

assert_http() {
    local desc="$1" url="$2" expected_code="$3"
    local resp body code
    resp=$(curl -s -w "\n%{http_code}" "$url")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "$expected_code" ]; then
        echo -e "  ${GREEN}PASS${NC} [$code] $desc"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code != $expected_code] $desc"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

assert_json_contains() {
    local desc="$1" url="$2" expected_code="$3" key="$4"
    local resp body code
    resp=$(curl -s -w "\n%{http_code}" "$url")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "$expected_code" ] && echo "$body" | grep -q "$key"; then
        echo -e "  ${GREEN}PASS${NC} [$code] $desc  (contains: $key)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code != $expected_code or missing '$key'] $desc"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

assert_json_code() {
    local desc="$1" url="$2" expected_json_code="$3"
    local resp body code json_code
    resp=$(curl -s -w "\n%{http_code}" "$url")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    json_code=$(echo "$body" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('code',''))" 2>/dev/null || echo "")
    if [ "$code" = "200" ] && [ "$json_code" = "$expected_json_code" ]; then
        echo -e "  ${GREEN}PASS${NC} [$code] $desc  (code=$json_code)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [http=$code json_code=$json_code] $desc"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

post_json() {
    local data="$1" url="$2"
    curl -s -X POST -H "Content-Type: application/json" -d "$data" "$url"
}

post_json_assert() {
    local desc="$1" url="$2" data="$3" expected_http="$4" expected_key="$5"
    local resp body code
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" -d "$data" "$url")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "$expected_http" ] && echo "$body" | grep -q "$expected_key"; then
        echo -e "  ${GREEN}PASS${NC} [$code] $desc  (contains: $expected_key)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code != $expected_http or missing '$expected_key'] $desc"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

# =============================================================================
# 测试分组
# =============================================================================

run_health_check() {
    echo ""
    echo "=== Health Check ==="
    for i in $(seq 1 30); do
        if curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/api/result/success" 2>/dev/null | grep -q "200"; then
            echo "  Application is UP"
            return 0
        fi
        echo "  Waiting for app to start... ($i/30)"
        sleep 2
    done
    echo -e "  ${RED}Application failed to start within 60s${NC}"
    exit 1
}

run_result_tests() {
    echo ""
    echo "=== Result<T> Tests ==="

    assert_http "Success result" "$BASE_URL/api/result/success" "200"
    assert_json_contains "Success mapped" "$BASE_URL/api/result/success/5" "200" "10"
    assert_http "Empty result" "$BASE_URL/api/result/empty" "200"
    assert_json_contains "Filter (pass)" "$BASE_URL/api/result/filter/5" "200" "5"
    assert_json_contains "Filter (fail → empty)" "$BASE_URL/api/result/filter/-1" "200" "code"
    assert_json_contains "FlatMap" "$BASE_URL/api/result/flatmap/5" "200" "15"
    assert_json_contains "getOrElse fail" "$BASE_URL/api/result/orelse?fail=true" "200" "default-value"
    assert_json_contains "getOrDefault fail" "$BASE_URL/api/result/ordefault?fail=true" "200" "default-value"

    assert_http "Failure result" "$BASE_URL/api/result/failure" "200"
    assert_http "Failure with args" "$BASE_URL/api/result/failure-with-args" "200"

    assert_http "ifFailure" "$BASE_URL/api/result/if-failure/true" "200"
    # ifEmpty: path variable = x, filter removes it (length > 0 → filter fails → empty)
    assert_json_contains "ifEmpty" "$BASE_URL/api/result/if-empty/x" "200" "wasEmpty"
}

run_exception_tests() {
    echo ""
    echo "=== Exception / ErrorThrowable Tests ==="

    assert_http "BizException" "$BASE_URL/api/result/biz-exception" "200"
    assert_http "BizException with list" "$BASE_URL/api/result/biz-exception-list" "200"
    assert_http "IllegalParamArgumentException" "$BASE_URL/api/result/illegal-param" "200"
    assert_http "IllegalEnumArgumentException" "$BASE_URL/api/result/illegal-enum" "200"
    assert_http "ErrorThrowable" "$BASE_URL/api/result/error-throwable" "200"
    assert_http "ErrorThrowable with cause" "$BASE_URL/api/result/error-throwable-cause" "200"

    # ThreadContext: 验证 filter 已初始化上下文
    assert_json_contains "ThreadContext" "$BASE_URL/api/result/thread-context" "200" "appName"
}

run_bigdecimal_tests() {
    echo ""
    echo "=== BigDecimal Safety Tests ==="

    # JSON Body — 正常
    post_json_assert "JSON body normal" "$BASE_URL/api/bigdecimal/json" \
        '{"amount":100,"price":2.5}' "200" "250.0"

    # Query Param — 正常
    assert_json_contains "Query param normal" "$BASE_URL/api/bigdecimal/query?amount=100&price=2.5" "200" "250.0"

    # Form Data — 正常
    assert_json_contains "Form data normal" "$BASE_URL/api/bigdecimal/form?amount=100&price=2.5" "200" "250.0"

    # PathVariable — 正常
    assert_json_contains "PathVariable normal" "$BASE_URL/api/bigdecimal/path/99.99" "200" "199.98"

    # 正常数值
    assert_json_contains "Normal value" "$BASE_URL/api/bigdecimal/normal?value=123.45" "200" "123.45"

    # 科学计数法合法值 (e3 ≤ exponent=5)
    assert_json_contains "Scientific OK 5e3" "$BASE_URL/api/bigdecimal/scientific-ok?value=5e3" "200" "5E+3"

    # ========== 攻击测试 ==========

    # 超大指数 (e6 > exponent=5) —— 应被 BigDecimalConverter 拦截
    local resp body code
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/bigdecimal/query?amount=1e6")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" != "200" ]; then
        echo -e "  ${GREEN}PASS${NC} [$code] BigDecimal exponent overflow blocked (1e6)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] BigDecimal exponent overflow should be blocked"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # 超长字符串 (len 80 > maxLength=75) —— 应被拦截
    local long_val
    long_val=$(python3 -c "print('9' * 80)")
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/bigdecimal/query?amount=$long_val")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" != "200" ]; then
        echo -e "  ${GREEN}PASS${NC} [$code] BigDecimal length overflow blocked (len=80)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] BigDecimal length overflow should be blocked"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

run_response_tests() {
    echo ""
    echo "=== Response<T> Tests ==="

    assert_json_code "Response success" "$BASE_URL/api/response/success" "200"
    assert_json_code "Response success data" "$BASE_URL/api/response/success-data" "200"
    assert_json_code "Response success void" "$BASE_URL/api/response/success-void" "200"

    assert_json_contains "Response failure by ErrorCode" "$BASE_URL/api/response/failure-error-code" "200" "400"
    assert_json_contains "Response failure by ErrorInfo" "$BASE_URL/api/response/failure-error-info" "200" "404"
    assert_json_contains "Response failure by int" "$BASE_URL/api/response/failure-code-int" "200" "500"
    assert_json_contains "Response failure with message" "$BASE_URL/api/response/failure-code-message" "200" "400"
}

run_error_code_tests() {
    echo ""
    echo "=== ErrorCode / CommonError Tests ==="

    assert_json_contains "ErrorCode demo" "$BASE_URL/api/response/error-code-demo" "200" "common.bad-request"
    assert_json_contains "ErrorCode all" "$BASE_URL/api/response/error-code-all" "200" "BAD_REQUEST"
    assert_json_contains "CommonError.getByCode 200" "$BASE_URL/api/response/common-error-by-code/200" "200" "SUCCESS"
    assert_json_contains "CommonError.getByCode 404" "$BASE_URL/api/response/common-error-by-code/404" "200" "NOT_FOUND"
    assert_json_contains "CommonError.getByCode unknown" "$BASE_URL/api/response/common-error-by-code/99999" "200" "false"
}

run_error_code_wrapper_tests() {
    echo ""
    echo "=== ErrorCodeWrapper Tests ==="

    assert_json_contains "ErrorCodeWrapper" "$BASE_URL/api/response/error-code-wrapper" "200" "custom.error"
    assert_json_contains "ErrorCodeWrapper resolved" "$BASE_URL/api/response/error-code-wrapper-resolved" "200" "custom.key"
}

run_error_info_tests() {
    echo ""
    echo "=== ErrorInfo Tests ==="

    assert_json_contains "ErrorInfoSimple" "$BASE_URL/api/response/error-info-simple" "200" "common.gone"
    # ErrorInfoEntity with cause → messageCodes 包含 RuntimeException
    assert_json_contains "ErrorInfoEntity" "$BASE_URL/api/response/error-info-entity" "200" "RuntimeException"

    assert_http "InvalidUriException" "$BASE_URL/api/response/invalid-uri" "200"
}

run_validation_tests() {
    echo ""
    echo "=== Validation (@Xss / @ValidBy) Tests ==="

    # @Xss query param — GET, 合法文本
    assert_json_contains "XSS SIMPLE_TEXT valid" "$BASE_URL/api/validation/xss/query?text=hello" "200" "hello"

    # @ValidBy — 合法状态
    post_json_assert "@ValidBy valid status" "$BASE_URL/api/validation/valid-by" \
        '{"status":"PENDING"}' "200" "PENDING"

    # @ValidBy — 非法状态 → 400
    local resp body code
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" \
        -d '{"status":"INVALID_STATUS"}' "$BASE_URL/api/validation/valid-by")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "400"; then
        echo -e "  ${GREEN}PASS${NC} [$code] @ValidBy invalid status → 400"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] @ValidBy invalid status should return 400"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # @ValidBy query param — 合法
    assert_json_contains "@ValidBy query valid" "$BASE_URL/api/validation/valid-by/query?status=PENDING" "200" "PENDING"
}

run_mvc_exception_tests() {
    echo ""
    echo "=== MvcExceptionHandler Tests ==="

    local resp body code

    # MethodArgumentNotValidException — @Valid 字段失败
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" \
        -d '{"amount":-5,"orderName":""}' "$BASE_URL/api/exception/validation-failed")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "400"; then
        echo -e "  ${GREEN}PASS${NC} [$code] MethodArgumentNotValidException → 400"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] MethodArgumentNotValidException should return 400"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # MissingServletRequestParameterException
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/exception/missing-param")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "400"; then
        echo -e "  ${GREEN}PASS${NC} [$code] MissingServletRequestParameterException → 400"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] MissingServletRequestParameterException should return 400"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # MethodArgumentTypeMismatchException
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/exception/type-mismatch?count=abc")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "400"; then
        echo -e "  ${GREEN}PASS${NC} [$code] MethodArgumentTypeMismatchException → 400"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] MethodArgumentTypeMismatchException should return 400"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # HttpMessageNotReadableException — 非法 JSON
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" \
        -d 'this is not json' "$BASE_URL/api/exception/unreadable-json")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "501"; then
        echo -e "  ${GREEN}PASS${NC} [$code] HttpMessageNotReadableException → 501"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] HttpMessageNotReadableException should return 501"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # HttpRequestMethodNotSupportedException
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/exception/method-not-supported")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "501"; then
        echo -e "  ${GREEN}PASS${NC} [$code] HttpRequestMethodNotSupportedException → 501"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] HttpRequestMethodNotSupportedException should return 501"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # NoHandlerFoundException → HTTP 404 (ResponseStatus(NOT_FOUND) 覆盖类级别 OK)
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/non-existent-path-xyz")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "404" ]; then
        echo -e "  ${GREEN}PASS${NC} [$code] NoHandlerFoundException → HTTP 404"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] NoHandlerFoundException should return HTTP 404"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # BigDecimal 反序列化安全异常 (超大指数通过 JSON body)
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" \
        -d '{"value":"1e9999"}' "$BASE_URL/api/exception/bigdecimal-overflow")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "400"; then
        echo -e "  ${GREEN}PASS${NC} [$code] BigDecimal deserialization overflow blocked → 400"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] BigDecimal deserialization overflow should be blocked"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

run_application_exception_tests() {
    echo ""
    echo "=== ApplicationExceptionHandler Tests ==="

    local resp body code

    # RuntimeException 兜底 → INTERNAL_SERVER_ERROR(500)
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/exception/runtime-exception")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "500"; then
        echo -e "  ${GREEN}PASS${NC} [$code] RuntimeException → 500 (ApplicationExceptionHandler)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] RuntimeException should return 500"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # NumberFormatException
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/exception/number-format?value=not-a-number")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ] && echo "$body" | grep -q "500"; then
        echo -e "  ${GREEN}PASS${NC} [$code] NumberFormatException → 500"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] NumberFormatException should return 500"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # Enum IllegalArgumentException
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/exception/enum/INVALID")
    code=$(echo "$resp" | tail -1)
    body=$(echo "$resp" | sed '$d')
    if [ "$code" = "200" ]; then
        echo -e "  ${GREEN}PASS${NC} [$code] Enum validation error handled"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} [$code] Enum validation error should be handled"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

run_i18n_tests() {
    echo ""
    echo "=== I18n Message Tests ==="

    local resp body

    # CommonError.BAD_REQUEST → key "common.bad-request" → 中文: 请求参数错误
    resp=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/response/failure-error-code")
    body=$(echo "$resp" | sed '$d')
    if echo "$body" | grep -q "请求参数错误"; then
        echo -e "  ${GREEN}PASS${NC} I18n: CommonError.BAD_REQUEST resolved to Chinese"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} I18n: CommonError.BAD_REQUEST not resolved"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # @ValidBy i18n 消息 → {order.status.invalid}
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" \
        -d '{"status":"INVALID"}' "$BASE_URL/api/validation/valid-by")
    body=$(echo "$resp" | sed '$d')
    if echo "$body" | grep -q "订单状态不合法"; then
        echo -e "  ${GREEN}PASS${NC} I18n: @ValidBy order.status.invalid resolved"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} I18n: @ValidBy message not resolved to Chinese"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi

    # @Valid 字段校验 i18n → {order.amount.positive}
    resp=$(curl -s -w "\n%{http_code}" -X POST -H "Content-Type: application/json" \
        -d '{"amount":-5,"orderName":""}' "$BASE_URL/api/exception/validation-failed")
    body=$(echo "$resp" | sed '$d')
    if echo "$body" | grep -q "订单金额"; then
        echo -e "  ${GREEN}PASS${NC} I18n: @Valid field message resolved (order.amount.positive)"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}FAIL${NC} I18n: @Valid field message not resolved"
        echo "       body: $(echo "$body" | head -c 200)"
        FAIL=$((FAIL + 1))
    fi
}

# =============================================================================
# 主流程
# =============================================================================

run_all() {
    echo "=============================================="
    echo "  examples-web 功能测试"
    echo "  Base URL: $BASE_URL"
    echo "=============================================="

    run_health_check
    run_result_tests
    run_exception_tests
    run_bigdecimal_tests
    run_response_tests
    run_error_code_tests
    run_error_code_wrapper_tests
    run_error_info_tests
    run_validation_tests
    run_mvc_exception_tests
    run_application_exception_tests
    run_i18n_tests
}

print_summary() {
    echo ""
    echo "=============================================="
    local total=$((PASS + FAIL))
    echo "  Total: $total  |  ${GREEN}Pass: $PASS${NC}  |  ${RED}Fail: $FAIL${NC}"
    echo "=============================================="
    if [ "$FAIL" -gt 0 ]; then
        exit 1
    fi
}

if [ $# -eq 0 ]; then
    run_all
else
    echo "=============================================="
    echo "  examples-web 功能测试 (selected groups)"
    echo "  Base URL: $BASE_URL"
    echo "=============================================="
    run_health_check
    for group in "$@"; do
        case "$group" in
            result)      run_result_tests ;;
            exception)   run_exception_tests ;;
            bigdecimal)  run_bigdecimal_tests ;;
            response)    run_response_tests ;;
            errorcode)   run_error_code_tests ;;
            errorwrapper) run_error_code_wrapper_tests ;;
            errorinfo)   run_error_info_tests ;;
            validation)  run_validation_tests ;;
            mvc)         run_mvc_exception_tests ;;
            app-ex)      run_application_exception_tests ;;
            i18n)        run_i18n_tests ;;
            all)         run_all ;;
            *)
                echo "Unknown group: $group"
                echo "Available: result exception bigdecimal response errorcode errorwrapper errorinfo validation mvc app-ex i18n all"
                exit 1 ;;
        esac
    done
fi

print_summary
