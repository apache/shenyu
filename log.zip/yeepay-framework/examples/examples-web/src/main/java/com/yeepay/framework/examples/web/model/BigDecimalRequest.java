package com.yeepay.framework.examples.web.model;

import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * BigDecimal 安全校验测试请求体 —— JSON body 由 Jackson BigDecimalDeserializer 校验，
 * form data / query param 由 BigDecimalConverter 校验.
 */
public class BigDecimalRequest {

    @NotNull
    private BigDecimal amount;

    private BigDecimal price;

    private BigDecimal taxRate;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }
}
