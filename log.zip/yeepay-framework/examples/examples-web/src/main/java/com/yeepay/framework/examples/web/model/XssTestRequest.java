package com.yeepay.framework.examples.web.model;

import com.yeepay.framework.web.annotation.Xss;

/**
 * XSS 多级别测试请求体.
 */
public class XssTestRequest {

    @Xss(level = Xss.Level.NONE)
    private String noneLevel;

    @Xss(level = Xss.Level.SIMPLE_TEXT)
    private String simpleTextLevel;

    @Xss(level = Xss.Level.BASIC)
    private String basicLevel;

    @Xss(level = Xss.Level.BASIC_WITH_IMAGES)
    private String basicWithImagesLevel;

    @Xss(level = Xss.Level.RELAXED)
    private String relaxedLevel;

    @Xss(level = Xss.Level.HUOBI)
    private String huobiLevel;

    public String getNoneLevel() {
        return noneLevel;
    }

    public void setNoneLevel(String noneLevel) {
        this.noneLevel = noneLevel;
    }

    public String getSimpleTextLevel() {
        return simpleTextLevel;
    }

    public void setSimpleTextLevel(String simpleTextLevel) {
        this.simpleTextLevel = simpleTextLevel;
    }

    public String getBasicLevel() {
        return basicLevel;
    }

    public void setBasicLevel(String basicLevel) {
        this.basicLevel = basicLevel;
    }

    public String getBasicWithImagesLevel() {
        return basicWithImagesLevel;
    }

    public void setBasicWithImagesLevel(String basicWithImagesLevel) {
        this.basicWithImagesLevel = basicWithImagesLevel;
    }

    public String getRelaxedLevel() {
        return relaxedLevel;
    }

    public void setRelaxedLevel(String relaxedLevel) {
        this.relaxedLevel = relaxedLevel;
    }

    public String getHuobiLevel() {
        return huobiLevel;
    }

    public void setHuobiLevel(String huobiLevel) {
        this.huobiLevel = huobiLevel;
    }
}
