package com.yeepay.framework.examples.web.controller;

import com.yeepay.framework.common.theadcontext.ThreadContext;
import com.yeepay.framework.common.theadcontext.ThreadContextUtils;
import com.yeepay.framework.examples.web.service.WebExampleService;
import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorInfoSimple;
import com.yeepay.framework.web.exception.BizException;
import com.yeepay.framework.web.exception.ErrorThrowable;
import com.yeepay.framework.web.exception.IllegalEnumArgumentException;
import com.yeepay.framework.web.exception.IllegalParamArgumentException;
import com.yeepay.framework.web.result.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Result / Response / 异常处理 测试控制器.
 *
 * <p>覆盖: Result&lt;T&gt; 成功/失败/空, ErrorThrowable, BizException,
 * CommonError, ResponseAdvice 自动包装, i18n 消息解析.
 */
@RestController
@RequestMapping("/api/result")
@RequiredArgsConstructor
public class ResultController {

    private final WebExampleService service;

    // ==================== Result<T> 成功 ====================

    @GetMapping("/success")
    public Result<String> success() {
        return service.getSuccessResult();
    }

    @GetMapping("/success/{input}")
    public Result<Integer> successMapped(@PathVariable int input) {
        return service.getMappedResult(input);
    }

    @GetMapping("/empty")
    public Result<String> empty() {
        return service.getEmptyResult();
    }

    @GetMapping("/filter/{input}")
    public Result<Integer> filter(@PathVariable int input) {
        return service.getFilteredResult(input);
    }

    @GetMapping("/flatmap/{input}")
    public Result<Integer> flatMap(@PathVariable int input) {
        return service.getFlatMapResult(input);
    }

    @GetMapping("/orelse")
    public String orElse(@RequestParam(defaultValue = "false") boolean fail) {
        return service.getOrElseDemo(fail);
    }

    @GetMapping("/ordefault")
    public String orDefault(@RequestParam(defaultValue = "false") boolean fail) {
        return service.getOrDefaultDemo(fail);
    }

    // ==================== Result<T> 失败 ====================

    @GetMapping("/failure")
    public Result<String> failure() {
        return service.getFailureResult();
    }

    @GetMapping("/failure-with-args")
    public Result<String> failureWithArgs() {
        return service.getFailureWithArgs();
    }

    // ==================== Result.ifFailure / ifEmpty / ifEmptyAndSuccess ====================

    @GetMapping("/if-failure/{fail}")
    public Map<String, Object> ifFailure(@PathVariable boolean fail) {
        Map<String, Object> result = new java.util.HashMap<>();
        result.put("handled", false);
        Result.success("ok")
                .filter(v -> !fail)
                .ifFailure(error -> result.put("handled", true));
        result.put("isFailure", fail);
        return result;
    }

    @GetMapping("/if-empty/{value}")
    public Map<String, Object> ifEmpty(@PathVariable String value) {
        Map<String, Object> result = new java.util.HashMap<>();
        Result.success(value)
                .filter(v -> v.length() <= 0)
                .ifEmpty(error -> {
                    result.put("wasEmpty", true);
                    return Result.empty();
                });
        return result;
    }

    // ==================== BizException ====================

    @GetMapping("/biz-exception")
    public Result<String> bizException() {
        return service.throwBizException();
    }

    @GetMapping("/biz-exception-list")
    public Result<String> bizExceptionList() {
        return service.throwBizExceptionWithList();
    }

    // ==================== 自定义异常 ====================

    @GetMapping("/illegal-param")
    public Result<String> illegalParam() {
        return service.throwIllegalParamException();
    }

    @GetMapping("/illegal-enum")
    public Result<String> illegalEnum() {
        return service.throwIllegalEnumException();
    }

    // ==================== ErrorThrowable ====================

    @GetMapping("/error-throwable")
    public String errorThrowable() {
        throw ErrorThrowable.wrap(new ErrorInfoSimple(CommonError.OPERATE_ERROR));
    }

    @GetMapping("/error-throwable-cause")
    public String errorThrowableWithCause() {
        RuntimeException cause = new RuntimeException("底层数据库异常");
        throw new ErrorThrowable(new ErrorInfoSimple(CommonError.INTERNAL_SERVER_ERROR), cause);
    }

    // ==================== ThreadContext 验证 ====================

    @GetMapping("/thread-context")
    public Map<String, Object> threadContext() {
        ThreadContext ctx = ThreadContextUtils.getContext();
        return Map.of(
                "appName", ThreadContextUtils.getAppName(),
                "sourceUID", String.valueOf(ctx != null ? ctx.getValue(ThreadContextUtils.KEY_GUID) : "N/A"),
                "transferLevel", String.valueOf(ctx != null ? ctx.getValue(ThreadContextUtils.KEY_TRANSFER_LEVEL) : "N/A"),
                "soaEnv", String.valueOf(ctx != null ? ctx.getValue(ThreadContextUtils.KEY_SOA_ENV) : "N/A"),
                "srcSoaApp", String.valueOf(ctx != null ? ctx.getValue(ThreadContextUtils.KEY_SRC_SOA_APP) : "N/A")
        );
    }
}
