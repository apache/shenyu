package com.yeepay.framework.examples.web.model;

import com.yeepay.framework.examples.web.enums.OrderStatus;
import com.yeepay.framework.web.annotation.ValidBy;
import com.yeepay.framework.web.annotation.Xss;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

/**
 * 带有 i18n 消息键的参数校验请求体.
 *
 * <p>Jakarta Validation message 属性使用 {key} 格式 → I18nMessageSource 解析.
 * <p>ParamErrorInfo.getMessageCodes() 返回:
 * <ol>
 *   <li>异常类名.字段名 → 精确匹配参数字段</li>
 *   <li>异常类名 → 通配异常类型</li>
 *   <li>ErrorCode.getKey() → 通用错误码</li>
 *   <li>ErrorCode.getCode() → 数字错误码</li>
 * </ol>
 */
public class ValidationRequest {

    @NotNull(message = "{order.amount.not-null}")
    @Positive(message = "{order.amount.positive}")
    private BigDecimal amount;

    @NotBlank(message = "{order.order-name.not-blank}")
    @Xss(level = Xss.Level.SIMPLE_TEXT, message = "{order.remark.xss}")
    private String orderName;

    @ValidBy(clazz = OrderStatus.class, method = "isValid", message = "{order.status.invalid}")
    private String status;

    private Integer quantity;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
