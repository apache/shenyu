package com.yeepay.framework.examples.web.service;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.exception.BizException;
import com.yeepay.framework.web.exception.IllegalEnumArgumentException;
import com.yeepay.framework.web.exception.IllegalParamArgumentException;
import com.yeepay.framework.web.result.Result;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Web模块功能测试 Service —— 覆盖 Result、异常、ErrorCode 等核心API.
 */
@Service
public class WebExampleService {

    // ==================== Result<T> 成功场景 ====================

    public Result<String> getSuccessResult() {
        return Result.success("hello world");
    }

    public Result<String> getEmptyResult() {
        return Result.empty();
    }

    public Result<Integer> getMappedResult(int input) {
        return Result.success(input).map(v -> v * 2);
    }

    public Result<Integer> getFilteredResult(int input) {
        return Result.success(input).filter(v -> v > 0);
    }

    public Result<Integer> getFlatMapResult(int input) {
        return Result.success(input).flatMap(v -> Result.success(v + 10));
    }

    // ==================== Result<T> 失败场景 ====================

    public Result<String> getFailureResult() {
        return Result.failure(CommonError.BAD_REQUEST);
    }

    public Result<String> getFailureWithArgs() {
        return Result.failure(CommonError.OPERATE_ERROR, "余额不足", "accountId", "12345");
    }

    // ==================== Result<T> 链式调用 ====================

    public String getOrElseDemo(boolean fail) {
        Result<String> result = fail ? Result.failure(CommonError.NOT_FOUND) : Result.success("found");
        return result.getOrElse(() -> "default-value");
    }

    public String getOrDefaultDemo(boolean fail) {
        Result<String> result = fail ? Result.failure(CommonError.NOT_FOUND) : Result.success("found");
        return result.getOrDefault("default-value");
    }

    // ==================== BizException ====================

    public Result<String> throwBizException() {
        throw new BizException(CommonError.OPERATE_ERROR, "操作失败详情");
    }

    public Result<String> throwBizExceptionWithList() {
        throw new BizException(CommonError.BAD_REQUEST, java.util.List.of("param1", "param2"));
    }

    // ==================== 自定义异常 ====================

    public Result<String> throwIllegalParamException() {
        throw new IllegalParamArgumentException("userId", "invalid-value");
    }

    public Result<String> throwIllegalEnumException() {
        throw new IllegalEnumArgumentException(com.yeepay.framework.examples.web.enums.OrderStatus.class, "UNKNOWN_STATUS");
    }

    // ==================== BigDecimal 业务计算 ====================

    public BigDecimal calculateTotal(BigDecimal price, BigDecimal quantity) {
        return price.multiply(quantity);
    }
}
