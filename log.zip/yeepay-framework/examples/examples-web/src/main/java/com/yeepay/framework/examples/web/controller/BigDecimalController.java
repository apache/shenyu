package com.yeepay.framework.examples.web.controller;

import com.yeepay.framework.examples.web.model.BigDecimalRequest;
import com.yeepay.framework.examples.web.service.WebExampleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Map;

/**
 * BigDecimal 安全校验测试控制器.
 *
 * <p>覆盖:
 * <ul>
 *   <li>JSON body 中的 BigDecimal 反序列化校验 (Jackson BigDecimalDeserializer)</li>
 *   <li>Query parameter 中的 BigDecimal 转换校验 (BigDecimalConverter)</li>
 *   <li>Form data 中的 BigDecimal 转换校验 (BigDecimalConverter)</li>
 *   <li>超大数字攻击防护 (超长字符串 / 超大指数)</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/bigdecimal")
@RequiredArgsConstructor
public class BigDecimalController {

    private final WebExampleService service;

    // ==================== JSON Body ====================

    @PostMapping("/json")
    public Map<String, Object> jsonBody(@Valid @RequestBody BigDecimalRequest request) {
        BigDecimal total = service.calculateTotal(request.getPrice(), request.getAmount());
        return Map.of("amount", request.getAmount(), "price", request.getPrice(), "total", total);
    }

    // ==================== Query Parameter ====================

    @GetMapping("/query")
    public Map<String, Object> queryParam(@RequestParam BigDecimal amount, @RequestParam(defaultValue = "1.0") BigDecimal price) {
        BigDecimal total = service.calculateTotal(price, amount);
        return Map.of("amount", amount, "price", price, "total", total);
    }

    // ==================== Form Data (@ModelAttribute) ====================

    @GetMapping("/form")
    public Map<String, Object> formData(@ModelAttribute BigDecimalRequest request) {
        BigDecimal price = request.getPrice() != null ? request.getPrice() : BigDecimal.ONE;
        BigDecimal amount = request.getAmount() != null ? request.getAmount() : BigDecimal.ZERO;
        return Map.of("amount", amount, "price", price, "total", service.calculateTotal(price, amount));
    }

    // ==================== PathVariable BigDecimal ====================

    @GetMapping("/path/{amount}")
    public Map<String, Object> pathVariable(@PathVariable BigDecimal amount) {
        return Map.of("amount", amount, "doubled", amount.multiply(new BigDecimal("2")));
    }

    // ==================== 安全边界测试 ====================

    /** 正常数值 —— 应通过 */
    @GetMapping("/normal")
    public Map<String, Object> normalValue(@RequestParam(defaultValue = "123.45") BigDecimal value) {
        return Map.of("value", value);
    }

    /** 科学计数法合法值 —— e3 在 exponent=5 范围内 */
    @GetMapping("/scientific-ok")
    public Map<String, Object> scientificOk(@RequestParam(defaultValue = "5e3") BigDecimal value) {
        return Map.of("value", value);
    }
}
