package com.yeepay.framework.examples.web.enums;

/**
 * 订单状态枚举 —— 用于 {@code @ValidBy} 注解示例.
 */
public enum OrderStatus {
    PENDING,
    CONFIRMED,
    SHIPPED,
    DELIVERED,
    CANCELLED;

    /**
     * 校验方法，供 {@code @ValidBy(clazz = OrderStatus.class, method = "isValid")} 调用.
     */
    public static boolean isValid(String value) {
        if (value == null || value.isBlank()) {
            return true;
        }
        try {
            OrderStatus.valueOf(value.toUpperCase());
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
