package com.yeepay.framework.examples.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Web模块示例 —— 覆盖 ThreadContextFilter / Result / Response / 异常处理 / 校验注解 / BigDecimal安全校验.
 */
@SpringBootApplication
public class WebExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebExampleApplication.class, args);
    }
}
