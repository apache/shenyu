package com.yeepay.framework.examples.web.controller;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorCodeWrapper;
import com.yeepay.framework.web.error.ErrorInfoEntity;
import com.yeepay.framework.web.error.ErrorInfoSimple;
import com.yeepay.framework.web.exception.InvalidUriException;
import com.yeepay.framework.web.response.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Response / ErrorCode / 异常处理 测试控制器.
 *
 * <p>覆盖:
 * <ul>
 *   <li>{@link Response} 接口 —— success / failure 工厂方法</li>
 *   <li>{@link ErrorCode} 接口 —— getKey / getMessage / createException</li>
 *   <li>{@link ErrorCodeWrapper} —— 自定义错误码包装</li>
 *   <li>{@link ErrorInfoSimple} / {@link ErrorInfoEntity} —— 错误信息实体</li>
 *   <li>{@link CommonError} —— 完整 HTTP 错误码枚举</li>
 *   <li>{@link InvalidUriException}</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/response")
public class ResponseController {

    // ==================== Response<T> 成功 ====================

    @GetMapping("/success")
    public Response<Map<String, String>> success() {
        return Response.success(Map.of("key", "value"));
    }

    @GetMapping("/success-data")
    public Response<String> successData() {
        return Response.success("hello");
    }

    @GetMapping("/success-void")
    public Response<Void> successVoid() {
        return Response.success();
    }

    // ==================== Response<T> 失败 ====================

    @GetMapping("/failure-error-code")
    public Response<Void> failureByErrorCode() {
        return Response.failure(CommonError.BAD_REQUEST);
    }

    @GetMapping("/failure-error-info")
    public Response<Void> failureByErrorInfo() {
        return Response.failure(new ErrorInfoSimple(CommonError.NOT_FOUND));
    }

    @GetMapping("/failure-code-int")
    public Response<Void> failureByIntCode() {
        return Response.failure(500);
    }

    @GetMapping("/failure-code-message")
    public Response<String> failureCodeWithMessage() {
        return Response.failure(400, "参数错误", "detail-info");
    }

    // ==================== ErrorCode 功能 ====================

    @GetMapping("/error-code-demo")
    public Map<String, Object> errorCodeDemo() {
        ErrorCode code = CommonError.BAD_REQUEST;
        return Map.of(
                "code", code.getCode(),
                "key", code.getKey(),
                "message", code.getMessage()
        );
    }

    @GetMapping("/error-code-all")
    public Map<String, Object> errorCodeAll() {
        var map = new java.util.LinkedHashMap<String, Object>();
        for (CommonError error : CommonError.values()) {
            map.put(error.name(), Map.of("code", error.getCode(), "key", error.getKey()));
        }
        return map;
    }

    // ==================== ErrorCodeWrapper ====================

    @GetMapping("/error-code-wrapper")
    public Map<String, Object> errorCodeWrapper() {
        ErrorCodeWrapper wrapper = new ErrorCodeWrapper(999, "custom.error", "自定义错误消息");
        return Map.of(
                "code", wrapper.getCode(),
                "key", wrapper.getKey(),
                "message", wrapper.getMessage(),
                "resolvedMessage", wrapper.getResolvedMessage()
        );
    }

    @GetMapping("/error-code-wrapper-resolved")
    public Map<String, Object> errorCodeWrapperResolved() {
        ErrorCodeWrapper wrapper = new ErrorCodeWrapper(CommonError.OPERATE_ERROR, "custom.key", "已解析的消息");
        return Map.of(
                "code", wrapper.getCode(),
                "key", wrapper.getKey(),
                "resolvedMessage", wrapper.getResolvedMessage()
        );
    }

    // ==================== ErrorInfo 系列 ====================

    @GetMapping("/error-info-simple")
    public Map<String, Object> errorInfoSimple() {
        ErrorInfoSimple info = new ErrorInfoSimple(CommonError.GONE);
        return Map.of(
                "code", info.getCode().getCode(),
                "key", info.getCode().getKey(),
                "messageCodes", (Object) info.getMessageCodes()
        );
    }

    @GetMapping("/error-info-entity")
    public Map<String, Object> errorInfoEntity() {
        ErrorInfoEntity entity = new ErrorInfoEntity(CommonError.INTERNAL_SERVER_ERROR, new RuntimeException("cause"));
        return Map.of(
                "code", entity.getCode().getCode(),
                "key", entity.getCode().getKey(),
                "messageCodes", (Object) entity.getMessageCodes(),
                "detail", entity.getDetail()
        );
    }

    // ==================== InvalidUriException ====================

    @GetMapping("/invalid-uri")
    public String invalidUri(HttpServletRequest request) {
        throw new InvalidUriException(request);
    }

    // ==================== CommonError.getByCode ====================

    @GetMapping("/common-error-by-code/{code}")
    public Map<String, Object> commonErrorByCode(@org.springframework.web.bind.annotation.PathVariable int code) {
        CommonError error = CommonError.getByCode(code);
        if (error == null) {
            return Map.of("found", false);
        }
        return Map.of("found", true, "name", error.name(), "code", error.getCode(), "key", error.getKey());
    }
}
