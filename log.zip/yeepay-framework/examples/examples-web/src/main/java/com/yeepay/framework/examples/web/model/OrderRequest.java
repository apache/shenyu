package com.yeepay.framework.examples.web.model;

import com.yeepay.framework.examples.web.enums.OrderStatus;
import com.yeepay.framework.web.annotation.ValidBy;
import com.yeepay.framework.web.annotation.Xss;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/**
 * XSS + @ValidBy 校验测试请求体.
 */
public class OrderRequest {

    @Xss(level = Xss.Level.SIMPLE_TEXT, message = "订单备注包含非法字符")
    private String remark;

    @NotBlank
    @Xss(level = Xss.Level.NONE, message = "订单名称不能包含HTML")
    private String orderName;

    @ValidBy(clazz = OrderStatus.class, method = "isValid", message = "{order.status.invalid}")
    private String status;

    @Positive
    private Long amount;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }
}
