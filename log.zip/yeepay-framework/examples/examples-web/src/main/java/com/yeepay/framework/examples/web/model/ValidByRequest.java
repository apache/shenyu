package com.yeepay.framework.examples.web.model;

import com.yeepay.framework.examples.web.enums.OrderStatus;
import com.yeepay.framework.web.annotation.ValidBy;

/**
 * @ValidBy 自定义校验方法测试请求体.
 */
public class ValidByRequest {

    @ValidBy(clazz = OrderStatus.class, method = "isValid", message = "订单状态不合法")
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
