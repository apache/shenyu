package com.yeepay.framework.examples.web.controller;

import com.yeepay.framework.examples.web.enums.OrderStatus;
import com.yeepay.framework.examples.web.model.OrderRequest;
import com.yeepay.framework.examples.web.model.ValidationRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.Map;

/**
 * MvcExceptionHandler 异常触发测试控制器.
 *
 * <p>精确触发每一个 {@link com.yeepay.framework.web.handler.MvcExceptionHandler} 定义的异常处理分支，
 * 验证 ParamErrorInfo 的消息码解析和 i18n 国际化。
 *
 * <p>同时也覆盖 {@link com.yeepay.framework.web.handler.ApplicationExceptionHandler}
 * 的兜底处理逻辑。
 */
@RestController
@RequestMapping("/api/exception")
public class ExceptionController {

    // ==================== MethodArgumentNotValidException —— @Valid 字段校验失败 ====================

    @PostMapping("/validation-failed")
    public Map<String, Object> validationFailed(@Valid @RequestBody ValidationRequest request) {
        return Map.of("amount", request.getAmount(), "orderName", request.getOrderName());
    }

    // ==================== MissingServletRequestParameterException —— 缺少必需参数 ====================

    @GetMapping("/missing-param")
    public Map<String, Object> missingParam(@RequestParam String requiredParam) {
        return Map.of("requiredParam", requiredParam);
    }

    // ==================== MethodArgumentTypeMismatchException —— 参数类型不匹配 ====================

    @GetMapping("/type-mismatch")
    public Map<String, Object> typeMismatch(@RequestParam Integer count) {
        return Map.of("count", count);
    }

    @GetMapping("/type-mismatch-bigdecimal")
    public Map<String, Object> typeMismatchBigDecimal(@RequestParam BigDecimal amount) {
        return Map.of("amount", amount);
    }

    // ==================== HttpMessageNotReadableException —— JSON 解析失败 ====================

    @PostMapping("/unreadable-json")
    public Map<String, Object> unreadableJson(@RequestBody OrderRequest request) {
        return Map.of("orderName", request.getOrderName());
    }

    // ==================== HttpRequestMethodNotSupportedException —— 请求方法不支持 ====================

    @RequestMapping(value = "/method-not-supported", method = RequestMethod.POST)
    public Map<String, Object> methodNotSupported() {
        return Map.of("ok", true);
    }

    // ==================== NoHandlerFoundException —— 404 ====================
    // Spring MVC 默认不抛 NoHandlerFoundException，需要在 application.yml 中配置:
    // spring.web.resources.add-mappings=false
    // spring.mvc.throw-exception-if-no-handler-found=true

    // ==================== BigDecimal 反序列化安全异常 (BigDecimalSafetyValidator) ====================

    @PostMapping("/bigdecimal-overflow")
    public Map<String, Object> bigDecimalOverflow(@RequestBody Map<String, BigDecimal> body) {
        return Map.of("value", body.get("value"));
    }

    // ==================== 普通 RuntimeException (ApplicationExceptionHandler 兜底) ====================

    @GetMapping("/runtime-exception")
    public Map<String, Object> runtimeException() {
        throw new RuntimeException("模拟未预期的运行时异常");
    }

    // ==================== NumberFormatException ====================

    @GetMapping("/number-format")
    public Map<String, Object> numberFormat(@RequestParam String value) {
        return Map.of("parsed", Long.parseLong(value));
    }

    // ==================== MaxUploadSizeExceededException —— 文件过大 ====================

    @PostMapping("/upload")
    public Map<String, Object> upload(@RequestParam MultipartFile file) {
        return Map.of("fileName", file.getOriginalFilename(), "size", file.getSize());
    }

    // ==================== Enum 校验失败 (会进入 MethodArgumentTypeMismatchException 分支) ====================

    @GetMapping("/enum/{status}")
    public Map<String, Object> enumValidation(@PathVariable String status) {
       OrderStatus s = OrderStatus.valueOf(status.toUpperCase());
        return Map.of("status", s.name());
    }
}
