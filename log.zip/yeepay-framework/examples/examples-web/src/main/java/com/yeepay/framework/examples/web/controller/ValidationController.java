package com.yeepay.framework.examples.web.controller;

import com.yeepay.framework.examples.web.enums.OrderStatus;
import com.yeepay.framework.examples.web.model.OrderRequest;
import com.yeepay.framework.examples.web.model.ValidByRequest;
import com.yeepay.framework.examples.web.model.XssTestRequest;
import com.yeepay.framework.web.annotation.ValidBy;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 参数校验测试控制器.
 *
 * <p>覆盖:
 * <ul>
 *   <li>{@code @Xss} —— 6个 XSS 防护级别 (NONE / SIMPLE_TEXT / BASIC / BASIC_WITH_IMAGES / RELAXED / HUOBI)</li>
 *   <li>{@code @ValidBy} —— 通用静态方法委托校验</li>
 *   <li>{@code @Valid} —— Jakarta Validation 集成</li>
 *   <li>{@code MethodArgumentNotValidException} 异常处理</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/validation")
public class ValidationController {

    // ==================== @Xss 注解 ====================

    @PostMapping("/order")
    public Map<String, Object> createOrder(@Valid @RequestBody OrderRequest request) {
        return Map.of(
                "orderName", request.getOrderName(),
                "remark", request.getRemark(),
                "status", request.getStatus(),
                "amount", request.getAmount()
        );
    }

    // ==================== @Xss 多级别测试 ====================

    @PostMapping("/xss/all-levels")
    public Map<String, Object> xssAllLevels(@Valid @RequestBody XssTestRequest request) {
        return Map.of(
                "noneLevel", String.valueOf(request.getNoneLevel()),
                "simpleTextLevel", String.valueOf(request.getSimpleTextLevel()),
                "basicLevel", String.valueOf(request.getBasicLevel()),
                "basicWithImagesLevel", String.valueOf(request.getBasicWithImagesLevel()),
                "relaxedLevel", String.valueOf(request.getRelaxedLevel()),
                "huobiLevel", String.valueOf(request.getHuobiLevel())
        );
    }

    @GetMapping("/xss/query")
    public Map<String, Object> xssQueryParam(
            @RequestParam @com.yeepay.framework.web.annotation.Xss(level = com.yeepay.framework.web.annotation.Xss.Level.SIMPLE_TEXT) String text) {
        return Map.of("text", text);
    }

    // ==================== @ValidBy 注解 ====================

    @PostMapping("/valid-by")
    public Map<String, Object> validByStatus(@Valid @RequestBody ValidByRequest request) {
        return Map.of("status", request.getStatus());
    }

    @GetMapping("/valid-by/query")
    public Map<String, Object> validByQuery(
            @RequestParam
            @ValidBy(clazz = OrderStatus.class, method = "isValid", message = "订单状态不合法")
            String status) {
        return Map.of("status", status);
    }
}
