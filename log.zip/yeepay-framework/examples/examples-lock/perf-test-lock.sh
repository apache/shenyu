#!/bin/bash
# ============================================================================
# Yeepay Distributed Lock Framework - Performance Test Script (Redisson)
#
# Usage:
#   bash perf-test-lock.sh [base_url]
#
# Default base_url: http://localhost:8080
#
# Prerequisites:
#   1. Start Redis: redis-server (default 127.0.0.1:6379)
#   2. Build the project:
#      mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip
#   3. Start the example service (Redisson profile):
#      mvn spring-boot:run -pl examples/examples-lock
#
# Test Dimensions:
#   - Single-request lock acquisition latency (serial)
#   - Same-key contention throughput (lock serialization)
#   - Different-key concurrent throughput (lock parallelism)
#   - Lock type comparison (REENTRANT vs FAIR)
#   - Read/Write lock concurrency
#   - tryLock failure rate under contention
#   - High-concurrency stress test (correctness & throughput)
# ============================================================================

set -euo pipefail

BASE_URL="${1:-http://localhost:8080}"

# Test parameters
SERIAL_COUNT=100                       # serial iterations
CONTENTION_LEVELS=(5 10 20 50 100)     # concurrency levels for same-key tests
PARALLEL_KEY_WORKERS=50                # workers for different-key throughput
PARALLEL_KEY_REQS_PER_WORKER=20        # requests per worker (different keys)
RW_READ_WORKERS=20                     # concurrent read-lock workers
STRESS_WORKERS=100                     # stress test concurrent workers
STRESS_SLEEP_MS=10                     # minimal business sleep for throughput focus
TRYLOCK_CONTENTION_LEVELS=(10 30 50 100)

# Temp directory
WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

# ---- Portable nanosecond timer ----------------------------------------------
if [[ "$(date +%s%N)" == *N ]]; then
    now_ns() { python3 -c 'import time; print(int(time.time()*1e9))'; }
else
    now_ns() { date +%s%N; }
fi

# ---- Colors & helpers -------------------------------------------------------
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

pass() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    PASS_COUNT=$((PASS_COUNT + 1))
    echo -e "  ${GREEN}[PASS]${NC} $1"
}

fail() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    FAIL_COUNT=$((FAIL_COUNT + 1))
    echo -e "  ${RED}[FAIL]${NC} $1"
}

info() {
    echo -e "  ${CYAN}[INFO]${NC} $1"
}

section() {
    echo ""
    echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}  $1${NC}"
    echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "  ${YELLOW}$2${NC}"
}

percentile() {
    local file="$1"
    local pct="$2"
    local total
    total=$(wc -l < "$file" | tr -d ' ')
    local idx=$(( (total * pct + 99) / 100 ))
    [ "$idx" -lt 1 ] && idx=1
    sed -n "${idx}p" "$file"
}

# ---- Pre-flight check -------------------------------------------------------
echo -e "${BOLD}╔═════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║  Yeepay Distributed Lock - Performance Test (Redisson) ║${NC}"
echo -e "${BOLD}╚═════════════════════════════════════════════════════════╝${NC}"
echo -e "  Target: $BASE_URL"
echo -e "  Date:   $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

echo -n "  Checking service availability... "
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE_URL/lock/annotation/order/health-check" 2>/dev/null || true)
if [ "$HTTP_CODE" != "200" ]; then
    echo -e "${RED}FAILED (HTTP $HTTP_CODE)${NC}"
    echo "  Cannot connect to $BASE_URL. Please start the service first:"
    echo "    mvn spring-boot:run -pl examples/examples-lock"
    exit 1
fi
echo -e "${GREEN}OK${NC}"

# Warm up
echo -n "  Warming up (30 requests)... "
for _i in $(seq 1 30); do
    curl -s "$BASE_URL/lock/annotation/order/warmup-$_i" > /dev/null &
done
wait
echo -e "${GREEN}done${NC}"

# =============================================================================
# TEST 1: Serial Lock Acquisition Latency
# =============================================================================
section "TEST 1: Serial Lock Acquisition Latency" \
    "$SERIAL_COUNT sequential requests — measuring per-request lock overhead"

LATENCY_FILE="$WORK_DIR/serial_latencies.txt"
: > "$LATENCY_FILE"

START_NS=$(now_ns)
for i in $(seq 1 "$SERIAL_COUNT"); do
    REQ_START=$(now_ns)
    curl -s "$BASE_URL/lock/annotation/order/serial-$i" > /dev/null
    REQ_END=$(now_ns)
    ELAPSED_US=$(( (REQ_END - REQ_START) / 1000 ))
    echo "$ELAPSED_US" >> "$LATENCY_FILE"
done
END_NS=$(now_ns)

TOTAL_MS=$(( (END_NS - START_NS) / 1000000 ))
TOTAL_SEC_X100=$(( (END_NS - START_NS) / 10000000 ))
if [ "$TOTAL_SEC_X100" -gt 0 ]; then
    TPS_SERIAL=$(( SERIAL_COUNT * 100 * 100 / TOTAL_SEC_X100 ))
else
    TPS_SERIAL=999999
fi

sort -n "$LATENCY_FILE" > "$WORK_DIR/sorted_serial.txt"
AVG_US=$(awk '{s+=$1} END {printf "%.0f", s/NR}' "$LATENCY_FILE")
MIN_US=$(head -1 "$WORK_DIR/sorted_serial.txt")
MAX_US=$(tail -1 "$WORK_DIR/sorted_serial.txt")
P50=$(percentile "$WORK_DIR/sorted_serial.txt" 50)
P95=$(percentile "$WORK_DIR/sorted_serial.txt" 95)
P99=$(percentile "$WORK_DIR/sorted_serial.txt" 99)

info "Total time:  ${TOTAL_MS} ms"
info "Throughput:  ~${TPS_SERIAL} req/s (serial, different keys)"
info "Latency:     avg=${AVG_US}us  min=${MIN_US}us  max=${MAX_US}us"
info "Percentiles: p50=${P50}us  p95=${P95}us  p99=${P99}us"
pass "serial lock latency measured ($SERIAL_COUNT requests)"

# =============================================================================
# TEST 2: Same-Key Contention (Lock Serialization)
# =============================================================================
section "TEST 2: Same-Key Contention (Lock Serialization)" \
    "Concurrent requests on SAME key — lock forces serialization. sleepMs=${STRESS_SLEEP_MS}ms"

echo ""
printf "  ${BOLD}%-12s  %-12s  %-12s  %-14s  %-10s${NC}\n" "Workers" "Total(ms)" "Avg(ms/req)" "Throughput" "Success"
printf "  %-12s  %-12s  %-12s  %-14s  %-10s\n"     "-------" "--------" "----------" "----------" "-------"

for LEVEL in "${CONTENTION_LEVELS[@]}"; do
    CONC_DIR="$WORK_DIR/contention_${LEVEL}"
    mkdir -p "$CONC_DIR"

    CONC_START=$(now_ns)
    for w in $(seq 1 "$LEVEL"); do
        curl -s -o "$CONC_DIR/body_$w" -w '%{http_code}' \
            "$BASE_URL/lock/annotation/contention/PERF-SAME-KEY?sleepMs=$STRESS_SLEEP_MS" \
            > "$CONC_DIR/code_$w" &
    done
    wait
    CONC_END=$(now_ns)

    CONC_MS=$(( (CONC_END - CONC_START) / 1000000 ))
    SUCCESS=0
    FAILED=0
    for w in $(seq 1 "$LEVEL"); do
        CODE=$(cat "$CONC_DIR/code_$w" 2>/dev/null)
        if [ "$CODE" = "200" ]; then
            SUCCESS=$((SUCCESS + 1))
        else
            FAILED=$((FAILED + 1))
        fi
    done

    if [ "$CONC_MS" -gt 0 ]; then
        AVG_PER_REQ=$(( CONC_MS * 1000 / LEVEL ))
        AVG_PER_REQ_MS=$(( AVG_PER_REQ / 1000 ))
        CONC_TPS=$(( SUCCESS * 1000 / CONC_MS ))
    else
        AVG_PER_REQ_MS=0
        CONC_TPS=999999
    fi

    printf "  %-12s  %-12s  %-12s  %-14s  %-10s\n" \
        "$LEVEL" "${CONC_MS}ms" "${AVG_PER_REQ_MS}ms" "~${CONC_TPS} req/s" "${SUCCESS}/${LEVEL}"
done

echo ""
info "Same-key locks serialize access — total time scales linearly with concurrency"
TOTAL_TESTS=$((TOTAL_TESTS + 1))
PASS_COUNT=$((PASS_COUNT + 1))
echo -e "  ${GREEN}[PASS]${NC} same-key contention measured at ${#CONTENTION_LEVELS[@]} concurrency levels"

# =============================================================================
# TEST 3: Different-Key Concurrent Throughput (Lock Parallelism)
# =============================================================================
DIFF_KEY_TOTAL=$((PARALLEL_KEY_WORKERS * PARALLEL_KEY_REQS_PER_WORKER))
section "TEST 3: Different-Key Concurrent Throughput" \
    "$PARALLEL_KEY_WORKERS workers x $PARALLEL_KEY_REQS_PER_WORKER reqs = $DIFF_KEY_TOTAL total (each uses unique key)"

DIFF_DIR="$WORK_DIR/diff_keys"
mkdir -p "$DIFF_DIR"

DIFF_START=$(now_ns)
for w in $(seq 1 "$PARALLEL_KEY_WORKERS"); do
    (
        for r in $(seq 1 "$PARALLEL_KEY_REQS_PER_WORKER"); do
            HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' \
                "$BASE_URL/lock/annotation/order/perf-w${w}-r${r}")
            echo "$HTTP_CODE"
        done > "$DIFF_DIR/worker_${w}.txt"
    ) &
done
wait
DIFF_END=$(now_ns)

DIFF_MS=$(( (DIFF_END - DIFF_START) / 1000000 ))
DIFF_SEC_X100=$(( (DIFF_END - DIFF_START) / 10000000 ))

ALL_DIFF="$WORK_DIR/all_diff_codes.txt"
cat "$DIFF_DIR"/worker_*.txt > "$ALL_DIFF"
DIFF_SUCCESS=$(grep -c '200' "$ALL_DIFF" || true)
DIFF_FAILED=$(grep -cv '200' "$ALL_DIFF" || true)

if [ "$DIFF_SEC_X100" -gt 0 ]; then
    DIFF_TPS=$(( DIFF_SUCCESS * 100 * 100 / DIFF_SEC_X100 ))
else
    DIFF_TPS=999999
fi

info "Total time:     ${DIFF_MS} ms"
info "Success:        ${DIFF_SUCCESS} / ${DIFF_KEY_TOTAL}"
info "Failed:         ${DIFF_FAILED}"
info "Throughput:     ~${DIFF_TPS} req/s (different keys, parallel)"

if [ "$DIFF_SUCCESS" -eq "$DIFF_KEY_TOTAL" ]; then
    pass "all $DIFF_KEY_TOTAL different-key requests succeeded"
else
    if [ "$DIFF_SUCCESS" -gt $(( DIFF_KEY_TOTAL * 90 / 100 )) ]; then
        pass "${DIFF_SUCCESS}/${DIFF_KEY_TOTAL} succeeded (>90%)"
    else
        fail "only ${DIFF_SUCCESS}/${DIFF_KEY_TOTAL} succeeded"
    fi
fi

# =============================================================================
# TEST 4: Lock Type Comparison (REENTRANT vs FAIR)
# =============================================================================
section "TEST 4: Lock Type Comparison" \
    "Serial latency: REENTRANT lock vs FAIR lock (50 requests each)"

LOCK_TYPE_COUNT=50

# REENTRANT lock
REENTRANT_FILE="$WORK_DIR/reentrant_latencies.txt"
: > "$REENTRANT_FILE"
for i in $(seq 1 "$LOCK_TYPE_COUNT"); do
    REQ_START=$(now_ns)
    curl -s "$BASE_URL/lock/annotation/order/type-reentrant-$i" > /dev/null
    REQ_END=$(now_ns)
    echo $(( (REQ_END - REQ_START) / 1000 )) >> "$REENTRANT_FILE"
done

sort -n "$REENTRANT_FILE" > "$WORK_DIR/sorted_reentrant.txt"
REENTRANT_AVG=$(awk '{s+=$1} END {printf "%.0f", s/NR}' "$REENTRANT_FILE")
REENTRANT_P50=$(percentile "$WORK_DIR/sorted_reentrant.txt" 50)
REENTRANT_P99=$(percentile "$WORK_DIR/sorted_reentrant.txt" 99)

# FAIR lock
FAIR_FILE="$WORK_DIR/fair_latencies.txt"
: > "$FAIR_FILE"
for i in $(seq 1 "$LOCK_TYPE_COUNT"); do
    REQ_START=$(now_ns)
    curl -s "$BASE_URL/lock/annotation/fair/type-fair-$i" > /dev/null
    REQ_END=$(now_ns)
    echo $(( (REQ_END - REQ_START) / 1000 )) >> "$FAIR_FILE"
done

sort -n "$FAIR_FILE" > "$WORK_DIR/sorted_fair.txt"
FAIR_AVG=$(awk '{s+=$1} END {printf "%.0f", s/NR}' "$FAIR_FILE")
FAIR_P50=$(percentile "$WORK_DIR/sorted_fair.txt" 50)
FAIR_P99=$(percentile "$WORK_DIR/sorted_fair.txt" 99)

echo ""
printf "  ${BOLD}%-14s  %-14s  %-14s  %-14s${NC}\n" "Lock Type" "Avg(us)" "P50(us)" "P99(us)"
printf "  %-14s  %-14s  %-14s  %-14s\n"             "---------" "------" "------" "------"
printf "  %-14s  %-14s  %-14s  %-14s\n" "REENTRANT" "$REENTRANT_AVG" "$REENTRANT_P50" "$REENTRANT_P99"
printf "  %-14s  %-14s  %-14s  %-14s\n" "FAIR" "$FAIR_AVG" "$FAIR_P50" "$FAIR_P99"
echo ""

pass "lock type comparison measured (REENTRANT vs FAIR)"

# =============================================================================
# TEST 5: Read/Write Lock Concurrency
# =============================================================================
section "TEST 5: Read/Write Lock Concurrency" \
    "READ locks should allow concurrency, WRITE lock serializes"

# 5a: Concurrent reads — should complete nearly simultaneously
RW_DIR="$WORK_DIR/rw_test"
mkdir -p "$RW_DIR"

READ_START=$(now_ns)
for w in $(seq 1 "$RW_READ_WORKERS"); do
    curl -s -o "$RW_DIR/read_body_$w" -w '%{http_code}' \
        "$BASE_URL/lock/annotation/config/read/perf-rw-key" \
        > "$RW_DIR/read_code_$w" &
done
wait
READ_END=$(now_ns)
READ_MS=$(( (READ_END - READ_START) / 1000000 ))

READ_SUCCESS=0
for w in $(seq 1 "$RW_READ_WORKERS"); do
    CODE=$(cat "$RW_DIR/read_code_$w" 2>/dev/null)
    [ "$CODE" = "200" ] && READ_SUCCESS=$((READ_SUCCESS + 1))
done

info "${RW_READ_WORKERS} concurrent READ locks completed in ${READ_MS}ms (${READ_SUCCESS} succeeded)"

# 5b: Concurrent writes — should serialize
WRITE_WORKERS=10
WRITE_START=$(now_ns)
for w in $(seq 1 "$WRITE_WORKERS"); do
    curl -s -o "$RW_DIR/write_body_$w" -w '%{http_code}' \
        "$BASE_URL/lock/annotation/config/write/perf-rw-key?value=val-$w" \
        > "$RW_DIR/write_code_$w" &
done
wait
WRITE_END=$(now_ns)
WRITE_MS=$(( (WRITE_END - WRITE_START) / 1000000 ))

WRITE_SUCCESS=0
for w in $(seq 1 "$WRITE_WORKERS"); do
    CODE=$(cat "$RW_DIR/write_code_$w" 2>/dev/null)
    [ "$CODE" = "200" ] && WRITE_SUCCESS=$((WRITE_SUCCESS + 1))
done

info "${WRITE_WORKERS} concurrent WRITE locks completed in ${WRITE_MS}ms (${WRITE_SUCCESS} succeeded)"

# 5c: Mixed read+write — reads should be slower when writes are interleaved
MIXED_START=$(now_ns)
for w in $(seq 1 10); do
    curl -s -o /dev/null "$BASE_URL/lock/annotation/config/read/perf-mixed-key" &
done
for w in $(seq 1 3); do
    curl -s -o /dev/null "$BASE_URL/lock/annotation/config/write/perf-mixed-key?value=mixed-$w" &
done
wait
MIXED_END=$(now_ns)
MIXED_MS=$(( (MIXED_END - MIXED_START) / 1000000 ))

info "Mixed 10 READs + 3 WRITEs completed in ${MIXED_MS}ms"

echo ""
printf "  ${BOLD}%-24s  %-14s  %-10s${NC}\n" "Scenario" "Time(ms)" "Success"
printf "  %-24s  %-14s  %-10s\n"             "--------" "-------" "-------"
printf "  %-24s  %-14s  %-10s\n" "${RW_READ_WORKERS} concurrent READs"  "${READ_MS}ms"  "${READ_SUCCESS}/${RW_READ_WORKERS}"
printf "  %-24s  %-14s  %-10s\n" "${WRITE_WORKERS} concurrent WRITEs" "${WRITE_MS}ms" "${WRITE_SUCCESS}/${WRITE_WORKERS}"
printf "  %-24s  %-14s  %-10s\n" "10 READs + 3 WRITEs"   "${MIXED_MS}ms" "—"
echo ""

if [ "$READ_MS" -lt "$WRITE_MS" ] || [ "$READ_SUCCESS" -eq "$RW_READ_WORKERS" ]; then
    pass "READ locks allow higher concurrency than WRITE locks"
else
    info "READ and WRITE latencies similar — may depend on business sleep times"
    pass "Read/Write lock test completed"
fi

# =============================================================================
# TEST 6: tryLock Failure Rate Under Contention
# =============================================================================
section "TEST 6: tryLock Failure Rate Under Contention" \
    "Concurrent tryLock on SAME key — measuring lock acquisition vs rejection rate"

echo ""
printf "  ${BOLD}%-12s  %-12s  %-12s  %-14s  %-12s${NC}\n" \
    "Workers" "Acquired" "Rejected" "Acquire Rate" "Time(ms)"
printf "  %-12s  %-12s  %-12s  %-14s  %-12s\n" \
    "-------" "--------" "--------" "------------" "-------"

for LEVEL in "${TRYLOCK_CONTENTION_LEVELS[@]}"; do
    TRY_DIR="$WORK_DIR/trylock_${LEVEL}"
    mkdir -p "$TRY_DIR"

    TRY_START=$(now_ns)
    for w in $(seq 1 "$LEVEL"); do
        (
            HTTP_CODE=$(curl -s -o "$TRY_DIR/body_$w" -w '%{http_code}' \
                "$BASE_URL/lock/manager/trylock/PERF-TRYLOCK-KEY")
            echo "$HTTP_CODE" > "$TRY_DIR/code_$w"
        ) &
    done
    wait
    TRY_END=$(now_ns)

    TRY_MS=$(( (TRY_END - TRY_START) / 1000000 ))
    ACQUIRED=0
    REJECTED=0
    for w in $(seq 1 "$LEVEL"); do
        CODE=$(cat "$TRY_DIR/code_$w" 2>/dev/null)
        BODY=$(cat "$TRY_DIR/body_$w" 2>/dev/null)
        if [ "$CODE" = "200" ] && echo "$BODY" | grep -q "processed"; then
            ACQUIRED=$((ACQUIRED + 1))
        else
            REJECTED=$((REJECTED + 1))
        fi
    done

    if [ "$LEVEL" -gt 0 ]; then
        RATE=$(( ACQUIRED * 100 / LEVEL ))
    else
        RATE=0
    fi

    printf "  %-12s  %-12s  %-12s  %-14s  %-12s\n" \
        "$LEVEL" "$ACQUIRED" "$REJECTED" "${RATE}%" "${TRY_MS}ms"

    sleep 0.5
done

echo ""
pass "tryLock contention measured at ${#TRYLOCK_CONTENTION_LEVELS[@]} concurrency levels"

# =============================================================================
# TEST 7: High-Concurrency Stress Test (Correctness)
# =============================================================================
section "TEST 7: High-Concurrency Stress Test" \
    "$STRESS_WORKERS concurrent requests on SAME key — verifying lock correctness (counter atomicity)"

STRESS_DIR="$WORK_DIR/stress"
mkdir -p "$STRESS_DIR"

STRESS_START=$(now_ns)
for w in $(seq 1 "$STRESS_WORKERS"); do
    curl -s -o "$STRESS_DIR/body_$w" -w '%{http_code}' \
        "$BASE_URL/lock/annotation/contention/STRESS-KEY?sleepMs=$STRESS_SLEEP_MS" \
        > "$STRESS_DIR/code_$w" &
done
wait
STRESS_END=$(now_ns)

STRESS_MS=$(( (STRESS_END - STRESS_START) / 1000000 ))
STRESS_SUCCESS=0
STRESS_FAIL=0
COUNTER_VALUES="$WORK_DIR/counter_values.txt"
: > "$COUNTER_VALUES"

for w in $(seq 1 "$STRESS_WORKERS"); do
    CODE=$(cat "$STRESS_DIR/code_$w" 2>/dev/null)
    BODY=$(cat "$STRESS_DIR/body_$w" 2>/dev/null)
    if [ "$CODE" = "200" ]; then
        STRESS_SUCCESS=$((STRESS_SUCCESS + 1))
        COUNTER=$(echo "$BODY" | sed -n 's/.*counter=\([0-9]*\).*/\1/p')
        [ -n "$COUNTER" ] && echo "$COUNTER" >> "$COUNTER_VALUES"
    else
        STRESS_FAIL=$((STRESS_FAIL + 1))
    fi
done

info "Total time:   ${STRESS_MS}ms"
info "Success:      ${STRESS_SUCCESS}/${STRESS_WORKERS}"
info "Failed:       ${STRESS_FAIL}"

if [ "$STRESS_MS" -gt 0 ]; then
    STRESS_TPS=$(( STRESS_SUCCESS * 1000 / STRESS_MS ))
    info "Throughput:   ~${STRESS_TPS} req/s (same key, serialized)"
fi

# Check counter uniqueness — if lock works correctly, each counter value should be unique
COUNTER_TOTAL=$(wc -l < "$COUNTER_VALUES" | tr -d ' ')
COUNTER_UNIQUE=$(sort -u "$COUNTER_VALUES" | wc -l | tr -d ' ')

if [ "$COUNTER_TOTAL" -gt 0 ]; then
    if [ "$COUNTER_UNIQUE" -eq "$COUNTER_TOTAL" ]; then
        pass "lock correctness verified — all $COUNTER_TOTAL counter values are unique (no race conditions)"
    else
        DUPS=$((COUNTER_TOTAL - COUNTER_UNIQUE))
        fail "$DUPS duplicate counter values — possible lock failure (race condition detected)"
        echo -e "  ${RED}Duplicate counter values:${NC}"
        sort "$COUNTER_VALUES" | uniq -d | head -10 | while read -r dup; do
            dup_count=$(grep -c "^${dup}$" "$COUNTER_VALUES")
            echo -e "    counter=$dup appeared $dup_count times"
        done
    fi
else
    fail "no counter values collected — all requests may have failed"
fi

# =============================================================================
# TEST 8: Annotation vs Programmatic API Comparison
# =============================================================================
section "TEST 8: Annotation vs Programmatic API Comparison" \
    "50 serial requests each — comparing @YeepayLock annotation vs LockManager API"

API_CMP_COUNT=50

# Annotation API
ANN_FILE="$WORK_DIR/annotation_latencies.txt"
: > "$ANN_FILE"
for i in $(seq 1 "$API_CMP_COUNT"); do
    REQ_START=$(now_ns)
    curl -s "$BASE_URL/lock/annotation/order/api-cmp-ann-$i" > /dev/null
    REQ_END=$(now_ns)
    echo $(( (REQ_END - REQ_START) / 1000 )) >> "$ANN_FILE"
done

sort -n "$ANN_FILE" > "$WORK_DIR/sorted_ann.txt"
ANN_AVG=$(awk '{s+=$1} END {printf "%.0f", s/NR}' "$ANN_FILE")
ANN_P50=$(percentile "$WORK_DIR/sorted_ann.txt" 50)
ANN_P99=$(percentile "$WORK_DIR/sorted_ann.txt" 99)

# Programmatic API
MGR_FILE="$WORK_DIR/manager_latencies.txt"
: > "$MGR_FILE"
for i in $(seq 1 "$API_CMP_COUNT"); do
    REQ_START=$(now_ns)
    curl -s "$BASE_URL/lock/manager/lock/api-cmp-mgr-$i" > /dev/null
    REQ_END=$(now_ns)
    echo $(( (REQ_END - REQ_START) / 1000 )) >> "$MGR_FILE"
done

sort -n "$MGR_FILE" > "$WORK_DIR/sorted_mgr.txt"
MGR_AVG=$(awk '{s+=$1} END {printf "%.0f", s/NR}' "$MGR_FILE")
MGR_P50=$(percentile "$WORK_DIR/sorted_mgr.txt" 50)
MGR_P99=$(percentile "$WORK_DIR/sorted_mgr.txt" 99)

echo ""
printf "  ${BOLD}%-18s  %-14s  %-14s  %-14s${NC}\n" "API Style" "Avg(us)" "P50(us)" "P99(us)"
printf "  %-18s  %-14s  %-14s  %-14s\n"             "---------" "------" "------" "------"
printf "  %-18s  %-14s  %-14s  %-14s\n" "@YeepayLock" "$ANN_AVG" "$ANN_P50" "$ANN_P99"
printf "  %-18s  %-14s  %-14s  %-14s\n" "LockManager" "$MGR_AVG" "$MGR_P50" "$MGR_P99"
echo ""

pass "API style comparison measured (@YeepayLock vs LockManager)"

# =============================================================================
# TEST 9: Sustained Throughput (Different Keys)
# =============================================================================
section "TEST 9: Sustained Throughput (Different Keys)" \
    "Burst of $STRESS_WORKERS concurrent requests, each with unique key — measuring peak throughput"

SUSTAINED_DIR="$WORK_DIR/sustained"
mkdir -p "$SUSTAINED_DIR"

SUSTAINED_START=$(now_ns)
for w in $(seq 1 "$STRESS_WORKERS"); do
    curl -s -o "$SUSTAINED_DIR/body_$w" -w '%{http_code}' \
        "$BASE_URL/lock/manager/lock/sustained-$RANDOM-$w" \
        > "$SUSTAINED_DIR/code_$w" &
done
wait
SUSTAINED_END=$(now_ns)

SUSTAINED_MS=$(( (SUSTAINED_END - SUSTAINED_START) / 1000000 ))
SUSTAINED_SUCCESS=0
for w in $(seq 1 "$STRESS_WORKERS"); do
    CODE=$(cat "$SUSTAINED_DIR/code_$w" 2>/dev/null)
    [ "$CODE" = "200" ] && SUSTAINED_SUCCESS=$((SUSTAINED_SUCCESS + 1))
done

if [ "$SUSTAINED_MS" -gt 0 ]; then
    SUSTAINED_TPS=$(( SUSTAINED_SUCCESS * 1000 / SUSTAINED_MS ))
else
    SUSTAINED_TPS=999999
fi

info "Total time:  ${SUSTAINED_MS}ms"
info "Success:     ${SUSTAINED_SUCCESS}/${STRESS_WORKERS}"
info "Throughput:  ~${SUSTAINED_TPS} req/s (different keys, peak)"

if [ "$SUSTAINED_SUCCESS" -eq "$STRESS_WORKERS" ]; then
    pass "all $STRESS_WORKERS concurrent different-key requests succeeded"
else
    if [ "$SUSTAINED_SUCCESS" -gt $(( STRESS_WORKERS * 90 / 100 )) ]; then
        pass "${SUSTAINED_SUCCESS}/${STRESS_WORKERS} succeeded (>90%)"
    else
        fail "only ${SUSTAINED_SUCCESS}/${STRESS_WORKERS} succeeded"
    fi
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo -e "${BOLD}╔═════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║  Summary                                                       ║${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║${NC}  Total tests:  ${BOLD}$TOTAL_TESTS${NC}"
echo -e "${BOLD}║${NC}  ${GREEN}Passed:       $PASS_COUNT${NC}"
echo -e "${BOLD}║${NC}  ${RED}Failed:       $FAIL_COUNT${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  Performance Metrics (Redisson)                                ║${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║${NC}  Serial latency (avg):         ${AVG_US} us"
echo -e "${BOLD}║${NC}  Serial latency (p50):         ${P50} us"
echo -e "${BOLD}║${NC}  Serial latency (p99):         ${P99} us"
echo -e "${BOLD}║${NC}  Serial throughput:             ~${TPS_SERIAL} req/s"
echo -e "${BOLD}║${NC}  Diff-key throughput:           ~${DIFF_TPS} req/s (${PARALLEL_KEY_WORKERS} workers)"
echo -e "${BOLD}║${NC}  Peak throughput (diff keys):   ~${SUSTAINED_TPS} req/s (${STRESS_WORKERS} concurrent)"
echo -e "${BOLD}║${NC}  Stress test (same key):        ${STRESS_MS}ms for ${STRESS_SUCCESS} requests"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  Lock Type Latency (serial)                                    ║${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║${NC}  REENTRANT:  avg=${REENTRANT_AVG}us  p50=${REENTRANT_P50}us  p99=${REENTRANT_P99}us"
echo -e "${BOLD}║${NC}  FAIR:       avg=${FAIR_AVG}us  p50=${FAIR_P50}us  p99=${FAIR_P99}us"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  API Style Latency (serial)                                    ║${NC}"
echo -e "${BOLD}╠═════════════════════════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║${NC}  @YeepayLock:  avg=${ANN_AVG}us  p50=${ANN_P50}us  p99=${ANN_P99}us"
echo -e "${BOLD}║${NC}  LockManager:  avg=${MGR_AVG}us  p50=${MGR_P50}us  p99=${MGR_P99}us"
echo -e "${BOLD}╚═════════════════════════════════════════════════════════════════╝${NC}"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo -e "  ${GREEN}${BOLD}ALL TESTS PASSED${NC} — Redisson distributed lock performs correctly under concurrency."
else
    echo -e "  ${RED}${BOLD}$FAIL_COUNT TEST(S) FAILED${NC} — check output above for details."
    exit 1
fi
echo ""
