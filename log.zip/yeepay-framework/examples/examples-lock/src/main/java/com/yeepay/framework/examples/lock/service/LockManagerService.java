package com.yeepay.framework.examples.lock.service;

import com.yeepay.framework.lock.api.LockManager;
import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.enums.LockType;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class LockManagerService {

    private final LockManager lockManager;

    private final AtomicInteger counter = new AtomicInteger(0);

    // ==================== lock() 阻塞加锁 ====================

    public String lockSimple(String orderId) {
        final String[] result = new String[1];
        lockManager.lock("order-lock:" + orderId, () -> {
            int current = counter.incrementAndGet();
            log.info("[lock] Processing order: {}, counter: {}", orderId, current);
            simulateBusiness(100);
            result[0] = "Order " + orderId + " processed, counter=" + current;
        });
        return result[0];
    }

    public String lockWithParams(String orderId) {
        final String[] result = new String[1];
        lockManager.lock(
                "order-lock-fair:" + orderId,
                5000,
                LockType.FAIR,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[lock(FAIR)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    result[0] = "Order " + orderId + " processed (FAIR), counter=" + current;
                },
                () -> {
                    log.warn("[lock(FAIR)] Failed to acquire lock for order: {}", orderId);
                    result[0] = "Failed to acquire lock for order " + orderId;
                });
        return result[0];
    }

    public String lockWithSupplier(String orderId) {
        LockEntity entity = LockEntity.builder()
                .keyName("order-lock-supplier:" + orderId)
                .waitTime(3000L)
                .leaseTime(5000L)
                .type(LockType.REENTRANT)
                .build();
        return lockManager.lock(
                entity,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[lock(Supplier)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    return "Order " + orderId + " processed (lock+Supplier), counter=" + current;
                },
                () -> {
                    log.warn("[lock(Supplier)] Failed for order: {}", orderId);
                    return "Failed to acquire lock for order " + orderId;
                });
    }

    public String lockWithEntity(String orderId) {
        LockEntity entity = LockEntity.builder()
                .keyName("order-lock-entity:" + orderId)
                .waitTime(3000L)
                .leaseTime(5000L)
                .type(LockType.REENTRANT)
                .build();
        final String[] result = new String[1];
        lockManager.lock(
                entity,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[lock(Entity)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    result[0] = "Order " + orderId + " processed (lock+Entity), counter=" + current;
                },
                () -> {
                    log.warn("[lock(Entity)] Failed for order: {}", orderId);
                    result[0] = "Failed to acquire lock for order " + orderId;
                });
        return result[0];
    }

    // ==================== tryLock() 非阻塞尝试加锁 ====================

    public String tryLockSimple(String orderId) {
        final String[] result = {"Lock not acquired for order " + orderId};
        lockManager.tryLock("order-trylock:" + orderId, () -> {
            int current = counter.incrementAndGet();
            log.info("[tryLock] Processing order: {}, counter: {}", orderId, current);
            simulateBusiness(100);
            result[0] = "Order " + orderId + " processed (tryLock), counter=" + current;
        });
        return result[0];
    }

    public String tryLockWithParams(String orderId) {
        final String[] result = new String[1];
        lockManager.tryLock(
                "order-trylock-params:" + orderId,
                5000,
                2000,
                LockType.REENTRANT,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[tryLock(params)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    result[0] = "Order " + orderId + " processed (tryLock+params), counter=" + current;
                },
                () -> {
                    log.warn("[tryLock(params)] Failed for order: {}", orderId);
                    result[0] = "Failed to acquire lock for order " + orderId;
                });
        return result[0];
    }

    public String tryLockWithReturn(String orderId) {
        LockEntity entity = LockEntity.builder()
                .keyName("order-trylock-return:" + orderId)
                .waitTime(3000L)
                .leaseTime(5000L)
                .type(LockType.REENTRANT)
                .build();
        return lockManager.tryLock(
                entity,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[tryLock(Supplier)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    return "Order " + orderId + " processed (tryLock+Supplier), counter=" + current;
                },
                () -> {
                    log.warn("[tryLock(Supplier)] Failed for order: {}", orderId);
                    return "Failed to acquire lock for order " + orderId;
                });
    }

    public String tryLockWithReturnParams(String orderId) {
        return lockManager.tryLock(
                "order-trylock-return-params:" + orderId,
                5000,
                2000,
                LockType.REENTRANT,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[tryLock(Supplier+params)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    return "Order " + orderId + " processed (tryLock+Supplier+params), counter=" + current;
                },
                () -> {
                    log.warn("[tryLock(Supplier+params)] Failed for order: {}", orderId);
                    return "Failed to acquire lock for order " + orderId;
                });
    }

    public String tryLockWithEntity(String orderId) {
        LockEntity entity = LockEntity.builder()
                .keyName("order-trylock-entity:" + orderId)
                .waitTime(3000L)
                .leaseTime(5000L)
                .type(LockType.REENTRANT)
                .build();
        final String[] result = {"Lock not acquired for order " + orderId};
        lockManager.tryLock(
                entity,
                () -> {
                    int current = counter.incrementAndGet();
                    log.info("[tryLock(Entity)] Processing order: {}, counter: {}", orderId, current);
                    simulateBusiness(100);
                    result[0] = "Order " + orderId + " processed (tryLock+Entity), counter=" + current;
                },
                () -> {
                    log.warn("[tryLock(Entity)] Failed for order: {}", orderId);
                    result[0] = "Failed to acquire lock for order " + orderId;
                });
        return result[0];
    }

    // ==================== 并发竞争演示 ====================

    public String contentionDemo(String resourceId, int sleepMs) {
        LockEntity entity = LockEntity.builder()
                .keyName("contention-mgr:" + resourceId)
                .waitTime(10000L)
                .leaseTime(15000L)
                .type(LockType.REENTRANT)
                .build();
        return lockManager.tryLock(
                entity,
                () -> {
                    int current = counter.incrementAndGet();
                    String threadName = Thread.currentThread().getName();
                    log.info("[contention] resource={}, thread={}, counter={}", resourceId, threadName, current);
                    simulateBusiness(sleepMs);
                    return "Resource " + resourceId + " processed by " + threadName + ", counter=" + current;
                },
                () -> "Contention: failed to acquire lock for " + resourceId);
    }

    private void simulateBusiness(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
