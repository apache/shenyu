package com.yeepay.framework.examples.lock.strategy;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LoggingReleaseTimeoutStrategy implements ReleaseTimeoutStrategy {

    @Override
    public void execute(final LockEntity lockEntity) {
        log.warn(
                "Lock release timeout (non-fatal): key={}, leaseTime={}ms. "
                        + "The lock may have expired before business logic completed.",
                lockEntity.getKeyName(),
                lockEntity.getLeaseTime());
    }
}
