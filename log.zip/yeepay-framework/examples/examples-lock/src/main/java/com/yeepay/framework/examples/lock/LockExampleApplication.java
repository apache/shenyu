package com.yeepay.framework.examples.lock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The type Lock example application.
 */
@SpringBootApplication
public class LockExampleApplication {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(LockExampleApplication.class, args);
    }
}
