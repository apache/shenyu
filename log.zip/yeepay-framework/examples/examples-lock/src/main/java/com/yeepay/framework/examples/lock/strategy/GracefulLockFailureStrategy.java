package com.yeepay.framework.examples.lock.strategy;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class GracefulLockFailureStrategy implements LockFailureStrategy {

    @Override
    public Object execute(final LockEntity lockEntity, final ProceedingJoinPoint point) {
        log.warn(
                "Lock acquisition failed gracefully: key={}, waitTime={}ms",
                lockEntity.getKeyName(),
                lockEntity.getWaitTime());
        return "{\"success\":false,\"message\":\"Lock acquisition failed\",\"key\":\"" + lockEntity.getKeyName()
                + "\",\"waitTime\":" + lockEntity.getWaitTime() + "}";
    }
}
