package com.yeepay.framework.examples.lock.strategy;

import com.yeepay.framework.springboot.starter.lock.strategy.LockKeyStrategy;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Slf4j
@Component
public class UserIdBasedKeyStrategy implements LockKeyStrategy {

    @Override
    public String buildKey(final JoinPoint joinPoint, final String[] keys) {
        String userId = resolveUserId();
        String methodName = joinPoint.getSignature().getName();
        String key = userId + ":" + methodName;
        log.info("UserIdBasedKeyStrategy built key: {}", key);
        return key;
    }

    private String resolveUserId() {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attrs != null) {
            HttpServletRequest request = attrs.getRequest();
            String userId = request.getHeader("X-User-Id");
            if (userId != null && !userId.isEmpty()) {
                return userId;
            }
        }
        return "anonymous";
    }
}
