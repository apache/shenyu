package com.yeepay.framework.examples.lock.controller;

import com.yeepay.framework.examples.lock.service.LockAnnotationService;
import com.yeepay.framework.examples.lock.service.LockManagerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/lock")
@RequiredArgsConstructor
public class LockExampleController {

    private final LockAnnotationService annotationService;

    private final LockManagerService lockManagerService;

    // ==================== Annotation (@YeepayLock) - 基础用法 ====================

    @GetMapping("/annotation/order/{orderId}")
    public String annotationOrder(@PathVariable String orderId) {
        return annotationService.processOrder(orderId);
    }

    @GetMapping("/annotation/inventory/{productId}")
    public String annotationInventory(@PathVariable String productId, @RequestParam(defaultValue = "1") int quantity) {
        return annotationService.deductInventory(productId, quantity);
    }

    @GetMapping("/annotation/transfer/{accountId}")
    public String annotationTransfer(@PathVariable String accountId, @RequestParam(defaultValue = "100") long amount) {
        return annotationService.transfer(accountId, amount);
    }

    // ==================== Annotation - 多 SpEL Key (组合键) ====================

    @GetMapping("/annotation/transfer-composite")
    public String annotationTransferComposite(
            @RequestParam String from, @RequestParam String to, @RequestParam(defaultValue = "100") long amount) {
        return annotationService.transferBetweenAccounts(from, to, amount);
    }

    // ==================== Annotation - FAIR 锁 ====================

    @GetMapping("/annotation/fair/{resourceId}")
    public String annotationFair(@PathVariable String resourceId) {
        return annotationService.fairQueueAccess(resourceId);
    }

    // ==================== Annotation - READ/WRITE 锁 ====================

    @GetMapping("/annotation/config/read/{configKey}")
    public String annotationReadConfig(@PathVariable String configKey) {
        return annotationService.readConfig(configKey);
    }

    @GetMapping("/annotation/config/write/{configKey}")
    public String annotationWriteConfig(
            @PathVariable String configKey, @RequestParam(defaultValue = "new_value") String value) {
        return annotationService.writeConfig(configKey, value);
    }

    // ==================== Annotation - 自定义失败策略 ====================

    @GetMapping("/annotation/graceful/{resourceId}")
    public String annotationGraceful(@PathVariable String resourceId) {
        return annotationService.gracefulLock(resourceId);
    }

    // ==================== Annotation - 自定义 Key 策略 ====================

    @GetMapping("/annotation/user-scoped/{operationType}")
    public String annotationUserScoped(@PathVariable String operationType) {
        return annotationService.userScopedOperation(operationType);
    }

    // ==================== Annotation - 自定义释放超时策略 ====================

    @GetMapping("/annotation/short-lease/{taskId}")
    public String annotationShortLease(@PathVariable String taskId) {
        return annotationService.shortLeaseTask(taskId);
    }

    // ==================== Annotation - 并发竞争演示 ====================

    @GetMapping("/annotation/contention/{resourceId}")
    public String annotationContention(
            @PathVariable String resourceId, @RequestParam(defaultValue = "1000") int sleepMs) {
        return annotationService.contentionDemo(resourceId, sleepMs);
    }

    // ==================== LockManager - lock() 阻塞加锁 ====================

    @GetMapping("/manager/lock/{orderId}")
    public String managerLock(@PathVariable String orderId) {
        return lockManagerService.lockSimple(orderId);
    }

    @GetMapping("/manager/lock-fair/{orderId}")
    public String managerLockFair(@PathVariable String orderId) {
        return lockManagerService.lockWithParams(orderId);
    }

    @GetMapping("/manager/lock-supplier/{orderId}")
    public String managerLockSupplier(@PathVariable String orderId) {
        return lockManagerService.lockWithSupplier(orderId);
    }

    @GetMapping("/manager/lock-entity/{orderId}")
    public String managerLockEntity(@PathVariable String orderId) {
        return lockManagerService.lockWithEntity(orderId);
    }

    // ==================== LockManager - tryLock() 非阻塞 ====================

    @GetMapping("/manager/trylock/{orderId}")
    public String managerTryLock(@PathVariable String orderId) {
        return lockManagerService.tryLockSimple(orderId);
    }

    @GetMapping("/manager/trylock-params/{orderId}")
    public String managerTryLockParams(@PathVariable String orderId) {
        return lockManagerService.tryLockWithParams(orderId);
    }

    @GetMapping("/manager/trylock-return/{orderId}")
    public String managerTryLockReturn(@PathVariable String orderId) {
        return lockManagerService.tryLockWithReturn(orderId);
    }

    @GetMapping("/manager/trylock-return-params/{orderId}")
    public String managerTryLockReturnParams(@PathVariable String orderId) {
        return lockManagerService.tryLockWithReturnParams(orderId);
    }

    @GetMapping("/manager/trylock-entity/{orderId}")
    public String managerTryLockEntity(@PathVariable String orderId) {
        return lockManagerService.tryLockWithEntity(orderId);
    }

    // ==================== LockManager - 并发竞争演示 ====================

    @GetMapping("/manager/contention/{resourceId}")
    public String managerContention(@PathVariable String resourceId, @RequestParam(defaultValue = "1000") int sleepMs) {
        return lockManagerService.contentionDemo(resourceId, sleepMs);
    }
}
