package com.yeepay.framework.examples.lock.service;

import com.yeepay.framework.examples.lock.strategy.GracefulLockFailureStrategy;
import com.yeepay.framework.examples.lock.strategy.LoggingReleaseTimeoutStrategy;
import com.yeepay.framework.examples.lock.strategy.UserIdBasedKeyStrategy;
import com.yeepay.framework.lock.api.enums.LockType;
import com.yeepay.framework.springboot.starter.lock.annotation.YeepayLock;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class LockAnnotationService {

    private final AtomicInteger counter = new AtomicInteger(0);

    // ==================== 基础用法 ====================

    @YeepayLock(
            name = "order",
            keys = {"#orderId"})
    public String processOrder(String orderId) {
        int current = counter.incrementAndGet();
        log.info("Processing order: {}, counter: {}", orderId, current);
        simulateBusiness(100);
        return "Order " + orderId + " processed, counter=" + current;
    }

    @YeepayLock(
            name = "inventory",
            keys = {"#productId"},
            lockType = LockType.REENTRANT,
            waitTime = 5000L,
            leaseTime = 10000L)
    public String deductInventory(String productId, int quantity) {
        log.info("Deducting inventory: product={}, quantity={}", productId, quantity);
        simulateBusiness(100);
        return "Deducted " + quantity + " of product " + productId;
    }

    @YeepayLock(
            name = "account",
            keys = {"#accountId"},
            waitTime = 1000L,
            leaseTime = 5000L)
    public String transfer(String accountId, long amount) {
        log.info("Transferring amount={} for account={}", amount, accountId);
        simulateBusiness(100);
        return "Transferred " + amount + " for account " + accountId;
    }

    // ==================== 多 SpEL Key (组合键) ====================

    @YeepayLock(
            name = "transfer-composite",
            keys = {"#fromAccount", "#toAccount"},
            waitTime = 3000L,
            leaseTime = 5000L)
    public String transferBetweenAccounts(String fromAccount, String toAccount, long amount) {
        log.info("Transfer {} from {} to {}", amount, fromAccount, toAccount);
        simulateBusiness(100);
        return "Transferred " + amount + " from " + fromAccount + " to " + toAccount;
    }

    // ==================== FAIR 锁 ====================

    @YeepayLock(
            name = "fair-queue",
            keys = {"#resourceId"},
            lockType = LockType.FAIR,
            waitTime = 5000L,
            leaseTime = 3000L)
    public String fairQueueAccess(String resourceId) {
        int current = counter.incrementAndGet();
        log.info("Fair lock acquired for resource={}, counter={}", resourceId, current);
        simulateBusiness(200);
        return "Fair lock on " + resourceId + ", counter=" + current;
    }

    // ==================== READ/WRITE 锁 (仅 Redisson 支持) ====================

    @YeepayLock(
            name = "config",
            keys = {"#configKey"},
            lockType = LockType.READ,
            waitTime = 3000L,
            leaseTime = 5000L)
    public String readConfig(String configKey) {
        log.info("Reading config with READ lock: key={}", configKey);
        simulateBusiness(50);
        return "Config value for " + configKey + " = some_value";
    }

    @YeepayLock(
            name = "config",
            keys = {"#configKey"},
            lockType = LockType.WRITE,
            waitTime = 5000L,
            leaseTime = 10000L)
    public String writeConfig(String configKey, String configValue) {
        log.info("Writing config with WRITE lock: key={}, value={}", configKey, configValue);
        simulateBusiness(100);
        return "Config " + configKey + " updated to " + configValue;
    }

    // ==================== 自定义失败策略 (优雅降级) ====================

    @YeepayLock(
            name = "graceful",
            keys = {"#resourceId"},
            waitTime = 500L,
            leaseTime = 3000L,
            failStrategy = GracefulLockFailureStrategy.class)
    public String gracefulLock(String resourceId) {
        log.info("Graceful lock acquired for resource={}", resourceId);
        simulateBusiness(2000);
        return "{\"success\":true,\"message\":\"Processed\",\"resource\":\"" + resourceId + "\"}";
    }

    // ==================== 自定义 Key 策略 (基于 UserId) ====================

    @YeepayLock(name = "user-op", waitTime = 3000L, leaseTime = 5000L, keyStrategy = UserIdBasedKeyStrategy.class)
    public String userScopedOperation(String operationType) {
        log.info("User-scoped operation: type={}", operationType);
        simulateBusiness(100);
        return "Operation " + operationType + " completed for current user";
    }

    // ==================== 自定义释放超时策略 (只记日志，不抛异常) ====================

    @YeepayLock(
            name = "logging-release",
            keys = {"#taskId"},
            waitTime = 3000L,
            leaseTime = 1000L,
            releaseTimeoutStrategy = LoggingReleaseTimeoutStrategy.class)
    public String shortLeaseTask(String taskId) {
        log.info("Short lease task started: taskId={}", taskId);
        simulateBusiness(100);
        return "Task " + taskId + " completed (short lease with logging release strategy)";
    }

    // ==================== 并发竞争演示 ====================

    @YeepayLock(
            name = "contention",
            keys = {"#resourceId"},
            waitTime = 5000L,
            leaseTime = 10000L)
    public String contentionDemo(String resourceId, int sleepMs) {
        int current = counter.incrementAndGet();
        String threadName = Thread.currentThread().getName();
        log.info("Contention lock acquired: resource={}, thread={}, counter={}", resourceId, threadName, current);
        simulateBusiness(sleepMs);
        return "Resource " + resourceId + " processed by " + threadName + ", counter=" + current;
    }

    private void simulateBusiness(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
