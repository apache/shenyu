#!/bin/bash
# ============================================================================
# Yeepay Distributed Lock Framework - Comprehensive Test Script
#
# Usage:
#   bash test-lock.sh [base_url]
#
# Default base_url: http://localhost:8080
#
# Prerequisites:
#   1. Start Redis: redis-server (default 127.0.0.1:6379)
#   2. Build the project:
#      mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip
#   3. Start the example service:
#      mvn spring-boot:run -pl examples/examples-lock
#      (or specify profile: -Dspring-boot.run.profiles=jedis)
# ============================================================================

BASE_URL="${1:-http://localhost:8080}"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

# ---------------------------------------------------------------------------
# Helper: single request, print result
# Args: description, url [, extra_curl_args...]
# ---------------------------------------------------------------------------
single_request() {
    local desc="$1"
    local url="$2"
    shift 2
    local tmpfile
    tmpfile=$(mktemp)
    local http_code
    http_code=$(curl -s -w '%{http_code}' -o "$tmpfile" "$@" "$url")
    local body
    body=$(cat "$tmpfile")
    rm -f "$tmpfile"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$http_code" -eq 200 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "  ${GREEN}[PASS]${NC} $desc -> HTTP $http_code | $body"
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo -e "  ${RED}[FAIL]${NC} $desc -> HTTP $http_code | $body"
    fi
}

# ---------------------------------------------------------------------------
# Helper: concurrent requests (background curl), verify serialization
# Args: description, url, count
# ---------------------------------------------------------------------------
concurrent_requests() {
    local desc="$1"
    local url="$2"
    local count="$3"
    local tmpdir
    tmpdir=$(mktemp -d)

    echo -e "  ${CYAN}[CONCURRENT]${NC} $desc: sending $count concurrent requests..."
    for i in $(seq 1 "$count"); do
        curl -s -o "$tmpdir/body_$i" -w '%{http_code}' "$url" > "$tmpdir/code_$i" &
    done
    wait

    local passed=0
    local failed=0
    for i in $(seq 1 "$count"); do
        local code
        code=$(cat "$tmpdir/code_$i" 2>/dev/null)
        if [ "$code" = "200" ]; then
            passed=$((passed + 1))
        else
            failed=$((failed + 1))
        fi
    done
    rm -rf "$tmpdir"

    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$passed" -gt 0 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "    ${GREEN}[PASS]${NC} $passed succeeded, $failed failed (lock serialized concurrent access)"
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo -e "    ${RED}[FAIL]${NC} all $count requests failed"
    fi
}

# ---------------------------------------------------------------------------
# Helper: concurrent requests with graceful failure body check
# Args: description, url, count
# ---------------------------------------------------------------------------
concurrent_graceful() {
    local desc="$1"
    local url="$2"
    local count="$3"
    local tmpdir
    tmpdir=$(mktemp -d)

    echo -e "  ${CYAN}[CONCURRENT]${NC} $desc: sending $count concurrent requests..."
    for i in $(seq 1 "$count"); do
        curl -s -o "$tmpdir/body_$i" -w '%{http_code}' "$url" > "$tmpdir/code_$i" &
    done
    wait

    local success=0
    local graceful=0
    local error=0
    for i in $(seq 1 "$count"); do
        local code body
        code=$(cat "$tmpdir/code_$i" 2>/dev/null)
        body=$(cat "$tmpdir/body_$i" 2>/dev/null)
        if [ "$code" = "200" ] && echo "$body" | grep -q '"success":true'; then
            success=$((success + 1))
        elif [ "$code" = "200" ] && echo "$body" | grep -q '"success":false'; then
            graceful=$((graceful + 1))
        else
            error=$((error + 1))
        fi
    done
    rm -rf "$tmpdir"

    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$graceful" -gt 0 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "    ${GREEN}[PASS]${NC} $success succeeded, ${YELLOW}$graceful gracefully rejected${NC}, $error errors"
    elif [ "$success" -gt 0 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "    ${YELLOW}[INFO]${NC} all $success requests succeeded (no contention with $count requests)"
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo -e "    ${RED}[FAIL]${NC} all requests errored"
    fi
}

section() {
    echo ""
    echo -e "${BOLD}$1${NC}"
    echo "  $2"
}

# ============================================================================
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Yeepay Distributed Lock Framework - Test Suite${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Target: $BASE_URL"
echo ""

# Check service is up
echo -n "Checking service availability... "
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE_URL/lock/annotation/order/health-check" 2>/dev/null)
if [ "$HTTP_CODE" = "000" ]; then
    echo -e "${RED}FAILED${NC}"
    echo "  Cannot connect to $BASE_URL. Please start the service first:"
    echo "    mvn spring-boot:run -pl examples/examples-lock"
    exit 1
fi
echo -e "${GREEN}OK${NC}"

# ===========================
# PART 1: Annotation-based
# ===========================
echo ""
echo -e "${BOLD}============ Part 1: Annotation-based (@YeepayLock) ============${NC}"

# --- 1.1 Basic: Order Processing ---
section "1.1 Basic Lock (SpEL key)" "name=order, keys=#orderId"
single_request "process order ORD001" "$BASE_URL/lock/annotation/order/ORD001"
single_request "process order ORD002" "$BASE_URL/lock/annotation/order/ORD002"

# --- 1.2 Full Config: Inventory ---
section "1.2 Full Config Lock" "name=inventory, lockType=REENTRANT, waitTime=5s, leaseTime=10s"
single_request "deduct inventory (default qty)" "$BASE_URL/lock/annotation/inventory/PROD001"
single_request "deduct inventory (qty=5)" "$BASE_URL/lock/annotation/inventory/PROD001?quantity=5"

# --- 1.3 Custom Timing: Transfer ---
section "1.3 Custom Timing" "name=account, waitTime=1s, leaseTime=5s"
single_request "transfer (default amount)" "$BASE_URL/lock/annotation/transfer/ACC001"
single_request "transfer (amount=500)" "$BASE_URL/lock/annotation/transfer/ACC001?amount=500"

# --- 1.4 Multiple SpEL Keys (Composite Key) ---
section "1.4 Multiple SpEL Keys (Composite)" "keys={#fromAccount, #toAccount}"
single_request "transfer A->B" "$BASE_URL/lock/annotation/transfer-composite?from=ACC001&to=ACC002&amount=100"
single_request "transfer B->C" "$BASE_URL/lock/annotation/transfer-composite?from=ACC002&to=ACC003&amount=200"

# --- 1.5 FAIR Lock ---
section "1.5 FAIR Lock" "lockType=FAIR, waitTime=5s"
single_request "fair lock access" "$BASE_URL/lock/annotation/fair/RESOURCE001"
sleep 0.5
concurrent_requests "fair lock concurrency" "$BASE_URL/lock/annotation/fair/RESOURCE-FAIR" 5

# --- 1.6 READ/WRITE Lock ---
section "1.6 READ Lock" "lockType=READ (Redisson only)"
single_request "read config" "$BASE_URL/lock/annotation/config/read/db.url"
single_request "read config (another key)" "$BASE_URL/lock/annotation/config/read/db.password"

section "1.7 WRITE Lock" "lockType=WRITE (Redisson only)"
single_request "write config" "$BASE_URL/lock/annotation/config/write/db.url?value=jdbc:mysql://new-host:3306/db"
single_request "write config (default value)" "$BASE_URL/lock/annotation/config/write/app.name"

section "1.8 READ + WRITE Concurrent" "multiple reads concurrent, then write"
concurrent_requests "concurrent reads" "$BASE_URL/lock/annotation/config/read/rw-test" 5
sleep 0.5
single_request "write after reads" "$BASE_URL/lock/annotation/config/write/rw-test?value=updated"

# --- 1.9 Custom Failure Strategy (Graceful) ---
section "1.9 Custom Failure Strategy (Graceful)" "failStrategy=GracefulLockFailureStrategy, returns JSON on failure"
single_request "graceful lock (single)" "$BASE_URL/lock/annotation/graceful/RES001"
sleep 0.5
concurrent_graceful "graceful lock (concurrent)" "$BASE_URL/lock/annotation/graceful/RES-GRACEFUL?sleepMs=2000" 5

# --- 1.10 Custom Key Strategy (UserIdBased) ---
section "1.10 Custom Key Strategy (UserIdBased)" "keyStrategy=UserIdBasedKeyStrategy, key from X-User-Id header"
single_request "user-scoped (no header)" "$BASE_URL/lock/annotation/user-scoped/withdraw"
single_request "user-scoped (User-A)" "$BASE_URL/lock/annotation/user-scoped/withdraw" -H "X-User-Id: user-A"
single_request "user-scoped (User-B)" "$BASE_URL/lock/annotation/user-scoped/deposit" -H "X-User-Id: user-B"

# --- 1.11 Custom Release Timeout Strategy ---
section "1.11 Custom Release Timeout Strategy" "releaseTimeoutStrategy=LoggingReleaseTimeoutStrategy, short leaseTime=1s"
single_request "short lease task" "$BASE_URL/lock/annotation/short-lease/TASK001"

# --- 1.12 Contention Demo (Annotation) ---
section "1.12 Contention Demo (Annotation)" "Same resource, concurrent access, lock serializes"
concurrent_requests "annotation contention (5 concurrent, 500ms each)" "$BASE_URL/lock/annotation/contention/SHARED-RES?sleepMs=500" 5

# ===========================
# PART 2: Programmatic (LockManager)
# ===========================
echo ""
echo -e "${BOLD}============ Part 2: Programmatic (LockManager) ============${NC}"

# --- 2.1 lock() Simple ---
section "2.1 lock() - Simple (Runnable)" "lockManager.lock(name, task)"
single_request "lock simple" "$BASE_URL/lock/manager/lock/ORD001"

# --- 2.2 lock() with Params (FAIR) ---
section "2.2 lock() - With Params (FAIR)" "lockManager.lock(name, leaseTime, FAIR, task, fail)"
single_request "lock fair" "$BASE_URL/lock/manager/lock-fair/ORD002"

# --- 2.3 lock() with Supplier ---
section "2.3 lock() - With Supplier Return" "lockManager.lock(entity, Supplier, Supplier)"
single_request "lock supplier" "$BASE_URL/lock/manager/lock-supplier/ORD003"

# --- 2.4 lock() with LockEntity ---
section "2.4 lock() - With LockEntity" "lockManager.lock(entity, Runnable, Runnable)"
single_request "lock entity" "$BASE_URL/lock/manager/lock-entity/ORD004"

# --- 2.5 tryLock() Simple ---
section "2.5 tryLock() - Simple (Runnable)" "lockManager.tryLock(name, task)"
single_request "tryLock simple" "$BASE_URL/lock/manager/trylock/ORD005"

# --- 2.6 tryLock() with Params ---
section "2.6 tryLock() - With Params" "lockManager.tryLock(name, leaseTime, waitTime, type, task, fail)"
single_request "tryLock params" "$BASE_URL/lock/manager/trylock-params/ORD006"

# --- 2.7 tryLock() with Supplier Return (Entity) ---
section "2.7 tryLock() - Supplier + Entity" "lockManager.tryLock(entity, Supplier, Supplier)"
single_request "tryLock return" "$BASE_URL/lock/manager/trylock-return/ORD007"

# --- 2.8 tryLock() with Supplier Return (Params) ---
section "2.8 tryLock() - Supplier + Params" "lockManager.tryLock(name, leaseTime, waitTime, type, Supplier, Supplier)"
single_request "tryLock return params" "$BASE_URL/lock/manager/trylock-return-params/ORD008"

# --- 2.9 tryLock() with LockEntity (Runnable) ---
section "2.9 tryLock() - Entity + Runnable" "lockManager.tryLock(entity, Runnable, Runnable)"
single_request "tryLock entity" "$BASE_URL/lock/manager/trylock-entity/ORD009"

# --- 2.10 Contention Demo (Programmatic) ---
section "2.10 Contention Demo (Programmatic)" "Same resource, concurrent access, lock serializes"
concurrent_requests "manager contention (5 concurrent, 500ms each)" "$BASE_URL/lock/manager/contention/SHARED-RES?sleepMs=500" 5

# ===========================
# PART 3: Edge Cases
# ===========================
echo ""
echo -e "${BOLD}============ Part 3: Edge Cases ============${NC}"

# --- 3.1 Same key, sequential requests ---
section "3.1 Sequential Same-Key Requests" "Same orderId, two sequential requests"
single_request "first request" "$BASE_URL/lock/annotation/order/SAME-KEY"
single_request "second request (same key)" "$BASE_URL/lock/annotation/order/SAME-KEY"

# --- 3.2 Different keys, parallel ---
section "3.2 Different Keys Concurrent" "Different orderIds should not block each other"
concurrent_requests "different keys" "$BASE_URL/lock/manager/lock/DIFF-KEY-\$RANDOM" 5

# --- 3.3 tryLock contention ---
section "3.3 tryLock Contention (short waitTime)" "Expect some requests to fail acquiring lock"
echo -e "  ${CYAN}[CONCURRENT]${NC} Sending 5 concurrent requests for same resource (500ms hold)..."
TMPDIR_TRYLOCK=$(mktemp -d)
for i in $(seq 1 5); do
    curl -s -o "$TMPDIR_TRYLOCK/body_$i" -w '%{http_code}' "$BASE_URL/lock/manager/trylock/CONTEND-KEY" > "$TMPDIR_TRYLOCK/code_$i" &
done
wait

ACQUIRED=0
NOT_ACQUIRED=0
for i in $(seq 1 5); do
    CODE=$(cat "$TMPDIR_TRYLOCK/code_$i" 2>/dev/null)
    BODY=$(cat "$TMPDIR_TRYLOCK/body_$i" 2>/dev/null)
    if [ "$CODE" = "200" ] && echo "$BODY" | grep -q "processed"; then
        ACQUIRED=$((ACQUIRED + 1))
    else
        NOT_ACQUIRED=$((NOT_ACQUIRED + 1))
    fi
done
rm -rf "$TMPDIR_TRYLOCK"

TOTAL_TESTS=$((TOTAL_TESTS + 1))
PASS_COUNT=$((PASS_COUNT + 1))
echo -e "    ${GREEN}[PASS]${NC} $ACQUIRED acquired lock, $NOT_ACQUIRED did not (expected behavior)"

# ===========================
# Summary
# ===========================
echo ""
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Summary${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Total test groups: $TOTAL_TESTS"
echo -e "  ${GREEN}Passed: $PASS_COUNT${NC}"
echo -e "  ${RED}Failed: $FAIL_COUNT${NC}"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo -e "  ${GREEN}All tests passed!${NC}"
else
    echo -e "  ${RED}Some tests failed. Check the output above for details.${NC}"
fi
echo ""
