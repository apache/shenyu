#!/bin/bash
# ============================================================================
# Yeepay Smart-Cache Framework - Test Script
#
# Usage:
#   bash test-smart-cache.sh [base_url]
#
# Default base_url: http://localhost:8080
#
# Prerequisites:
#   1. Start Redis: redis-server (default 127.0.0.1:6379)
#   2. Build the project:
#      mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip
#   3. Start the example service:
#      mvn spring-boot:run -pl examples/examples-smart-cache
# ============================================================================

BASE_URL="${1:-http://localhost:8088}"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

# ---------------------------------------------------------------------------
# Helper: single request, print result
# Args: description, url [, extra_curl_args...]
# ---------------------------------------------------------------------------
single_request() {
    local desc="$1"
    local url="$2"
    shift 2
    local tmpfile
    tmpfile=$(mktemp)
    local http_code
    http_code=$(curl -s -w '%{http_code}' -o "$tmpfile" "$@" "$url")
    local body
    body=$(cat "$tmpfile")
    rm -f "$tmpfile"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$http_code" -eq 200 ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "  ${GREEN}[PASS]${NC} $desc -> HTTP $http_code | $body"
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo -e "  ${RED}[FAIL]${NC} $desc -> HTTP $http_code | $body"
    fi
}

# ---------------------------------------------------------------------------
# Helper: verify cache hit (second call should return same value)
# Args: description, url
# ---------------------------------------------------------------------------
verify_cache_hit() {
    local desc="$1"
    local url="$2"
    local tmpfile1 tmpfile2
    tmpfile1=$(mktemp)
    tmpfile2=$(mktemp)

    curl -s -w '%{http_code}' -o "$tmpfile1" "$url" > /dev/null 2>&1
    local body1
    body1=$(cat "$tmpfile1")

    curl -s -w '%{http_code}' -o "$tmpfile2" "$url" > /dev/null 2>&1
    local body2
    body2=$(cat "$tmpfile2")

    rm -f "$tmpfile1" "$tmpfile2"

    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    if [ "$body1" = "$body2" ]; then
        PASS_COUNT=$((PASS_COUNT + 1))
        echo -e "  ${GREEN}[PASS]${NC} $desc -> 缓存命中，两次返回一致: $body2"
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo -e "  ${RED}[FAIL]${NC} $desc -> 缓存未命中，两次返回不一致"
        echo -e "         第1次: $body1"
        echo -e "         第2次: $body2"
    fi
}

section() {
    echo ""
    echo -e "${BOLD}$1${NC}"
    echo "  $2"
}

# ============================================================================
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Yeepay Smart-Cache Framework - Test Suite${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Target: $BASE_URL"
echo ""

# Check service is up
echo -n "Checking service availability... "
HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE_URL/smart-cache/programmatic/contains?key=healthcheck" 2>/dev/null)
if [ "$HTTP_CODE" = "000" ]; then
    echo -e "${RED}FAILED${NC}"
    echo "  Cannot connect to $BASE_URL. Please start the service first:"
    echo "    mvn spring-boot:run -pl examples/examples-smart-cache"
    exit 1
fi
echo -e "${GREEN}OK${NC}"

# ===========================
# PART 1: Annotation-based (@SmartCache)
# ===========================
echo ""
echo -e "${BOLD}============ Part 1: Annotation-based (@SmartCache) ============${NC}"

# --- 1.1 Basic cache-aside ---
section "1.1 Basic Cache (key=#p0)" "@SmartCache(key=\"#p0\", expire=60)"
single_request "首次查询用户(cache miss)" "$BASE_URL/smart-cache/annotation/user/U001"
verify_cache_hit "再次查询用户(cache hit)" "$BASE_URL/smart-cache/annotation/user/U001"

# --- 1.2 Cache with group ---
section "1.2 Cache with Group" "@SmartCache(key=\"#p0\", group=\"products\", expire=120)"
single_request "首次查询商品(cache miss)" "$BASE_URL/smart-cache/annotation/product/P001"
verify_cache_hit "再次查询商品(cache hit)" "$BASE_URL/smart-cache/annotation/product/P001"

# --- 1.3 Compound SpEL key ---
section "1.3 Compound SpEL Key" "@SmartCache(key=\"'order:' + #p0 + ':' + #p1\")"
single_request "查询订单(复合key)" "$BASE_URL/smart-cache/annotation/order/U001/ORD001"
verify_cache_hit "再次查询订单(cache hit)" "$BASE_URL/smart-cache/annotation/order/U001/ORD001"

# --- 1.4 Cache invalidation ---
section "1.4 Cache Invalidation (remove=true)" "@SmartCache(key=\"#p0\", remove=true)"
single_request "查询用户U002(缓存)" "$BASE_URL/smart-cache/annotation/user/U002"
single_request "删除用户U002(清除缓存)" "$BASE_URL/smart-cache/annotation/user/U002" -X DELETE

# --- 1.5 Cache invalidation with group ---
section "1.5 Cache Invalidation with Group" "@SmartCache(key=\"#p0\", group=\"products\", remove=true)"
single_request "查询商品P002(缓存)" "$BASE_URL/smart-cache/annotation/product/P002"
single_request "删除商品P002(清除缓存)" "$BASE_URL/smart-cache/annotation/product/P002" -X DELETE

# --- 1.6 Short TTL ---
section "1.6 Short TTL (expire=5s)" "验证缓存过期"
single_request "设置短TTL缓存" "$BASE_URL/smart-cache/annotation/short-ttl/ttl-test"
echo -e "  ${CYAN}[INFO]${NC} 等待6秒让缓存过期..."
sleep 6
TOTAL_TESTS=$((TOTAL_TESTS + 1))
tmpfile1=$(mktemp)
tmpfile2=$(mktemp)
curl -s -o "$tmpfile1" "$BASE_URL/smart-cache/annotation/short-ttl/ttl-test" 2>/dev/null
body_before=$(cat "$tmpfile1")
curl -s -o "$tmpfile2" "$BASE_URL/smart-cache/annotation/short-ttl/ttl-test" 2>/dev/null
body_after=$(cat "$tmpfile2")
rm -f "$tmpfile1" "$tmpfile2"
if [ "$body_before" = "$body_after" ]; then
    PASS_COUNT=$((PASS_COUNT + 1))
    echo -e "  ${GREEN}[PASS]${NC} 缓存过期后重新加载并再次缓存"
else
    FAIL_COUNT=$((FAIL_COUNT + 1))
    echo -e "  ${RED}[FAIL]${NC} 缓存过期后两次请求不一致"
fi

# ===========================
# PART 2: Programmatic (SmartCacheUtils)
# ===========================
echo ""
echo -e "${BOLD}============ Part 2: Programmatic (SmartCacheUtils) ============${NC}"

# --- 2.1 set + get ---
section "2.1 Set & Get" "SmartCacheUtils.set / SmartCacheUtils.get"
single_request "set(key=test1, value=hello)" "$BASE_URL/smart-cache/programmatic/set?key=test1&value=hello&expire=60"
single_request "get(key=test1)" "$BASE_URL/smart-cache/programmatic/get?key=test1"

# --- 2.2 set + get with group ---
section "2.2 Set & Get with Group" "SmartCacheUtils.set(group, key, value, expire)"
single_request "set(group=myGroup, key=gk1, value=world)" "$BASE_URL/smart-cache/programmatic/set-group?group=myGroup&key=gk1&value=world&expire=60"
single_request "get(group=myGroup, key=gk1)" "$BASE_URL/smart-cache/programmatic/get-group?group=myGroup&key=gk1"

# --- 2.3 contains ---
section "2.3 Contains" "SmartCacheUtils.contains"
single_request "contains(key=test1) => true" "$BASE_URL/smart-cache/programmatic/contains?key=test1"
single_request "contains(key=nonexist) => false" "$BASE_URL/smart-cache/programmatic/contains?key=nonexist"

# --- 2.4 contains with group ---
section "2.4 Contains with Group" "SmartCacheUtils.contains(group, key)"
single_request "contains(group=myGroup, key=gk1) => true" "$BASE_URL/smart-cache/programmatic/contains-group?group=myGroup&key=gk1"

# --- 2.5 keys ---
section "2.5 Keys" "SmartCacheUtils.keys / SmartCacheUtils.keys(group)"
single_request "keys(默认分组)" "$BASE_URL/smart-cache/programmatic/keys"
single_request "keys(group=myGroup)" "$BASE_URL/smart-cache/programmatic/keys-group?group=myGroup"

# --- 2.6 remove ---
section "2.6 Remove" "SmartCacheUtils.remove"
single_request "remove(key=test1)" "$BASE_URL/smart-cache/programmatic/remove?key=test1" -X DELETE
single_request "验证删除: contains(key=test1) => false" "$BASE_URL/smart-cache/programmatic/contains?key=test1"

# --- 2.7 remove with group ---
section "2.7 Remove with Group" "SmartCacheUtils.remove(group, key)"
single_request "remove(group=myGroup, key=gk1)" "$BASE_URL/smart-cache/programmatic/remove-group?group=myGroup&key=gk1" -X DELETE

# --- 2.8 clear ---
section "2.8 Clear" "SmartCacheUtils.clear"
single_request "先写入一些数据" "$BASE_URL/smart-cache/programmatic/set?key=clearTest1&value=v1&expire=60"
single_request "clear(默认分组)" "$BASE_URL/smart-cache/programmatic/clear" -X DELETE

# --- 2.9 clear with group ---
section "2.9 Clear with Group" "SmartCacheUtils.clear(group)"
single_request "先写入分组数据" "$BASE_URL/smart-cache/programmatic/set-group?group=clearGroup&key=ck1&value=v1&expire=60"
single_request "clear(group=clearGroup)" "$BASE_URL/smart-cache/programmatic/clear-group?group=clearGroup" -X DELETE

# ===========================
# PART 3: Cross-API Verification
# ===========================
echo ""
echo -e "${BOLD}============ Part 3: Cross-API Verification ============${NC}"

section "3.1 Annotation set -> Programmatic get" "验证切面写入的缓存能通过API读取"
single_request "通过切面缓存用户U100" "$BASE_URL/smart-cache/annotation/user/U100"
single_request "通过API读取(需要知道group和key)" "$BASE_URL/smart-cache/programmatic/get-group?group=defaultGroup&key=U100"

section "3.2 Programmatic set -> Annotation get" "验证API写入的缓存能通过切面读取"
single_request "通过API写入缓存(group=products, key=P100)" "$BASE_URL/smart-cache/programmatic/set-group?group=products&key=P100&value=api_product&expire=60"
single_request "通过切面读取商品P100" "$BASE_URL/smart-cache/annotation/product/P100"

# ===========================
# PART 4: CacheType Variants (SmartCacheUtils with CacheTypeEnum)
# ===========================
echo ""
echo -e "${BOLD}============ Part 4: CacheType Variants (CacheTypeEnum) ============${NC}"

# --- 4.1 set + get with CacheType EHCACHE ---
section "4.1 Set & Get with CacheType=EHCACHE" "SmartCacheUtils.set/get(group, key, val, expire, CacheTypeEnum)"
single_request "set(group=typeGroup, key=tk1, value=ehVal, cacheType=EHCACHE)" "$BASE_URL/smart-cache/programmatic/set-cachetype?group=typeGroup&key=tk1&value=ehVal&expire=60&cacheType=EHCACHE"
single_request "get(group=typeGroup, key=tk1, cacheType=EHCACHE)" "$BASE_URL/smart-cache/programmatic/get-cachetype?group=typeGroup&key=tk1&cacheType=EHCACHE"

# --- 4.2 set + get with CacheType REDIS ---
section "4.2 Set & Get with CacheType=REDIS" "SmartCacheUtils.set/get(group, key, val, expire, CacheTypeEnum)"
single_request "set(group=typeGroup, key=tk2, value=redisVal, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/set-cachetype?group=typeGroup&key=tk2&value=redisVal&expire=60&cacheType=REDIS"
single_request "get(group=typeGroup, key=tk2, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/get-cachetype?group=typeGroup&key=tk2&cacheType=REDIS"

# --- 4.3 contains with CacheType ---
section "4.3 Contains with CacheType" "SmartCacheUtils.contains(group, key, CacheTypeEnum)"
single_request "contains(group=typeGroup, key=tk1, cacheType=EHCACHE) => true" "$BASE_URL/smart-cache/programmatic/contains-cachetype?group=typeGroup&key=tk1&cacheType=EHCACHE"
single_request "contains(group=typeGroup, key=nonexist, cacheType=EHCACHE) => false" "$BASE_URL/smart-cache/programmatic/contains-cachetype?group=typeGroup&key=nonexist&cacheType=EHCACHE"

# --- 4.4 keys with CacheType ---
section "4.4 Keys with CacheType" "SmartCacheUtils.keys(group, CacheTypeEnum)"
single_request "keys(group=typeGroup, cacheType=EHCACHE)" "$BASE_URL/smart-cache/programmatic/keys-cachetype?group=typeGroup&cacheType=EHCACHE"
single_request "keys(group=typeGroup, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/keys-cachetype?group=typeGroup&cacheType=REDIS"

# --- 4.5 remove with CacheType ---
section "4.5 Remove with CacheType" "SmartCacheUtils.remove(group, key, CacheTypeEnum)"
single_request "remove(group=typeGroup, key=tk1, cacheType=EHCACHE)" "$BASE_URL/smart-cache/programmatic/remove-cachetype?group=typeGroup&key=tk1&cacheType=EHCACHE" -X DELETE
single_request "验证删除: contains(group=typeGroup, key=tk1, cacheType=EHCACHE) => false" "$BASE_URL/smart-cache/programmatic/contains-cachetype?group=typeGroup&key=tk1&cacheType=EHCACHE"

# --- 4.6 clear with CacheType ---
section "4.6 Clear with CacheType" "SmartCacheUtils.clear(group, CacheTypeEnum)"
single_request "先写入数据(cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/set-cachetype?group=clearTypeGroup&key=ctk1&value=v1&expire=60&cacheType=REDIS"
single_request "clear(group=clearTypeGroup, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/clear-cachetype?group=clearTypeGroup&cacheType=REDIS" -X DELETE

# ===========================
# PART 5: Cross-App Variants (SmartCacheUtils with appName)
# ===========================
echo ""
echo -e "${BOLD}============ Part 5: Cross-App Variants (appName) ============${NC}"

# --- 5.1 set + get cross-app ---
section "5.1 Cross-App Set & Get" "SmartCacheUtils.set/get(appName, group, key, val, expire, CacheTypeEnum)"
single_request "set(appName=otherApp, group=xGroup, key=xk1, value=crossVal, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/set-crossapp?appName=otherApp&group=xGroup&key=xk1&value=crossVal&expire=60&cacheType=REDIS"
single_request "get(appName=otherApp, group=xGroup, key=xk1, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/get-crossapp?appName=otherApp&group=xGroup&key=xk1&cacheType=REDIS"

# --- 5.2 contains cross-app ---
section "5.2 Cross-App Contains" "SmartCacheUtils.contains(appName, group, key, CacheTypeEnum)"
single_request "contains(appName=otherApp, group=xGroup, key=xk1, cacheType=REDIS) => true" "$BASE_URL/smart-cache/programmatic/contains-crossapp?appName=otherApp&group=xGroup&key=xk1&cacheType=REDIS"
single_request "contains(appName=otherApp, group=xGroup, key=nokey, cacheType=REDIS) => false" "$BASE_URL/smart-cache/programmatic/contains-crossapp?appName=otherApp&group=xGroup&key=nokey&cacheType=REDIS"

# --- 5.3 keys cross-app ---
section "5.3 Cross-App Keys" "SmartCacheUtils.keys(appName, group, CacheTypeEnum)"
single_request "keys(appName=otherApp, group=xGroup, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/keys-crossapp?appName=otherApp&group=xGroup&cacheType=REDIS"

# --- 5.4 remove cross-app ---
section "5.4 Cross-App Remove" "SmartCacheUtils.remove(appName, group, key, CacheTypeEnum)"
single_request "remove(appName=otherApp, group=xGroup, key=xk1, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/remove-crossapp?appName=otherApp&group=xGroup&key=xk1&cacheType=REDIS" -X DELETE
single_request "验证删除: contains(appName=otherApp, group=xGroup, key=xk1) => false" "$BASE_URL/smart-cache/programmatic/contains-crossapp?appName=otherApp&group=xGroup&key=xk1&cacheType=REDIS"

# --- 5.5 clear cross-app ---
section "5.5 Cross-App Clear" "SmartCacheUtils.clear(appName, group, CacheTypeEnum)"
single_request "先写入跨应用数据" "$BASE_URL/smart-cache/programmatic/set-crossapp?appName=otherApp&group=clearXGroup&key=cxk1&value=v1&expire=60&cacheType=REDIS"
single_request "clear(appName=otherApp, group=clearXGroup, cacheType=REDIS)" "$BASE_URL/smart-cache/programmatic/clear-crossapp?appName=otherApp&group=clearXGroup&cacheType=REDIS" -X DELETE

# ===========================
# Summary
# ===========================
echo ""
echo -e "${BOLD}========================================================${NC}"
echo -e "${BOLD}  Summary${NC}"
echo -e "${BOLD}========================================================${NC}"
echo -e "  Total test groups: $TOTAL_TESTS"
echo -e "  ${GREEN}Passed: $PASS_COUNT${NC}"
echo -e "  ${RED}Failed: $FAIL_COUNT${NC}"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo -e "  ${GREEN}All tests passed!${NC}"
else
    echo -e "  ${RED}Some tests failed. Check the output above for details.${NC}"
fi
echo ""
