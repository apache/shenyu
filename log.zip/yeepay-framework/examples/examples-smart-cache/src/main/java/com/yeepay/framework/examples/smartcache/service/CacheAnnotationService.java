package com.yeepay.framework.examples.smartcache.service;

import com.yeepay.g3.utils.smartcache.annotation.SmartCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CacheAnnotationService {

    // ==================== 基础用法：缓存读取 ====================

    @SmartCache(key = "#p0", expire = 60)
    public String getUserById(String userId) {
        log.info("Cache MISS - 从数据库查询用户: userId={}", userId);
        simulateBusiness(100);
        return "{\"userId\":\"" + userId + "\",\"name\":\"User_" + userId + "\",\"source\":\"db\"}";
    }

    // ==================== 带 group 的缓存 ====================

    @SmartCache(key = "#p0", group = "products", expire = 120)
    public String getProductById(String productId) {
        log.info("Cache MISS - 从数据库查询商品: productId={}", productId);
        simulateBusiness(100);
        return "{\"productId\":\"" + productId + "\",\"name\":\"Product_" + productId
                + "\",\"price\":99.99,\"source\":\"db\"}";
    }

    // ==================== 复合 SpEL key ====================

    @SmartCache(key = "'order:' + #p0 + ':' + #p1", group = "orders", expire = 300)
    public String getOrder(String userId, String orderId) {
        log.info("Cache MISS - 从数据库查询订单: userId={}, orderId={}", userId, orderId);
        simulateBusiness(100);
        return "{\"userId\":\"" + userId + "\",\"orderId\":\"" + orderId + "\",\"status\":\"PAID\",\"source\":\"db\"}";
    }

    // ==================== 缓存移除 ====================

    @SmartCache(key = "#p0", remove = true)
    public String deleteUser(String userId) {
        log.info("删除用户并清除缓存: userId={}", userId);
        return "{\"userId\":\"" + userId + "\",\"deleted\":true}";
    }

    @SmartCache(key = "#p0", group = "products", remove = true)
    public String deleteProduct(String productId) {
        log.info("删除商品并清除缓存: productId={}", productId);
        return "{\"productId\":\"" + productId + "\",\"deleted\":true}";
    }

    // ==================== 短 TTL（验证过期） ====================

    @SmartCache(key = "#p0", expire = 5)
    public String getWithShortTtl(String key) {
        log.info("Cache MISS - 计算短TTL值: key={}", key);
        return "value_" + key + "_at_" + System.currentTimeMillis();
    }

    private void simulateBusiness(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
