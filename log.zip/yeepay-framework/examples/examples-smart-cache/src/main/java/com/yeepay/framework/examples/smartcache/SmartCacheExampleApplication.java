package com.yeepay.framework.examples.smartcache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCacheExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCacheExampleApplication.class, args);
    }
}
