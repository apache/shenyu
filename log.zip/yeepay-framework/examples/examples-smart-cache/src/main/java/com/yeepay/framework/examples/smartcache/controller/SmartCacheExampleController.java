package com.yeepay.framework.examples.smartcache.controller;

import com.yeepay.framework.examples.smartcache.service.CacheAnnotationService;
import com.yeepay.framework.examples.smartcache.service.CacheProgrammaticService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/smart-cache")
@RequiredArgsConstructor
public class SmartCacheExampleController {

    private final CacheAnnotationService annotationService;
    private final CacheProgrammaticService programmaticService;

    // ==================== Annotation (@SmartCache) ====================

    @GetMapping("/annotation/user/{userId}")
    public String annotationGetUser(@PathVariable String userId) {
        return annotationService.getUserById(userId);
    }

    @GetMapping("/annotation/product/{productId}")
    public String annotationGetProduct(@PathVariable String productId) {
        return annotationService.getProductById(productId);
    }

    @GetMapping("/annotation/order/{userId}/{orderId}")
    public String annotationGetOrder(@PathVariable String userId, @PathVariable String orderId) {
        return annotationService.getOrder(userId, orderId);
    }

    @DeleteMapping("/annotation/user/{userId}")
    public String annotationDeleteUser(@PathVariable String userId) {
        return annotationService.deleteUser(userId);
    }

    @DeleteMapping("/annotation/product/{productId}")
    public String annotationDeleteProduct(@PathVariable String productId) {
        return annotationService.deleteProduct(productId);
    }

    @GetMapping("/annotation/short-ttl/{key}")
    public String annotationShortTtl(@PathVariable String key) {
        return annotationService.getWithShortTtl(key);
    }

    // ==================== Programmatic (SmartCacheUtils) ====================

    @GetMapping("/programmatic/set")
    public String programmaticSet(
            @RequestParam String key, @RequestParam String value, @RequestParam(defaultValue = "60") int expire) {
        return programmaticService.setAndGet(key, value, expire);
    }

    @GetMapping("/programmatic/get")
    public String programmaticGet(@RequestParam String key) {
        return programmaticService.get(key);
    }

    @GetMapping("/programmatic/set-group")
    public String programmaticSetGroup(
            @RequestParam String group,
            @RequestParam String key,
            @RequestParam String value,
            @RequestParam(defaultValue = "60") int expire) {
        return programmaticService.setWithGroup(group, key, value, expire);
    }

    @GetMapping("/programmatic/get-group")
    public String programmaticGetGroup(@RequestParam String group, @RequestParam String key) {
        return programmaticService.getWithGroup(group, key);
    }

    @DeleteMapping("/programmatic/remove")
    public String programmaticRemove(@RequestParam String key) {
        return programmaticService.remove(key);
    }

    @DeleteMapping("/programmatic/remove-group")
    public String programmaticRemoveGroup(@RequestParam String group, @RequestParam String key) {
        return programmaticService.removeWithGroup(group, key);
    }

    @GetMapping("/programmatic/contains")
    public String programmaticContains(@RequestParam String key) {
        return programmaticService.contains(key);
    }

    @GetMapping("/programmatic/contains-group")
    public String programmaticContainsGroup(@RequestParam String group, @RequestParam String key) {
        return programmaticService.containsWithGroup(group, key);
    }

    @GetMapping("/programmatic/keys")
    public String programmaticKeys() {
        return programmaticService.keys();
    }

    @GetMapping("/programmatic/keys-group")
    public String programmaticKeysGroup(@RequestParam String group) {
        return programmaticService.keysWithGroup(group);
    }

    @DeleteMapping("/programmatic/clear")
    public String programmaticClear() {
        return programmaticService.clear();
    }

    @DeleteMapping("/programmatic/clear-group")
    public String programmaticClearGroup(@RequestParam String group) {
        return programmaticService.clearGroup(group);
    }

    // ==================== Programmatic with CacheType ====================

    @GetMapping("/programmatic/set-cachetype")
    public String programmaticSetCacheType(
            @RequestParam String group,
            @RequestParam String key,
            @RequestParam String value,
            @RequestParam(defaultValue = "60") int expire,
            @RequestParam String cacheType) {
        return programmaticService.setWithCacheType(group, key, value, expire, cacheType);
    }

    @GetMapping("/programmatic/get-cachetype")
    public String programmaticGetCacheType(
            @RequestParam String group, @RequestParam String key, @RequestParam String cacheType) {
        return programmaticService.getWithCacheType(group, key, cacheType);
    }

    @DeleteMapping("/programmatic/remove-cachetype")
    public String programmaticRemoveCacheType(
            @RequestParam String group, @RequestParam String key, @RequestParam String cacheType) {
        return programmaticService.removeWithCacheType(group, key, cacheType);
    }

    @GetMapping("/programmatic/contains-cachetype")
    public String programmaticContainsCacheType(
            @RequestParam String group, @RequestParam String key, @RequestParam String cacheType) {
        return programmaticService.containsWithCacheType(group, key, cacheType);
    }

    @GetMapping("/programmatic/keys-cachetype")
    public String programmaticKeysCacheType(@RequestParam String group, @RequestParam String cacheType) {
        return programmaticService.keysWithCacheType(group, cacheType);
    }

    @DeleteMapping("/programmatic/clear-cachetype")
    public String programmaticClearCacheType(@RequestParam String group, @RequestParam String cacheType) {
        return programmaticService.clearWithCacheType(group, cacheType);
    }

    // ==================== Programmatic Cross-App ====================

    @GetMapping("/programmatic/set-crossapp")
    public String programmaticSetCrossApp(
            @RequestParam String appName,
            @RequestParam String group,
            @RequestParam String key,
            @RequestParam String value,
            @RequestParam(defaultValue = "60") int expire,
            @RequestParam String cacheType) {
        return programmaticService.setWithCrossApp(appName, group, key, value, expire, cacheType);
    }

    @GetMapping("/programmatic/get-crossapp")
    public String programmaticGetCrossApp(
            @RequestParam String appName,
            @RequestParam String group,
            @RequestParam String key,
            @RequestParam String cacheType) {
        return programmaticService.getWithCrossApp(appName, group, key, cacheType);
    }

    @DeleteMapping("/programmatic/remove-crossapp")
    public String programmaticRemoveCrossApp(
            @RequestParam String appName,
            @RequestParam String group,
            @RequestParam String key,
            @RequestParam String cacheType) {
        return programmaticService.removeWithCrossApp(appName, group, key, cacheType);
    }

    @GetMapping("/programmatic/contains-crossapp")
    public String programmaticContainsCrossApp(
            @RequestParam String appName,
            @RequestParam String group,
            @RequestParam String key,
            @RequestParam String cacheType) {
        return programmaticService.containsWithCrossApp(appName, group, key, cacheType);
    }

    @GetMapping("/programmatic/keys-crossapp")
    public String programmaticKeysCrossApp(
            @RequestParam String appName, @RequestParam String group, @RequestParam String cacheType) {
        return programmaticService.keysWithCrossApp(appName, group, cacheType);
    }

    @DeleteMapping("/programmatic/clear-crossapp")
    public String programmaticClearCrossApp(
            @RequestParam String appName, @RequestParam String group, @RequestParam String cacheType) {
        return programmaticService.clearWithCrossApp(appName, group, cacheType);
    }
}
