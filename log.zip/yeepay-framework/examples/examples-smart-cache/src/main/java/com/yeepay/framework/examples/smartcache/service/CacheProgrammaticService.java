package com.yeepay.framework.examples.smartcache.service;

import com.yeepay.g3.utils.smartcache.enums.CacheTypeEnum;
import com.yeepay.g3.utils.smartcache.utils.SmartCacheUtils;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CacheProgrammaticService {

    // ==================== get / set ====================

    public String setAndGet(String key, String value, int expireSeconds) {
        SmartCacheUtils.set(key, value, expireSeconds);
        log.info("写入缓存: key={}, value={}, expire={}s", key, value, expireSeconds);
        Object cached = SmartCacheUtils.get(key);
        return "set=" + value + ", get=" + cached;
    }

    public String get(String key) {
        Object cached = SmartCacheUtils.get(key);
        log.info("读取缓存: key={}, result={}", key, cached);
        return cached != null ? cached.toString() : "null";
    }

    // ==================== get / set with group ====================

    public String setWithGroup(String group, String key, String value, int expireSeconds) {
        SmartCacheUtils.set(group, key, value, expireSeconds);
        log.info("写入分组缓存: group={}, key={}, value={}", group, key, value);
        Object cached = SmartCacheUtils.get(group, key);
        return "set=" + value + ", get=" + cached;
    }

    public String getWithGroup(String group, String key) {
        Object cached = SmartCacheUtils.get(group, key);
        log.info("读取分组缓存: group={}, key={}, result={}", group, key, cached);
        return cached != null ? cached.toString() : "null";
    }

    // ==================== remove ====================

    public String remove(String key) {
        SmartCacheUtils.remove(key);
        log.info("删除缓存: key={}", key);
        boolean exists = SmartCacheUtils.contains(key);
        return "removed=true, exists=" + exists;
    }

    public String removeWithGroup(String group, String key) {
        SmartCacheUtils.remove(group, key);
        log.info("删除分组缓存: group={}, key={}", group, key);
        boolean exists = SmartCacheUtils.contains(group, key);
        return "removed=true, exists=" + exists;
    }

    // ==================== contains ====================

    public String contains(String key) {
        boolean exists = SmartCacheUtils.contains(key);
        log.info("检查缓存是否存在: key={}, exists={}", key, exists);
        return "contains=" + exists;
    }

    public String containsWithGroup(String group, String key) {
        boolean exists = SmartCacheUtils.contains(group, key);
        log.info("检查分组缓存是否存在: group={}, key={}, exists={}", group, key, exists);
        return "contains=" + exists;
    }

    // ==================== keys ====================

    public String keys() {
        Set<String> allKeys = SmartCacheUtils.keys();
        log.info("获取默认分组所有key: {}", allKeys);
        return "keys=" + allKeys;
    }

    public String keysWithGroup(String group) {
        Set<String> groupKeys = SmartCacheUtils.keys(group);
        log.info("获取分组所有key: group={}, keys={}", group, groupKeys);
        return "keys=" + groupKeys;
    }

    // ==================== clear ====================

    public String clear() {
        SmartCacheUtils.clear();
        log.info("清空默认分组缓存");
        return "cleared=true";
    }

    public String clearGroup(String group) {
        SmartCacheUtils.clear(group);
        log.info("清空分组缓存: group={}", group);
        return "cleared=true, group=" + group;
    }

    // ==================== get / set with CacheType ====================

    public String setWithCacheType(String group, String key, String value, int expireSeconds, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        SmartCacheUtils.set(group, key, value, expireSeconds, type);
        log.info("写入指定缓存类型: group={}, key={}, value={}, cacheType={}", group, key, value, cacheType);
        Object cached = SmartCacheUtils.get(group, key, type);
        return "set=" + value + ", get=" + cached + ", cacheType=" + cacheType;
    }

    public String getWithCacheType(String group, String key, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        Object cached = SmartCacheUtils.get(group, key, type);
        log.info("读取指定缓存类型: group={}, key={}, cacheType={}, result={}", group, key, cacheType, cached);
        return cached != null ? cached.toString() : "null";
    }

    // ==================== remove with CacheType ====================

    public String removeWithCacheType(String group, String key, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        SmartCacheUtils.remove(group, key, type);
        log.info("删除指定缓存类型: group={}, key={}, cacheType={}", group, key, cacheType);
        boolean exists = SmartCacheUtils.contains(group, key, type);
        return "removed=true, exists=" + exists + ", cacheType=" + cacheType;
    }

    // ==================== contains with CacheType ====================

    public String containsWithCacheType(String group, String key, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        boolean exists = SmartCacheUtils.contains(group, key, type);
        log.info("检查指定缓存类型是否存在: group={}, key={}, cacheType={}, exists={}", group, key, cacheType, exists);
        return "contains=" + exists + ", cacheType=" + cacheType;
    }

    // ==================== keys with CacheType ====================

    public String keysWithCacheType(String group, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        Set<String> groupKeys = SmartCacheUtils.keys(group, type);
        log.info("获取指定缓存类型所有key: group={}, cacheType={}, keys={}", group, cacheType, groupKeys);
        return "keys=" + groupKeys + ", cacheType=" + cacheType;
    }

    // ==================== clear with CacheType ====================

    public String clearWithCacheType(String group, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        SmartCacheUtils.clear(group, type);
        log.info("清空指定缓存类型: group={}, cacheType={}", group, cacheType);
        return "cleared=true, group=" + group + ", cacheType=" + cacheType;
    }

    // ==================== cross-app: get / set ====================

    public String setWithCrossApp(
            String appName, String group, String key, String value, int expireSeconds, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        SmartCacheUtils.set(appName, group, key, value, expireSeconds, type);
        log.info(
                "跨应用写入缓存: appName={}, group={}, key={}, value={}, cacheType={}", appName, group, key, value, cacheType);
        Object cached = SmartCacheUtils.get(appName, group, key, type);
        return "set=" + value + ", get=" + cached + ", appName=" + appName;
    }

    public String getWithCrossApp(String appName, String group, String key, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        Object cached = SmartCacheUtils.get(appName, group, key, type);
        log.info(
                "跨应用读取缓存: appName={}, group={}, key={}, cacheType={}, result={}",
                appName,
                group,
                key,
                cacheType,
                cached);
        return cached != null ? cached.toString() : "null";
    }

    // ==================== cross-app: remove ====================

    public String removeWithCrossApp(String appName, String group, String key, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        SmartCacheUtils.remove(appName, group, key, type);
        log.info("跨应用删除缓存: appName={}, group={}, key={}, cacheType={}", appName, group, key, cacheType);
        boolean exists = SmartCacheUtils.contains(appName, group, key, type);
        return "removed=true, exists=" + exists + ", appName=" + appName;
    }

    // ==================== cross-app: contains ====================

    public String containsWithCrossApp(String appName, String group, String key, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        boolean exists = SmartCacheUtils.contains(appName, group, key, type);
        log.info(
                "跨应用检查缓存: appName={}, group={}, key={}, cacheType={}, exists={}",
                appName,
                group,
                key,
                cacheType,
                exists);
        return "contains=" + exists + ", appName=" + appName;
    }

    // ==================== cross-app: keys ====================

    public String keysWithCrossApp(String appName, String group, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        Set<String> appKeys = SmartCacheUtils.keys(appName, group, type);
        log.info("跨应用获取所有key: appName={}, group={}, cacheType={}, keys={}", appName, group, cacheType, appKeys);
        return "keys=" + appKeys + ", appName=" + appName;
    }

    // ==================== cross-app: clear ====================

    public String clearWithCrossApp(String appName, String group, String cacheType) {
        CacheTypeEnum type = CacheTypeEnum.valueOf(cacheType);
        SmartCacheUtils.clear(appName, group, type);
        log.info("跨应用清空缓存: appName={}, group={}, cacheType={}", appName, group, cacheType);
        return "cleared=true, appName=" + appName + ", group=" + group;
    }
}
