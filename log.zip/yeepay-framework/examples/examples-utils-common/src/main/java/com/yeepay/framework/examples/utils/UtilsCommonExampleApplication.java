package com.yeepay.framework.examples.utils;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtilsCommonExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(UtilsCommonExampleApplication.class, args);
    }
}
