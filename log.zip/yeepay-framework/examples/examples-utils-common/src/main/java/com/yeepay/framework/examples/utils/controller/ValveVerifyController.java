package com.yeepay.framework.examples.utils.controller;

import com.yeepay.g3.utils.common.ThreadContextUtils;
import com.yeepay.g3.utils.common.threadcontext.ThreadContext;
import com.yeepay.g3.utils.common.threadcontext.ThreadContextType;
import com.yeepay.infra.atlas.agent.SpanContextUtil;
import com.yeepay.infra.atlas.agent.SpanUtil;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Verify ThreadContextValve and MonitorValve under Spring Boot 3 + JDK 17.
 */
@RestController
@RequestMapping("/verify/valve")
public class ValveVerifyController {

    /**
     * Verify ThreadContextValve:
     * - ThreadContext should be initialized after request enters
     * - GUID should be auto-generated or taken from header
     * - SOA env, lane, context should propagate from headers
     */
    @GetMapping("/thread-context")
    public Map<String, Object> verifyThreadContext() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            boolean initialized = ThreadContextUtils.contextInitialized();
            r.put("contextInitialized", initialized);

            ThreadContext ctx = ThreadContextUtils.getContext();
            if (ctx != null) {
                r.put("guid", ctx.getThreadUID());
                r.put(
                        "guid_notEmpty",
                        ctx.getThreadUID() != null && !ctx.getThreadUID().isEmpty());
                r.put("appName", ctx.getAppName());
                r.put("contextType", ctx.getType() != null ? ctx.getType().name() : null);
                r.put("contextType_isWEB", ctx.getType() == ThreadContextType.WEB);
                r.put("transferLevel", ctx.getTransferLevel());
                r.put("soaEnv", ctx.getSoaEnv());
                r.put("soaContext", ctx.getSoaContext());
                r.put("srcSoaApp", ctx.getSrcSoaApp());
                r.put("lang", ctx.getLang());
            } else {
                r.put("context", "NULL - ThreadContextValve may not be registered");
            }

            r.put("spanContext_initialized", SpanContextUtil.isInitialized());
            r.put("span_initialized", SpanUtil.isInitialized());

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    /**
     * Verify ThreadContextValve with custom headers.
     * Call with headers:
     *   _thread_uid: custom-guid-12345
     *   x-yeepay-cdn-lane: gray  (or _soa_env as fallback)
     *   x-yeepay-cdn-context: test-context  (or _soa_context as fallback)
     *   _src_soa_app: caller-app
     *   _lang: lane-01
     */
    @GetMapping("/thread-context-headers")
    public Map<String, Object> verifyThreadContextHeaders() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            ThreadContext ctx = ThreadContextUtils.getContext();
            if (ctx != null) {
                r.put("guid", ctx.getThreadUID());
                r.put("soaEnv", ctx.getSoaEnv());
                r.put("soaContext", ctx.getSoaContext());
                r.put("srcSoaApp", ctx.getSrcSoaApp());
                r.put("lang", ctx.getLang());
                r.put("hint", "Use curl with custom headers to verify header propagation, e.g.:");
                r.put(
                        "example_curl",
                        "curl -H '_thread_uid: custom-guid-123' "
                                + "-H 'x-yeepay-cdn-lane: gray' "
                                + "-H 'x-yeepay-cdn-context: test-ctx' "
                                + "-H '_src_soa_app: caller-app' "
                                + "-H '_lang: lane-01' "
                                + "http://localhost:8099/verify/valve/thread-context-headers");
            } else {
                r.put("context", "NULL");
            }
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    /**
     * Verify MonitorValve:
     * - Slow requests should be tracked and visible via ServiceMonitor
     * - Uses MonitorValve.getBlockingThreshold() to confirm registration
     */
    @GetMapping("/monitor")
    public Map<String, Object> verifyMonitor(@RequestParam(value = "sleepMs", defaultValue = "0") long sleepMs) {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            long threshold = com.yeepay.g3.utils.common.tomcat.MonitorValve.getBlockingThreshold();
            r.put("blockingThreshold_ms", threshold);
            r.put("blockingThreshold_default_10s", threshold == 10000L);

            long start = System.currentTimeMillis();
            if (sleepMs > 0) {
                Thread.sleep(sleepMs);
            }
            long elapsed = System.currentTimeMillis() - start;
            r.put("requestElapsed_ms", elapsed);
            r.put("wouldTriggerAlarm", elapsed >= threshold);

            r.put(
                    "hint_slow_request",
                    "Call with ?sleepMs=11000 to simulate a slow request that exceeds the 10s threshold");

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    /**
     * Verify MonitorValve: change the blocking threshold and test detection.
     */
    @GetMapping("/monitor-threshold")
    public Map<String, Object> verifyMonitorThreshold(
            @RequestParam(value = "threshold", defaultValue = "2000") long threshold,
            @RequestParam(value = "sleepMs", defaultValue = "3000") long sleepMs) {
        Map<String, Object> r = new LinkedHashMap<>();
        long originalThreshold = com.yeepay.g3.utils.common.tomcat.MonitorValve.getBlockingThreshold();
        try {
            com.yeepay.g3.utils.common.tomcat.MonitorValve.setBlockingThreshold(threshold);
            r.put("threshold_set_to_ms", threshold);

            long start = System.currentTimeMillis();
            if (sleepMs > 0) {
                Thread.sleep(sleepMs);
            }
            long elapsed = System.currentTimeMillis() - start;
            r.put("requestElapsed_ms", elapsed);
            r.put("exceededThreshold", elapsed >= threshold);
            r.put("hint", "Check application logs for 'invoke url use ... miniseconds' message");

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        } finally {
            com.yeepay.g3.utils.common.tomcat.MonitorValve.setBlockingThreshold(originalThreshold);
            r.put("threshold_restored_to_ms", originalThreshold);
        }
        return r;
    }

    /**
     * Combined verification of both valves.
     */
    @GetMapping("/all")
    public Map<String, Object> verifyAll() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("45_threadContextValve", verifyThreadContext());
        result.put("46_monitorValve", verifyMonitor(0));
        return result;
    }
}
