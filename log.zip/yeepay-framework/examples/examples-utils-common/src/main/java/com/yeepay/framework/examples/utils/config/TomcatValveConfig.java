package com.yeepay.framework.examples.utils.config;

import com.yeepay.g3.utils.common.tomcat.MonitorValve;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TomcatValveConfig {

    @Bean
    public WebServerFactoryCustomizer<TomcatServletWebServerFactory> valveCustomizer() {
        return factory -> {
            // ThreadContextValve 已被 ThreadContextRequestListener 替代（更早执行、容器无关）
            // factory.addContextValves(new ThreadContextValve());
            factory.addContextValves(new MonitorValve());
        };
    }
}
