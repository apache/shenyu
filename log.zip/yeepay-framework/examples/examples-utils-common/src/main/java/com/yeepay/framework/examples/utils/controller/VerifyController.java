package com.yeepay.framework.examples.utils.controller;

import com.alibaba.druid.pool.DruidDataSource;
import com.yeepay.g3.utils.common.ArrayUtils;
import com.yeepay.g3.utils.common.AssertUtils;
import com.yeepay.g3.utils.common.BeanUtils;
import com.yeepay.g3.utils.common.CheckUtils;
import com.yeepay.g3.utils.common.ClassUtils;
import com.yeepay.g3.utils.common.CollectionUtils;
import com.yeepay.g3.utils.common.CommonUtils;
import com.yeepay.g3.utils.common.ConvertUtils;
import com.yeepay.g3.utils.common.DateUtils;
import com.yeepay.g3.utils.common.DebugUtils;
import com.yeepay.g3.utils.common.EqualUtils;
import com.yeepay.g3.utils.common.FormatUtils;
import com.yeepay.g3.utils.common.HttpClientUtil;
import com.yeepay.g3.utils.common.IDCardUtils;
import com.yeepay.g3.utils.common.MaskUtils;
import com.yeepay.g3.utils.common.MathUtils;
import com.yeepay.g3.utils.common.MessageFormater;
import com.yeepay.g3.utils.common.NumberFormatUtils;
import com.yeepay.g3.utils.common.OgnlUtils;
import com.yeepay.g3.utils.common.OrderedProperties;
import com.yeepay.g3.utils.common.PinyinUtils;
import com.yeepay.g3.utils.common.PropertyUtils;
import com.yeepay.g3.utils.common.ReflectionUtils;
import com.yeepay.g3.utils.common.Resources;
import com.yeepay.g3.utils.common.StringUtils;
import com.yeepay.g3.utils.common.UIDGenerator;
import com.yeepay.g3.utils.common.ValidateUtils;
import com.yeepay.g3.utils.common.ZoneUtils;
import com.yeepay.g3.utils.common.datasource.Config;
import com.yeepay.g3.utils.common.datasource.DataSourceFactoryBean;
import com.yeepay.g3.utils.common.datasource.MonitorDataSource;
import com.yeepay.g3.utils.common.datasource.MonitorDataSourceManager;
import com.yeepay.g3.utils.common.datasource.MonitorDataSourceSummary;
import com.yeepay.g3.utils.common.datasource.impl.DruidPooledDataSource;
import com.yeepay.g3.utils.common.datasource.impl.DruidPooledDataSourceFactory;
import com.yeepay.g3.utils.common.encrypt.AES;
import com.yeepay.g3.utils.common.encrypt.Base64;
import com.yeepay.g3.utils.common.encrypt.DESede;
import com.yeepay.g3.utils.common.encrypt.Digest;
import com.yeepay.g3.utils.common.encrypt.Hex;
import com.yeepay.g3.utils.common.encrypt.HmacSign;
import com.yeepay.g3.utils.common.encrypt.pki.KeyUtils;
import com.yeepay.g3.utils.common.encrypt.pki.RSA;
import com.yeepay.g3.utils.common.exception.YeepayBizException;
import com.yeepay.g3.utils.common.exception.YeepayRuntimeException;
import com.yeepay.g3.utils.common.httpclient.SimpleHttpUtils;
import com.yeepay.g3.utils.common.json.JSONArray;
import com.yeepay.g3.utils.common.json.JSONObject;
import com.yeepay.g3.utils.common.json.JSONUtils;
import com.yeepay.g3.utils.common.json.XML;
import com.yeepay.g3.utils.common.log.Logger;
import com.yeepay.g3.utils.common.log.LoggerFactory;
import com.yeepay.g3.utils.common.monitor.ListableServiceMonitor;
import com.yeepay.g3.utils.common.monitor.ServiceMonitorListModel;
import com.yeepay.g3.utils.common.monitor.ServiceMonitorRegister;
import com.yeepay.g3.utils.common.monitor.models.model.ApplicationStatusModel;
import com.yeepay.g3.utils.common.monitor.models.model.JVMModel;
import com.yeepay.g3.utils.common.monitor.models.model.ServerResourceAccessOperation;
import com.yeepay.g3.utils.common.monitor.models.util.InitializationHelper;
import com.yeepay.g3.utils.common.mvel.MVELUtils;
import com.yeepay.g3.utils.common.page.PageList;
import com.yeepay.g3.utils.common.page.Paginator;
import com.yeepay.g3.utils.common.quota.QuotaManager;
import com.yeepay.g3.utils.common.security.Cryptos;
import java.beans.PropertyDescriptor;
import java.io.InputStream;
import java.math.RoundingMode;
import java.security.Key;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/verify")
public class VerifyController {

    private final DataSource dataSource;

    @Value("${spring.datasource.url}")
    private String dbUrl;

    @Value("${spring.datasource.username}")
    private String dbUser;

    @Value("${spring.datasource.password}")
    private String dbPassword;

    public VerifyController(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @GetMapping("/all")
    public Map<String, Object> verifyAll() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("01_stringUtils", verifyStringUtils());
        result.put("02_dateUtils", verifyDateUtils());
        result.put("03_validateUtils", verifyValidateUtils());
        result.put("04_messageFormater", verifyMessageFormater());
        result.put("05_encrypt", verifyEncrypt());
        result.put("06_collectionUtils", verifyCollectionUtils());
        result.put("07_mathUtils", verifyMathUtils());
        result.put("08_maskUtils", verifyMaskUtils());
        result.put("09_beanUtils", verifyBeanUtils());
        result.put("10_numberFormatUtils", verifyNumberFormatUtils());
        result.put("11_uidGenerator", verifyUIDGenerator());
        result.put("12_pinyinUtils", verifyPinyinUtils());
        result.put("13_convertUtils", verifyConvertUtils());
        result.put("14_ognlUtils", verifyOgnlUtils());
        result.put("15_jsonUtils", verifyJsonUtils());
        result.put("16_checkUtils", verifyCheckUtils());
        result.put("17_equalUtils", verifyEqualUtils());
        result.put("18_formatUtils", verifyFormatUtils());
        result.put("19_idCardUtils", verifyIDCardUtils());
        result.put("20_base64", verifyBase64());
        result.put("21_arrayUtils", verifyArrayUtils());
        result.put("22_assertUtils", verifyAssertUtils());
        result.put("23_reflectionUtils", verifyReflectionUtils());
        result.put("24_propertyUtils", verifyPropertyUtils());
        result.put("25_classUtils", verifyClassUtils());
        result.put("26_debugUtils", verifyDebugUtils());
        result.put("27_commonUtils", verifyCommonUtils());
        result.put("28_orderedProperties", verifyOrderedProperties());
        result.put("29_resources", verifyResources());
        result.put("30_zoneUtils", verifyZoneUtils());
        result.put("31_hex", verifyHex());
        result.put("32_cryptos", verifyCryptos());
        result.put("33_rsaKeyUtils", verifyRsaKeyUtils());
        result.put("34_jsonUtilsAdvanced", verifyJsonUtilsAdvanced());
        result.put("35_xmlJson", verifyXmlJson());
        result.put("36_mvelUtils", verifyMvelUtils());
        result.put("37_paginator", verifyPaginator());
        result.put("38_logger", verifyLogger());
        result.put("39_exception", verifyException());
        result.put("40_quotaManager", verifyQuotaManager());
        result.put("41_druidStarter", verifyDruidStarter());
        result.put("42_dataSourceFactory", verifyDataSourceFactory());
        result.put("43_httpClient", verifyHttpClient());
        result.put("44_simpleHttp", verifySimpleHttp());
        result.put("45_monitorDataSource", verifyMonitorDataSource());
        result.put("46_dataSourceFactoryBean", verifyDataSourceFactoryBean());
        result.put("47_serviceMonitorListModel", verifyServiceMonitorListModel());
        result.put("48_jvmModel", verifyJvmModel());
        result.put("49_applicationStatusModel", verifyApplicationStatusModel());
        result.put("50_serverResourceAccessOperation", verifyServerResourceAccessOperation());
        result.put("51_initializationHelper", verifyInitializationHelper());
        return result;
    }

    // ===================== 1. StringUtils =====================
    @GetMapping("/string")
    public Map<String, Object> verifyStringUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("isBlank_null", StringUtils.isBlank(null));
            r.put("isBlank_empty", StringUtils.isBlank(""));
            r.put("isNotBlank", StringUtils.isNotBlank("hello"));
            r.put("trim", StringUtils.trim("  abc  "));
            r.put("replace", StringUtils.replace("hello world", "world", "JDK17"));
            r.put("substringByByte", StringUtils.substringByByte("你好世界", 0, 6));
            r.put("isEmpty", StringUtils.isEmpty(""));
            r.put("isNotEmpty", StringUtils.isNotEmpty("abc"));
            r.put("equals", StringUtils.equals("abc", "abc"));
            r.put("defaultIfEmpty", StringUtils.defaultIfEmpty("", "default_val"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 2. DateUtils =====================
    @GetMapping("/date")
    public Map<String, Object> verifyDateUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Date now = new Date();
            r.put("formatDatetime", DateUtils.toString(now, "yyyy-MM-dd HH:mm:ss"));
            r.put("formatDate", DateUtils.toString(now, "yyyy-MM-dd"));
            Date parsed = DateUtils.parseDate("2024-01-15", "yyyy-MM-dd");
            r.put("parseDate", parsed != null);
            Date parsed2 = DateUtils.parseDate("2024-06-15 10:30:00", "yyyy-MM-dd HH:mm:ss");
            r.put("parseDatetime", parsed2 != null);
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 3. ValidateUtils =====================
    @GetMapping("/validate")
    public Map<String, Object> verifyValidateUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("isEmail_valid", ValidateUtils.isEmail("test@yeepay.com"));
            r.put("isEmail_invalid", !ValidateUtils.isEmail("not-email"));
            r.put("isMobile_valid", ValidateUtils.isMobile("13800138000"));
            r.put("isMobile_invalid", !ValidateUtils.isMobile("1234"));
            r.put("isIP_valid", ValidateUtils.isIP("192.168.1.1"));
            r.put("isIP_invalid", !ValidateUtils.isIP("999.999.999.999"));
            r.put("isEmpty_null", ValidateUtils.isEmpty(null));
            r.put("isEmpty_string", ValidateUtils.isEmpty(""));
            r.put("isNotEmpty", !ValidateUtils.isEmpty("abc"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 4. MessageFormater =====================
    @GetMapping("/message")
    public Map<String, Object> verifyMessageFormater() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            MessageFormater formater = new MessageFormater();
            r.put("escapeHtml", formater.escapeHtml("<script>alert('xss')</script>"));
            r.put("escapeJavaScript", formater.escapeJavaScript("alert('test')"));
            r.put("escapeXml", formater.escapeXml("<tag attr=\"val\">"));
            r.put("maskCellphone", formater.maskCellphone("13800138000"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 5. Encrypt =====================
    @GetMapping("/encrypt")
    public Map<String, Object> verifyEncrypt() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            String md5 = Digest.md5Digest("hello");
            r.put("md5", md5);
            r.put("md5_ok", md5 != null && md5.length() == 32);
        } catch (Exception e) {
            r.put("md5", "FAIL: " + e.getMessage());
        }
        try {
            String sha = Digest.shaDigest("hello");
            r.put("sha", sha);
            r.put("sha_ok", sha != null && sha.length() == 40);
        } catch (Exception e) {
            r.put("sha", "FAIL: " + e.getMessage());
        }
        try {
            String key16 = "1234567890123456";
            String encrypted = AES.encryptToBase64("hello world", key16);
            String decrypted = AES.decryptFromBase64(encrypted, key16);
            r.put("aes_encrypt", encrypted);
            r.put("aes_decrypt", decrypted);
            r.put("aes_ok", "hello world".equals(decrypted));
        } catch (Exception e) {
            r.put("aes", "FAIL: " + e.getMessage());
        }
        try {
            String key24 = "123456789012345678901234";
            String desEncrypted = DESede.encryptToBase64("hello DESede", key24);
            String desDecrypted = DESede.decryptFromBase64(desEncrypted, key24);
            r.put("desede_encrypt", desEncrypted);
            r.put("desede_decrypt", desDecrypted);
            r.put("desede_ok", "hello DESede".equals(desDecrypted));
        } catch (Exception e) {
            r.put("desede", "FAIL: " + e.getMessage());
        }
        try {
            String hmac = HmacSign.signToHex("hello", "secret_key");
            r.put("hmac_hex", hmac);
            r.put("hmac_ok", hmac != null && !hmac.isEmpty());
            String hmacBase64 = HmacSign.signToBase64("hello", "secret_key");
            r.put("hmac_base64", hmacBase64);
        } catch (Exception e) {
            r.put("hmac", "FAIL: " + e.getMessage());
        }
        r.put("status", "PASS");
        return r;
    }

    // ===================== 6. CollectionUtils =====================
    @GetMapping("/collection")
    public Map<String, Object> verifyCollectionUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            List<String> list1 = new ArrayList<>(Arrays.asList("a", "b", "c"));
            List<String> list2 = new ArrayList<>(Arrays.asList("b", "c", "d"));
            r.put("union_size", CollectionUtils.union(list1, list2).size());
            r.put(
                    "intersection_size",
                    CollectionUtils.intersection(list1, list2).size());
            r.put("subtract_size", CollectionUtils.subtract(list1, list2).size());
            r.put("disjunction_size", CollectionUtils.disjunction(list1, list2).size());
            r.put("containsAny", CollectionUtils.containsAny(list1, list2));
            r.put("isSubCollection", CollectionUtils.isSubCollection(Arrays.asList("a", "b"), list1));
            r.put("isEqualCollection", CollectionUtils.isEqualCollection(list1, new ArrayList<>(list1)));
            List<String> withDups = new ArrayList<>(Arrays.asList("a", "b", "a", "c", "b"));
            r.put("removeDup_size", CollectionUtils.removeDupValue(withDups).size());
            r.put("isCollection_list", CollectionUtils.isCollection(list1));
            r.put("isCollection_string", !CollectionUtils.isCollection("not_a_collection"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 7. MathUtils =====================
    @GetMapping("/math")
    public Map<String, Object> verifyMathUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("add_double", MathUtils.add(0.1, 0.2));
            r.put("add_string", MathUtils.add("100.01", "200.02"));
            r.put("subtract", MathUtils.subtract(10.5, 3.2));
            r.put("multiply", MathUtils.multiply(2.5, 4.0));
            r.put("divide", MathUtils.divide(10.0, 3.0, 4));
            r.put("divide_string", MathUtils.divide("100", "7", 6));
            r.put("add_precision_ok", "0.3".equals(String.valueOf(MathUtils.add(0.1, 0.2))));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 8. MaskUtils =====================
    @GetMapping("/mask")
    public Map<String, Object> verifyMaskUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("maskCellphone", MaskUtils.maskCellphone("13800138000"));
            r.put("maskEmail", MaskUtils.maskEmail("test@yeepay.com"));
            r.put("maskIDCard", MaskUtils.maskIDCardNo("110101199001011234"));
            r.put("maskBankCard", MaskUtils.maskBankCardNo("6222021234567890123"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 9. BeanUtils =====================
    @GetMapping("/bean")
    public Map<String, Object> verifyBeanUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Map<String, Object> source = new HashMap<>();
            source.put("name", "test");
            source.put("value", 123);
            Map<String, Object> target = new HashMap<>();
            BeanUtils.copyProperties(source, target);
            r.put("copyProperties_ok", "test".equals(target.get("name")));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 10. NumberFormatUtils =====================
    @GetMapping("/numberformat")
    public Map<String, Object> verifyNumberFormatUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("format_double", NumberFormatUtils.format(12345.678, "#,##0.00"));
            r.put("format_long", NumberFormatUtils.format(1234567L, "#,###"));
            r.put("parse", NumberFormatUtils.parse("12,345.67", "#,##0.00"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 11. UIDGenerator =====================
    @GetMapping("/uid")
    public Map<String, Object> verifyUIDGenerator() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            String uuid = UIDGenerator.getUUID();
            r.put("uuid", uuid);
            r.put("uuid_length", uuid.length());
            String uuid2 = UIDGenerator.getUUIDNonBlocked();
            r.put("uuidNonBlocked", uuid2);
            r.put("uuid_unique", !uuid.equals(uuid2));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 12. PinyinUtils =====================
    @GetMapping("/pinyin")
    public Map<String, Object> verifyPinyinUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Character firstChar = PinyinUtils.getPinYinFirstChar('中');
            r.put("firstChar", firstChar);
            String pinyin = PinyinUtils.getPinyin('中');
            r.put("pinyin", pinyin);
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 13. ConvertUtils =====================
    @GetMapping("/convert")
    public Map<String, Object> verifyConvertUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Object intVal = ConvertUtils.convert(Integer.class, "123");
            r.put("toInt", intVal);
            r.put("toInt_ok", Integer.valueOf(123).equals(intVal));
            Object longVal = ConvertUtils.convert(Long.class, "999999");
            r.put("toLong", longVal);
            r.put("toLong_ok", Long.valueOf(999999L).equals(longVal));
            Object boolVal = ConvertUtils.convert(Boolean.class, "true");
            r.put("toBool", boolVal);
            r.put("toBool_ok", Boolean.TRUE.equals(boolVal));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 14. OgnlUtils =====================
    @GetMapping("/ognl")
    public Map<String, Object> verifyOgnlUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Map<String, Object> root = new HashMap<>();
            root.put("name", "yeepay");
            root.put("count", 100);
            Object nameVal = OgnlUtils.executeExpression("name", root);
            r.put("getName", nameVal);
            r.put("getName_ok", "yeepay".equals(nameVal));
            Object countVal = OgnlUtils.executeExpression("count", root);
            r.put("getCount", countVal);
            r.put("getCount_ok", Integer.valueOf(100).equals(countVal));
            Object expr = OgnlUtils.executeExpression("count > 50", root);
            r.put("expression_eval", expr);
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 15. JSON Utils =====================
    @GetMapping("/json")
    public Map<String, Object> verifyJsonUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            JSONObject obj = new JSONObject();
            obj.put("name", "yeepay");
            obj.put("version", 5);
            obj.put("jdk17", true);
            r.put("jsonObject_toString", obj.toString());
            r.put("jsonObject_get", obj.getString("name"));

            JSONObject parsed = new JSONObject("{\"key\":\"value\",\"num\":42}");
            r.put("jsonParse_key", parsed.getString("key"));
            r.put("jsonParse_num", parsed.getInt("num"));

            JSONArray arr = new JSONArray();
            arr.put("item1");
            arr.put("item2");
            arr.put(3);
            r.put("jsonArray_length", arr.length());
            r.put("jsonArray_get0", arr.getString(0));

            JSONArray parsedArr = new JSONArray("[1,2,3,\"four\"]");
            r.put("jsonArrayParse_length", parsedArr.length());
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 16. CheckUtils =====================
    @GetMapping("/check")
    public Map<String, Object> verifyCheckUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("isNull_null", CheckUtils.isNull(null));
            r.put("isNull_obj", !CheckUtils.isNull("abc"));
            r.put("isEmpty_null", CheckUtils.isEmpty(null));
            r.put("isEmpty_empty", CheckUtils.isEmpty(""));
            r.put("isEmpty_obj", !CheckUtils.isEmpty("abc"));
            r.put("isPrimitive_int", CheckUtils.isPrimitive(123));
            r.put("isPrimitive_string", !CheckUtils.isPrimitive("abc"));
            boolean notNullOk = false;
            try {
                CheckUtils.notNull("abc", "should not throw");
                notNullOk = true;
            } catch (Exception ignored) {
            }
            r.put("notNull_ok", notNullOk);
            boolean notNullFail = false;
            try {
                CheckUtils.notNull(null, "should throw");
            } catch (Exception e) {
                notNullFail = true;
            }
            r.put("notNull_throws", notNullFail);
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 17. EqualUtils =====================
    @GetMapping("/equal")
    public Map<String, Object> verifyEqualUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("equal_same", EqualUtils.isEqual("abc", "abc"));
            r.put("equal_diff", !EqualUtils.isEqual("abc", "xyz"));
            r.put("equal_null_null", EqualUtils.isEqual(null, null));
            r.put("equal_null_obj", !EqualUtils.isEqual(null, "abc"));
            r.put("equal_int", EqualUtils.isEqual(100, 100));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 18. FormatUtils =====================
    @GetMapping("/format")
    public Map<String, Object> verifyFormatUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("formatDate", FormatUtils.formatDate(new Date(), "yyyy-MM-dd", null));
            r.put("formatNumber", FormatUtils.formatNumber(12345.678, "#,##0.00", RoundingMode.HALF_UP, 1));
            r.put("formatCellphone", FormatUtils.formatCellphone("13800138000"));
            r.put("formatEmail", FormatUtils.formatEmail("test@yeepay.com"));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 19. IDCardUtils =====================
    @GetMapping("/idcard")
    public Map<String, Object> verifyIDCardUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("verify_18_invalid", !IDCardUtils.verifi("110101199001011234"));
            r.put("verify_null", !IDCardUtils.verifi(null));
            r.put("verify_empty", !IDCardUtils.verifi(""));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 20. Base64 =====================
    @GetMapping("/base64")
    public Map<String, Object> verifyBase64() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            String encoded = Base64.encode("Hello JDK17 Base64!");
            r.put("encode", encoded);
            String decoded = Base64.decode(encoded);
            r.put("decode", decoded);
            r.put("roundtrip_ok", "Hello JDK17 Base64!".equals(decoded));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 41. Druid Spring Boot Starter =====================
    @GetMapping("/druid-starter")
    public Map<String, Object> verifyDruidStarter() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("dataSource_type", dataSource.getClass().getName());
            r.put("is_druid", dataSource instanceof DruidDataSource);

            if (dataSource instanceof DruidDataSource druid) {
                r.put("druid_initialSize", druid.getInitialSize());
                r.put("druid_minIdle", druid.getMinIdle());
                r.put("druid_maxActive", druid.getMaxActive());
                r.put("druid_driverClass", druid.getDriverClassName());
                r.put("druid_url", druid.getUrl());
                r.put("druid_poolingCount", druid.getPoolingCount());
                r.put("druid_activeCount", druid.getActiveCount());
                r.put("druid_testWhileIdle", druid.isTestWhileIdle());
                r.put("druid_validationQuery", druid.getValidationQuery());
            }

            try (Connection conn = dataSource.getConnection()) {
                r.put("connection_ok", conn != null && !conn.isClosed());
                r.put("connection_class", conn.getClass().getName());
                executeCrudTest(conn, r, "starter");
            }

            if (dataSource instanceof DruidDataSource druid) {
                r.put("druid_connectCount", druid.getConnectCount());
                r.put("druid_closeCount", druid.getCloseCount());
            }

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 42. DataSourceFactoryBean 方式 =====================
    @GetMapping("/datasource-factory")
    public Map<String, Object> verifyDataSourceFactory() {
        Map<String, Object> r = new LinkedHashMap<>();
        DataSource factoryDs = null;
        try {
            String encryptedPassword = AES.encryptToBase64(dbPassword, Config.AES_KEY);
            r.put("aes_encrypt_password_ok", encryptedPassword != null);

            Properties props = new Properties();
            props.setProperty("driverClass", "com.mysql.cj.jdbc.Driver");
            props.setProperty("jdbcUrl", dbUrl);
            props.setProperty("user", dbUser);
            props.setProperty("password", encryptedPassword);
            props.setProperty("validationQuery", "SELECT 1");
            props.setProperty("min", "1");
            props.setProperty("max", "5");
            props.setProperty("testperiod", "30");
            props.setProperty("maxIdle", "300");
            props.setProperty("checkoutTimeout", "5000");
            props.setProperty("useAtlas", "false");

            Config config = Config.instance(props);
            r.put("config_driverClass", config.getDriverClass());
            r.put("config_jdbcUrl", config.getJdbcUrl());
            r.put("config_user", config.getUser());
            r.put("config_password_decrypted_ok", dbPassword.equals(config.getPassword()));
            r.put("config_minPoolSize", config.getMinPoolSize());
            r.put("config_maxPoolSize", config.getMaxPoolSize());
            r.put("config_validationQuery", config.getValidationQuery());

            DruidPooledDataSourceFactory factory = new DruidPooledDataSourceFactory();
            factoryDs = factory.getDataSource(config);
            r.put("factoryDs_type", factoryDs.getClass().getName());
            r.put("factoryDs_ok", factoryDs instanceof DruidPooledDataSource);

            try (Connection conn = factoryDs.getConnection()) {
                r.put("factory_connection_ok", conn != null && !conn.isClosed());
                executeCrudTest(conn, r, "factory");
            }

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        } finally {
            if (factoryDs instanceof DruidPooledDataSource ds) {
                ds.close();
            }
        }
        return r;
    }

    // ===================== 21. ArrayUtils =====================
    @GetMapping("/array")
    public Map<String, Object> verifyArrayUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("EMPTY_STRING_ARRAY", ArrayUtils.EMPTY_STRING_ARRAY.length == 0);
            r.put("EMPTY_INT_ARRAY", ArrayUtils.EMPTY_INT_ARRAY.length == 0);
            r.put("EMPTY_OBJECT_ARRAY", ArrayUtils.EMPTY_OBJECT_ARRAY.length == 0);
            r.put("EMPTY_LONG_ARRAY", ArrayUtils.EMPTY_LONG_ARRAY.length == 0);
            r.put("EMPTY_BYTE_ARRAY", ArrayUtils.EMPTY_BYTE_ARRAY.length == 0);
            r.put("EMPTY_DOUBLE_ARRAY", ArrayUtils.EMPTY_DOUBLE_ARRAY.length == 0);
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 22. AssertUtils =====================
    @GetMapping("/assert")
    public Map<String, Object> verifyAssertUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            AssertUtils.isTrue(true, "should pass");
            r.put("isTrue_pass", true);

            boolean isTrueFail = false;
            try {
                AssertUtils.isTrue(false, "should fail");
            } catch (IllegalArgumentException e) {
                isTrueFail = true;
            }
            r.put("isTrue_throws", isTrueFail);

            AssertUtils.notNull("abc", "should pass");
            r.put("notNull_pass", true);

            boolean notNullFail = false;
            try {
                AssertUtils.notNull(null, "should fail");
            } catch (IllegalArgumentException e) {
                notNullFail = true;
            }
            r.put("notNull_throws", notNullFail);

            AssertUtils.isNull(null, "should pass");
            r.put("isNull_pass", true);

            boolean isNullFail = false;
            try {
                AssertUtils.isNull("not null", "should fail");
            } catch (IllegalArgumentException e) {
                isNullFail = true;
            }
            r.put("isNull_throws", isNullFail);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 23. ReflectionUtils =====================
    @GetMapping("/reflection")
    public Map<String, Object> verifyReflectionUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Class<?> clz = ReflectionUtils.classForName("java.util.HashMap");
            r.put("classForName", clz.getName());
            r.put("classForName_ok", clz == HashMap.class);

            Map<String, Object> map = new HashMap<>();
            map.put("key1", "value1");
            Object result = ReflectionUtils.executeMethod(map, "size");
            r.put("executeMethod_size", result);

            Object getResult =
                    ReflectionUtils.executeMethod(map, "get", new Object[] {"key1"}, new Class[] {Object.class});
            r.put("executeMethod_get", getResult);
            r.put("executeMethod_get_ok", "value1".equals(getResult));

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 24. PropertyUtils =====================
    @GetMapping("/property")
    public Map<String, Object> verifyPropertyUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            PropertyDescriptor[] descriptors = PropertyUtils.getPropertyDescriptors(Paginator.class);
            r.put("descriptors_count", descriptors.length);
            r.put("descriptors_ok", descriptors.length > 0);

            String[] names = PropertyUtils.getPropertyNames(Paginator.class);
            r.put("propertyNames_count", names.length);

            Class<?> type = PropertyUtils.getPropertyType(Paginator.class, "page");
            r.put("propertyType_page", type != null ? type.getName() : "null");

            Paginator p = new Paginator(10, 100);
            Object page = PropertyUtils.getProperty(p, "page");
            r.put("getProperty_page", page);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 25. ClassUtils =====================
    @GetMapping("/classutils")
    public Map<String, Object> verifyClassUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            java.lang.reflect.Method method = ClassUtils.findMethod(HashMap.class, "put", Object.class, Object.class);
            r.put("findMethod", method != null);
            r.put("findMethod_name", method != null ? method.getName() : "null");

            Class<?> iface = ClassUtils.getAllInterface(ArrayList.class);
            r.put("getAllInterface", iface != null ? iface.getName() : "null");

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 26. DebugUtils =====================
    @GetMapping("/debug")
    public Map<String, Object> verifyDebugUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
            String full = DebugUtils.getStackTrace(stacks);
            r.put("getStackTrace_ok", full != null && full.contains("verifyDebugUtils"));
            r.put("getStackTrace_length", full.length());

            String shortTrace = DebugUtils.getShortStackTrace(stacks, 3);
            r.put("getShortStackTrace_ok", shortTrace != null && !shortTrace.isEmpty());

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 27. CommonUtils =====================
    @GetMapping("/common")
    public Map<String, Object> verifyCommonUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            String uuid = CommonUtils.getUUID();
            r.put("uuid", uuid);
            r.put("uuid_ok", uuid != null && !uuid.isEmpty());

            String uuidNonBlocked = CommonUtils.getUUIDNonBlocked();
            r.put("uuidNonBlocked", uuidNonBlocked);
            r.put("uuidNonBlocked_ok", uuidNonBlocked != null && !uuidNonBlocked.isEmpty());

            r.put("uuid_unique", !uuid.equals(uuidNonBlocked));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 28. OrderedProperties =====================
    @GetMapping("/ordered-properties")
    public Map<String, Object> verifyOrderedProperties() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            OrderedProperties props = new OrderedProperties();
            props.setProperty("z_key", "z_val");
            props.setProperty("a_key", "a_val");
            props.setProperty("m_key", "m_val");
            r.put("size", props.size());
            r.put("get_a", props.getProperty("a_key"));
            r.put("get_z", props.getProperty("z_key"));

            List<String> keys = new ArrayList<>();
            for (Object k : props.keySet()) {
                keys.add(k.toString());
            }
            r.put("keys_order", keys.toString());
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 29. Resources =====================
    @GetMapping("/resources")
    public Map<String, Object> verifyResources() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            ClassLoader cl = Resources.getDefaultClassLoader();
            r.put("defaultClassLoader", cl != null);

            InputStream is = Resources.getResourceAsStream("application.yml");
            r.put("loadApplicationYml", is != null);
            if (is != null) is.close();

            Properties props = Resources.getResourceAsProperties("dbconf/testdb.properties");
            r.put("loadDbconf", props != null);
            if (props != null) {
                r.put("dbconf_driverClass", props.getProperty("driverClass"));
            }

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 30. ZoneUtils =====================
    @GetMapping("/zone")
    public Map<String, Object> verifyZoneUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("isGzone", ZoneUtils.isGzone());
            r.put("isRzone", ZoneUtils.isRzone());
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 31. Hex =====================
    @GetMapping("/hex")
    public Map<String, Object> verifyHex() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            byte[] data = "Hello JDK17".getBytes("UTF-8");
            String hexStr = Hex.toHex(data);
            r.put("toHex", hexStr);
            r.put("toHex_ok", hexStr != null && !hexStr.isEmpty());

            byte[] decoded = Hex.fromHex(hexStr);
            String decodedStr = new String(decoded, "UTF-8");
            r.put("fromHex", decodedStr);
            r.put("roundtrip_ok", "Hello JDK17".equals(decodedStr));
            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 32. Cryptos =====================
    @GetMapping("/cryptos")
    public Map<String, Object> verifyCryptos() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            byte[] aesKey = Cryptos.generateAesKey();
            r.put("generateAesKey_length", aesKey.length);

            byte[] input = "hello cryptos".getBytes("UTF-8");
            byte[] encrypted = Cryptos.aesEncrypt(input, aesKey);
            String decrypted = Cryptos.aesDecrypt(encrypted, aesKey);
            r.put("aes_roundtrip_ok", "hello cryptos".equals(decrypted));

            byte[] hmacKey = Cryptos.generateHmacSha1Key();
            r.put("generateHmacKey_length", hmacKey.length);

            byte[] hmac = Cryptos.hmacSha1(input, hmacKey);
            r.put("hmacSha1_length", hmac.length);
            r.put("hmacSha1_valid", Cryptos.isMacValid(hmac, input, hmacKey));

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 33. RSA + KeyUtils =====================
    @GetMapping("/rsa")
    public Map<String, Object> verifyRsaKeyUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Map<String, Object> keyMap = KeyUtils.initKey();
            r.put("initKey_ok", keyMap != null && !keyMap.isEmpty());

            Key publicKey = KeyUtils.getPublicKey(keyMap);
            Key privateKey = KeyUtils.getPrivateKey(keyMap);
            r.put("publicKey_algorithm", publicKey.getAlgorithm());
            r.put("privateKey_algorithm", privateKey.getAlgorithm());

            String plainText = "RSA JDK17 Test";
            String encrypted = RSA.encryptToBase64(plainText, publicKey);
            r.put("rsa_encrypted", encrypted != null && !encrypted.isEmpty());

            String decrypted = RSA.decryptFromBase64(encrypted, privateKey);
            r.put("rsa_decrypted", decrypted);
            r.put("rsa_roundtrip_ok", plainText.equals(decrypted));

            String signature = RSA.sign(plainText, (java.security.PrivateKey) privateKey);
            r.put("rsa_signature_ok", signature != null && !signature.isEmpty());

            boolean verified = RSA.verifySign(plainText, signature, (java.security.PublicKey) publicKey);
            r.put("rsa_verify_ok", verified);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 34. JSONUtils (Jackson-based) =====================
    @GetMapping("/json-utils")
    public Map<String, Object> verifyJsonUtilsAdvanced() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("name", "yeepay");
            map.put("version", 5);
            map.put("jdk17", true);
            String jsonStr = JSONUtils.toJsonString(map);
            r.put("toJsonString", jsonStr);
            r.put("toJsonString_ok", jsonStr != null && jsonStr.contains("yeepay"));

            Map<String, Object> parsed = JSONUtils.jsonToMap(jsonStr, String.class, Object.class);
            r.put("jsonToMap_ok", parsed != null && "yeepay".equals(parsed.get("name")));

            String listJson = "[{\"id\":1},{\"id\":2}]";
            List<?> list = JSONUtils.jsonToList(listJson, Map.class);
            r.put("jsonToList_size", list != null ? list.size() : 0);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 35. XML <-> JSON =====================
    @GetMapping("/xml-json")
    public Map<String, Object> verifyXmlJson() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            String xml = "<root><name>yeepay</name><version>5</version></root>";
            JSONObject jsonFromXml = XML.toJSONObject(xml);
            r.put("xmlToJson", jsonFromXml.toString());
            r.put("xmlToJson_ok", jsonFromXml.has("root"));

            JSONObject inner = jsonFromXml.getJSONObject("root");
            r.put("xml_name", inner.getString("name"));
            r.put("xml_version", inner.getInt("version"));

            String backToXml = XML.toString(jsonFromXml);
            r.put("jsonToXml", backToXml);
            r.put("jsonToXml_ok", backToXml.contains("yeepay"));

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 36. MVELUtils =====================
    @GetMapping("/mvel")
    public Map<String, Object> verifyMvelUtils() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Map<String, Object> vars = new HashMap<>();
            vars.put("name", "yeepay");
            vars.put("amount", 100);

            Object result1 = MVELUtils.eval("name", null, vars);
            r.put("eval_name", result1);
            r.put("eval_name_ok", "yeepay".equals(result1));

            Object result2 = MVELUtils.eval("amount * 2", null, vars);
            r.put("eval_expr", result2);
            r.put("eval_expr_ok", Integer.valueOf(200).equals(result2));

            Object result3 = MVELUtils.eval("amount > 50 ? 'high' : 'low'", null, vars);
            r.put("eval_ternary", result3);
            r.put("eval_ternary_ok", "high".equals(result3));

            String tpl = "Hello @{name}, total=@{amount * 3}";
            String rendered = MVELUtils.evalTemplate(tpl, null, vars);
            r.put("evalTemplate", rendered);
            r.put("evalTemplate_ok", rendered.contains("yeepay") && rendered.contains("300"));

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 37. Paginator + PageList =====================
    @GetMapping("/paginator")
    public Map<String, Object> verifyPaginator() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Paginator p = new Paginator(10, 95);
            r.put("totalCount", p.getTotalCount());
            r.put("pageSize", p.getPageSize());
            r.put("pages", p.getPages());
            r.put("page", p.getPage());
            r.put("firstPage", p.getFirstPage());
            r.put("lastPage", p.getLastPage());
            r.put("offset", p.getOffset());
            r.put("length", p.getLength());
            r.put("beginIndex", p.getBeginIndex());
            r.put("endIndex", p.getEndIndex());

            p.setPage(5);
            r.put("setPage5_page", p.getPage());
            r.put("setPage5_offset", p.getOffset());
            r.put("previousPage", p.getPreviousPage());
            r.put("nextPage", p.getNextPage());

            PageList<String> pageList = new PageList<>();
            pageList.add("item1");
            pageList.add("item2");
            pageList.add("item3");
            pageList.setPaginator(new Paginator(10, 100));
            r.put("pageList_size", pageList.size());
            r.put("pageList_get0", pageList.get(0));
            r.put("pageList_paginator_pages", pageList.getPaginator().getPages());

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 38. Logger / LoggerFactory =====================
    @GetMapping("/logger")
    public Map<String, Object> verifyLogger() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            Logger logger = LoggerFactory.getLogger(VerifyController.class);
            r.put("logger_ok", logger != null);
            r.put("logger_class", logger.getClass().getName());

            logger.info("JDK17 compatibility test - info level");
            r.put("log_info", "OK");
            logger.warn("JDK17 compatibility test - warn level");
            r.put("log_warn", "OK");
            logger.debug("JDK17 compatibility test - debug level");
            r.put("log_debug", "OK");

            Logger namedLogger = LoggerFactory.getLogger("testLogger");
            r.put("namedLogger_ok", namedLogger != null);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 39. Exception =====================
    @GetMapping("/exception")
    public Map<String, Object> verifyException() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            YeepayRuntimeException rtEx = new YeepayRuntimeException("test error: {0}", "detail");
            r.put("runtimeException_msg", rtEx.getMessage());
            r.put("runtimeException_ok", rtEx instanceof RuntimeException);
            r.put(
                    "runtimeException_hasMsg",
                    rtEx.getMessage() != null && rtEx.getMessage().contains("detail"));

            YeepayRuntimeException rtEx2 = new YeepayRuntimeException(new IllegalStateException("cause"));
            r.put("runtimeException_cause", rtEx2.getCause() instanceof IllegalStateException);

            r.put("bizException_class_ok", YeepayBizException.class.getSuperclass() == RuntimeException.class);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 40. QuotaManager =====================
    @GetMapping("/quota")
    public Map<String, Object> verifyQuotaManager() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            QuotaManager qm = QuotaManager.instance();
            r.put("instance_ok", qm != null);

            Object result = qm.checkQuota("testQuota", 5, () -> "quota_result");
            r.put("checkQuota_result", result);
            r.put("checkQuota_ok", "quota_result".equals(result));

            qm.removeQuota("testQuota");
            r.put("removeQuota", "OK");

            qm.clear();
            r.put("clear", "OK");

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 43. HttpClientUtil =====================
    @GetMapping("/httpclient")
    public Map<String, Object> verifyHttpClient() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            HttpClientUtil client = new HttpClientUtil();
            client.setTimeout(5000);
            r.put("instance_ok", true);
            r.put("status", "PASS (instance created, skip network call)");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 44. SimpleHttpUtils =====================
    @GetMapping("/simplehttp")
    public Map<String, Object> verifySimpleHttp() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            r.put("class_loaded", SimpleHttpUtils.class.getName());
            r.put("status", "PASS (class loaded, skip network call)");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 45. MonitorDataSource =====================
    @GetMapping("/monitor-datasource")
    public Map<String, Object> verifyMonitorDataSource() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            MonitorDataSource monitorDs = new MonitorDataSource(dataSource);
            monitorDs.setName("test-monitor-ds");
            monitorDs.setEnableMonitorStatement(true);
            monitorDs.setReleaseAlarmThreshold(5000);
            monitorDs.setBlockingThreshold(3000);
            monitorDs.setExecuteBlockingThreshold(2000);
            r.put("monitorDs_created", true);
            r.put("monitorDs_name", monitorDs.getName());
            r.put("monitorDs_enableMonitorStatement", monitorDs.isEnableMonitorStatement());
            r.put("monitorDs_releaseAlarmThreshold", monitorDs.getReleaseAlarmThreshold());
            r.put("monitorDs_blockingThreshold", monitorDs.getBlockingThreshold());
            r.put("monitorDs_executeBlockingThreshold", monitorDs.getExecuteBlockingThreshold());

            MonitorDataSourceSummary summary = monitorDs.getSummary();
            r.put("summary_initial_used", summary.getUsed());
            r.put("summary_initial_fetchCount", summary.getFetchCount());

            try (Connection conn = monitorDs.getConnection()) {
                r.put("monitor_connection_ok", conn != null && !conn.isClosed());
                r.put("monitor_connection_class", conn.getClass().getName());
                r.put("summary_after_get_used", summary.getUsed());
                r.put("summary_after_get_fetchCount", summary.getFetchCount());
                r.put(
                        "monitorConnections_size",
                        monitorDs.getMonitorConnections().size());

                try (Statement stmt = conn.createStatement()) {
                    try (ResultSet rs = stmt.executeQuery("SELECT 1")) {
                        rs.next();
                        r.put("monitor_query_ok", rs.getInt(1) == 1);
                    }
                }
            }

            r.put("summary_after_close_used", summary.getUsed());
            r.put(
                    "monitorConnections_after_close",
                    monitorDs.getMonitorConnections().size());
            r.put(
                    "blockingConnections_size",
                    monitorDs.getBlockingMonitorConnections().size());

            MonitorDataSourceManager manager = MonitorDataSourceManager.instance();
            r.put("manager_ok", manager != null);

            ListableServiceMonitor connMonitor = ServiceMonitorRegister.getListableServiceMonitor("monitor-connection");
            r.put("serviceMonitor_connection_registered", connMonitor != null);
            if (connMonitor != null) {
                List<?> allStatus = connMonitor.getAllServiceStatus();
                r.put("serviceMonitor_connection_statusList", allStatus != null);
            }

            ListableServiceMonitor summaryMonitor =
                    ServiceMonitorRegister.getListableServiceMonitor("monitor-datasource-summary");
            r.put("serviceMonitor_summary_registered", summaryMonitor != null);
            if (summaryMonitor != null) {
                Object summaryStatus = summaryMonitor.getServiceStatus("test-monitor-ds");
                r.put("serviceMonitor_summary_status_ok", summaryStatus != null);
            }

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 46. DataSourceFactoryBean (useMonitor=true) =====================
    @GetMapping("/datasource-factorybean")
    public Map<String, Object> verifyDataSourceFactoryBean() {
        Map<String, Object> r = new LinkedHashMap<>();
        DataSource factoryDs = null;
        try {
            DataSourceFactoryBean factoryBean = new DataSourceFactoryBean();
            factoryBean.setName("testdb");
            factoryBean.setUseMonitor(true);
            r.put("factoryBean_isSingleton", factoryBean.isSingleton());
            r.put("factoryBean_objectType", factoryBean.getObjectType().getName());

            factoryDs = (DataSource) factoryBean.getObject();
            r.put("factoryBean_ds_type", factoryDs.getClass().getName());
            r.put("factoryBean_ds_isMonitor", factoryDs instanceof MonitorDataSource);

            if (factoryDs instanceof MonitorDataSource monitorDs) {
                r.put("monitor_name", monitorDs.getName());
                r.put("monitor_releaseAlarmThreshold", monitorDs.getReleaseAlarmThreshold());
                r.put("monitor_blockingThreshold", monitorDs.getBlockingThreshold());

                MonitorDataSourceSummary summary = monitorDs.getSummary();
                r.put("summary_initial_used", summary.getUsed());
                r.put("summary_initial_fetchCount", summary.getFetchCount());

                try (Connection conn = factoryDs.getConnection()) {
                    r.put("monitor_connection_ok", conn != null && !conn.isClosed());
                    r.put("summary_after_get_used", summary.getUsed());
                    r.put("summary_after_get_fetchCount", summary.getFetchCount());
                    r.put(
                            "monitorConnections_size",
                            monitorDs.getMonitorConnections().size());

                    executeCrudTest(conn, r, "factorybean");
                }

                r.put("summary_after_close_used", summary.getUsed());
                r.put(
                        "monitorConnections_after_close",
                        monitorDs.getMonitorConnections().size());

                ListableServiceMonitor summaryMonitor =
                        ServiceMonitorRegister.getListableServiceMonitor("monitor-datasource-summary");
                if (summaryMonitor != null) {
                    Object summaryStatus = summaryMonitor.getServiceStatus("testdb");
                    r.put("serviceMonitor_summary_ok", summaryStatus != null);
                }
            }

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 47. ServiceMonitorListModel =====================
    @GetMapping("/service-monitor-list-model")
    public Map<String, Object> verifyServiceMonitorListModel() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            ServiceMonitorListModel model = new ServiceMonitorListModel();
            r.put("model_ok", model != null);

            List<Map<String, Object>> dsList = model.getDataSourceConnectionStatusList();
            r.put("dsConnectionStatusList", dsList != null ? dsList.size() : "null");

            boolean connTimeoutAlarm = model.getConnectionTimeountAlarm();
            r.put("connectionTimeoutAlarm", connTimeoutAlarm);

            boolean fetchTimeoutAlarm = model.getFetchConnectionTimeoutAlarm();
            r.put("fetchConnectionTimeoutAlarm", fetchTimeoutAlarm);

            boolean releaseTimeoutAlarm = model.getReleaseConnectionTimeoutAlarm();
            r.put("releaseConnectionTimeoutAlarm", releaseTimeoutAlarm);

            List<Map<String, Object>> quotaList = model.getQuotaStatusList();
            r.put("quotaStatusList", quotaList != null ? quotaList.size() : "null");

            boolean quotaAlarm = model.getQuotaAlarm();
            r.put("quotaAlarm", quotaAlarm);

            r.put("toString_ok", model.toString() != null);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 48. JVMModel =====================
    @GetMapping("/jvm-model")
    public Map<String, Object> verifyJvmModel() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            JVMModel jvmModel = new JVMModel();
            r.put("jvmModel_ok", jvmModel != null);

            try {
                java.math.BigDecimal memoryUsed = jvmModel.getJvmMemoryUsedRatio();
                r.put("jvmMemoryUsedRatio", memoryUsed);
                r.put("jvmMemoryUsedRatio_ok", memoryUsed != null);
            } catch (Exception e) {
                r.put("jvmMemoryUsedRatio", "N/A: " + e.getMessage());
            }

            try {
                java.math.BigDecimal oldGen = jvmModel.getJvmPSOldGenUsedRatio();
                r.put("jvmPSOldGenUsedRatio", oldGen);
            } catch (Exception e) {
                r.put("jvmPSOldGenUsedRatio", "N/A: " + e.getMessage());
            }

            try {
                java.math.BigDecimal permGen = jvmModel.getJvmPSPermGenUsedRatio();
                r.put("jvmPSPermGenUsedRatio", permGen);
            } catch (Exception e) {
                r.put("jvmPSPermGenUsedRatio", "N/A: " + e.getMessage());
            }

            try {
                long gcTime = jvmModel.getJvmGCTotalTime();
                r.put("jvmGCTotalTime", gcTime);
            } catch (Exception e) {
                r.put("jvmGCTotalTime", "N/A: " + e.getMessage());
            }

            try {
                long gcCount = jvmModel.getJvmGCTotalCount();
                r.put("jvmGCTotalCount", gcCount);
            } catch (Exception e) {
                r.put("jvmGCTotalCount", "N/A: " + e.getMessage());
            }

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 49. ApplicationStatusModel =====================
    @GetMapping("/app-status-model")
    public Map<String, Object> verifyApplicationStatusModel() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            ApplicationStatusModel model = new ApplicationStatusModel();
            r.put("model_ok", model != null);

            try {
                String port = model.getPort();
                r.put("port", port != null ? port : "null");
            } catch (Exception e) {
                r.put("port", "N/A: " + e.getMessage());
            }

            try {
                String appServerName = model.getAppServerName();
                r.put("appServerName", appServerName != null ? appServerName : "null");
            } catch (Exception e) {
                r.put("appServerName", "N/A: " + e.getMessage());
            }

            try {
                Map<String, Map<String, String>> appStatusMap = model.getAppStatusMap();
                r.put("appStatusMap", appStatusMap != null ? appStatusMap.size() : "null");
            } catch (Exception e) {
                r.put("appStatusMap", "N/A: " + e.getMessage());
            }

            try {
                boolean serverAlarm = model.getServerStatusAlarm();
                r.put("serverStatusAlarm", serverAlarm);
            } catch (Exception e) {
                r.put("serverStatusAlarm", "N/A: " + e.getMessage());
            }

            r.put("toString_ok", model.toString() != null);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 50. ServerResourceAccessOperation =====================
    @GetMapping("/server-resource-access")
    public Map<String, Object> verifyServerResourceAccessOperation() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            ServerResourceAccessOperation op = new ServerResourceAccessOperation();
            r.put("operation_ok", op != null);

            Map<String, String> dirAccess = op.accquireDirAccessProperty(System.getProperty("java.io.tmpdir"));
            r.put("tmpDir_access", dirAccess != null);
            if (dirAccess != null) {
                r.put("tmpDir_rwProperty", dirAccess.get("rwProperty"));
            }

            String ip = op.accquireDnsMappingIP("localhost");
            r.put("dns_localhost_ip", ip);

            boolean dnsConnect = op.accquireDnsConnectStatus("localhost", 2000);
            r.put("dns_localhost_connect", dnsConnect);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    // ===================== 51. InitializationHelper =====================
    @GetMapping("/initialization-helper")
    public Map<String, Object> verifyInitializationHelper() {
        Map<String, Object> r = new LinkedHashMap<>();
        try {
            InitializationHelper helper = InitializationHelper.getInstance();
            r.put("helper_ok", helper != null);

            InitializationHelper helper2 = InitializationHelper.getInstance();
            r.put("singleton_ok", helper == helper2);

            r.put("status", "PASS");
        } catch (Exception e) {
            r.put("status", "FAIL: " + e.getMessage());
        }
        return r;
    }

    private void executeCrudTest(Connection conn, Map<String, Object> r, String prefix) throws Exception {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS verify_" + prefix
                    + " (id INT PRIMARY KEY, name VARCHAR(100),"
                    + " amount DECIMAL(10,2),"
                    + " created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            r.put(prefix + "_create_table", "OK");

            stmt.execute("INSERT INTO verify_" + prefix + " (id, name, amount) VALUES (1, 'yeepay', 99.99)");
            stmt.execute("INSERT INTO verify_" + prefix + " (id, name, amount) VALUES (2, 'jdk17', 17.00)");
            stmt.execute("INSERT INTO verify_" + prefix + " (id, name, amount) VALUES (3, 'springboot3', 3.00)");
            r.put(prefix + "_insert", "OK (3 rows)");

            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM verify_" + prefix)) {
                rs.next();
                r.put(prefix + "_select_count", rs.getInt(1));
            }

            try (ResultSet rs = stmt.executeQuery("SELECT name, amount FROM verify_" + prefix + " WHERE id = 1")) {
                rs.next();
                r.put(prefix + "_select_name", rs.getString("name"));
                r.put(prefix + "_select_amount", rs.getBigDecimal("amount"));
            }

            stmt.execute("UPDATE verify_" + prefix + " SET amount = 100.00 WHERE id = 1");
            try (ResultSet rs = stmt.executeQuery("SELECT amount FROM verify_" + prefix + " WHERE id = 1")) {
                rs.next();
                r.put(prefix + "_update_ok", rs.getBigDecimal("amount").doubleValue() == 100.00);
            }

            stmt.execute("DELETE FROM verify_" + prefix + " WHERE id = 3");
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM verify_" + prefix)) {
                rs.next();
                r.put(prefix + "_delete_ok", rs.getInt(1) == 2);
            }

            stmt.execute("DROP TABLE verify_" + prefix);
            r.put(prefix + "_drop_table", "OK");
        }
    }
}
