package com.yeepay.framework.examples.utils.config;

import com.yeepay.g3.utils.common.CommonUtils;
import com.yeepay.g3.utils.common.StringUtils;
import com.yeepay.g3.utils.common.ThreadContextUtils;
import com.yeepay.g3.utils.common.threadcontext.ThreadContextType;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

/**
 * Servlet 规范标准实现，替代 Tomcat ValveBase。
 * 执行时机：比 Valve、Filter 都早（在 StandardHostValve 中触发）。
 * 可移植性：Tomcat / Jetty / Undertow 通用。
 */
@Component
public class ThreadContextRequestListener implements ServletRequestListener {

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        ServletRequest servletRequest = sre.getServletRequest();
        if (!(servletRequest instanceof HttpServletRequest request)) {
            return;
        }

        if (ThreadContextUtils.contextInitialized()) {
            ThreadContextUtils.clearContext();
        }

        String guid = request.getHeader("_thread_uid");
        if (StringUtils.isBlank(guid)) {
            guid = CommonUtils.getUUIDNonBlocked();
        }

        ThreadContextType contextType = ThreadContextType.WEB;
        String contentType = request.getContentType();
        if ("x-application/hessian".equalsIgnoreCase(contentType)
                || "application/x-java-serialized-object".equalsIgnoreCase(contentType)) {
            contextType = ThreadContextType.INTERFACE;
        }

        String soaEnv = request.getHeader("x-yeepay-cdn-lane");
        if (StringUtils.isBlank(soaEnv)) {
            soaEnv = request.getHeader("_soa_env");
        }
        if (StringUtils.isBlank(soaEnv) || "product".equals(soaEnv)) {
            soaEnv = System.getProperty("dubbo.application.environment", "product");
        }

        String soaContext = request.getHeader("x-yeepay-cdn-context");
        if (StringUtils.isBlank(soaContext)) {
            soaContext = request.getHeader("_soa_context");
        }

        String srcSoaApp = request.getHeader("_src_soa_app");
        String transferLevel = request.getHeader("_transfer_level");
        transferLevel = StringUtils.isBlank(transferLevel) ? "1" : transferLevel;

        String appName =
                request.getContextPath() != null ? request.getContextPath().replace("/", "") : "";

        ThreadContextUtils.initContext(appName, guid, contextType, transferLevel, soaEnv, srcSoaApp, "", soaContext);
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        if (ThreadContextUtils.contextInitialized()) {
            ThreadContextUtils.clearContext();
        }
    }
}
