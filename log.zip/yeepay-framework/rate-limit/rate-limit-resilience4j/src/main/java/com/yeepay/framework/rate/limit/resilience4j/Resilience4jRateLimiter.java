package com.yeepay.framework.rate.limit.resilience4j;

import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadConfig;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RateLimiterConfig;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 基于 Resilience4j 的本地限流器.
 *
 * <h3>Resilience4j 限流相关组件一览</h3>
 * <p>Resilience4j 提供了以下可用于限流/并发控制的组件：</p>
 * <table>
 *   <tr><th>组件</th><th>类型</th><th>原理</th><th>本类中的用途</th></tr>
 *   <tr>
 *     <td>{@code RateLimiter}</td>
 *     <td>速率限流</td>
 *     <td>将时间划分为固定周期（epoch），每个周期开始时刷新 {@code limitForPeriod} 个许可。
 *         请求到来时扣减许可，许可耗尽则拒绝（或等待到超时）。
 *         底层实现是 {@code AtomicRateLimiter}，通过原子变量跟踪当前周期和许可数。</td>
 *     <td>用于 TOKEN_BUCKET、SLIDING_WINDOW、LEAKY_BUCKET（不同算法用不同的配置策略）</td>
 *   </tr>
 *   <tr>
 *     <td>{@code Bulkhead}（信号量模式）</td>
 *     <td>并发控制</td>
 *     <td>内部持有一个 {@code Semaphore}，控制同时执行的最大请求数。
 *         {@code tryAcquirePermission()} 非阻塞获取许可，
 *         请求完成后需 {@code onComplete()} 释放许可。</td>
 *     <td>用于 CONCURRENT_REQUEST</td>
 *   </tr>
 *   <tr>
 *     <td>{@code ThreadPoolBulkhead}</td>
 *     <td>线程池隔离</td>
 *     <td>使用独立线程池执行任务，通过线程池大小+等待队列控制并发。
 *         返回 {@code CompletionStage}，适合异步场景。</td>
 *     <td>本类未使用（更适合线程隔离场景，非纯限流）</td>
 *   </tr>
 *   <tr>
 *     <td>{@code TimeLimiter}</td>
 *     <td>超时控制</td>
 *     <td>限制操作的最大执行时间，超时则取消。不是限流组件，但可与限流组合使用。</td>
 *     <td>本类未使用</td>
 *   </tr>
 * </table>
 *
 * <h3>Resilience4j RateLimiter 的工作原理（AtomicRateLimiter）</h3>
 * <pre>
 *   时间轴：  |----周期1----|----周期2----|----周期3----|
 *   许可数：  [  20个许可  ] [  刷新20个  ] [  刷新20个  ]
 *
 *   配置项：
 *   - limitForPeriod:    每个周期刷新的许可数（类比"桶容量"或"窗口上限"）
 *   - limitRefreshPeriod: 周期长度（多久刷新一次许可）
 *   - timeoutDuration:   许可不足时最长等待时间（设为 0 = 立即拒绝）
 * </pre>
 *
 * <h3>各算法的配置策略</h3>
 * <ul>
 *   <li><b>TOKEN_BUCKET</b>：短周期 + 少量许可，模拟令牌逐渐补充<br>
 *       周期 = 1 秒，每周期许可 = replenishRate<br>
 *       效果：每秒补充 replenishRate 个许可，近似令牌桶的稳定速率</li>
 *   <li><b>SLIDING_WINDOW</b>：完整窗口 + 满额许可<br>
 *       周期 = burstCapacity/replenishRate 秒，每周期许可 = burstCapacity<br>
 *       效果：一个完整时间窗口内允许 burstCapacity 个请求</li>
 *   <li><b>LEAKY_BUCKET</b>：极短周期 + 单个许可，模拟匀速漏出<br>
 *       周期 = 1/replenishRate 秒，每周期许可 = 1<br>
 *       效果：严格匀速放行，每隔固定间隔通过一个请求</li>
 *   <li><b>CONCURRENT_REQUEST</b>：使用 Bulkhead 信号量<br>
 *       maxConcurrentCalls = burstCapacity</li>
 * </ul>
 *
 * <h3>局限性</h3>
 * <ul>
 *   <li>Resilience4j 的 RateLimiter 本质是固定窗口（epoch-based），并非真正的令牌桶或漏桶，
 *       存在窗口边界突发问题（两个窗口交界处可能短时间内通过 2 倍的请求）。
 *       如需精确的令牌桶/漏桶语义，请使用 GuavaRateLimiter 或 RedissonRateLimiter。</li>
 *   <li>所有状态仅存在于 JVM 内存中，不支持分布式场景</li>
 *   <li>Bulkhead 需要调用方在请求完成后调用 {@code onComplete()} 释放许可</li>
 * </ul>
 */
public class Resilience4jRateLimiter implements YeepayRateLimiter {

    /**
     * per-key 的 Resilience4j RateLimiter 实例缓存.
     * <p>同一个 key 首次调用时创建并缓存，后续复用同一实例。</p>
     */
    private final Map<String, RateLimiter> rateLimiterCache = new ConcurrentHashMap<>();

    /**
     * per-key 的 Resilience4j Bulkhead 实例缓存（仅 CONCURRENT_REQUEST 使用）.
     */
    private final Map<String, Bulkhead> bulkheadCache = new ConcurrentHashMap<>();

    @Override
    public RateLimitResult isAllowed(final RateLimitEntity entity) {
        return switch (entity.getAlgorithm()) {
            case TOKEN_BUCKET -> executeTokenBucket(entity);
            case SLIDING_WINDOW -> executeSlidingWindow(entity);
            case LEAKY_BUCKET -> executeLeakyBucket(entity);
            case CONCURRENT_REQUEST -> executeBulkhead(entity);
        };
    }

    // ─────────────────────────────────────────────────────────────────────
    //  令牌桶 → Resilience4j RateLimiter（短周期模式）
    //
    //  配置：周期 = 1 秒，每周期许可 = replenishRate
    //
    //  效果：每秒刷新 replenishRate 个许可。
    //  例如 replenishRate=10 → 每秒获得 10 个许可，一秒内最多通过 10 个请求。
    //
    //  与真正令牌桶的差异：
    //  - 真正的令牌桶是连续补充（每 100ms 补充 1 个），Resilience4j 是周期开始时一次性刷新
    //  - 真正的令牌桶有 burstCapacity 上限（可积攒），这里每个周期固定刷新 replenishRate 个
    //  - 窗口边界处可能出现 2*replenishRate 的瞬时突发
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeTokenBucket(final RateLimitEntity entity) {
        RateLimiter limiter = rateLimiterCache.computeIfAbsent(entity.getKey(), k -> {
            // 周期 = 1 秒，每周期补充 replenishRate 个许可
            // 不等待，立即返回结果
            RateLimiterConfig config = RateLimiterConfig.custom()
                    .limitForPeriod((int) entity.getReplenishRate())
                    .limitRefreshPeriod(Duration.ofSeconds(1))
                    .timeoutDuration(Duration.ZERO)
                    .build();
            return RateLimiter.of(k, config);
        });
        return doAcquire(limiter, entity);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  滑动窗口 → Resilience4j RateLimiter（完整窗口模式）
    //
    //  配置：周期 = burstCapacity / replenishRate 秒，每周期许可 = burstCapacity
    //
    //  效果：在一个完整的时间窗口内最多通过 burstCapacity 个请求。
    //  例如 replenishRate=10, burstCapacity=20
    //    → 窗口 = 20/10 = 2 秒，每 2 秒允许 20 个请求。
    //
    //  注意：这是固定窗口（Fixed Window），不是真正的滑动窗口（Sliding Window）。
    //  真正的滑动窗口会平滑地移动窗口边界，而固定窗口在周期边界处一次性重置计数。
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeSlidingWindow(final RateLimitEntity entity) {
        RateLimiter limiter = rateLimiterCache.computeIfAbsent(entity.getKey(), k -> {
            // 窗口大小 = burstCapacity / replenishRate（秒）
            long periodMs = (long) (entity.getBurstCapacity() / entity.getReplenishRate() * 1000);
            RateLimiterConfig config = RateLimiterConfig.custom()
                    .limitForPeriod((int) entity.getBurstCapacity())
                    .limitRefreshPeriod(Duration.ofMillis(Math.max(1, periodMs)))
                    .timeoutDuration(Duration.ZERO)
                    .build();
            return RateLimiter.of(k, config);
        });
        return doAcquire(limiter, entity);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  漏桶 → Resilience4j RateLimiter（极短周期匀速模式）
    //
    //  配置：周期 = 1/replenishRate 秒，每周期许可 = 1
    //
    //  效果：严格匀速放行，每隔固定间隔通过 1 个请求。
    //  例如 replenishRate=10 → 周期 = 100ms，每 100ms 允许 1 个请求。
    //
    //  这是最接近漏桶语义的配置：请求以恒定速率被处理（"漏出"），
    //  不允许突发（每个极短周期只有 1 个许可）。
    //
    //  局限性：不支持 requestCount > 1 的场景（每周期只有 1 个许可）。
    //  如需支持，可将 limitForPeriod 设为 requestCount，
    //  但这会改变匀速语义。
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeLeakyBucket(final RateLimitEntity entity) {
        RateLimiter limiter = rateLimiterCache.computeIfAbsent(entity.getKey(), k -> {
            // 周期 = 1/replenishRate 秒（即两个请求之间的最小间隔）
            long periodMs = (long) (1000.0 / entity.getReplenishRate());
            RateLimiterConfig config = RateLimiterConfig.custom()
                    .limitForPeriod(1)
                    .limitRefreshPeriod(Duration.ofMillis(Math.max(1, periodMs)))
                    .timeoutDuration(Duration.ZERO)
                    .build();
            return RateLimiter.of(k, config);
        });
        return doAcquire(limiter, entity);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  并发限流 → Resilience4j Bulkhead（信号量模式）
    //
    //  配置：maxConcurrentCalls = burstCapacity
    //
    //  原理：Bulkhead 内部持有一个 Semaphore，控制同时执行的请求数。
    //  - tryAcquirePermission(): 非阻塞获取一个许可
    //  - 请求完成后需调用 bulkhead.onComplete() 释放许可
    //
    //  与 ThreadPoolBulkhead 的区别：
    //  - Bulkhead（信号量）：在调用线程上执行，只控制并发数，不隔离线程
    //  - ThreadPoolBulkhead：在独立线程池中执行，返回 CompletionStage，
    //    实现线程隔离，适合需要故障隔离的场景（如微服务调用）
    //
    //  这里使用信号量模式，因为我们只需要并发计数，不需要线程隔离。
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeBulkhead(final RateLimitEntity entity) {
        Bulkhead bulkhead = bulkheadCache.computeIfAbsent(entity.getKey(), k -> {
            // 不等待，立即返回
            BulkheadConfig config = BulkheadConfig.custom()
                    .maxConcurrentCalls((int) entity.getBurstCapacity())
                    .maxWaitDuration(Duration.ZERO)
                    .build();
            return Bulkhead.of(k, config);
        });

        // tryAcquirePermission() 尝试获取一个许可，无许可时立即返回 false
        boolean allowed = bulkhead.tryAcquirePermission();
        // 获取当前可用的并发槽位数
        int remaining = bulkhead.getMetrics().getAvailableConcurrentCalls();
        return new RateLimitResult(allowed, Math.max(0, remaining), List.of(entity.getKey()));
    }

    @Override
    public void release(final RateLimitEntity entity) {
        if (entity.getAlgorithm() == RateLimitAlgorithm.CONCURRENT_REQUEST) {
            Bulkhead bulkhead = bulkheadCache.get(entity.getKey());
            if (Objects.nonNull(bulkhead)) {
                bulkhead.onComplete();
            }
        }
    }

    /**
     * 通用的许可获取逻辑，供 TOKEN_BUCKET / SLIDING_WINDOW / LEAKY_BUCKET 共用.
     *
     * @param limiter Resilience4j 的 RateLimiter 实例
     * @param entity  限流请求实体
     * @return 限流结果
     */
    private static RateLimitResult doAcquire(final RateLimiter limiter, final RateLimitEntity entity) {
        // acquirePermission(permits) 尝试获取指定数量的许可
        // 由于 timeoutDuration=0，许可不足时立即返回 false，不会阻塞
        boolean allowed = limiter.acquirePermission((int) entity.getRequestCount());
        // 获取当前周期内剩余的可用许可数
        int remaining = limiter.getMetrics().getAvailablePermissions();
        return new RateLimitResult(allowed, Math.max(0, remaining), List.of(entity.getKey()));
    }
}
