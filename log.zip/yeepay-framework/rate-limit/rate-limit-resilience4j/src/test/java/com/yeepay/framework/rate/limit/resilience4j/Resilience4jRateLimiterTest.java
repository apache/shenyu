package com.yeepay.framework.rate.limit.resilience4j;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Resilience4jRateLimiterTest {

    private Resilience4jRateLimiter rateLimiter;

    @BeforeEach
    void setUp() {
        rateLimiter = new Resilience4jRateLimiter();
    }

    private RateLimitEntity.RateLimitEntityBuilder baseEntity() {
        return RateLimitEntity.builder().key("test-key").replenishRate(10).burstCapacity(20);
    }

    // ── Token Bucket (via Resilience4j RateLimiter) ───────────────────────

    @Test
    void tokenBucket_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void tokenBucket_exhausted() {
        // TOKEN_BUCKET 模式：limitForPeriod = replenishRate，所以每秒允许 replenishRate 个请求
        RateLimitEntity entity = baseEntity()
                .key("tb-exhaust")
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(3)
                .replenishRate(3)
                .build();

        for (int i = 0; i < 3; i++) {
            assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        }
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    @Test
    void tokenBucket_isDefaultAlgorithm() {
        RateLimitResult result =
                rateLimiter.isAllowed(baseEntity().key("tb-default").build());
        assertThat(result.isAllowed()).isTrue();
    }

    // ── Sliding Window (via Resilience4j RateLimiter) ─────────────────────

    @Test
    void slidingWindow_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(baseEntity()
                .key("sw-allow")
                .algorithm(RateLimitAlgorithm.SLIDING_WINDOW)
                .build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
    }

    @Test
    void slidingWindow_exhausted() {
        RateLimitEntity entity = baseEntity()
                .key("sw-exhaust")
                .algorithm(RateLimitAlgorithm.SLIDING_WINDOW)
                .burstCapacity(3)
                .replenishRate(1)
                .build();

        for (int i = 0; i < 3; i++) {
            assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        }
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    // ── Leaky Bucket (via Resilience4j RateLimiter) ───────────────────────

    @Test
    void leakyBucket_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(baseEntity()
                .key("lb-allow")
                .algorithm(RateLimitAlgorithm.LEAKY_BUCKET)
                .build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
    }

    @Test
    void leakyBucket_exhausted() {
        // LEAKY_BUCKET 模式：limitForPeriod = 1，匀速放行，每个周期只允许 1 个请求
        RateLimitEntity entity = baseEntity()
                .key("lb-exhaust")
                .algorithm(RateLimitAlgorithm.LEAKY_BUCKET)
                .burstCapacity(3)
                .replenishRate(1)
                .build();

        // 第 1 个请求通过（消耗本周期唯一的许可）
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        // 第 2 个请求被拒绝（本周期许可已用完，timeoutDuration=0 不等待）
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    // ── Concurrent Request (via Resilience4j Bulkhead) ────────────────────

    @Test
    void concurrentRequest_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(baseEntity()
                .key("cr-allow")
                .algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST)
                .build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
        assertThat(result.getKeys()).containsExactly("cr-allow");
    }

    @Test
    void concurrentRequest_exhausted() {
        RateLimitEntity entity = baseEntity()
                .key("cr-exhaust")
                .algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST)
                .burstCapacity(2)
                .replenishRate(1)
                .build();

        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    // ── Different keys are independent ────────────────────────────────────

    @Test
    void differentKeysAreIndependent() {
        RateLimitEntity entity1 = baseEntity()
                .key("independent-1")
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(1)
                .replenishRate(1)
                .build();
        RateLimitEntity entity2 = baseEntity()
                .key("independent-2")
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(1)
                .replenishRate(1)
                .build();

        assertThat(rateLimiter.isAllowed(entity1).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity1).isAllowed()).isFalse();
        assertThat(rateLimiter.isAllowed(entity2).isAllowed()).isTrue();
    }
}
