package com.yeepay.framework.rate.limit.jedis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisNoScriptException;

@ExtendWith(MockitoExtension.class)
class JedisRateLimiterTest {

    @Mock
    private UnifiedJedis jedisClient;

    @Captor
    private ArgumentCaptor<List<String>> keysCaptor;

    private JedisRateLimiter rateLimiter;

    @BeforeEach
    void setUp() {
        rateLimiter = new JedisRateLimiter(jedisClient);
    }

    private RateLimitEntity.RateLimitEntityBuilder baseEntity() {
        return RateLimitEntity.builder().key("test-key").replenishRate(10).burstCapacity(20);
    }

    private void stubEval(final List<Long> result) {
        when(jedisClient.scriptLoad(anyString())).thenReturn("test-sha");
        doReturn(result).when(jedisClient).evalsha(anyString(), any(List.class), any(List.class));
    }

    // ── Token Bucket ──────────────────────────────────────────────────────

    @Test
    void tokenBucket_allowed() {
        stubEval(Arrays.asList(1L, 19L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(19L);
        assertThat(result.getKeys()).containsExactly("test-key.tokens", "test-key.timestamp");
    }

    @Test
    void tokenBucket_rejected() {
        stubEval(Arrays.asList(0L, 0L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void tokenBucket_isDefaultAlgorithm() {
        stubEval(Arrays.asList(1L, 15L));

        RateLimitResult result = rateLimiter.isAllowed(baseEntity().build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getKeys()).containsExactly("test-key.tokens", "test-key.timestamp");
    }

    @Test
    void tokenBucket_customRequestCount() {
        stubEval(Arrays.asList(1L, 15L));

        RateLimitResult result = rateLimiter.isAllowed(baseEntity()
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .requestCount(5)
                .build());

        assertThat(result.isAllowed()).isTrue();
    }

    // ── Sliding Window ────────────────────────────────────────────────────

    @Test
    void slidingWindow_allowed() {
        stubEval(Arrays.asList(1L, 15L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(15L);
        assertThat(result.getKeys()).containsExactly("test-key.tokens");
    }

    @Test
    void slidingWindow_rejected() {
        stubEval(Arrays.asList(0L, 0L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void slidingWindow_keysContainUniqueMembers() {
        stubEval(Arrays.asList(1L, 10L));

        rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        verify(jedisClient).evalsha(anyString(), keysCaptor.capture(), any(List.class));
        List<String> keys = keysCaptor.getValue();
        assertThat(keys).hasSize(2);
        assertThat(keys.get(0)).isEqualTo("test-key.tokens");
        assertThat(keys.get(1)).startsWith("test-key.");
    }

    // ── Concurrent Request ────────────────────────────────────────────────

    @Test
    void concurrentRequest_allowed() {
        stubEval(Arrays.asList(1L, 5L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(15L);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void concurrentRequest_rejected() {
        stubEval(Arrays.asList(0L, 20L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void concurrentRequest_remainingClampedToZero() {
        stubEval(Arrays.asList(0L, 25L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.getTokensRemaining()).isZero();
    }

    // ── Leaky Bucket ──────────────────────────────────────────────────────

    @Test
    void leakyBucket_allowed() {
        stubEval(Arrays.asList(1L, 5L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(15L);
        assertThat(result.getKeys()).containsExactly("test-key.bucket", "test-key.last");
    }

    @Test
    void leakyBucket_rejected() {
        stubEval(Arrays.asList(0L, 21L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void leakyBucket_remainingClampedToZero() {
        stubEval(Arrays.asList(0L, 30L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.getTokensRemaining()).isZero();
    }

    // ── evalsha / NOSCRIPT fallback ───────────────────────────────────────

    @Test
    void evalSha_noscriptFallback_reloadsScript() {
        when(jedisClient.scriptLoad(anyString())).thenReturn("sha-1", "sha-2");
        doThrow(new JedisNoScriptException("NOSCRIPT No matching script"))
                .doReturn(Arrays.asList(1L, 10L))
                .when(jedisClient)
                .evalsha(anyString(), any(List.class), any(List.class));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        verify(jedisClient, times(2)).scriptLoad(anyString());
    }

    @Test
    void evalSha_nonNoscriptException_rethrown() {
        when(jedisClient.scriptLoad(anyString())).thenReturn("sha-1");
        doThrow(new RuntimeException("Connection refused"))
                .when(jedisClient)
                .evalsha(anyString(), any(List.class), any(List.class));

        assertThatThrownBy(() -> rateLimiter.isAllowed(
                        baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build()))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Connection refused");
    }

    // ── SHA caching ───────────────────────────────────────────────────────

    @Test
    void shaCached_scriptLoadCalledOnlyOnce() {
        stubEval(Arrays.asList(1L, 10L));

        rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());
        rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        verify(jedisClient, times(1)).scriptLoad(anyString());
        verify(jedisClient, times(2)).evalsha(anyString(), any(List.class), any(List.class));
    }
}
