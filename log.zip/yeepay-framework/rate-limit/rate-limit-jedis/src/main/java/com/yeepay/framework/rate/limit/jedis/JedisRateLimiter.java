package com.yeepay.framework.rate.limit.jedis;

import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisNoScriptException;

/**
 * 基于 Jedis 的限流器实现.
 */
@RequiredArgsConstructor
public class JedisRateLimiter implements YeepayRateLimiter {

    private static final String SCRIPT_DIR = "META-INF/scripts/";

    private static final Map<RateLimitAlgorithm, String> SCRIPT_MAP = Map.of(
            RateLimitAlgorithm.TOKEN_BUCKET, "request_rate_limiter.lua",
            RateLimitAlgorithm.SLIDING_WINDOW, "sliding_window_request_rate_limiter.lua",
            RateLimitAlgorithm.CONCURRENT_REQUEST, "concurrent_request_rate_limiter.lua",
            RateLimitAlgorithm.LEAKY_BUCKET, "request_leaky_rate_limiter.lua");

    private static final Map<RateLimitAlgorithm, String> SCRIPT_CACHE = new ConcurrentHashMap<>();

    private final Map<RateLimitAlgorithm, String> shaCache = new ConcurrentHashMap<>();

    private final UnifiedJedis jedisClient;

    @Override
    public RateLimitResult isAllowed(final RateLimitEntity entity) {
        RateLimitAlgorithm algorithm = entity.getAlgorithm();
        String script = loadScript(algorithm);
        return switch (algorithm) {
            case TOKEN_BUCKET -> executeTokenBucket(algorithm, script, entity);
            case SLIDING_WINDOW -> executeSlidingWindow(algorithm, script, entity);
            case CONCURRENT_REQUEST -> executeConcurrentRequest(algorithm, script, entity);
            case LEAKY_BUCKET -> executeLeakyBucket(algorithm, script, entity);
        };
    }

    private RateLimitResult executeTokenBucket(
            final RateLimitAlgorithm algorithm, final String script, final RateLimitEntity entity) {
        String tokensKey = entity.getKey() + ".tokens";
        String timestampKey = entity.getKey() + ".timestamp";
        List<String> keys = Arrays.asList(tokensKey, timestampKey);
        long now = Instant.now().getEpochSecond();
        List<Long> results = eval(
                algorithm,
                script,
                keys,
                String.valueOf(entity.getReplenishRate()),
                String.valueOf(entity.getBurstCapacity()),
                String.valueOf(now),
                String.valueOf(entity.getRequestCount()));
        return new RateLimitResult(results.get(0) == 1L, results.get(1), List.of(tokensKey, timestampKey));
    }

    private RateLimitResult executeSlidingWindow(
            final RateLimitAlgorithm algorithm, final String script, final RateLimitEntity entity) {
        String tokensKey = entity.getKey() + ".tokens";
        String memberKey = entity.getKey() + "." + UUID.randomUUID();
        List<String> keys = Arrays.asList(tokensKey, memberKey);
        long now = Instant.now().getEpochSecond();
        List<Long> results = eval(
                algorithm,
                script,
                keys,
                String.valueOf(entity.getReplenishRate()),
                String.valueOf(entity.getBurstCapacity()),
                String.valueOf(now));
        return new RateLimitResult(results.get(0) == 1L, results.get(1), List.of(tokensKey));
    }

    private RateLimitResult executeConcurrentRequest(
            final RateLimitAlgorithm algorithm, final String script, final RateLimitEntity entity) {
        String id = UUID.randomUUID().toString();
        List<String> keys = Arrays.asList(entity.getKey(), id);
        long now = Instant.now().getEpochSecond();
        List<Long> results = eval(
                algorithm,
                script,
                keys,
                String.valueOf(entity.getReplenishRate()),
                String.valueOf(entity.getBurstCapacity()),
                String.valueOf(now));
        long remaining = (long) entity.getBurstCapacity() - results.get(1);
        return new RateLimitResult(results.get(0) == 1L, Math.max(0, remaining), List.of(entity.getKey()));
    }

    private RateLimitResult executeLeakyBucket(
            final RateLimitAlgorithm algorithm, final String script, final RateLimitEntity entity) {
        String bucketKey = entity.getKey() + ".bucket";
        String lastKey = entity.getKey() + ".last";
        List<String> keys = Arrays.asList(bucketKey, lastKey);
        long now = Instant.now().getEpochSecond();
        List<Long> results = eval(
                algorithm,
                script,
                keys,
                String.valueOf(entity.getReplenishRate()),
                String.valueOf(entity.getBurstCapacity()),
                String.valueOf(now),
                String.valueOf(entity.getRequestCount()));
        long remaining = (long) entity.getBurstCapacity() - results.get(1);
        return new RateLimitResult(results.get(0) == 1L, Math.max(0, remaining), List.of(bucketKey, lastKey));
    }

    @SuppressWarnings("unchecked")
    private List<Long> eval(
            final RateLimitAlgorithm algorithm, final String script, final List<String> keys, final String... args) {
        List<String> argList = Arrays.asList(args);
        String sha = shaCache.computeIfAbsent(algorithm, alg -> jedisClient.scriptLoad(script));
        try {
            return (List<Long>) jedisClient.evalsha(sha, keys, argList);
        } catch (JedisNoScriptException e) {
            sha = jedisClient.scriptLoad(script);
            shaCache.put(algorithm, sha);
            return (List<Long>) jedisClient.evalsha(sha, keys, argList);
        }
    }

    private static String loadScript(final RateLimitAlgorithm algorithm) {
        return SCRIPT_CACHE.computeIfAbsent(algorithm, alg -> {
            String fileName = SCRIPT_MAP.get(alg);
            String path = SCRIPT_DIR + fileName;
            try (InputStream is = JedisRateLimiter.class.getClassLoader().getResourceAsStream(path)) {
                if (Objects.isNull(is)) {
                    throw new IllegalStateException("Script not found: " + path);
                }
                return new String(is.readAllBytes(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new IllegalStateException("Failed to load script: " + path, e);
            }
        });
    }
}
