package com.yeepay.framework.rate.limit.guava;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 基于 Guava Cache 的本地内存限流器.
 *
 * <h3>设计思路</h3>
 * <p>每种算法的核心状态（令牌数、水位、时间戳队列、信号量）都存放在 Guava {@link Cache} 中，
 * 以 {@code entity.key} 作为缓存键，实现 <b>按资源隔离</b> 的限流。
 * 缓存设置了空闲过期（默认 1 小时），长期无访问的 key 会被自动回收，避免内存泄漏。</p>
 *
 * <h3>精度处理</h3>
 * <p>由于 {@link RateLimitEntity} 中 replenishRate / burstCapacity / requestCount 都是 {@code double} 类型，
 * 但内部使用 {@code long} 进行原子操作，因此统一乘以 {@code 1_000_000}（scaleUp）转为整数运算，
 * 返回结果时再除回来（scaleDown），避免浮点累积误差。</p>
 *
 * <h3>线程安全</h3>
 * <p>令牌桶和漏桶使用 {@link AtomicReference#updateAndGet} 做 CAS 无锁更新；
 * 滑动窗口使用 {@link ConcurrentLinkedDeque} + {@link AtomicLong}；
 * 并发限流使用 {@link Semaphore}。所有操作都是线程安全的。</p>
 *
 * <h3>局限性</h3>
 * <ul>
 *   <li>所有状态仅存在于 JVM 内存中，应用重启后丢失</li>
 *   <li>不支持分布式场景（多实例间不共享状态），分布式场景请使用 RedissonRateLimiter</li>
 *   <li>并发限流的 Semaphore 需要调用方手动释放（或配合 AOP 自动释放）</li>
 * </ul>
 */
public class GuavaRateLimiter implements YeepayRateLimiter {

    /** 1 秒 = 1_000_000_000 纳秒，用于时间换算. */
    private static final long NANOS_PER_SECOND = TimeUnit.SECONDS.toNanos(1);

    /** 令牌桶算法的 per-key 状态缓存. */
    private final Cache<String, AtomicReference<long[]>> tokenBucketStates;

    /** 滑动窗口算法的 per-key 状态缓存. */
    private final Cache<String, SlidingWindowState> slidingWindowStates;

    /** 并发限流算法的 per-key 信号量缓存. */
    private final Cache<String, Semaphore> concurrentStates;

    /** 漏桶算法的 per-key 状态缓存. */
    private final Cache<String, AtomicReference<long[]>> leakyBucketStates;

    public GuavaRateLimiter() {
        this(1, TimeUnit.HOURS);
    }

    /**
     * @param expireAfterAccess 缓存空闲过期时间，超过该时间未访问的 key 将被自动回收
     * @param unit              时间单位
     */
    public GuavaRateLimiter(final long expireAfterAccess, final TimeUnit unit) {
        tokenBucketStates = CacheBuilder.newBuilder()
                .expireAfterAccess(expireAfterAccess, unit)
                .build();
        slidingWindowStates = CacheBuilder.newBuilder()
                .expireAfterAccess(expireAfterAccess, unit)
                .build();
        concurrentStates = CacheBuilder.newBuilder()
                .expireAfterAccess(expireAfterAccess, unit)
                .build();
        leakyBucketStates = CacheBuilder.newBuilder()
                .expireAfterAccess(expireAfterAccess, unit)
                .build();
    }

    @Override
    public RateLimitResult isAllowed(final RateLimitEntity entity) {
        return switch (entity.getAlgorithm()) {
            case TOKEN_BUCKET -> executeTokenBucket(entity);
            case SLIDING_WINDOW -> executeSlidingWindow(entity);
            case CONCURRENT_REQUEST -> executeConcurrentRequest(entity);
            case LEAKY_BUCKET -> executeLeakyBucket(entity);
        };
    }

    // ─────────────────────────────────────────────────────────────────────
    //  令牌桶算法 (Token Bucket)
    //
    //  原理：桶中持有令牌，每秒以 replenishRate 的速率补充，最多持有 burstCapacity 个。
    //       每次请求消耗 requestCount 个令牌，令牌不足时拒绝。
    //
    //  状态：long[3] = {scaledTokens, lastRefillNanos, allowed(仅用于返回值传递)}
    //
    //  工作流程：
    //    1. 计算距离上次补充过去了多少纳秒 (elapsed)
    //    2. 按速率计算应补充的令牌数：tokens += elapsed * rate / 1秒
    //    3. 令牌数上限为 burstCapacity（不能无限积攒）
    //    4. 如果令牌 >= requestCount，扣减并放行；否则拒绝
    //
    //  举例：replenishRate=10, burstCapacity=20, requestCount=1
    //    - 初始桶中有 20 个令牌
    //    - 连续 20 次请求全部通过，令牌降为 0
    //    - 此后每 100ms 补充 1 个令牌，才能再通过 1 个请求
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeTokenBucket(final RateLimitEntity entity) {
        // 首次访问时初始化状态：令牌数 = burstCapacity（桶满），时间戳 = 当前时间
        AtomicReference<long[]> stateRef = getOrCreate(tokenBucketStates, entity.getKey(), () -> {
            long scaledTokens = scaleUp(entity.getBurstCapacity());
            return new AtomicReference<>(new long[] {scaledTokens, System.nanoTime(), 0});
        });

        long scaledRate = scaleUp(entity.getReplenishRate());
        long scaledCapacity = scaleUp(entity.getBurstCapacity());
        long scaledRequested = scaleUp(entity.getRequestCount());

        // CAS 无锁更新：可能有多线程同时调用，updateAndGet 保证原子性
        long[] result = stateRef.updateAndGet(prev -> {
            long tokens = prev[0];
            long lastRefill = prev[1];
            long now = System.nanoTime();
            long elapsed = now - lastRefill;

            // 按时间流逝补充令牌，不超过桶容量
            long newTokens = Math.min(scaledCapacity, tokens + elapsed * scaledRate / NANOS_PER_SECOND);

            if (newTokens >= scaledRequested) {
                // 令牌充足 → 扣减令牌，标记允许通过 (allowed=1)
                return new long[] {newTokens - scaledRequested, now, 1};
            }
            // 令牌不足 → 不扣减，标记拒绝 (allowed=0)，但仍更新时间戳以便下次正确计算补充量
            return new long[] {newTokens, now, 0};
        });

        boolean allowed = result[2] == 1;
        long remaining = scaleDown(result[0]);
        return new RateLimitResult(allowed, remaining, List.of(entity.getKey()));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  滑动窗口算法 (Sliding Window)
    //
    //  原理：维护一个时间窗口，只统计窗口内的请求次数。
    //       窗口大小 = burstCapacity / replenishRate 秒。
    //       窗口内请求数 < burstCapacity 时允许通过。
    //
    //  状态：
    //    - timestamps: 双端队列，记录每个请求的纳秒时间戳（按时间顺序）
    //    - count: 当前窗口内的请求计数
    //
    //  工作流程：
    //    1. 计算窗口起始时间 cutoff = now - windowSize
    //    2. 从队列头部移除所有早于 cutoff 的过期时间戳，同时递减计数
    //    3. 检查当前计数是否 < burstCapacity
    //    4. 若未超限，添加当前时间戳到队列尾部，计数+1
    //
    //  举例：replenishRate=10, burstCapacity=20
    //    - 窗口大小 = 20/10 = 2 秒
    //    - 在 2 秒的滑动窗口内最多允许 20 个请求
    //    - 旧请求随时间滑出窗口后，计数自动下降，新请求可以进来
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeSlidingWindow(final RateLimitEntity entity) {
        // 窗口大小（纳秒）= burstCapacity / replenishRate * 10^9
        long windowNanos = (long) (entity.getBurstCapacity() / entity.getReplenishRate() * NANOS_PER_SECOND);
        long maxRequests = (long) entity.getBurstCapacity();

        SlidingWindowState state = getOrCreate(slidingWindowStates, entity.getKey(), SlidingWindowState::new);

        long now = System.nanoTime();
        // 清理过期时间戳：移除窗口之前的所有记录
        state.removeExpired(now - windowNanos);

        long currentCount = state.count.get();
        if (currentCount < maxRequests) {
            // 窗口内请求数未满 → 记录本次请求时间戳，计数+1，放行
            state.timestamps.addLast(now);
            long newCount = state.count.incrementAndGet();
            long remaining = Math.max(0, maxRequests - newCount);
            return new RateLimitResult(true, remaining, List.of(entity.getKey()));
        }
        // 窗口内请求数已满 → 拒绝
        return new RateLimitResult(false, 0, List.of(entity.getKey()));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  并发限流算法 (Concurrent Request)
    //
    //  原理：使用信号量 (Semaphore) 控制同时执行的请求数量。
    //       burstCapacity 即为最大并发数。
    //
    //  工作流程：
    //    1. 尝试获取一个许可（非阻塞）
    //    2. 获取成功 → 放行（调用方需在请求完成后释放许可）
    //    3. 获取失败 → 拒绝
    //
    //  注意：调用方需要在请求处理完成后调用 Semaphore.release() 释放许可，
    //       否则许可会被永久占用。通常配合 try-finally 或 AOP 使用。
    //
    //  举例：burstCapacity=100
    //    - 同一时刻最多允许 100 个请求并发执行
    //    - 第 101 个请求会被拒绝，直到前面某个请求完成并释放许可
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeConcurrentRequest(final RateLimitEntity entity) {
        int maxConcurrent = (int) entity.getBurstCapacity();
        // 首次访问时创建信号量，许可数 = burstCapacity
        Semaphore semaphore = getOrCreate(concurrentStates, entity.getKey(), () -> new Semaphore(maxConcurrent));

        // tryAcquire() 非阻塞：有许可则获取并返回 true，否则立即返回 false
        boolean allowed = semaphore.tryAcquire();
        int remaining = semaphore.availablePermits();
        return new RateLimitResult(allowed, remaining, List.of(entity.getKey()));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  漏桶算法 (Leaky Bucket)
    //
    //  原理：想象一个桶，请求是往桶里注水，桶底有一个固定速率的出水口。
    //       - 桶容量 = burstCapacity（最多能积攒多少水/请求）
    //       - 漏出速率 = replenishRate（每秒漏出多少水/请求）
    //       - 每次请求往桶里注入 requestCount 单位的水
    //       - 如果注入后水位超过桶容量 → 拒绝（溢出）
    //
    //  与令牌桶的区别：
    //    - 令牌桶：令牌逐渐增加，请求消耗令牌 → 允许突发（桶满时可一次消耗很多令牌）
    //    - 漏桶：水位逐渐减少，请求增加水位 → 平滑限流（即使桶空，也是匀速漏出）
    //
    //  状态：long[3] = {scaledWaterLevel, lastLeakNanos, allowed}
    //
    //  工作流程：
    //    1. 计算距离上次漏水过去了多少纳秒 (elapsed)
    //    2. 计算漏掉的水量：leaked = elapsed * leakRate / 1秒
    //    3. 更新水位：water = max(0, water - leaked)
    //    4. 检查 water + requestCount <= capacity → 放行，否则拒绝
    //
    //  举例：replenishRate=10, burstCapacity=20, requestCount=1
    //    - 桶容量 20，每秒漏 10
    //    - 瞬间灌入 20 个请求 → 全部通过，桶满
    //    - 之后每 100ms 漏出 1 个，才能再接收 1 个请求
    // ─────────────────────────────────────────────────────────────────────

    private RateLimitResult executeLeakyBucket(final RateLimitEntity entity) {
        // 首次访问时初始化：水位 = 0（空桶），时间戳 = 当前时间
        AtomicReference<long[]> stateRef = getOrCreate(leakyBucketStates, entity.getKey(), () -> {
            return new AtomicReference<>(new long[] {0, System.nanoTime()});
        });

        long scaledCapacity = scaleUp(entity.getBurstCapacity());
        long scaledLeakRate = scaleUp(entity.getReplenishRate());
        long scaledRequested = scaleUp(entity.getRequestCount());

        // CAS 无锁更新水位
        long[] result = stateRef.updateAndGet(prev -> {
            long water = prev[0];
            long lastLeak = prev[1];
            long now = System.nanoTime();
            long elapsed = now - lastLeak;

            // 计算这段时间漏掉了多少水，水位不能低于 0
            long leaked = elapsed * scaledLeakRate / NANOS_PER_SECOND;
            water = Math.max(0, water - leaked);

            if (water + scaledRequested <= scaledCapacity) {
                // 注水后不会溢出 → 水位上升，放行
                return new long[] {water + scaledRequested, now, 1};
            }
            // 注水后会溢出 → 拒绝，水位不变
            return new long[] {water, now, 0};
        });

        boolean allowed = result[2] == 1;
        // remaining = 桶还能再接受多少水（剩余容量）
        long remaining = Math.max(0, scaleDown(scaledCapacity - result[0]));
        return new RateLimitResult(allowed, remaining, List.of(entity.getKey()));
    }

    @Override
    public void release(final RateLimitEntity entity) {
        if (entity.getAlgorithm() == RateLimitAlgorithm.CONCURRENT_REQUEST) {
            Semaphore semaphore = concurrentStates.getIfPresent(entity.getKey());
            if (Objects.nonNull(semaphore)) {
                semaphore.release((int) entity.getRequestCount());
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  工具方法
    // ─────────────────────────────────────────────────────────────────────

    /**
     * 将 double 放大 100 万倍转为 long，用于整数原子运算，避免浮点误差.
     * <p>例如 replenishRate=1.5 → scaleUp 后为 1_500_000</p>
     */
    private static long scaleUp(final double value) {
        return (long) (value * 1_000_000);
    }

    /** 将放大后的 long 缩回原始数量级. */
    private static long scaleDown(final long value) {
        return value / 1_000_000;
    }

    /** 从 Guava Cache 中获取 key 对应的值，不存在时通过 loader 创建. */
    private static <V> V getOrCreate(
            final Cache<String, V> cache, final String key, final java.util.concurrent.Callable<V> loader) {
        try {
            return cache.get(key, loader);
        } catch (ExecutionException e) {
            throw new IllegalStateException("Failed to create rate limiter state for key: " + key, e);
        }
    }

    /**
     * 滑动窗口的内部状态.
     * <p>{@code timestamps} 是按时间顺序排列的请求时间戳队列，
     * {@code count} 是窗口内的请求计数（与队列大小同步）。
     * 分开维护计数是为了 O(1) 读取当前窗口大小，无需遍历队列。</p>
     */
    static final class SlidingWindowState {
        private final Deque<Long> timestamps = new ConcurrentLinkedDeque<>();

        private final AtomicLong count = new AtomicLong(0);

        /** 从队列头部移除所有早于 cutoff 的过期时间戳. */
        void removeExpired(final long cutoff) {
            while (true) {
                Long head = timestamps.peekFirst();
                if (Objects.isNull(head) || head >= cutoff) {
                    break;
                }
                if (Objects.nonNull(timestamps.pollFirst())) {
                    count.decrementAndGet();
                }
            }
        }
    }
}
