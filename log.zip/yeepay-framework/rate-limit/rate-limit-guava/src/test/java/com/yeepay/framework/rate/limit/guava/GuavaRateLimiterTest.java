package com.yeepay.framework.rate.limit.guava;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GuavaRateLimiterTest {

    private GuavaRateLimiter rateLimiter;

    @BeforeEach
    void setUp() {
        rateLimiter = new GuavaRateLimiter();
    }

    private RateLimitEntity.RateLimitEntityBuilder baseEntity() {
        return RateLimitEntity.builder().key("test-key").replenishRate(10).burstCapacity(20);
    }

    // ── Token Bucket ──────────────────────────────────────────────────────

    @Test
    void tokenBucket_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void tokenBucket_exhausted() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(3)
                .replenishRate(1)
                .build();

        for (int i = 0; i < 3; i++) {
            assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        }
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    @Test
    void tokenBucket_customRequestCount() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(10)
                .replenishRate(1)
                .requestCount(5)
                .build();

        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    @Test
    void tokenBucket_differentKeysAreIndependent() {
        RateLimitEntity entity1 = baseEntity()
                .key("key-1")
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(1)
                .replenishRate(1)
                .build();
        RateLimitEntity entity2 = baseEntity()
                .key("key-2")
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .burstCapacity(1)
                .replenishRate(1)
                .build();

        assertThat(rateLimiter.isAllowed(entity1).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity1).isAllowed()).isFalse();
        assertThat(rateLimiter.isAllowed(entity2).isAllowed()).isTrue();
    }

    @Test
    void tokenBucket_isDefaultAlgorithm() {
        RateLimitResult result = rateLimiter.isAllowed(baseEntity().build());
        assertThat(result.isAllowed()).isTrue();
    }

    // ── Sliding Window ────────────────────────────────────────────────────

    @Test
    void slidingWindow_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void slidingWindow_exhausted() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.SLIDING_WINDOW)
                .burstCapacity(3)
                .replenishRate(1)
                .build();

        for (int i = 0; i < 3; i++) {
            assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        }
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    @Test
    void slidingWindow_remainingDecreases() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.SLIDING_WINDOW)
                .burstCapacity(5)
                .replenishRate(1)
                .build();

        RateLimitResult r1 = rateLimiter.isAllowed(entity);
        RateLimitResult r2 = rateLimiter.isAllowed(entity);

        assertThat(r1.getTokensRemaining()).isGreaterThan(r2.getTokensRemaining());
    }

    // ── Concurrent Request ────────────────────────────────────────────────

    @Test
    void concurrentRequest_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void concurrentRequest_exhausted() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST)
                .burstCapacity(2)
                .replenishRate(1)
                .build();

        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    // ── Leaky Bucket ──────────────────────────────────────────────────────

    @Test
    void leakyBucket_allowed() {
        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isGreaterThanOrEqualTo(0);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void leakyBucket_exhausted() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.LEAKY_BUCKET)
                .burstCapacity(3)
                .replenishRate(1)
                .requestCount(1)
                .build();

        for (int i = 0; i < 3; i++) {
            assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        }
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    @Test
    void leakyBucket_customRequestCount() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.LEAKY_BUCKET)
                .burstCapacity(10)
                .replenishRate(1)
                .requestCount(5)
                .build();

        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isTrue();
        assertThat(rateLimiter.isAllowed(entity).isAllowed()).isFalse();
    }

    @Test
    void leakyBucket_remainingDecreases() {
        RateLimitEntity entity = baseEntity()
                .algorithm(RateLimitAlgorithm.LEAKY_BUCKET)
                .burstCapacity(10)
                .replenishRate(1)
                .build();

        RateLimitResult r1 = rateLimiter.isAllowed(entity);
        RateLimitResult r2 = rateLimiter.isAllowed(entity);

        assertThat(r1.getTokensRemaining()).isGreaterThan(r2.getTokensRemaining());
    }
}
