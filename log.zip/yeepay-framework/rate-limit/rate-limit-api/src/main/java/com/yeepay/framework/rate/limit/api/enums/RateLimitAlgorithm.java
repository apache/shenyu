package com.yeepay.framework.rate.limit.api.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * The enum Rate limit algorithm.
 */
@RequiredArgsConstructor
@Getter
public enum RateLimitAlgorithm {

    /**
     * Token bucket algorithm.
     */
    TOKEN_BUCKET("token_bucket"),

    /**
     * Sliding window algorithm.
     */
    SLIDING_WINDOW("sliding_window"),

    /**
     * Concurrent request algorithm.
     */
    CONCURRENT_REQUEST("concurrent_request"),

    /**
     * Leaky bucket algorithm.
     */
    LEAKY_BUCKET("leaky_bucket");

    private final String algorithmName;

    /**
     * Resolve algorithm by name.
     *
     * @param algorithmName the algorithm name
     * @return the rate limit algorithm
     */
    public static RateLimitAlgorithm of(final String algorithmName) {
        for (RateLimitAlgorithm algorithm : values()) {
            if (algorithm.getAlgorithmName().equals(algorithmName)) {
                return algorithm;
            }
        }
        return TOKEN_BUCKET;
    }
}
