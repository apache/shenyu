package com.yeepay.framework.rate.limit.api;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;

/**
 * 限流管理器.
 *
 * <p>封装 {@link YeepayRateLimiter} 的底层实现细节，提供面向业务的限流 API。
 * 调用方无需感知具体的限流实现，直接传入业务任务（{@link Runnable} 或 {@link Supplier}）即可。
 *
 * <p>支持两种使用方式：
 * <ul>
 *   <li>{@code isAllowed}：仅判断是否允许通过，返回 {@link RateLimitResult}；</li>
 *   <li>{@code tryAcquire}：判断是否允许通过，允许则执行任务，否则执行失败回调。</li>
 * </ul>
 */
@RequiredArgsConstructor
public class RateLimiterManager {

    private final YeepayRateLimiter rateLimiter;

    /**
     * 判断是否允许通过，使用默认参数（令牌桶，速率 10，容量 20，消耗 1）.
     *
     * @param key 限流资源标识
     * @return 限流结果
     */
    public RateLimitResult isAllowed(String key) {
        RateLimitEntity entity = RateLimitEntity.builder().key(key).build();
        return rateLimiter.isAllowed(entity);
    }

    /**
     * 判断是否允许通过，自定义速率和容量.
     *
     * @param key            限流资源标识
     * @param replenishRate  令牌补充速率（个/秒）
     * @param burstCapacity  最大容量
     * @return 限流结果
     */
    public RateLimitResult isAllowed(String key, double replenishRate, double burstCapacity) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key(key)
                .replenishRate(replenishRate)
                .burstCapacity(burstCapacity)
                .build();
        return rateLimiter.isAllowed(entity);
    }

    /**
     * 判断是否允许通过，完整参数.
     *
     * @param key            限流资源标识
     * @param replenishRate  令牌补充速率（个/秒）
     * @param burstCapacity  最大容量
     * @param requestCount   单次请求消耗令牌数
     * @param algorithm      限流算法
     * @return 限流结果
     */
    public RateLimitResult isAllowed(
            String key, double replenishRate, double burstCapacity, double requestCount, RateLimitAlgorithm algorithm) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key(key)
                .replenishRate(replenishRate)
                .burstCapacity(burstCapacity)
                .requestCount(requestCount)
                .algorithm(algorithm)
                .build();
        return rateLimiter.isAllowed(entity);
    }

    /**
     * 判断是否允许通过.
     *
     * @param entity 限流实体
     * @return 限流结果
     */
    public RateLimitResult isAllowed(RateLimitEntity entity) {
        return rateLimiter.isAllowed(entity);
    }

    /**
     * 尝试获取令牌后执行任务，使用默认参数，获取失败时静默跳过.
     *
     * @param key  限流资源标识
     * @param task 获取令牌成功后执行的任务
     */
    public void tryAcquire(String key, Runnable task) {
        RateLimitEntity entity = RateLimitEntity.builder().key(key).build();
        doTryAcquire(entity, task, null);
    }

    /**
     * 尝试获取令牌后执行任务，自定义速率和容量.
     *
     * @param key            限流资源标识
     * @param replenishRate  令牌补充速率（个/秒）
     * @param burstCapacity  最大容量
     * @param task           获取令牌成功后执行的任务
     * @param fail           获取令牌失败后执行的回调，可为 null
     */
    public void tryAcquire(
            String key, double replenishRate, double burstCapacity, Runnable task, Consumer<RateLimitResult> fail) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key(key)
                .replenishRate(replenishRate)
                .burstCapacity(burstCapacity)
                .build();
        doTryAcquire(entity, task, fail);
    }

    /**
     * 尝试获取令牌后执行任务.
     *
     * @param entity 限流实体
     * @param task   获取令牌成功后执行的任务
     * @param fail   获取令牌失败后执行的回调，可为 null
     */
    public void tryAcquire(RateLimitEntity entity, Runnable task, Consumer<RateLimitResult> fail) {
        doTryAcquire(entity, task, fail);
    }

    /**
     * 尝试获取令牌后执行有返回值的任务，使用默认参数.
     *
     * @param key  限流资源标识
     * @param task 获取令牌成功后执行的任务
     * @param fail 获取令牌失败后执行的回调，可为 null
     * @param <R>  任务返回值类型
     * @return 任务或失败回调的返回值；两者均为 null 时返回 null
     */
    public <R> R tryAcquire(String key, Supplier<R> task, Supplier<R> fail) {
        RateLimitEntity entity = RateLimitEntity.builder().key(key).build();
        return doTryAcquire(entity, task, fail);
    }

    /**
     * 尝试获取令牌后执行有返回值的任务，自定义速率和容量.
     *
     * @param key            限流资源标识
     * @param replenishRate  令牌补充速率（个/秒）
     * @param burstCapacity  最大容量
     * @param task           获取令牌成功后执行的任务
     * @param fail           获取令牌失败后执行的回调，可为 null
     * @param <R>            任务返回值类型
     * @return 任务或失败回调的返回值；两者均为 null 时返回 null
     */
    public <R> R tryAcquire(
            String key, double replenishRate, double burstCapacity, Supplier<R> task, Supplier<R> fail) {
        RateLimitEntity entity = RateLimitEntity.builder()
                .key(key)
                .replenishRate(replenishRate)
                .burstCapacity(burstCapacity)
                .build();
        return doTryAcquire(entity, task, fail);
    }

    /**
     * 尝试获取令牌后执行有返回值的任务.
     *
     * @param entity 限流实体
     * @param task   获取令牌成功后执行的任务
     * @param fail   获取令牌失败后执行的回调，可为 null
     * @param <R>    任务返回值类型
     * @return 任务或失败回调的返回值；两者均为 null 时返回 null
     */
    public <R> R tryAcquire(RateLimitEntity entity, Supplier<R> task, Supplier<R> fail) {
        return doTryAcquire(entity, task, fail);
    }

    private void doTryAcquire(RateLimitEntity entity, Runnable task, Consumer<RateLimitResult> fail) {
        RateLimitResult result = rateLimiter.isAllowed(entity);
        if (result.isAllowed()) {
            try {
                task.run();
            } finally {
                rateLimiter.release(entity);
            }
        } else if (Objects.nonNull(fail)) {
            fail.accept(result);
        }
    }

    private <R> R doTryAcquire(RateLimitEntity entity, Supplier<R> task, Supplier<R> fail) {
        RateLimitResult result = rateLimiter.isAllowed(entity);
        if (result.isAllowed()) {
            try {
                return task.get();
            } finally {
                rateLimiter.release(entity);
            }
        } else if (Objects.nonNull(fail)) {
            return fail.get();
        }
        return null;
    }
}
