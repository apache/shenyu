package com.yeepay.framework.rate.limit.api.result;

import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * rateLimiter result.
 */
@RequiredArgsConstructor
@Getter
public class RateLimitResult {

    private final boolean allowed;

    private final long tokensRemaining;

    private final List<String> keys;
}
