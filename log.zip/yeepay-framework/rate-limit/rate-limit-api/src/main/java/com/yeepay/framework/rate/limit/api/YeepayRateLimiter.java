package com.yeepay.framework.rate.limit.api;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;

/**
 * The interface Rate limiter.
 */
public interface YeepayRateLimiter {

    /**
     * Is allowed rate limit result.
     *
     * @param entity the entity
     * @return the rate limit result
     */
    RateLimitResult isAllowed(RateLimitEntity entity);

    /**
     * 释放限流资源（仅 CONCURRENT_REQUEST 算法需要）.
     *
     * <p>在业务逻辑执行完成后调用，归还并发许可。非 CONCURRENT_REQUEST 算法调用此方法无任何效果。
     * 由 {@link RateLimiterManager#tryAcquire} 和 RateLimitTemplate 在 finally 块中自动调用。</p>
     *
     * @param entity 限流实体（与 isAllowed 传入的实体一致）
     */
    default void release(RateLimitEntity entity) {}
}
