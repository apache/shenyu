package com.yeepay.framework.rate.limit.api.entity;

import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import lombok.Builder;
import lombok.Data;

/**
 * 限流请求实体.
 */
@Data
@Builder
public class RateLimitEntity {

    /**
     * 限流资源唯一标识，用于在 Redis 中区分不同的限流维度，例如 "order:create" 或 "user:10001:api".
     */
    private String key;

    /**
     * 令牌补充速率（单位：个/秒），默认为 10.
     * <p>对于令牌桶算法，表示每秒向桶中补充的令牌数量；
     * 对于漏桶算法，表示每秒漏出的请求数量；
     * 对于滑动窗口算法，与 burstCapacity 共同决定窗口大小（windowSize = burstCapacity / replenishRate）。</p>
     */
    @Builder.Default
    private double replenishRate = 10;

    /**
     * 最大容量（令牌桶的最大令牌数 / 漏桶的最大水量 / 滑动窗口和并发限流的最大请求数），默认为 20.
     * <p>突发流量场景下允许通过的最大请求数上限。</p>
     */
    @Builder.Default
    private double burstCapacity = 20;

    /**
     * 单次请求消耗的令牌数量，默认为 1.
     * <p>适用于令牌桶和漏桶算法；滑动窗口和并发限流算法中每次请求固定消耗 1。</p>
     */
    @Builder.Default
    private double requestCount = 1.0;

    /**
     * 限流算法，默认为 {@link RateLimitAlgorithm#TOKEN_BUCKET}.
     *
     * @see RateLimitAlgorithm
     */
    @Builder.Default
    private RateLimitAlgorithm algorithm = RateLimitAlgorithm.TOKEN_BUCKET;
}
