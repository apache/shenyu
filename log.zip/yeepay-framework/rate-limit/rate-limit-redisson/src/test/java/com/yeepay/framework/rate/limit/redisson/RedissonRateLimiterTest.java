package com.yeepay.framework.rate.limit.redisson;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.redisson.api.RScript;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.StringCodec;

@ExtendWith(MockitoExtension.class)
class RedissonRateLimiterTest {

    @Mock
    private RedissonClient redissonClient;

    @Mock
    private RScript rScript;

    @Captor
    private ArgumentCaptor<List<Object>> keysCaptor;

    private RedissonRateLimiter rateLimiter;

    @BeforeEach
    void setUp() {
        rateLimiter = new RedissonRateLimiter(redissonClient);
    }

    private RateLimitEntity.RateLimitEntityBuilder baseEntity() {
        return RateLimitEntity.builder().key("test-key").replenishRate(10).burstCapacity(20);
    }

    private void stubEval(final List<Long> result) {
        when(redissonClient.getScript(StringCodec.INSTANCE)).thenReturn(rScript);
        when(rScript.scriptLoad(anyString())).thenReturn("test-sha");
        doReturn(result)
                .when(rScript)
                .evalSha(
                        any(RScript.Mode.class),
                        anyString(),
                        any(RScript.ReturnType.class),
                        any(List.class),
                        any(Object[].class));
    }

    // ── Token Bucket ──────────────────────────────────────────────────────

    @Test
    void tokenBucket_allowed() {
        stubEval(Arrays.asList(1L, 19L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(19L);
        assertThat(result.getKeys()).containsExactly("test-key.tokens", "test-key.timestamp");
    }

    @Test
    void tokenBucket_rejected() {
        stubEval(Arrays.asList(0L, 0L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void tokenBucket_isDefaultAlgorithm() {
        stubEval(Arrays.asList(1L, 15L));

        RateLimitResult result = rateLimiter.isAllowed(baseEntity().build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getKeys()).containsExactly("test-key.tokens", "test-key.timestamp");
    }

    @Test
    void tokenBucket_customRequestCount() {
        stubEval(Arrays.asList(1L, 15L));

        RateLimitResult result = rateLimiter.isAllowed(baseEntity()
                .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
                .requestCount(5)
                .build());

        assertThat(result.isAllowed()).isTrue();
    }

    // ── Sliding Window ────────────────────────────────────────────────────

    @Test
    void slidingWindow_allowed() {
        stubEval(Arrays.asList(1L, 15L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(15L);
        assertThat(result.getKeys()).containsExactly("test-key.tokens");
    }

    @Test
    void slidingWindow_rejected() {
        stubEval(Arrays.asList(0L, 0L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void slidingWindow_keysContainUniqueMembers() {
        stubEval(Arrays.asList(1L, 10L));

        rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.SLIDING_WINDOW).build());

        verify(rScript)
                .evalSha(
                        any(RScript.Mode.class),
                        anyString(),
                        any(RScript.ReturnType.class),
                        keysCaptor.capture(),
                        any(Object[].class));
        List<Object> keys = keysCaptor.getValue();
        assertThat(keys).hasSize(2);
        assertThat(keys.get(0)).isEqualTo("test-key.tokens");
        assertThat(keys.get(1).toString()).startsWith("test-key.");
    }

    // ── Concurrent Request ────────────────────────────────────────────────

    @Test
    void concurrentRequest_allowed() {
        stubEval(Arrays.asList(1L, 5L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(15L);
        assertThat(result.getKeys()).containsExactly("test-key");
    }

    @Test
    void concurrentRequest_rejected() {
        stubEval(Arrays.asList(0L, 20L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void concurrentRequest_remainingClampedToZero() {
        stubEval(Arrays.asList(0L, 25L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST).build());

        assertThat(result.getTokensRemaining()).isZero();
    }

    // ── Leaky Bucket ──────────────────────────────────────────────────────

    @Test
    void leakyBucket_allowed() {
        stubEval(Arrays.asList(1L, 5L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        assertThat(result.getTokensRemaining()).isEqualTo(15L);
        assertThat(result.getKeys()).containsExactly("test-key.bucket", "test-key.last");
    }

    @Test
    void leakyBucket_rejected() {
        stubEval(Arrays.asList(0L, 21L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.isAllowed()).isFalse();
        assertThat(result.getTokensRemaining()).isZero();
    }

    @Test
    void leakyBucket_remainingClampedToZero() {
        stubEval(Arrays.asList(0L, 30L));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.LEAKY_BUCKET).build());

        assertThat(result.getTokensRemaining()).isZero();
    }

    // ── evalSha / NOSCRIPT fallback ───────────────────────────────────────

    @Test
    void evalSha_noscriptFallback_reloadsScript() {
        when(redissonClient.getScript(StringCodec.INSTANCE)).thenReturn(rScript);
        when(rScript.scriptLoad(anyString())).thenReturn("sha-1", "sha-2");
        doThrow(new RuntimeException("NOSCRIPT No matching script"))
                .doReturn(Arrays.asList(1L, 10L))
                .when(rScript)
                .evalSha(
                        any(RScript.Mode.class),
                        anyString(),
                        any(RScript.ReturnType.class),
                        any(List.class),
                        any(Object[].class));

        RateLimitResult result = rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        assertThat(result.isAllowed()).isTrue();
        verify(rScript, times(2)).scriptLoad(anyString());
    }

    @Test
    void evalSha_nonNoscriptException_rethrown() {
        when(redissonClient.getScript(StringCodec.INSTANCE)).thenReturn(rScript);
        when(rScript.scriptLoad(anyString())).thenReturn("sha-1");
        doThrow(new RuntimeException("Connection refused"))
                .when(rScript)
                .evalSha(
                        any(RScript.Mode.class),
                        anyString(),
                        any(RScript.ReturnType.class),
                        any(List.class),
                        any(Object[].class));

        assertThatThrownBy(() -> rateLimiter.isAllowed(
                        baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build()))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Connection refused");
    }

    // ── SHA caching ───────────────────────────────────────────────────────

    @Test
    void shaCached_scriptLoadCalledOnlyOnce() {
        stubEval(Arrays.asList(1L, 10L));

        rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());
        rateLimiter.isAllowed(
                baseEntity().algorithm(RateLimitAlgorithm.TOKEN_BUCKET).build());

        verify(rScript, times(1)).scriptLoad(anyString());
        verify(rScript, times(2))
                .evalSha(
                        any(RScript.Mode.class),
                        anyString(),
                        any(RScript.ReturnType.class),
                        any(List.class),
                        any(Object[].class));
    }
}
