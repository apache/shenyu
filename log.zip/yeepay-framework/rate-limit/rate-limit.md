# 限流 (Rate Limit)

## 概述

基于 **SPI 可插拔架构** + **AOP 声明式注解**的限流模块，提供两套 API：

- **注解方式（推荐）**：`@YeepayRateLimit` 声明式限流，AOP 自动管理
- **编程方式**：`RateLimiterManager` 在代码中直接调用 `isAllowed()` / `tryAcquire()`

支持 **4 种算法** × **4 种后端**，用户按需组合。

**适用场景：** API 限流、防止刷接口、消息消费控制、下游调用保护。

## 选型指引

| 需求 | 推荐后端 |
|------|----------|
| 单机限流，不需要分布式协调，性能最高 | **Guava** |
| 单机限流，需要更多高级策略（熔断/重试）配合 | **Resilience4j** |
| 跨实例全局限流，Redis 集群已部署 | **Jedis** 或 **Redisson** |
| 跨实例限流 + 需要 Redisson 框架集成 | **Redisson** |

> **本地 vs 分布式：** Guava / Resilience4j 是单机限流，每个实例独立计数。Jedis / Redisson 通过 Redis 实现全局限流，多实例共享配额。

---

## 核心概念（所有后端通用）

### 限流算法

| 算法 | 枚举值 | 行为 | 适用场景 |
|------|--------|------|----------|
| 令牌桶 | `TOKEN_BUCKET` | 固定速率补充令牌，允许突发（桶满时一次性消耗多令牌） | 大多数场景的默认选择 |
| 滑动窗口 | `SLIDING_WINDOW` | 统计滑动时间窗口内的请求数，窗口大小 = burstCapacity / replenishRate | 严格限制时间窗口内的请求量 |
| 漏桶 | `LEAKY_BUCKET` | 固定速率漏出，请求注水，超过容量则拒绝 | 平滑流量，消峰填谷 |
| 并发请求 | `CONCURRENT_REQUEST` | 限制同时执行的数量，基于 Semaphore 信号量 | 限制并发度（如数据库连接） |

**各后端支持的算法：**

| 算法 | Guava | Resilience4j | Jedis | Redisson |
|------|-------|-------------|-------|----------|
| `TOKEN_BUCKET` | CAS 无锁实现 | 周期刷新模式（边界可能突发） | Redis Lua 脚本 | Redis Lua 脚本 |
| `SLIDING_WINDOW` | ConcurrentLinkedDeque | 固定窗口模式（非真正滑动） | Redis Lua 脚本 | Redis Lua 脚本 |
| `LEAKY_BUCKET` | CAS 无锁实现 | 极短周期匀速模式 | Redis Lua 脚本 | Redis Lua 脚本 |
| `CONCURRENT_REQUEST` | Semaphore | Semaphore (Bulkhead) | Redis Lua 脚本 | Redis Lua 脚本 |

### RateLimitEntity — 限流参数

```java
@Data @Builder
public class RateLimitEntity {
    private String key;                           // 限流资源唯一标识，如 "order:create"
    @Builder.Default
    private double replenishRate = 10;            // 令牌补充速率（个/秒）
    @Builder.Default
    private double burstCapacity = 20;            // 最大容量（令牌桶上限 / 窗口请求上限 / 最大并发数）
    @Builder.Default
    private double requestCount = 1.0;            // 单次请求消耗令牌数
    @Builder.Default
    private RateLimitAlgorithm algorithm = TOKEN_BUCKET;  // 限流算法
}
```

参数含义因算法而异：
- **令牌桶**：`replenishRate` = 每秒补充令牌数，`burstCapacity` = 桶最大令牌数
- **滑动窗口**：`replenishRate` 和 `burstCapacity` 共同决定窗口大小 = `burstCapacity / replenishRate` 秒
- **漏桶**：`replenishRate` = 每秒漏出速率，`burstCapacity` = 桶容量上限
- **并发请求**：仅使用 `burstCapacity` = 最大并发数，`replenishRate` 和 `requestCount` 无意义

### RateLimitResult — 限流结果

```java
@Getter
public class RateLimitResult {
    private final boolean allowed;           // 是否允许通过
    private final long tokensRemaining;      // 剩余令牌数 / 剩余容量 / 剩余并发槽位
    private final List<String> keys;         // 使用的 Redis key 列表
}
```

### RateLimiterManager API

| 方法 | 说明 |
|------|------|
| `isAllowed(key)` | 仅判断是否允许，默认参数 |
| `isAllowed(key, rate, capacity)` | 仅判断，自定义速率和容量 |
| `isAllowed(key, rate, capacity, requestCount, algorithm)` | 仅判断，完整参数 |
| `isAllowed(entity)` | 仅判断，RateLimitEntity |
| `tryAcquire(key, task)` | 允许则执行 task，否则静默跳过 |
| `tryAcquire(key, rate, capacity, task, fail)` | 允许则执行 task，否则执行 fail 回调 |
| `tryAcquire(entity, task, fail)` | 允许则执行 task，否则执行 fail 回调 |

所有 `tryAcquire` 方法支持 `Runnable` / `Consumer<RateLimitResult>` 和 `Supplier<R>` 两种形式，执行后自动调用 `release()` 释放资源。

**编程方式示例：**

```java
@Autowired
private RateLimiterManager rateLimiterManager;

// 仅判断
RateLimitResult result = rateLimiterManager.isAllowed("api:sendSms", 10, 20);
if (result.isAllowed()) {
    sendSms();
} else {
    log.warn("限流触发, remaining={}", result.getTokensRemaining());
}

// tryAcquire — 允许则执行
rateLimiterManager.tryAcquire("api:sendSms", 10, 20,
    () -> sendSms(),
    (result) -> log.warn("限流触发, remaining={}", result.getTokensRemaining())
);

// tryAcquire 带返回值
String resp = rateLimiterManager.tryAcquire("api:query", 100, 200,
    () -> queryData(),
    () -> "TOO_MANY_REQUESTS"
);

// 完整参数
RateLimitEntity entity = RateLimitEntity.builder()
    .key("service:export")
    .replenishRate(5)
    .burstCapacity(10)
    .algorithm(RateLimitAlgorithm.SLIDING_WINDOW)
    .build();
rateLimiterManager.tryAcquire(entity,
    () -> exportData(),
    (result) -> { throw new BizException("导出繁忙，请稍后重试"); }
);
```

---

## 注解方式（所有后端通用）

`@YeepayRateLimit` 注解由 `YeepayRateLimitAspect` 处理，自动完成 key 生成 → 限流判断 → 执行/拒绝 流程。

**注解属性：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `name` | String | `""` | 限流名称前缀 |
| `algorithm` | `RateLimitAlgorithm` | `TOKEN_BUCKET` | 限流算法 |
| `replenishRate` | double | `10` | 令牌补充速率（个/秒） |
| `burstCapacity` | double | `20` | 最大容量 |
| `requestCount` | double | `1` | 单次请求消耗令牌数 |
| `keys` | String[] | `{}` | SpEL 表达式，动态限流 key |
| `keyStrategy` | Class | 默认策略 | key 生成策略 |
| `failStrategy` | Class | 默认策略 | 触发限流时的处理策略 |

**锁 Key 规则：**
- `keys` 为空 → 方法级限流：`yeepay-rate-limit@{name}#{全限定类名}.{方法名}`
- `keys` 不为空 → 参数级限流：`yeepay-rate-limit@{name}#{SpEL值1}.{SpEL值2}...`

**注解示例：**

```java
// 最简用法 — 令牌桶，每秒 10 令牌，峰值 20
@YeepayRateLimit(name = "sendSms")
public void sendSms(String phone) { ... }

// 按用户限流
@YeepayRateLimit(name = "query", keys = {"#userId"}, replenishRate = 100, burstCapacity = 200)
public Order queryOrder(String userId) { ... }

// 滑动窗口 + 自定义失败策略
@YeepayRateLimit(name = "export", algorithm = RateLimitAlgorithm.SLIDING_WINDOW,
                 replenishRate = 5, burstCapacity = 10,
                 failStrategy = MyFailStrategy.class)
public void exportData() { ... }
```

### 自定义策略

**Key 策略 — 自定义 key 生成（如按 IP 限流）：**

```java
@Component
public class IpBasedKeyStrategy implements RateLimitKeyStrategy {
    @Override
    public String buildKey(JoinPoint joinPoint, String[] keys) {
        HttpServletRequest request =
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String ip = request.getRemoteAddr();
        MethodSignature sig = (MethodSignature) joinPoint.getSignature();
        return sig.getName() + ":" + ip;
    }
}

// 使用
@YeepayRateLimit(name = "api", keyStrategy = IpBasedKeyStrategy.class)
public void api() { ... }
```

**失败策略 — 限流触发时的处理（默认抛 RuntimeException）：**

```java
@Component
public class AlertFailStrategy implements RateLimitFailureStrategy {
    @Override
    public Object execute(String key, RateLimitResult result, ProceedingJoinPoint point) {
        // 告警 + 返回错误码，不抛异常
        log.error("[RATE_LIMIT] key={}, remaining={}", key, result.getTokensRemaining());
        MethodSignature sig = (MethodSignature) point.getSignature();
        Class<?> returnType = sig.getReturnType();
        if (returnType == boolean.class) return false;
        return null;
    }
}
```

**切面工作流程：**

```
@Around → buildKey() → RateLimitEntity → rateLimitTemplate.invoke()
                                              │
                          ┌───────────────────┴───────────────────┐
                          │ rateLimiter.isAllowed(entity)         │
                          ├── allowed=true  → joinPoint.proceed() │
                          │                → rateLimiter.release()│
                          ├── allowed=false → failStrategy.execute│
                          └───────────────────────────────────────┘
```

---

## Guava 限流（本地）

基于 Guava Cache 的本地内存限流器，所有算法状态（令牌数、时间戳队列、信号量）都存放在 JVM 中，以 key 为缓存键隔离。

**特点：** 四种算法全部使用 CAS 无锁编程实现，性能最高（无网络开销），默认 1 小时无访问后自动回收缓存。

### 1. 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-rate-limit-guava</artifactId>
</dependency>
```

### 2. 配置

```yaml
yeepay:
  framework:
    rate-limit:
      # 仅多后端共存时需指定，单后端无需设置
      # type: guava
```

Guava 限流器无需 Redis 连接，零配置即可使用。

### 3. 实现原理

**令牌桶** — `AtomicReference<long[]>` 存 `{tokens, lastRefillNanos}`，CAS 无锁更新。每次请求先按时间补充令牌（`tokens += elapsed * rate / 1s`），上限 `burstCapacity`，再判断是否足够扣减。浮点数乘以 1,000,000 放大为整数避免累积误差。

**滑动窗口** — `ConcurrentLinkedDeque` 记录每个请求的时间戳，每次请求先移除窗口外的过期时间戳，再判断当前计数是否 < `burstCapacity`。

**并发请求** — `Semaphore(maxConcurrentCalls)`，`tryAcquire()` 非阻塞获取许可。需在 finally 中调用 `release()` 释放。

**漏桶** — 与令牌桶类似，但反向：`AtomicReference<long[]>` 存 `{water, lastLeakNanos}`，按时间漏出水量，再判断注水后是否溢出。

**局限性：** 仅单机有效，多实例不共享状态。应用重启后限流数据丢失。

### 4. 使用示例

```java
// 注解方式
@YeepayRateLimit(name = "api", algorithm = RateLimitAlgorithm.LEAKY_BUCKET,
                 replenishRate = 50, burstCapacity = 100)
public void api() { ... }

// 编程方式
@Autowired
private RateLimiterManager rateLimiterManager;

public void consume() {
    rateLimiterManager.tryAcquire("mq:order", 100, 200,
        () -> processMessage(),
        (result) -> log.warn("消费过快, remaining={}", result.getTokensRemaining())
    );
}
```

---

## Resilience4j 限流（本地）

基于 Resilience4j RateLimiter + Bulkhead 的本地限流器。通过将 4 种算法映射到 Resilience4j 的组件上实现，适合需要同时使用 Resilience4j 其他能力（熔断、重试、舱壁隔离）的场景。

**特点：** 与 Resilience4j 生态集成，提供 Metrics 端点。底层是固定窗口周期刷新，非真正的令牌桶/漏桶/滑动窗口。

### 1. 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-rate-limit-resilience4j</artifactId>
</dependency>
```

### 2. 配置

```yaml
yeepay:
  framework:
    rate-limit:
      # type: resilience4j
```

Resilience4j 限流器无需 Redis，零配置即可使用。

### 3. 实现原理

各算法对应的 Resilience4j 配置策略：

| 算法 | Resilience4j 组件 | 配置策略 |
|------|-------------------|----------|
| `TOKEN_BUCKET` | `RateLimiter` | 周期 = 1s，每周期许可 = replenishRate。每秒刷新 replenishRate 个许可 |
| `SLIDING_WINDOW` | `RateLimiter` | 周期 = burstCapacity/replenishRate 秒，每周期许可 = burstCapacity。一个完整窗口内允许 burstCapacity 个请求 |
| `LEAKY_BUCKET` | `RateLimiter` | 周期 = 1/replenishRate 秒，每周期 1 个许可。严格匀速放行 |
| `CONCURRENT_REQUEST` | `Bulkhead`(Semaphore) | maxConcurrentCalls = burstCapacity。非阻塞获取+释放许可 |

**重要差异：** Resilience4j 的 RateLimiter 是固定窗口（Fixed Window），不是真正的滑动窗口或令牌桶。窗口边界处可能出现瞬时 2 倍请求（周期末尾和下一周期开头连着通过）。

**局限性：** 仅单机有效。`LEAKY_BUCKET` 模式下 `requestCount > 1` 语义不精确。

### 4. 使用示例

```java
// 并发限流
@YeepayRateLimit(name = "db", algorithm = RateLimitAlgorithm.CONCURRENT_REQUEST,
                 burstCapacity = 50)
public void queryDB() { ... }

// 编程方式
@Autowired
private RateLimiterManager rateLimiterManager;

public void call() {
    rateLimiterManager.tryAcquire("downstream", 10, 20,
        () -> callDownstream(),
        (result) -> { throw new RuntimeException("下游调用频控"); }
    );
}
```

---

## Jedis 限流（分布式）

基于 Jedis + Lua 脚本的分布式限流器。所有限流逻辑在 Redis 服务端通过 Lua 脚本原子执行，多实例共享限流状态。

**特点：** 全局限流，Lua 脚本保证原子性。需要部署 Redis 并配置 Jedis 连接。

### 1. 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-rate-limit-jedis</artifactId>
</dependency>
```

### 2. 配置

```yaml
yeepay:
  framework:
    # ──────────────── Redis 连接配置 ────────────────
    infra:
      jedis:
        password: your-password    # Redis 密码（可选）
        database: 0                # 数据库索引，默认 0
        timeout: 2000              # 连接 / Socket 超时（毫秒），默认 2000
        pool:
          max-total: 8             # 最大连接数，默认 8
          max-idle: 8              # 最大空闲连接数，默认 8
          min-idle: 0              # 最小空闲连接数，默认 0
          max-wait: 2000           # 获取连接最大等待时间（毫秒），默认 2000

        # ─── 单机模式 ───
        single:
          host: 127.0.0.1          # Redis 主机地址，默认 localhost
          port: 6379               # Redis 端口，默认 6379

        # ─── 哨兵模式（与 single / cluster 互斥）───
        # sentinel:
        #   master-name: mymaster
        #   nodes:
        #     - 127.0.0.1:26379
        #     - 127.0.0.1:26380
        #   sentinel-password: sentinel-pass

        # ─── 集群模式（与 single / sentinel 互斥）───
        # cluster:
        #   nodes:
        #     - 127.0.0.1:7000
        #     - 127.0.0.1:7001
        #   max-attempts: 5

    # ──────────────── 限流配置 ────────────────
    rate-limit:
      # type: jedis
```

### 3. 实现原理

Lua 脚本从 classpath `META-INF/scripts/` 加载，首次执行时 `SCRIPT LOAD` 到 Redis，后续用 `EVALSHA` 调用（更高效）。脚本丢失时自动重新加载。

每种算法在 Redis 中使用的数据结构：

| 算法 | Redis key | 数据结构 |
|------|-----------|----------|
| 令牌桶 | `{key}.tokens`, `{key}.timestamp` | String（令牌数 + 上次补充时间戳） |
| 滑动窗口 | `{key}.tokens` (ZSet), `{key}.{UUID}` | ZSet（时间戳为 score） + 随机 member |
| 并发请求 | `{key}`, `{UUID}` | String（当前计数） + 随机标记 |
| 漏桶 | `{key}.bucket`, `{key}.last` | String（水位 + 上次漏水时间戳） |

### 4. 使用示例

```java
// 注解方式 — 分布式限流
@YeepayRateLimit(name = "api", keys = {"#userId"}, replenishRate = 100, burstCapacity = 200)
public Result<String> api(String userId) { ... }

// 编程方式
@Autowired
private RateLimiterManager rateLimiterManager;

public void sendSms(String phone) {
    RateLimitEntity entity = RateLimitEntity.builder()
        .key("sms:" + phone)
        .replenishRate(1)           // 每秒 1 个
        .burstCapacity(5)           // 最多积攒 5 个
        .algorithm(RateLimitAlgorithm.TOKEN_BUCKET)
        .build();
    rateLimiterManager.tryAcquire(entity,
        () -> doSendSms(phone),
        (result) -> log.warn("短信发送过于频繁, phone={}", phone)
    );
}
```

**Redis 版本要求：** 2.6+（支持 Lua 脚本）。

---

## Redisson 限流（分布式）

基于 Redisson RScript 的分布式限流器。与 Jedis 限量使用同一套 Lua 脚本，区别在于通过 Redisson API 执行。

**特点：** 与 Redisson 框架集成，自动复用 Redisson 连接池和配置。

### 1. 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-rate-limit-redisson</artifactId>
</dependency>
```

### 2. 配置

```yaml
yeepay:
  framework:
    # ──────────────── Redis 连接配置 ────────────────
    infra:
      redisson:
        threads: 16                 # Redisson 执行器线程数，默认 16
        netty-threads: 32           # Netty 工作线程数，默认 32
        codec: KRYO5                # 编解码器类型，默认 KRYO5

        # ─── 单机模式 ───
        single:
          address: redis://127.0.0.1:6379  # Redis 地址（必填）
          password: your-password           # Redis 密码（可选）
          database: 0                       # 数据库索引，默认 0
          connection:
            idle-timeout: 10s               # 空闲连接超时，默认 10 秒
            connect-timeout: 500ms          # 连接超时，默认 500 毫秒
            timeout: 100ms                  # 命令响应超时，默认 100 毫秒
            retry-attempts: 3               # 命令重试次数，默认 3
            ping-interval: 5s               # 心跳间隔，默认 5 秒
          pool:
            minimum-idle-size: 24           # 最小空闲连接数，默认 24
            pool-size: 64                   # 最大连接池大小，默认 64

        # ─── 哨兵模式 ───
        # sentinel:
        #   master-name: mymaster
        #   sentinel-addresses:
        #     - redis://127.0.0.1:26379
        #     - redis://127.0.0.1:26380
        #   password: master-pass
        #   sentinel-password: sentinel-pass

        # ─── 集群模式 ───
        # cluster:
        #   node-addresses:
        #     - redis://127.0.0.1:7000
        #     - redis://127.0.0.1:7001
        #   password: cluster-pass
        #   check-slots-coverage: true
        #   scan-interval: 1s

    # ──────────────── 限流配置 ────────────────
    rate-limit:
      # type: redisson
```

### 3. 实现原理

与 Jedis 使用相同的 Lua 脚本，但通过 `redissonClient.getScript(StringCodec.INSTANCE).evalSha()` 执行。Sha 缓存、脚本丢失重加载逻辑与 Jedis 一致。

### 4. 使用示例

```java
// 注解方式
@YeepayRateLimit(name = "order", keys = {"#userId"}, replenishRate = 50, burstCapacity = 100)
public void createOrder(String userId) { ... }

// 编程方式
@Autowired
private RateLimiterManager rateLimiterManager;

public void export() {
    rateLimiterManager.tryAcquire("export", 2, 5,
        () -> doExport(),
        (result) -> { throw new RuntimeException("导出任务繁忙"); }
    );
}
```

---

## 限流专属配置

配置前缀：`yeepay.framework.rate-limit`

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | boolean | `true` | 是否启用。`false` 关闭所有限流功能 |
| `type` | String | — | 实现类型：`guava` / `jedis` / `redisson` / `resilience4j`。多后端共存时必填 |

**多后端共存：** 同时引入多个限流 starter 时，必须通过 `type` 指定使用哪个，否则启动报 duplicate bean 错误。

**关闭限流：** `yeepay.framework.rate-limit.enabled=false` 关闭所有限流（注解和编程方式均不生效）。

---

## 四种算法详解

### 令牌桶 (Token Bucket)

```
┌─────────────────┐
│   令牌补充器     │ → 每秒补充 replenishRate 个令牌
│   (固定速率)     │
└────────┬────────┘
         ▼
┌─────────────────┐     请求来了
│   令牌桶        │ ←────────── 消耗 requestCount 个令牌
│  最多存          │    令牌不足 → 拒绝
│  burstCapacity  │
└─────────────────┘
```

**参数：** `replenishRate=10, burstCapacity=20`
- 初始桶满 20 个令牌
- 每秒补充 10 个，桶满则丢弃多余令牌
- 支持突发：桶有 20 个令牌时可瞬间通过 20 个请求（之后需等待补充）

### 滑动窗口 (Sliding Window)

```
时间轴：  ──[2秒前的请求已过期]────[1秒前]────[刚刚]──→ 现在
窗口:     [←─────── 2秒窗口 (burstCapacity/replenishRate) ──────→]
         窗口内最多 burstCapacity 个请求
```

**参数：** `replenishRate=10, burstCapacity=20` → 窗口 = 2 秒，2 秒内最多 20 个请求

与令牌桶的区别：不积攒令牌，只看窗口内的请求数。不会因"空闲"而增加配额。

### 漏桶 (Leaky Bucket)

```
请求 → 注水 → ┌─────────────────┐ → 漏水（固定速率 replenishRate）→ 处理
              │      漏桶        │
              │  容量 =          │
              │  burstCapacity   │  溢出 → 拒绝
              └─────────────────┘
```

**参数：** `replenishRate=10, burstCapacity=20` → 桶容量 20，每秒漏出 10。允许 20 的突发积压，之后强制匀速。

与令牌桶的区别：即使长时间空闲，也只"空桶"而不积攒令牌。流量整形能力更强。

### 并发请求 (Concurrent Request)

```
Semaphore(permits=burstCapacity)

请求 → tryAcquire() ─── 成功 → 执行业务 → release()
            │
            └── 失败 → 拒绝（超出并发数）
```

**参数：** `burstCapacity=100` → 最多同时 100 个请求并发执行。`replenishRate` 和 `requestCount` 对此算法无意义。

**注意：** 使用此算法 MUST 确保业务执行完成后调用 `release()`。注解方式会在 finally 中自动调用，编程方式使用 `tryAcquire` 也会自动 release。

---

## 各后端算法实现差异

| 算法 | Guava | Resilience4j | Jedis / Redisson |
|------|-------|-------------|------------------|
| 令牌桶 | CAS 精确实现，1ms 精度 | 固定窗口，每秒刷新，精度 1s | Lua 脚本，Redis 时间精度 1s |
| 滑动窗口 | ConcurrentLinkedDeque，纳秒精度 | 固定窗口（非真正滑动） | Lua + ZSet，真正滑动窗口 |
| 漏桶 | CAS 精确实现 | 极短周期 1 许可/周期 | Lua 脚本精确实现 |
| 并发请求 | Semaphore | Semaphore (Bulkhead) | Lua 脚本 + 随机标记 |

**精度差异关键：**
- **Guava**：使用 `System.nanoTime()`，纳秒精度，最接近算法理论值
- **Resilience4j**：固定窗口周期刷新，边界处可能瞬时 2 倍通过量
- **Jedis / Redisson**：使用 `Instant.now().getEpochSecond()`，秒级精度，足够大多数业务场景

---

## 后端对比

| 维度 | Guava | Resilience4j | Jedis | Redisson |
|------|-------|-------------|-------|----------|
| 类型 | 本地 | 本地 | 分布式（Redis + Lua） | 分布式（Redis + Lua） |
| 精确度 | 纳秒级 CAS | 固定窗口（边界突发） | 秒级 Lua | 秒级 Lua |
| 支持算法 | 全部 4 种 | 全部 4 种 | 全部 4 种 | 全部 4 种 |
| 多实例共享 | 不支持 | 不支持 | 支持 | 支持 |
| Redis 依赖 | 无 | 无 | 需要 | 需要 |
| 生态集成 | Guava Cache | 熔断/重试/Bulkhead | Jedis 连接池 | Redisson 全套 |
| 适用场景 | 单机高性能 | 单机 + 多策略组合 | 分布式精确限流 | 分布式 + Redisson 生态 |

---

## 注意事项

1. **本地 vs 分布式：** Guava 和 Resilience4j 仅单机有效。如果需要全局限流（多实例共享配额），必须使用 Jedis 或 Redisson。

2. **算法可用性：** Guava 和 Jedis/Redisson 四种算法都是精确实现。Resilience4j 底层是固定窗口，语义不完全等同于真正的令牌桶/滑动窗口/漏桶。

3. **并发请求算法必须 release：** 使用 `CONCURRENT_REQUEST` 时，注解方式在 finally 中自动 `release()`；编程方式使用 `tryAcquire` 也会自动 release。但 `isAllowed` 需要手动调用 `release()`。

4. **SpEL 动态 Key：** 使用 `keys = {"#userId"}` 时对不同用户独立限流；不指定 keys 时整个方法共用一个限流 key。

5. **Redis Lua 脚本：** Jedis/Redisson 依赖 Lua 脚本。Redis 版本需 2.6+。脚本在首次执行时自动加载，Redis 重启后自动重新加载。

6. **多后端冲突：** 同时引入多个限流 starter 时，必须通过 `yeepay.framework.rate-limit.type` 指定使用哪个。

7. **令牌桶参数比例：** `burstCapacity / replenishRate` 越大，允许的突发流量越大。例如 rate=10, capacity=100 允许一次通过 100 个请求后等待 10 秒。

## 完整示例

参见 `examples/examples-rate-limit/`，包含 Guava、Redisson、Resilience4j 的完整配置和代码。
