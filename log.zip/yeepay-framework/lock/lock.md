# 分布式锁 (Lock)

## 概述

基于 **SPI 可插拔架构** + **AOP 声明式注解**的分布式锁模块，提供两套 API：

- **注解方式（推荐）**：`@YeepayLock` 声明式加锁，AOP 自动管理锁生命周期
- **编程方式**：`LockManager` 在代码中直接调用 `lock()` / `tryLock()`

支持 Jedis 和 Redisson 两种后端，用户按需选其一即可。

**适用场景：** 防止重复提交、定时任务单实例执行、库存扣减、消息幂等消费。

## 选型指引

| 需求 | 推荐后端 |
|------|----------|
| 简单互斥锁、短期锁、轻量级 | **Jedis** |
| 可重入锁、公平锁、读写锁、长时间锁 | **Redisson** |

两个后端共用同一套 API（`LockManager`、`@YeepayLock`），切换只需换依赖和配置。

---

## 核心概念（两个后端通用）

### LockType — 锁类型

```java
public enum LockType {
    REENTRANT,  // 可重入锁（默认）
    FAIR,       // 公平锁
    READ,       // 读锁（读写锁）
    WRITE;      // 写锁（读写锁）
}
```

| 锁类型 | Jedis | Redisson |
|--------|-------|----------|
| `REENTRANT` | 支持 | 支持 |
| `FAIR` | 不支持 | 支持 |
| `READ` | 不支持 | 支持 |
| `WRITE` | 不支持 | 支持 |

### LockEntity — 锁参数

```java
@Data @Builder
public class LockEntity {
    private String keyName;           // 锁 key，如 "order:12345"
    @Builder.Default
    private LockType type = REENTRANT;
    @Builder.Default
    private long waitTime = 3000L;    // 最大等待时间（毫秒）
    @Builder.Default
    private long leaseTime = 3000L;   // 锁持有时间（毫秒），到期 Redis 自动释放
    @Builder.Default
    private boolean autoRelease = true;
}
```

### LockManager API

| 方法 | 说明 |
|------|------|
| `lock(lockName, task)` | 阻塞加锁，默认参数 |
| `lock(lockName, leaseTime, lockType, task, fail)` | 阻塞加锁，自定义参数 |
| `lock(entity, task, fail)` | 阻塞加锁，完整 LockEntity |
| `tryLock(lockName, task)` | 尝试加锁，默认参数，失败静默跳过 |
| `tryLock(lockName, leaseTime, waitTime, lockType, task, fail)` | 尝试加锁，自定义参数 |
| `tryLock(entity, task, fail)` | 尝试加锁，完整 LockEntity |

以上方法均有对应的 `Supplier<R>` 版本，支持返回值。

**编程方式示例：**

```java
@Autowired
private LockManager lockManager;

// 最简阻塞加锁
lockManager.lock("inventory:123", () -> doDeductStock());

// tryLock 带超时和失败回调
lockManager.tryLock("order:456", 5000, 2000, LockType.REENTRANT,
    () -> createOrder(),
    () -> log.warn("订单处理中，跳过")
);

// LockEntity + 返回值
LockEntity entity = LockEntity.builder()
    .keyName("order:789")
    .waitTime(2000)
    .leaseTime(5000)
    .build();
Result<String> result = lockManager.tryLock(entity,
    () -> Result.success(doProcess()),
    () -> Result.fail("BUSY", "操作繁忙")
);
```

---

## 注解方式（两个后端通用）

`@YeepayLock` 注解由 `YeepayLockAspect` 处理，自动完成加锁 → 执行 → 解锁流程。

**注解属性：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `name` | String | `""` | 锁名称前缀 |
| `lockType` | `LockType` | `REENTRANT` | 锁类型。Jedis 仅支持 REENTRANT |
| `waitTime` | long | `3000` | 最大等待时间（毫秒） |
| `leaseTime` | long | `3000` | 锁持有时间（毫秒） |
| `keys` | String[] | `{}` | SpEL 表达式，动态锁 key |
| `keyStrategy` | Class | 默认策略 | key 生成策略 |
| `failStrategy` | Class | 默认策略 | 获取锁失败时的处理策略 |
| `releaseTimeoutStrategy` | Class | 默认策略 | 解锁失败时的处理策略 |
| `autoRelease` | boolean | `true` | 是否自动释放锁 |

**锁 Key 规则：** `keys` 为空 → 方法级锁；`keys` 不为空 → 参数级锁，格式 `yeepay-lock{name}#{SpEL值1}.{SpEL值2}...`

**基本用法：**

```java
// 方法级锁 — 所有调用串行
@YeepayLock(name = "syncOrder")
public void syncOrder() { ... }

// 参数级锁 — 不同订单并发，相同订单串行
@YeepayLock(name = "pay", keys = {"#orderId"}, waitTime = 5000, leaseTime = 10000)
public void pay(String orderId) { ... }

// 多参数组合
@YeepayLock(name = "transfer", keys = {"#from", "#to"}, leaseTime = 15000)
public void transfer(String from, String to) { ... }

// Redisson 公平锁
@YeepayLock(name = "seat", keys = {"#seatId"}, lockType = LockType.FAIR,
            waitTime = 10000, leaseTime = 30000)
public void bookSeat(String seatId) { ... }
```

### 自定义策略

**失败策略 — 获取锁超时时触发（默认抛异常）：**

```java
@Component
public class ReturnErrorCodeStrategy implements LockFailureStrategy {
    @Override
    public Object execute(LockEntity entity, ProceedingJoinPoint point) {
        MethodSignature sig = (MethodSignature) point.getSignature();
        Class<?> returnType = sig.getReturnType();
        if (returnType == boolean.class) return false;
        if (returnType == int.class) return 0;
        return null;
    }
}
```

**Key 策略 — 自定义 key 生成逻辑：**

```java
@Component
public class TenantAwareKeyStrategy implements LockKeyStrategy {
    @Override
    public String buildKey(JoinPoint joinPoint, String[] keys) {
        String tenantId = ThreadContext.get("tenantId");
        MethodSignature sig = (MethodSignature) joinPoint.getSignature();
        String method = sig.getDeclaringTypeName() + "." + sig.getName();
        if (keys.length == 0) return tenantId + ":" + method;
        return tenantId + ":" + method + ":" + String.join(".", keys);
    }
}
```

**释放超时策略 — 锁提前过期时触发（默认抛异常）：**

```java
@Component
public class WarnOnlyReleaseStrategy implements ReleaseTimeoutStrategy {
    @Override
    public void execute(LockEntity lockEntity) {
        log.warn("[LOCK_EXPIRED] key={}, leaseTime={}ms", lockEntity.getKeyName(), lockEntity.getLeaseTime());
    }
}
```

---

## Jedis 分布式锁

基于 Redis `SET NX PX` + Lua 解锁脚本，轻量互斥锁。仅支持 `REENTRANT`（不可重入）。

### 1. 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-lock-jedis</artifactId>
</dependency>
```

### 2. 配置

```yaml
yeepay:
  framework:
    # ──────────────── Redis 连接配置 ────────────────
    infra:
      jedis:
        # Redis 认证密码（可选，无密码则不配）
        password: your-password
        # 使用的数据库索引，默认 0
        database: 0
        # 连接 / Socket 超时（毫秒），默认 2000
        timeout: 2000

        # 连接池配置
        pool:
          max-total: 8            # 最大连接数，默认 8
          max-idle: 8             # 最大空闲连接数，默认 8
          min-idle: 0             # 最小空闲连接数，默认 0
          max-wait: 2000          # 获取连接最大等待时间（毫秒），默认 2000
          test-on-borrow: false   # 借出时是否检查连接可用性
          test-on-return: false   # 归还时是否检查连接可用性
          test-while-idle: false  # 空闲时是否检查连接可用性
          block-when-exhausted: true  # 池耗尽时是否阻塞等待

        # ─── 单机模式（与 sentinel / cluster 互斥，三选一）───
        single:
          host: 127.0.0.1         # Redis 主机地址，默认 localhost
          port: 6379              # Redis 端口，默认 6379

        # ─── 哨兵模式（与 single / cluster 互斥）───
        # sentinel:
        #   master-name: mymaster           # 哨兵监控的主节点名称（必填）
        #   nodes:                           # 哨兵节点列表
        #     - 127.0.0.1:26379
        #     - 127.0.0.1:26380
        #     - 127.0.0.1:26381
        #   sentinel-password: sentinel-pass # 哨兵密码（可选）

        # ─── 集群模式（与 single / sentinel 互斥）───
        # cluster:
        #   nodes:                           # 集群节点列表
        #     - 127.0.0.1:7000
        #     - 127.0.0.1:7001
        #     - 127.0.0.1:7002
        #   max-attempts: 5                 # 命令最大重试次数，默认 5

    # ──────────────── 锁配置 ────────────────
    lock:
      # 多后端共存时必填（jedis / redisson），单后端无需设置
      # type: jedis
      retry-interval: 50         # 获取锁失败后轮询间隔（毫秒），默认 50
```

### 3. 使用示例

```java
@Component
public class PaymentService {

    @Autowired
    private LockManager lockManager;

    // 编程方式
    public void pay(String orderId) {
        lockManager.tryLock("pay:" + orderId, 5000, 2000, LockType.REENTRANT,
            () -> doPay(orderId),
            () -> log.warn("订单 {} 处理中，跳过", orderId)
        );
    }

    // 注解方式
    @YeepayLock(name = "pay", keys = {"#orderId"}, waitTime = 3000, leaseTime = 5000)
    public void payWithAnnotation(String orderId) {
        doPay(orderId);
    }
}
```

**加锁原理：** `SET key UUID NX PX leaseTime`，解锁用 Lua 脚本校验 token 后删除，防止误解锁。

---

## Redisson 分布式锁

基于 Redisson `RLock` API，支持可重入、公平锁、读写锁、看门狗自动续期。功能全面，适合复杂锁场景。

### 1. 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-lock-redisson</artifactId>
</dependency>
```

### 2. 配置

```yaml
yeepay:
  framework:
    # ──────────────── Redis 连接配置 ────────────────
    infra:
      redisson:
        # Redisson 执行器线程数，默认 16
        threads: 16
        # Netty 工作线程数，默认 32
        netty-threads: 32
        # 编解码器类型，默认 KRYO5（可选：KRYO5 / JACKSON / SNAPPY 等）
        codec: KRYO5
        # Redis 协议版本，默认 RESP2
        protocol: RESP2

        # ─── 分布式锁相关配置 ───
        lock:
          watchdog-timeout: 30s         # 看门狗超时，默认 30 秒
          fair-wait-timeout: 5m         # 公平锁默认等待超时，默认 5 分钟
          check-synced-slaves: true     # 获取锁时是否校验从节点同步，默认 true
          slaves-sync-timeout: 1m       # 等待从节点同步超时，默认 1 分钟

        # ─── 单机模式（与 sentinel / cluster 互斥，三选一）───
        single:
          address: redis://127.0.0.1:6379  # Redis 地址（必填）
          password: your-password           # Redis 密码（可选）
          database: 0                       # 数据库索引，默认 0
          client-name: my-client            # 客户端名称（可选）
          connection:
            idle-timeout: 10s               # 空闲连接超时，默认 10 秒
            connect-timeout: 500ms          # 连接超时，默认 500 毫秒
            timeout: 100ms                  # 命令响应超时，默认 100 毫秒
            retry-attempts: 3               # 命令重试次数，默认 3
            ping-interval: 5s               # 心跳间隔，默认 5 秒
          pool:
            minimum-idle-size: 24           # 最小空闲连接数，默认 24
            pool-size: 64                   # 最大连接池大小，默认 64
            reconnection-interval: 3s       # 失败重连间隔，默认 3 秒
          subscription-pool:
            minimum-idle-size: 1            # 订阅连接最小空闲数，默认 1
            pool-size: 50                   # 订阅连接池大小，默认 50
            reconnection-interval: 3s       # 失败重连间隔，默认 3 秒

        # ─── 哨兵模式（与 single / cluster 互斥）───
        # sentinel:
        #   master-name: mymaster                    # 哨兵监控的主节点名称（必填）
        #   sentinel-addresses:                       # 哨兵节点地址列表
        #     - redis://127.0.0.1:26379
        #     - redis://127.0.0.1:26380
        #     - redis://127.0.0.1:26381
        #   sentinel-username: sentinel-user          # 哨兵用户名（可选）
        #   sentinel-password: sentinel-pass          # 哨兵密码（可选）
        #   password: master-pass                     # Redis 主节点密码（可选）
        #   database: 0                               # 数据库索引
        #   read-write-mode:
        #     read-mode: SLAVE           # 读模式：SLAVE / MASTER / MASTER_SLAVE
        #     subscription-mode: MASTER  # 订阅模式：MASTER / SLAVE
        #   master-pool:                 # 主节点连接池（同 single.pool）
        #     minimum-idle-size: 24
        #     pool-size: 64
        #   slave-pool:                  # 从节点连接池（同 single.pool）
        #     minimum-idle-size: 24
        #     pool-size: 64

        # ─── 集群模式（与 single / sentinel 互斥）───
        # cluster:
        #   node-addresses:                           # 集群节点地址列表
        #     - redis://127.0.0.1:7000
        #     - redis://127.0.0.1:7001
        #     - redis://127.0.0.1:7002
        #   password: cluster-pass                    # Redis 密码（可选）
        #   check-slots-coverage: true                # 启动时检查 slot 覆盖，默认 true
        #   scan-interval: 1s                         # 集群拓扑扫描间隔，默认 1 秒
        #   read-write-mode:
        #     read-mode: SLAVE           # 读模式：SLAVE / MASTER / MASTER_SLAVE
        #     subscription-mode: MASTER  # 订阅模式：MASTER / SLAVE
        #   master-pool:
        #     minimum-idle-size: 24
        #     pool-size: 64
        #   slave-pool:
        #     minimum-idle-size: 24
        #     pool-size: 64

    # ──────────────── 锁配置 ────────────────
    lock:
      # 多后端共存时必填（jedis / redisson），单后端无需设置
      # type: redisson
```

### 3. 使用示例

```java
@Component
public class PaymentService {

    @Autowired
    private LockManager lockManager;

    // 编程方式 — 公平锁
    public void bookSeat(String seatId) {
        LockEntity entity = LockEntity.builder()
            .keyName("seat:" + seatId)
            .type(LockType.FAIR)
            .waitTime(10000)
            .leaseTime(30000)
            .build();
        lockManager.tryLock(entity,
            () -> doBook(seatId),
            () -> log.warn("座位 {} 已被锁定", seatId)
        );
    }

    // 编程方式 — 读写锁
    public String readConfig(String key) {
        LockEntity entity = LockEntity.builder()
            .keyName("config:" + key)
            .type(LockType.READ)
            .build();
        return lockManager.tryLock(entity,
            () -> queryFromDB(key),
            () -> "BUSY"
        );
    }

    // 注解方式 — 公平锁
    @YeepayLock(name = "seat", keys = {"#seatId"}, lockType = LockType.FAIR,
                waitTime = 10000, leaseTime = 30000)
    public void bookSeatWithAnnotation(String seatId) { ... }

    // 注解方式 — 写锁
    @YeepayLock(name = "config", keys = {"#key"}, lockType = LockType.WRITE,
                waitTime = 3000, leaseTime = 5000)
    public void updateConfig(String key, String value) { ... }
}
```

**加锁原理：** 根据 LockType 获取对应 Redisson 锁对象（`getLock` / `getFairLock` / `getReadWriteLock`），通过 `tryLock(waitTime, leaseTime, TimeUnit)` 加锁。看门狗在未设 `leaseTime` 时自动续期。

---

## 锁专属配置

配置前缀：`yeepay.framework.lock`

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | boolean | `true` | 是否启用。`false` 关闭所有锁功能 |
| `type` | String | — | `jedis` / `redisson`。多后端共存时必须指定 |
| `retry-interval` | long | `50` | 轮询间隔（毫秒），仅 Jedis 后端使用 |

**多后端共存：** 同时引入 Jedis 和 Redisson starter 时，必须通过 `type` 指定使用哪个，否则启动报 duplicate bean 错误。

---

## Jedis vs Redisson 对比

| 维度 | Jedis | Redisson |
|------|-------|----------|
| 加锁方式 | `SET NX PX` + Lua 解锁 | Redisson `RLock` API |
| 可重入 | 不支持（每次新 UUID） | 支持（hash + 计数器） |
| 公平锁 | 不支持 | 支持 |
| 读写锁 | 不支持 | 支持 |
| 自动续期 | 不支持 | 支持（看门狗） |
| 重试机制 | Thread.sleep 轮询 | pub/sub 通知 |
| 性能 | 命令级，轻量 | 功能丰富，稍重 |
| 适用场景 | 简单互斥锁、短期锁 | 复杂锁语义、可重入需求 |

---

## 模块结构

```
lock/
├── lock-api/              # SPI 接口 + 公共模型
├── lock-jedis/            # Jedis SETNX 实现
└── lock-redission/        # Redisson RLock 实现

springboot-starter/springboot-starter-lock/
├── springboot-starter-lock-base/      # 公共自动配置、@YeepayLock 注解、切面、策略
├── springboot-starter-lock-jedis/     # Jedis 后端自动配置
└── springboot-starter-lock-redisson/  # Redisson 后端自动配置
```

---

## 注意事项

1. **leaseTime 要大于业务执行时间：** 设置过短导致锁提前释放，其他线程可能同时获取锁；设置过长则在服务宕机时锁长时间无法自动释放。

2. **避免锁粒度过大：** 锁 key 尽量精确到具体资源（如 `order:12345`），不带参数的方法级锁会导致不必要的排队。

3. **SpEL 参数名：** 使用 `keys = {"#orderId"}` 需要编译时保留参数名。框架 Maven 配置已默认开启 `-parameters`。

4. **注解走 tryLock：** `YeepayLockAspect` 内部调用的是 `tryLock()`，超时后触发 `LockFailureStrategy`，不会无限阻塞。

5. **Jedis 不可重入：** 同一线程对同一 key 多次加锁会失败（每次新 UUID）。有重入需求选 Redisson。

6. **Jedis lock() 无限阻塞：** `lock()` 方法无超时，高并发下可能大量线程阻塞。建议优先用 `tryLock()` 并设置合理 `waitTime`。

7. **Redisson 看门狗：** 不设 `leaseTime` 时看门狗自动续期；明确设置 `leaseTime` 后看门狗不生效。

8. **autoRelease 默认 true：** 方法正常返回或抛异常都会自动释放锁。

## 完整示例

参见 `examples/examples-lock/`，包含 Jedis 和 Redisson 两种后端的完整配置和代码。
