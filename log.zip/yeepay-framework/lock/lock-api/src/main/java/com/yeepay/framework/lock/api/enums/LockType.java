package com.yeepay.framework.lock.api.enums;

/**
 * The enum Lock type.
 */
public enum LockType {

    /**
     * Reentrant lock type.
     */
    REENTRANT,

    /**
     * Fair lock type.
     */
    FAIR,

    /**
     * Read lock type.
     */
    READ,

    /**
     * Write lock type.
     */
    WRITE;
}
