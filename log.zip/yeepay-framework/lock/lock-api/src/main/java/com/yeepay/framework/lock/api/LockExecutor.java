package com.yeepay.framework.lock.api;

import com.yeepay.framework.lock.api.entity.LockEntity;

/**
 * The interface Lock executor.
 *
 * @param <T> the type parameter
 */
public interface LockExecutor<T> {

    /**
     * Try lock .
     *
     * @param lockEntity the lock entity
     * @return the t
     */
    T tryLock(LockEntity lockEntity);

    /**
     * Lock.
     *
     * @param lockEntity the lock entity
     * @return the t
     */
    T lock(LockEntity lockEntity);

    /**
     * Unlock boolean.
     *
     * @param lock the lock
     * @return the boolean
     */
    boolean unlock(T lock);
}
