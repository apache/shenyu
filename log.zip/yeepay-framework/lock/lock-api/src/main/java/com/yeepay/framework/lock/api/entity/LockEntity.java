package com.yeepay.framework.lock.api.entity;

import com.yeepay.framework.lock.api.enums.LockType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 分布式锁参数实体.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LockEntity {

    /** 锁的 key 名称. */
    private String keyName;

    /** 锁类型，默认可重入锁. */
    @Builder.Default
    private LockType type = LockType.REENTRANT;

    /** 等待获取锁的最长时间（毫秒），默认 3000ms. */
    @Builder.Default
    private long waitTime = 3000L;

    /** 锁的持有时间（毫秒），默认 3000ms. */
    @Builder.Default
    private long leaseTime = 3000L;

    /** 任务完成后是否自动释放锁，默认 true. */
    @Builder.Default
    private boolean autoRelease = true;
}
