package com.yeepay.framework.lock.api;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.enums.LockType;
import java.util.Objects;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;

/**
 * 分布式锁管理器.
 *
 * <p>封装 {@link LockExecutor} 的底层实现细节，提供面向业务的加锁 API。
 * 调用方无需感知锁句柄的具体类型，直接传入业务任务（{@link Runnable} 或 {@link Supplier}）即可。
 *
 * <p>支持两种加锁语义：
 * <ul>
 *   <li>{@code lock}：阻塞直到获取到锁后执行任务；</li>
 *   <li>{@code tryLock}：在指定等待时间内尝试获取锁，获取失败则执行失败回调。</li>
 * </ul>
 */
@RequiredArgsConstructor
public class LockManager {

    private final LockExecutor<?> lockExecutor;

    /**
     * 阻塞加锁后执行任务，使用默认锁参数.
     *
     * @param lockName 锁名称
     * @param task     获取锁成功后执行的任务
     */
    public void lock(String lockName, Runnable task) {
        LockEntity entity = LockEntity.builder().keyName(lockName).build();
        doLock(lockExecutor, entity, task, null);
    }

    /**
     * 阻塞加锁后执行任务，支持自定义锁参数.
     *
     * @param lockName  锁名称
     * @param leaseTime 锁持有时间（毫秒）
     * @param lockType  锁类型
     * @param task      获取锁成功后执行的任务
     * @param fail      获取锁失败后执行的回调，可为 null
     */
    public void lock(String lockName, int leaseTime, LockType lockType, Runnable task, Runnable fail) {
        LockEntity entity = LockEntity.builder()
                .keyName(lockName)
                .type(lockType)
                .leaseTime(leaseTime)
                .build();
        doLock(lockExecutor, entity, task, fail);
    }

    /**
     * 阻塞加锁后执行有返回值的任务.
     *
     * @param lockEntity 锁参数实体
     * @param task       获取锁成功后执行的任务
     * @param fail       获取锁失败后执行的回调，可为 null
     * @param <R>        任务返回值类型
     * @return 任务或失败回调的返回值；两者均为 null 时返回 null
     */
    public <R> R lock(LockEntity lockEntity, Supplier<R> task, Supplier<R> fail) {
        return doLock(lockExecutor, lockEntity, task, fail);
    }

    /**
     * 阻塞加锁后执行任务.
     *
     * @param lockEntity 锁参数实体
     * @param task       获取锁成功后执行的任务
     * @param fail       获取锁失败后执行的回调，可为 null
     */
    public void lock(LockEntity lockEntity, Runnable task, Runnable fail) {
        doLock(lockExecutor, lockEntity, task, fail);
    }

    /**
     * 尝试获取锁后执行任务，使用默认锁参数，获取失败时静默跳过.
     *
     * @param lockName 锁名称
     * @param task     获取锁成功后执行的任务
     */
    public void tryLock(String lockName, Runnable task) {
        LockEntity entity = LockEntity.builder().keyName(lockName).build();
        doTryLock(lockExecutor, entity, task, null);
    }

    /**
     * 尝试获取锁后执行任务，支持自定义锁参数.
     *
     * @param lockName  锁名称
     * @param leaseTime 锁持有时间（毫秒）
     * @param waitTime  等待获取锁的最长时间（毫秒）
     * @param lockType  锁类型
     * @param task      获取锁成功后执行的任务
     * @param fail      获取锁失败后执行的回调，可为 null
     */
    public void tryLock(String lockName, int leaseTime, int waitTime, LockType lockType, Runnable task, Runnable fail) {
        LockEntity entity = LockEntity.builder()
                .keyName(lockName)
                .type(lockType)
                .waitTime(waitTime)
                .leaseTime(leaseTime)
                .build();
        doTryLock(lockExecutor, entity, task, fail);
    }

    /**
     * 尝试获取锁后执行有返回值的任务，支持自定义锁参数.
     *
     * @param lockName  锁名称
     * @param leaseTime 锁持有时间（毫秒）
     * @param waitTime  等待获取锁的最长时间（毫秒）
     * @param lockType  锁类型
     * @param task      获取锁成功后执行的任务
     * @param fail      获取锁失败后执行的回调，可为 null
     * @param <R>       任务返回值类型
     * @return 任务或失败回调的返回值；两者均为 null 时返回 null
     */
    public <R> R tryLock(
            String lockName, int leaseTime, int waitTime, LockType lockType, Supplier<R> task, Supplier<R> fail) {
        LockEntity entity = LockEntity.builder()
                .keyName(lockName)
                .type(lockType)
                .waitTime(waitTime)
                .leaseTime(leaseTime)
                .build();
        return doTryLock(lockExecutor, entity, task, fail);
    }

    /**
     * 尝试获取锁后执行有返回值的任务.
     *
     * @param lockEntity 锁参数实体
     * @param task       获取锁成功后执行的任务
     * @param fail       获取锁失败后执行的回调，可为 null
     * @param <R>        任务返回值类型
     * @return 任务或失败回调的返回值；两者均为 null 时返回 null
     */
    public <R> R tryLock(LockEntity lockEntity, Supplier<R> task, Supplier<R> fail) {
        return doTryLock(lockExecutor, lockEntity, task, fail);
    }

    /**
     * 尝试获取锁后执行任务.
     *
     * @param lockEntity 锁参数实体
     * @param task       获取锁成功后执行的任务
     * @param fail       获取锁失败后执行的回调，可为 null
     */
    public void tryLock(LockEntity lockEntity, Runnable task, Runnable fail) {
        doTryLock(lockExecutor, lockEntity, task, fail);
    }

    private <T> void doLock(LockExecutor<T> executor, LockEntity entity, Runnable task, Runnable fail) {
        T lock = executor.lock(entity);
        if (Objects.nonNull(lock)) {
            try {
                task.run();
            } finally {
                executor.unlock(lock);
            }
        } else if (Objects.nonNull(fail)) {
            fail.run();
        }
    }

    private <T, R> R doLock(LockExecutor<T> executor, LockEntity entity, Supplier<R> task, Supplier<R> fail) {
        T lock = executor.lock(entity);
        if (Objects.nonNull(lock)) {
            try {
                return task.get();
            } finally {
                executor.unlock(lock);
            }
        } else if (Objects.nonNull(fail)) {
            return fail.get();
        }
        return null;
    }

    private <T> void doTryLock(LockExecutor<T> executor, LockEntity entity, Runnable task, Runnable fail) {
        T lock = executor.tryLock(entity);
        if (Objects.nonNull(lock)) {
            try {
                task.run();
            } finally {
                executor.unlock(lock);
            }
        } else if (Objects.nonNull(fail)) {
            fail.run();
        }
    }

    private <T, R> R doTryLock(LockExecutor<T> executor, LockEntity entity, Supplier<R> task, Supplier<R> fail) {
        T lock = executor.tryLock(entity);
        if (Objects.nonNull(lock)) {
            try {
                return task.get();
            } finally {
                executor.unlock(lock);
            }
        } else if (Objects.nonNull(fail)) {
            return fail.get();
        }
        return null;
    }
}
