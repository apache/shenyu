package com.yeepay.framework.lock.api.exeception;

/**
 * The type lock runtime exception.
 */
public class LockRuntimeException extends RuntimeException {

    /**
     * Instantiates a new lock runtime exception.
     *
     * @param e the e
     */
    public LockRuntimeException(final Throwable e) {
        super(e);
    }

    /**
     * Instantiates a new lock runtime exception.
     *
     * @param message the message
     */
    public LockRuntimeException(final String message) {
        super(message);
    }

    /**
     * Instantiates a new lock runtime exception.
     *
     * @param message   the message
     * @param throwable the throwable
     */
    public LockRuntimeException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
