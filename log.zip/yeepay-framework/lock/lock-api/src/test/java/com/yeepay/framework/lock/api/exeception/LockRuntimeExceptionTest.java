package com.yeepay.framework.lock.api.exeception;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class LockRuntimeExceptionTest {

    @Test
    void messageConstructor() {
        LockRuntimeException ex = new LockRuntimeException("error message");
        assertThat(ex).hasMessage("error message");
        assertThat(ex.getCause()).isNull();
    }

    @Test
    void throwableConstructor() {
        RuntimeException cause = new RuntimeException("root cause");
        LockRuntimeException ex = new LockRuntimeException(cause);
        assertThat(ex.getCause()).isSameAs(cause);
    }

    @Test
    void messageAndThrowableConstructor() {
        RuntimeException cause = new RuntimeException("c");
        LockRuntimeException ex = new LockRuntimeException("msg", cause);
        assertThat(ex).hasMessage("msg");
        assertThat(ex.getCause()).isSameAs(cause);
    }
}
