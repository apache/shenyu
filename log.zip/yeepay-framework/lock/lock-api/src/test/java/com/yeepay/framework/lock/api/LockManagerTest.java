package com.yeepay.framework.lock.api;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.enums.LockType;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LockManagerTest {

    @Mock
    private LockExecutor<Object> lockExecutor;

    private LockManager lockManager;
    private final Object mockLock = new Object();

    @BeforeEach
    void setUp() {
        lockManager = new LockManager(lockExecutor);
    }

    // ── lock(String, Runnable) ──────────────────────────────────────────────

    @Test
    void lock_byName_acquired_runsTaskAndUnlocks() {
        when(lockExecutor.lock(any())).thenReturn(mockLock);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.lock("key", () -> ran.set(true));
        assertThat(ran).isTrue();
        verify(lockExecutor).unlock(mockLock);
    }

    @Test
    void lock_byName_notAcquired_skipsSilently() {
        when(lockExecutor.lock(any())).thenReturn(null);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.lock("key", () -> ran.set(true));
        assertThat(ran).isFalse();
        verify(lockExecutor, never()).unlock(any());
    }

    @Test
    void lock_byName_taskThrows_unlockStillCalled() {
        when(lockExecutor.lock(any())).thenReturn(mockLock);
        assertThatThrownBy(() -> lockManager.lock("key", () -> {
                    throw new RuntimeException("boom");
                }))
                .isInstanceOf(RuntimeException.class);
        verify(lockExecutor).unlock(mockLock);
    }

    // ── lock(String, leaseTime, LockType, task, fail) ──────────────────────

    @Test
    void lock_withParams_acquired_runsTask() {
        when(lockExecutor.lock(any())).thenReturn(mockLock);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.lock("key", 1000, LockType.REENTRANT, () -> ran.set(true), null);
        assertThat(ran).isTrue();
        verify(lockExecutor).unlock(mockLock);
    }

    @Test
    void lock_withParams_notAcquired_runsFail() {
        when(lockExecutor.lock(any())).thenReturn(null);
        AtomicBoolean failed = new AtomicBoolean(false);
        lockManager.lock("key", 1000, LockType.REENTRANT, () -> {}, () -> failed.set(true));
        assertThat(failed).isTrue();
    }

    @Test
    void lock_withParams_notAcquiredNullFail_skipsSilently() {
        when(lockExecutor.lock(any())).thenReturn(null);
        lockManager.lock("key", 1000, LockType.REENTRANT, () -> {}, null);
        verify(lockExecutor, never()).unlock(any());
    }

    // ── lock(LockEntity, Supplier, Supplier) ───────────────────────────────

    @Test
    void lock_withSupplier_acquired_returnsTaskResult() {
        when(lockExecutor.lock(any())).thenReturn(mockLock);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        String result = lockManager.lock(entity, () -> "ok", () -> "fail");
        assertThat(result).isEqualTo("ok");
        verify(lockExecutor).unlock(mockLock);
    }

    @Test
    void lock_withSupplier_notAcquired_returnsFailResult() {
        when(lockExecutor.lock(any())).thenReturn(null);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        String result = lockManager.lock(entity, () -> "ok", () -> "fail");
        assertThat(result).isEqualTo("fail");
    }

    @Test
    void lock_withSupplier_notAcquiredNullFail_returnsNull() {
        when(lockExecutor.lock(any())).thenReturn(null);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        String result = lockManager.lock(entity, () -> "ok", null);
        assertThat(result).isNull();
    }

    @Test
    void lock_withSupplier_taskThrows_unlockStillCalled() {
        when(lockExecutor.lock(any())).thenReturn(mockLock);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        assertThatThrownBy(() -> lockManager.lock(
                        entity,
                        (java.util.function.Supplier<String>) () -> {
                            throw new RuntimeException("boom");
                        },
                        null))
                .isInstanceOf(RuntimeException.class);
        verify(lockExecutor).unlock(mockLock);
    }

    // ── lock(LockEntity, Runnable, Runnable) ───────────────────────────────

    @Test
    void lock_entityRunnable_acquired_runsTask() {
        when(lockExecutor.lock(any())).thenReturn(mockLock);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.lock(LockEntity.builder().keyName("key").build(), () -> ran.set(true), null);
        assertThat(ran).isTrue();
    }

    @Test
    void lock_entityRunnable_notAcquired_runsFail() {
        when(lockExecutor.lock(any())).thenReturn(null);
        AtomicBoolean failed = new AtomicBoolean(false);
        lockManager.lock(LockEntity.builder().keyName("key").build(), () -> {}, () -> failed.set(true));
        assertThat(failed).isTrue();
    }

    // ── tryLock(String, Runnable) ───────────────────────────────────────────

    @Test
    void tryLock_byName_acquired_runsTask() {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.tryLock("key", () -> ran.set(true));
        assertThat(ran).isTrue();
        verify(lockExecutor).unlock(mockLock);
    }

    @Test
    void tryLock_byName_notAcquired_skipsSilently() {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.tryLock("key", () -> ran.set(true));
        assertThat(ran).isFalse();
    }

    // ── tryLock(String, leaseTime, waitTime, LockType, task, fail) ─────────

    @Test
    void tryLock_withParams_acquired_runsTask() {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.tryLock("key", 1000, 500, LockType.REENTRANT, () -> ran.set(true), null);
        assertThat(ran).isTrue();
    }

    @Test
    void tryLock_withParams_notAcquired_runsFail() {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        AtomicBoolean failed = new AtomicBoolean(false);
        lockManager.tryLock("key", 1000, 500, LockType.REENTRANT, () -> {}, () -> failed.set(true));
        assertThat(failed).isTrue();
    }

    // ── tryLock(String, leaseTime, waitTime, LockType, Supplier, Supplier) ─

    @Test
    void tryLock_withSupplierParams_acquired_returnsResult() {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        String result = lockManager.tryLock("key", 1000, 500, LockType.REENTRANT, () -> "ok", () -> "fail");
        assertThat(result).isEqualTo("ok");
    }

    @Test
    void tryLock_withSupplierParams_notAcquired_returnsFailResult() {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        String result = lockManager.tryLock("key", 1000, 500, LockType.REENTRANT, () -> "ok", () -> "fail");
        assertThat(result).isEqualTo("fail");
    }

    @Test
    void tryLock_withSupplierParams_notAcquiredNullFail_returnsNull() {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        String result = lockManager.tryLock("key", 1000, 500, LockType.REENTRANT, () -> "ok", null);
        assertThat(result).isNull();
    }

    // ── tryLock(LockEntity, Supplier, Supplier) ────────────────────────────

    @Test
    void tryLock_entitySupplier_acquired_returnsResult() {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        String result = lockManager.tryLock(entity, () -> "ok", () -> "fail");
        assertThat(result).isEqualTo("ok");
    }

    @Test
    void tryLock_entitySupplier_notAcquiredNullFail_returnsNull() {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        String result = lockManager.tryLock(entity, () -> "ok", null);
        assertThat(result).isNull();
    }

    @Test
    void tryLock_entitySupplier_taskThrows_unlockStillCalled() {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        LockEntity entity = LockEntity.builder().keyName("key").build();
        assertThatThrownBy(() -> lockManager.tryLock(
                        entity,
                        (java.util.function.Supplier<String>) () -> {
                            throw new RuntimeException("boom");
                        },
                        null))
                .isInstanceOf(RuntimeException.class);
        verify(lockExecutor).unlock(mockLock);
    }

    // ── tryLock(LockEntity, Runnable, Runnable) ────────────────────────────

    @Test
    void tryLock_entityRunnable_acquired_runsTask() {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        AtomicBoolean ran = new AtomicBoolean(false);
        lockManager.tryLock(LockEntity.builder().keyName("key").build(), () -> ran.set(true), null);
        assertThat(ran).isTrue();
    }

    @Test
    void tryLock_entityRunnable_notAcquired_runsFail() {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        AtomicBoolean failed = new AtomicBoolean(false);
        lockManager.tryLock(LockEntity.builder().keyName("key").build(), () -> {}, () -> failed.set(true));
        assertThat(failed).isTrue();
    }
}
