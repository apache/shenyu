package com.yeepay.framework.lock.api.enums;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class LockTypeTest {

    @Test
    void values_containsAllFourTypes() {
        LockType[] values = LockType.values();
        assertThat(values).hasSize(4);
        assertThat(values).containsExactly(LockType.REENTRANT, LockType.FAIR, LockType.READ, LockType.WRITE);
    }

    @Test
    void valueOf_validNames_returnCorrectEnum() {
        assertThat(LockType.valueOf("REENTRANT")).isEqualTo(LockType.REENTRANT);
        assertThat(LockType.valueOf("FAIR")).isEqualTo(LockType.FAIR);
        assertThat(LockType.valueOf("READ")).isEqualTo(LockType.READ);
        assertThat(LockType.valueOf("WRITE")).isEqualTo(LockType.WRITE);
    }

    @Test
    void valueOf_invalidName_throwsIllegalArgument() {
        assertThatThrownBy(() -> LockType.valueOf("INVALID")).isInstanceOf(IllegalArgumentException.class);
    }
}
