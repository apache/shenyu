package com.yeepay.framework.lock.api.entity;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.lock.api.enums.LockType;
import org.junit.jupiter.api.Test;

class LockEntityTest {

    @Test
    void builder_defaults() {
        LockEntity e = LockEntity.builder().keyName("k").build();
        assertThat(e.getKeyName()).isEqualTo("k");
        assertThat(e.getType()).isEqualTo(LockType.REENTRANT);
        assertThat(e.getWaitTime()).isEqualTo(3000L);
        assertThat(e.getLeaseTime()).isEqualTo(3000L);
        assertThat(e.isAutoRelease()).isTrue();
    }

    @Test
    void builder_customValues() {
        LockEntity e = LockEntity.builder()
                .keyName("lock")
                .type(LockType.FAIR)
                .waitTime(100L)
                .leaseTime(200L)
                .autoRelease(false)
                .build();
        assertThat(e.getKeyName()).isEqualTo("lock");
        assertThat(e.getType()).isEqualTo(LockType.FAIR);
        assertThat(e.getWaitTime()).isEqualTo(100L);
        assertThat(e.getLeaseTime()).isEqualTo(200L);
        assertThat(e.isAutoRelease()).isFalse();
    }

    @Test
    void allArgsConstructor_setsAllFields() {
        LockEntity e = new LockEntity("k2", LockType.READ, 50L, 100L, false);
        assertThat(e.getKeyName()).isEqualTo("k2");
        assertThat(e.getType()).isEqualTo(LockType.READ);
        assertThat(e.getWaitTime()).isEqualTo(50L);
        assertThat(e.getLeaseTime()).isEqualTo(100L);
        assertThat(e.isAutoRelease()).isFalse();
    }

    @Test
    void noArgsConstructor_thenSetters() {
        LockEntity e = new LockEntity();
        e.setKeyName("k3");
        e.setType(LockType.WRITE);
        assertThat(e.getKeyName()).isEqualTo("k3");
        assertThat(e.getType()).isEqualTo(LockType.WRITE);
    }
}
