package com.yeepay.framework.lock.redission;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.enums.LockType;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.redisson.api.RFuture;
import org.redisson.api.RLock;
import org.redisson.api.RReadWriteLock;
import org.redisson.api.RedissonClient;

@ExtendWith(MockitoExtension.class)
class RedissonLockExecutorTest {

    @Mock
    private RedissonClient redissonClient;

    @Mock
    private RLock rLock;

    @Mock
    private RReadWriteLock rwLock;

    @Mock
    private RFuture<Void> rFuture;

    private RedissonLockExecutor executor;

    @BeforeEach
    void setUp() {
        executor = new RedissonLockExecutor(redissonClient);
    }

    private LockEntity entity(String key, LockType type) {
        return LockEntity.builder()
                .keyName(key)
                .type(type)
                .waitTime(1000L)
                .leaseTime(2000L)
                .build();
    }

    // ── tryLock ────────────────────────────────────────────────────────────

    @Test
    void tryLock_reentrant_acquired() throws InterruptedException {
        when(redissonClient.getLock("k")).thenReturn(rLock);
        when(rLock.tryLock(1000L, 2000L, TimeUnit.MILLISECONDS)).thenReturn(true);
        assertThat(executor.tryLock(entity("k", LockType.REENTRANT))).isNotNull();
    }

    @Test
    void tryLock_reentrant_notAcquired_returnsNull() throws InterruptedException {
        when(redissonClient.getLock("k")).thenReturn(rLock);
        when(rLock.tryLock(1000L, 2000L, TimeUnit.MILLISECONDS)).thenReturn(false);
        assertThat(executor.tryLock(entity("k", LockType.REENTRANT))).isNull();
    }

    @Test
    void tryLock_interrupted_returnsNull() throws InterruptedException {
        when(redissonClient.getLock("k")).thenReturn(rLock);
        when(rLock.tryLock(anyLong(), anyLong(), any())).thenThrow(new InterruptedException());
        assertThat(executor.tryLock(entity("k", LockType.REENTRANT))).isNull();
    }

    @Test
    void tryLock_fair_usesFairLock() throws InterruptedException {
        when(redissonClient.getFairLock("k")).thenReturn(rLock);
        when(rLock.tryLock(anyLong(), anyLong(), any())).thenReturn(true);
        executor.tryLock(entity("k", LockType.FAIR));
        verify(redissonClient).getFairLock("k");
    }

    @Test
    void tryLock_read_usesReadLock() throws InterruptedException {
        when(redissonClient.getReadWriteLock("k")).thenReturn(rwLock);
        when(rwLock.readLock()).thenReturn(rLock);
        when(rLock.tryLock(anyLong(), anyLong(), any())).thenReturn(true);
        executor.tryLock(entity("k", LockType.READ));
        verify(redissonClient).getReadWriteLock("k");
        verify(rwLock).readLock();
    }

    @Test
    void tryLock_write_usesWriteLock() throws InterruptedException {
        when(redissonClient.getReadWriteLock("k")).thenReturn(rwLock);
        when(rwLock.writeLock()).thenReturn(rLock);
        when(rLock.tryLock(anyLong(), anyLong(), any())).thenReturn(true);
        executor.tryLock(entity("k", LockType.WRITE));
        verify(rwLock).writeLock();
    }

    // ── lock ───────────────────────────────────────────────────────────────

    @Test
    void lock_success_returnsLock() {
        when(redissonClient.getLock("k")).thenReturn(rLock);
        doNothing().when(rLock).lock(anyLong(), any(TimeUnit.class));
        assertThat(executor.lock(entity("k", LockType.REENTRANT))).isSameAs(rLock);
    }

    @Test
    void lock_exceptionThrown_returnsNull() {
        when(redissonClient.getLock("k")).thenReturn(rLock);
        doThrow(new RuntimeException("err")).when(rLock).lock(anyLong(), any(TimeUnit.class));
        assertThat(executor.lock(entity("k", LockType.REENTRANT))).isNull();
    }

    @Test
    void lock_fair_usesFairLock() {
        when(redissonClient.getFairLock("k")).thenReturn(rLock);
        doNothing().when(rLock).lock(anyLong(), any(TimeUnit.class));
        executor.lock(entity("k", LockType.FAIR));
        verify(redissonClient).getFairLock("k");
    }

    @Test
    void lock_read_usesReadLock() {
        when(redissonClient.getReadWriteLock("k")).thenReturn(rwLock);
        when(rwLock.readLock()).thenReturn(rLock);
        doNothing().when(rLock).lock(anyLong(), any(TimeUnit.class));
        executor.lock(entity("k", LockType.READ));
        verify(rwLock).readLock();
    }

    @Test
    void lock_write_usesWriteLock() {
        when(redissonClient.getReadWriteLock("k")).thenReturn(rwLock);
        when(rwLock.writeLock()).thenReturn(rLock);
        doNothing().when(rLock).lock(anyLong(), any(TimeUnit.class));
        executor.lock(entity("k", LockType.WRITE));
        verify(rwLock).writeLock();
    }

    // ── unlock ─────────────────────────────────────────────────────────────

    @Test
    void unlock_heldByCurrentThread_success() throws Exception {
        when(rLock.isHeldByCurrentThread()).thenReturn(true);
        when(rLock.unlockAsync()).thenReturn(rFuture);
        when(rFuture.get()).thenReturn(null);
        assertThat(executor.unlock(rLock)).isTrue();
    }

    @Test
    void unlock_notHeldByCurrentThread_returnsFalse() {
        when(rLock.isHeldByCurrentThread()).thenReturn(false);
        assertThat(executor.unlock(rLock)).isFalse();
    }

    @Test
    void unlock_executionException_returnsFalse() throws Exception {
        when(rLock.isHeldByCurrentThread()).thenReturn(true);
        when(rLock.unlockAsync()).thenReturn(rFuture);
        when(rFuture.get()).thenThrow(new ExecutionException("err", new RuntimeException()));
        assertThat(executor.unlock(rLock)).isFalse();
    }

    @Test
    void unlock_interruptedException_returnsFalse() throws Exception {
        when(rLock.isHeldByCurrentThread()).thenReturn(true);
        when(rLock.unlockAsync()).thenReturn(rFuture);
        when(rFuture.get()).thenThrow(new InterruptedException());
        assertThat(executor.unlock(rLock)).isFalse();
    }
}
