package com.yeepay.framework.lock.redission;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.enums.LockType;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;

/**
 * The type Redisson lock executor.
 */
@RequiredArgsConstructor
@Slf4j
public class RedissonLockExecutor implements LockExecutor<RLock> {

    private final RedissonClient redissonClient;

    @Override
    public RLock tryLock(final LockEntity lockEntity) {
        try {
            RLock lock = getLock(lockEntity);
            boolean acquired = lock.tryLock(lockEntity.getWaitTime(), lockEntity.getLeaseTime(), TimeUnit.MILLISECONDS);
            if (acquired) {
                return lock;
            } else {
                return null;
            }
        } catch (InterruptedException e) {
            log.error("try lock error", e);
            return null;
        }
    }

    @Override
    public RLock lock(final LockEntity lockEntity) {
        try {
            RLock lock = getLock(lockEntity);
            lock.lock(lockEntity.getLeaseTime(), TimeUnit.MILLISECONDS);
            return lock;
        } catch (Exception e) {
            log.error("try lock error", e);
            return null;
        }
    }

    @Override
    public boolean unlock(final RLock lock) {
        if (lock.isHeldByCurrentThread()) {
            try {
                lock.unlockAsync().get();
                return true;
            } catch (ExecutionException | InterruptedException e) {
                return false;
            }
        }
        return false;
    }

    private RLock getLock(final LockEntity lockEntity) {
        LockType type = lockEntity.getType();
        switch (type) {
            case FAIR:
                return redissonClient.getFairLock(lockEntity.getKeyName());
            case READ:
                return redissonClient.getReadWriteLock(lockEntity.getKeyName()).readLock();
            case WRITE:
                return redissonClient.getReadWriteLock(lockEntity.getKeyName()).writeLock();
            default:
                return redissonClient.getLock(lockEntity.getKeyName());
        }
    }
}
