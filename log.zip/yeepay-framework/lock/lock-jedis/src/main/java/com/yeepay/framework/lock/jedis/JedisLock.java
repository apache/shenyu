package com.yeepay.framework.lock.jedis;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Jedis 分布式锁句柄，持有锁的 key 与唯一归属令牌（UUID）.
 *
 * <p>令牌用于在解锁时原子性地验证当前线程是锁的持有者，防止误删他人持有的锁。
 */
@Getter
@RequiredArgsConstructor
public class JedisLock {

    /** Redis key. */
    private final String key;

    /** 加锁时写入 Redis 的唯一令牌，用于解锁校验. */
    private final String token;
}
