package com.yeepay.framework.lock.jedis;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.enums.LockType;
import com.yeepay.framework.lock.api.exeception.LockRuntimeException;
import java.util.Collections;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.params.SetParams;

/**
 * 基于 Jedis SETNX 的分布式锁执行器.
 *
 * <p>加锁使用 {@code SET key token NX PX leaseTime} 原子命令；
 * 解锁使用 Lua 脚本原子性地校验令牌后再删除，防止误解锁。
 *
 * <p><b>限制：</b>仅支持 {@link LockType#REENTRANT} 类型（互斥锁），
 * 不支持公平锁、读写锁。传入其他类型将抛出 {@link LockRuntimeException}。
 */
@Slf4j
@RequiredArgsConstructor
public class JedisLockExecutor implements LockExecutor<JedisLock> {

    /** 解锁 Lua 脚本：仅当 token 匹配时才删除 key，保证原子性. */
    private static final String UNLOCK_SCRIPT =
            "if redis.call('get', KEYS[1]) == ARGV[1] then " + "    return redis.call('del', KEYS[1]) "
                    + "else "
                    + "    return 0 "
                    + "end";

    private final UnifiedJedis jedisClient;

    /** 轮询重试间隔（毫秒），默认 50ms，可通过构造器覆盖. */
    private final long retryIntervalMs;

    /**
     * 在 {@code waitTime} 时间内不断尝试获取锁，超时返回 null.
     */
    @Override
    public JedisLock tryLock(final LockEntity lockEntity) {
        String key = lockEntity.getKeyName();
        String token = UUID.randomUUID().toString();
        long deadline = System.currentTimeMillis() + lockEntity.getWaitTime();
        do {
            if (setnx(key, token, lockEntity.getLeaseTime())) {
                return new JedisLock(key, token);
            }
            try {
                Thread.sleep(retryIntervalMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.warn("tryLock interrupted, key={}", key);
                return null;
            }
        } while (System.currentTimeMillis() < deadline);
        log.debug("tryLock timeout, key={}", key);
        return null;
    }

    /**
     * 阻塞直到获取锁为止.
     *
     * <p>锁到期后 Redis 自动释放，下一个等待线程可以抢锁.
     */
    @Override
    public JedisLock lock(final LockEntity lockEntity) {
        String key = lockEntity.getKeyName();
        String token = UUID.randomUUID().toString();
        while (true) {
            if (setnx(key, token, lockEntity.getLeaseTime())) {
                return new JedisLock(key, token);
            }
            try {
                Thread.sleep(retryIntervalMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.error("lock interrupted, key={}", key);
                return null;
            }
        }
    }

    /**
     * 释放锁.
     *
     * <p>通过 Lua 脚本校验令牌，仅持有者才能成功解锁.
     *
     * @return true 解锁成功；false 令牌不匹配（锁已过期或被其他线程持有）
     */
    @Override
    public boolean unlock(final JedisLock lock) {
        try {
            Object result = jedisClient.eval(
                    UNLOCK_SCRIPT,
                    Collections.singletonList(lock.getKey()),
                    Collections.singletonList(lock.getToken()));
            return Long.valueOf(1L).equals(result);
        } catch (Exception e) {
            log.error("unlock error, key={}", lock.getKey(), e);
            return false;
        }
    }

    private boolean setnx(final String key, final String token, final long leaseTimeMs) {
        try {
            String result =
                    jedisClient.set(key, token, SetParams.setParams().nx().px(leaseTimeMs));
            return "OK".equals(result);
        } catch (Exception e) {
            log.error("setnx error, key={}", key, e);
            return false;
        }
    }
}
