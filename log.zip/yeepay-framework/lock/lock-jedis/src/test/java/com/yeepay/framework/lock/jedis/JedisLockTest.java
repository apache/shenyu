package com.yeepay.framework.lock.jedis;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class JedisLockTest {

    @Test
    void constructor_setsKeyAndToken() {
        JedisLock lock = new JedisLock("myKey", "myToken");
        assertThat(lock.getKey()).isEqualTo("myKey");
        assertThat(lock.getToken()).isEqualTo("myToken");
    }

    @Test
    void constructor_emptyStrings() {
        JedisLock lock = new JedisLock("", "");
        assertThat(lock.getKey()).isEmpty();
        assertThat(lock.getToken()).isEmpty();
    }
}
