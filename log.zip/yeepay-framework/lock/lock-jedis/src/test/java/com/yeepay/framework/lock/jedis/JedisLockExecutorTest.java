package com.yeepay.framework.lock.jedis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.yeepay.framework.lock.api.entity.LockEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.params.SetParams;

@ExtendWith(MockitoExtension.class)
class JedisLockExecutorTest {

    @Mock
    private UnifiedJedis jedisClient;

    private JedisLockExecutor executor;

    @BeforeEach
    void setUp() {
        executor = new JedisLockExecutor(jedisClient, 10L);
    }

    private LockEntity entity(String key, long waitMs) {
        return LockEntity.builder()
                .keyName(key)
                .leaseTime(1000L)
                .waitTime(waitMs)
                .build();
    }

    // ── tryLock ────────────────────────────────────────────────────────────

    @Test
    void tryLock_immediateSuccess_returnsLock() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class))).thenReturn("OK");
        JedisLock lock = executor.tryLock(entity("k", 500L));
        assertThat(lock).isNotNull();
        assertThat(lock.getKey()).isEqualTo("k");
        assertThat(lock.getToken()).isNotBlank();
    }

    @Test
    void tryLock_timeoutExceeded_returnsNull() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class))).thenReturn(null);
        JedisLock lock = executor.tryLock(entity("k", 0L));
        assertThat(lock).isNull();
    }

    @Test
    void tryLock_setnxThrowsException_returnsNull() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class)))
                .thenThrow(new RuntimeException("redis error"));
        JedisLock lock = executor.tryLock(entity("k", 0L));
        assertThat(lock).isNull();
    }

    // ── lock ───────────────────────────────────────────────────────────────

    @Test
    void lock_immediateSuccess_returnsLock() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class))).thenReturn("OK");
        JedisLock lock = executor.lock(entity("k", 0L));
        assertThat(lock).isNotNull();
    }

    @Test
    void lock_successOnSecondAttempt_returnsLock() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class)))
                .thenReturn(null)
                .thenReturn("OK");
        JedisLock lock = executor.lock(entity("k", 0L));
        assertThat(lock).isNotNull();
    }

    @Test
    void tryLock_interrupted_returnsNull() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class))).thenReturn(null);
        Thread.currentThread().interrupt();
        JedisLock lock = executor.tryLock(entity("k", 5000L));
        assertThat(lock).isNull();
        assertThat(Thread.interrupted()).isTrue();
    }

    // ── lock ───────────────────────────────────────────────────────────────

    @Test
    void lock_interrupted_returnsNull() {
        when(jedisClient.set(anyString(), anyString(), any(SetParams.class))).thenReturn(null);
        Thread.currentThread().interrupt();
        JedisLock lock = executor.lock(entity("k", 0L));
        assertThat(lock).isNull();
        assertThat(Thread.interrupted()).isTrue();
    }

    // ── unlock ─────────────────────────────────────────────────────────────

    @Test
    void unlock_evalReturns1L_returnsTrue() {
        when(jedisClient.eval(anyString(), anyList(), anyList())).thenReturn(1L);
        assertThat(executor.unlock(new JedisLock("k", "t"))).isTrue();
    }

    @Test
    void unlock_evalReturns0L_returnsFalse() {
        when(jedisClient.eval(anyString(), anyList(), anyList())).thenReturn(0L);
        assertThat(executor.unlock(new JedisLock("k", "t"))).isFalse();
    }

    @Test
    void unlock_evalThrowsException_returnsFalse() {
        when(jedisClient.eval(anyString(), anyList(), anyList())).thenThrow(new RuntimeException("redis error"));
        assertThat(executor.unlock(new JedisLock("k", "t"))).isFalse();
    }

    @Test
    void unlock_evalReturnsNull_returnsFalse() {
        when(jedisClient.eval(anyString(), anyList(), anyList())).thenReturn(null);
        assertThat(executor.unlock(new JedisLock("k", "t"))).isFalse();
    }
}
