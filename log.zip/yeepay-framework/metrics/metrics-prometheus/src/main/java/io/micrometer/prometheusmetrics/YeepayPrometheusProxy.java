package io.micrometer.prometheusmetrics;

import com.yeepay.framework.metrics.api.StatsDClient;
import com.yeepay.framework.metrics.api.config.MetricsConfig;
import com.yeepay.framework.metrics.prometheus.entity.DoubleGauge;
import com.yeepay.framework.metrics.prometheus.entity.MeterContainer;
import com.yeepay.framework.metrics.prometheus.entity.MeterTags;
import com.yeepay.framework.metrics.prometheus.entity.ReportableMeter;
import io.micrometer.common.lang.Nullable;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.DistributionSummary;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.config.MeterFilter;
import io.micrometer.core.instrument.distribution.DistributionStatisticConfig;
import io.prometheus.metrics.config.PrometheusProperties;
import io.prometheus.metrics.config.PrometheusPropertiesLoader;
import io.prometheus.metrics.model.registry.PrometheusRegistry;
import io.prometheus.metrics.tracer.common.SpanContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.ToDoubleFunction;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Prometheus代理类，实现StatsD客户端接口.
 */
@Slf4j
public class YeepayPrometheusProxy implements StatsDClient {

    private final ConcurrentMap<String, MeterContainer> meters = new ConcurrentHashMap<>();

    private final YeepayMetricsReporter reporter;

    private final MetricsConfig config;

    @Nullable
    private final ExemplarSamplerFactory exemplarSamplerFactory;

    private final Clock clock;

    private final PrometheusMeterRegistry prometheusMeterRegistry;

    private final MeterFilter[] filters;

    private final String prefix;

    private final String suffix;

    private final Map<String, String> globalTags;

    public YeepayPrometheusProxy(
            PrometheusConfig prometheusConfig,
            Clock clock,
            @Nullable SpanContext spanContext,
            PrometheusMeterRegistry prometheusMeterRegistry,
            MetricsConfig config,
            PrometheusRegistry collectorRegistry,
            Map<String, String> globalTags,
            MeterFilter[] filters,
            String prefix) {
        this.config = config;
        this.clock = clock;
        PrometheusProperties prometheusProperties = Objects.nonNull(prometheusConfig.prometheusProperties())
                ? PrometheusPropertiesLoader.load(prometheusConfig.prometheusProperties())
                : PrometheusPropertiesLoader.load();
        this.exemplarSamplerFactory = Objects.nonNull(spanContext)
                ? new DefaultExemplarSamplerFactory(spanContext, prometheusProperties.getExemplarProperties())
                : null;
        this.prometheusMeterRegistry = prometheusMeterRegistry;
        this.filters = filters;
        this.reporter = new YeepayMetricsReporter(this.meters, config, prometheusConfig);
        this.globalTags = globalTags;
        if (StringUtils.isNotBlank(prefix)) {
            this.prefix = prefix + "_";
        } else {
            this.prefix = "";
        }
        String suffix = config.getSuffix();
        if (StringUtils.isNotBlank(suffix)) {
            this.suffix = suffix;
        } else {
            this.suffix = "";
        }
        collectorRegistry.register(this.reporter.getPrometheusCollector());
    }

    @Nullable
    private <M extends Meter> M registerMeterIfNecessary(
            String aspect, Class<M> meterClass, Meter.Type type, String... tags) {
        Meter m = getOrCreateMeter(aspect, type, tags);
        if (Objects.isNull(m)) {
            return null;
        }
        if (!meterClass.isInstance(m)) {
            log.error(
                    "There is already a registered meter of a different type ({} vs. {}) with the same name: {}",
                    m.getClass().getSimpleName(),
                    meterClass.getSimpleName(),
                    aspect);
            return null;
        }
        return meterClass.cast(m);
    }

    /**
     * get or create meter.
     * @param name meter name
     * @param type meter type
     * @param tags meter tags
     * @return Meter
     */
    @Nullable
    private Meter getOrCreateMeter(String name, Meter.Type type, String... tags) {
        MeterContainer meterContainer = meters.get(name);
        if (Objects.isNull(meterContainer)) {
            meterContainer = new MeterContainer(name, type);
            MeterContainer oldMeterContainer = meters.putIfAbsent(name, meterContainer);
            if (Objects.nonNull(oldMeterContainer)) {
                meterContainer = oldMeterContainer;
            }
        }
        if (meterContainer.getType() != type) {
            log.error(
                    "Prometheus requires that all meters with the same name have the same type. the name {} type is {}, new type is {}",
                    name,
                    meterContainer.getType(),
                    type);
            return null;
        }
        MeterTags meterTags = MeterTags.of(tags);
        ConcurrentMap<MeterTags, ReportableMeter<?>> subMap = meterContainer.getMeters();
        ReportableMeter<?> reportableMeter = subMap.get(meterTags);

        if (Objects.nonNull(reportableMeter)) {
            return reportableMeter.getMeter();
        }

        if (subMap.size() > config.getTagsLimit()) {
            // 为了避免内存无限占用，当 tag 值过多时，丢弃
            log.error("The tag count of `{}` meter reached limit, the limit is {}.", name, config.getTagsLimit());
            return null;
        }

        Meter meter = buildMeter(name, type, meterTags);
        reportableMeter = new ReportableMeter<>(meter);
        ReportableMeter<?> existing = subMap.putIfAbsent(meterTags, reportableMeter);
        if (Objects.nonNull(existing)) {
            return existing.getMeter();
        }
        return meter;
    }

    /**
     * 构建不同类型的度量实例.
     *
     * @param name      度量名称
     * @param type      meter type
     * @param meterTags 标签
     * @return meter instance
     * @see PrometheusMeterRegistry#newCounter(Meter.Id)
     * @see PrometheusMeterRegistry#newGauge(Meter.Id, Object, ToDoubleFunction)
     * @see PrometheusMeterRegistry#newDistributionSummary(Meter.Id, DistributionStatisticConfig, double)
     * @see MeterRegistry#summary(String, Iterable)
     */
    private Meter buildMeter(String name, Meter.Type type, MeterTags meterTags) {
        Meter.Id id = buildId(name, type, meterTags);
        switch (type) {
            case GAUGE:
                return new DoubleGauge(id);
            case COUNTER:
                return new PrometheusCounter(id, exemplarSamplerFactory);
            case DISTRIBUTION_SUMMARY:
                DistributionStatisticConfig.Builder distributionConfigBuilder = DistributionStatisticConfig.builder();
                DistributionStatisticConfig summaryConfig = distributionConfigBuilder.build();
                for (MeterFilter filter : filters) {
                    DistributionStatisticConfig filteredConfig = filter.configure(id, summaryConfig);
                    if (Objects.nonNull(filteredConfig)) {
                        summaryConfig = filteredConfig;
                    }
                }
                return new PrometheusDistributionSummary(
                        id,
                        this.clock,
                        summaryConfig.merge(prometheusMeterRegistry.defaultHistogramConfig()),
                        1.0,
                        this.exemplarSamplerFactory);
            default:
                throw new IllegalArgumentException("Unknown meter type " + type);
        }
    }

    private Meter.Id buildId(String name, Meter.Type type, MeterTags meterTags) {
        List<Tag> tagList =
                new ArrayList<>(globalTags.size() + meterTags.getSet().size());
        for (Map.Entry<String, String> entry : globalTags.entrySet()) {
            String key = entry.getKey();
            if (StringUtils.isEmpty(key)) {
                log.error("Global tag `{}` have a empty key", name);
                continue;
            }
            String value = entry.getValue();
            if (StringUtils.isEmpty(value)) {
                log.error("Global tag `{}` have a empty value for {}", key, name);
                continue;
            }
            tagList.add(Tag.of(key, value));
        }
        for (String label : meterTags.getSet()) {
            int i = label.indexOf(":");
            String tag;
            String value;
            if (i == -1) {
                tag = label;
                value = "-";
            } else {
                tag = label.substring(0, i);
                value = i == label.length() - 1 ? "-" : label.substring(i + 1);
            }
            if (StringUtils.isEmpty(tag)) {
                log.error("The tag `{}` have a empty key, for {}", label, name);
                continue;
            }
            if (StringUtils.isEmpty(value)) {
                log.error("The tag `{}` have a empty value, for {}", label, name);
                continue;
            }
            tagList.add(Tag.of(tag, value));
        }

        Tags tags = Tags.of(tagList);
        return new Meter.Id(this.prefix + name + suffix, tags, null, null, type);
    }

    @Override
    public void close() {
        reporter.close();
    }

    @Override
    public void count(String aspect, long delta, String... tags) {
        Counter counter = registerMeterIfNecessary(aspect, Counter.class, Meter.Type.COUNTER, tags);
        if (Objects.nonNull(counter)) {
            counter.increment(delta);
        }
    }

    @Override
    public void count(String aspect, long delta, double sampleRate, String... tags) {
        count(aspect, delta, tags);
    }

    @Override
    public void count(String aspect, double delta, String... tags) {
        count(aspect, (long) delta, tags);
    }

    @Override
    public void count(String aspect, double delta, double sampleRate, String... tags) {
        count(aspect, (long) delta, tags);
    }

    @Override
    public void incrementCounter(String aspect, String... tags) {
        count(aspect, 1, tags);
    }

    @Override
    public void incrementCounter(String aspect, double sampleRate, String... tags) {
        count(aspect, 1, tags);
    }

    @Override
    public void increment(String aspect, String... tags) {
        count(aspect, 1, tags);
    }

    @Override
    public void increment(String aspect, double sampleRate, String... tags) {
        count(aspect, 1, tags);
    }

    @Override
    public void decrementCounter(String aspect, String... tags) {
        count(aspect, -1L, tags);
    }

    @Override
    public void decrementCounter(String aspect, double sampleRate, String... tags) {
        count(aspect, -1L, tags);
    }

    @Override
    public void decrement(String aspect, String... tags) {
        count(aspect, -1L, tags);
    }

    @Override
    public void decrement(String aspect, double sampleRate, String... tags) {
        count(aspect, -1L, tags);
    }

    @Override
    public void recordGaugeValue(String aspect, double value, String... tags) {
        DoubleGauge gauge = registerMeterIfNecessary(aspect, DoubleGauge.class, Meter.Type.GAUGE, tags);
        if (Objects.nonNull(gauge)) {
            gauge.setValue(value);
        }
    }

    @Override
    public void recordGaugeValue(String aspect, double value, double sampleRate, String... tags) {
        recordGaugeValue(aspect, value, tags);
    }

    @Override
    public void recordGaugeValue(String aspect, long value, String... tags) {
        DoubleGauge gauge = registerMeterIfNecessary(aspect, DoubleGauge.class, Meter.Type.GAUGE, tags);
        if (Objects.nonNull(gauge)) {
            gauge.setValue(value);
        }
    }

    @Override
    public void recordGaugeValue(String aspect, long value, double sampleRate, String... tags) {
        recordGaugeValue(aspect, value, tags);
    }

    @Override
    public void gauge(String aspect, double value, String... tags) {
        recordGaugeValue(aspect, value, tags);
    }

    @Override
    public void gauge(String aspect, double value, double sampleRate, String... tags) {
        recordGaugeValue(aspect, value, tags);
    }

    @Override
    public void gauge(String aspect, long value, String... tags) {
        recordGaugeValue(aspect, value, tags);
    }

    @Override
    public void gauge(String aspect, long value, double sampleRate, String... tags) {
        recordGaugeValue(aspect, value, tags);
    }

    @Override
    public void recordExecutionTime(String aspect, long timeInMs, String... tags) {
        DistributionSummary distributionSummary =
                registerMeterIfNecessary(aspect, DistributionSummary.class, Meter.Type.DISTRIBUTION_SUMMARY, tags);
        if (Objects.nonNull(distributionSummary)) {
            distributionSummary.record(timeInMs);
        }
    }

    @Override
    public void recordExecutionTime(String aspect, long timeInMs, double sampleRate, String... tags) {
        recordExecutionTime(aspect, timeInMs, tags);
    }

    @Override
    public void time(String aspect, long value, String... tags) {
        recordExecutionTime(aspect, value, tags);
    }

    @Override
    public void time(String aspect, long value, double sampleRate, String... tags) {
        recordExecutionTime(aspect, value, tags);
    }

    @Override
    public void recordHistogramValue(String aspect, double value, String... tags) {
        recordHistogramValue(aspect, (long) value, tags);
    }

    @Override
    public void recordHistogramValue(String aspect, double value, double sampleRate, String... tags) {
        recordHistogramValue(aspect, (long) value, tags);
    }

    @Override
    public void recordHistogramValue(String aspect, long value, String... tags) {
        recordExecutionTime(aspect, value, tags);
    }

    @Override
    public void recordHistogramValue(String aspect, long value, double sampleRate, String... tags) {
        recordHistogramValue(aspect, value, tags);
    }

    @Override
    public void histogram(String aspect, double value, String... tags) {
        recordHistogramValue(aspect, (long) value, tags);
    }

    @Override
    public void histogram(String aspect, double value, double sampleRate, String... tags) {
        recordHistogramValue(aspect, (long) value, tags);
    }

    @Override
    public void histogram(String aspect, long value, String... tags) {
        recordHistogramValue(aspect, value, tags);
    }

    @Override
    public void histogram(String aspect, long value, double sampleRate, String... tags) {
        recordHistogramValue(aspect, value, tags);
    }
}
