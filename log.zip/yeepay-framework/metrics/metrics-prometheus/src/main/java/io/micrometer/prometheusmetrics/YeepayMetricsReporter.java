package io.micrometer.prometheusmetrics;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.metrics.api.config.MetricsConfig;
import com.yeepay.framework.metrics.prometheus.collector.YeepayPrometheusCollector;
import com.yeepay.framework.metrics.prometheus.entity.MeterContainer;
import com.yeepay.framework.metrics.prometheus.entity.MeterTags;
import com.yeepay.framework.metrics.prometheus.entity.ReportableMeter;
import com.yeepay.framework.metrics.prometheus.utils.PrometheusNameUtil;
import io.micrometer.common.lang.Nullable;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.distribution.CountAtBucket;
import io.micrometer.core.instrument.distribution.ValueAtPercentile;
import io.prometheus.metrics.model.snapshots.ClassicHistogramBuckets;
import io.prometheus.metrics.model.snapshots.Exemplars;
import io.prometheus.metrics.model.snapshots.GaugeSnapshot;
import io.prometheus.metrics.model.snapshots.HistogramSnapshot;
import io.prometheus.metrics.model.snapshots.InfoSnapshot;
import io.prometheus.metrics.model.snapshots.Labels;
import io.prometheus.metrics.model.snapshots.MetricMetadata;
import io.prometheus.metrics.model.snapshots.MetricSnapshot;
import io.prometheus.metrics.model.snapshots.MetricSnapshots;
import io.prometheus.metrics.model.snapshots.Quantile;
import io.prometheus.metrics.model.snapshots.Quantiles;
import io.prometheus.metrics.model.snapshots.SummarySnapshot;
import java.io.Closeable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * 指标报告器，负责收集和报告指标数据.
 */
@Slf4j
public class YeepayMetricsReporter implements Closeable {

    private final ConcurrentMap<String, MeterContainer> metrics;

    private final ScheduledExecutorService executor;

    private final MetricsConfig config;

    @Getter
    private final YeepayPrometheusCollector prometheusCollector;

    private final ConcurrentMap<String, YeepayMicrometerCollector> collectorMap = new ConcurrentHashMap<>();

    private final PrometheusConfig prometheusConfig;

    public YeepayMetricsReporter(
            ConcurrentMap<String, MeterContainer> metrics, MetricsConfig config, PrometheusConfig prometheusConfig) {
        this.metrics = metrics;
        this.config = config;
        this.executor = new ScheduledThreadPoolExecutor(
                config.getScheduleThreads(), YeepayThreadFactory.create("thx-metrics-reporter-"));
        this.prometheusCollector = new YeepayPrometheusCollector();
        this.prometheusConfig = prometheusConfig;

        Duration publishFrequency = config.getPublishFrequency();
        executor.scheduleWithFixedDelay(this::report, 1000, publishFrequency.toMillis(), TimeUnit.MILLISECONDS);
        log.info("init MetricsReporter successfully.");
    }

    protected List<Tag> getConventionTags(Meter.Id id) {
        return id.getConventionTags(PrometheusNameUtil.NAMING_CONVENTION);
    }

    protected String getConventionName(Meter.Id id) {
        return id.getConventionName(PrometheusNameUtil.NAMING_CONVENTION);
    }

    private void applyToCollector(Meter.Id id, Consumer<MicrometerCollector> consumer) {
        collectorMap.compute(getConventionName(id), (name, existingCollector) -> {
            if (Objects.isNull(existingCollector)) {
                YeepayMicrometerCollector micrometerCollector =
                        new YeepayMicrometerCollector(name, id, PrometheusNameUtil.NAMING_CONVENTION);
                consumer.accept(micrometerCollector);
                return micrometerCollector;
            }

            List<String> tagKeys =
                    getConventionTags(id).stream().map(Tag::getKey).toList();
            Meter.Id existingId = existingCollector.getId();
            if (existingId.getType() != id.getType()) {
                log.error("Prometheus requires that all meters with the same name have the same"
                        + " type. There is already an existing meter named '" + existingId.getName()
                        + "' containing tag keys ["
                        + getConventionTags(existingId).stream()
                                .map(Tag::getKey)
                                .collect(joining(", "))
                        + "]. The meter you are attempting to register" + " has keys ["
                        + getConventionTags(id).stream().map(Tag::getKey).collect(joining(", ")) + "].");
                return existingCollector;
            }
            if (existingCollector.getTagKeys().equals(tagKeys)) {
                consumer.accept(existingCollector);
                return existingCollector;
            }

            log.error("Prometheus requires that all meters with the same name have the same"
                    + " set of tag keys. There is already an existing meter named '" + id.getName()
                    + "' containing tag keys ["
                    + String.join(", ", collectorMap.get(getConventionName(id)).getTagKeys())
                    + "]. The meter you are attempting to register" + " has keys ["
                    + getConventionTags(id).stream().map(Tag::getKey).collect(joining(", ")) + "].");
            return existingCollector;
        });
    }

    private synchronized void report() {
        try {
            for (final Map.Entry<String, MeterContainer> entry : metrics.entrySet()) {
                MeterContainer meterContainer = entry.getValue();
                ConcurrentMap<MeterTags, ReportableMeter<?>> reportableMetrics = meterContainer.getMeters();
                Iterator<Map.Entry<MeterTags, ReportableMeter<?>>> iterator2 =
                        reportableMetrics.entrySet().iterator();
                while (iterator2.hasNext()) {
                    Map.Entry<MeterTags, ReportableMeter<?>> reportableMetricEntry = iterator2.next();
                    ReportableMeter<?> reportableMeter = reportableMetricEntry.getValue();

                    if (!reportableMeter.isReportable()) {
                        // 删除一段时间没有更新的数据
                        if (reportableMeter.isCanRemove(config.getKeepAlive().toMillis())) {
                            iterator2.remove();
                            if (reportableMeter.isRegistered()) {
                                onMeterRemoved(reportableMeter.getMeter());
                            }
                            continue;
                        }
                    }
                    if (!reportableMeter.isRegistered()) {
                        Meter meter = reportableMeter.getMeter();
                        if (meter instanceof Gauge gauge) {
                            registerGauge(gauge);
                        } else if (meter instanceof PrometheusCounter counter) {
                            reportCounter(counter);
                        } else if (meter instanceof PrometheusDistributionSummary summary) {
                            logDistributionSummary(summary);
                        } else {
                            log.error("unknown meter type: {}", meter.getClass().getName());
                        }
                        reportableMeter.registered();
                    }
                    reportableMeter.updateCount();
                }
            }
            List<MetricSnapshot> snapshots = new LinkedList<>();
            for (Map.Entry<String, YeepayMicrometerCollector> entry : collectorMap.entrySet()) {
                entry.getValue().collect().forEach(snapshots::add);
            }
            this.prometheusCollector.setMetricSnapshots(new MetricSnapshots(snapshots));
        } catch (Throwable throwable) {
            log.error("report error.", throwable);
        }
    }

    @Override
    public void close() {
        executor.shutdown();
    }

    private void logDistributionSummary(PrometheusDistributionSummary summary) {
        Meter.Id id = summary.getId();
        applyToCollector(id, collector -> {
            List<String> tagValues = tagValues(id);
            collector.add(tagValues, (conventionName, tagKeys) -> {
                Stream.Builder<MicrometerCollector.Family<?>> families = Stream.builder();

                final ValueAtPercentile[] percentileValues =
                        summary.takeSnapshot().percentileValues();
                final CountAtBucket[] histogramCounts = summary.histogramCounts();
                long count = summary.count();
                double sum = summary.totalAmount();

                if (histogramCounts.length == 0) {
                    Quantiles quantiles = Quantiles.EMPTY;
                    if (percentileValues.length > 0) {
                        List<Quantile> quantileList = new ArrayList<>();
                        for (ValueAtPercentile v : percentileValues) {
                            quantileList.add(new Quantile(v.percentile(), v.value()));
                        }
                        quantiles = Quantiles.of(quantileList);
                    }

                    Exemplars exemplars = summary.exemplars();
                    families.add(new MicrometerCollector.Family<>(
                            conventionName,
                            family -> new SummarySnapshot(family.metadata, family.dataPointSnapshots),
                            getMetadata(conventionName, id.getDescription()),
                            new SummarySnapshot.SummaryDataPointSnapshot(
                                    count, sum, quantiles, Labels.of(tagKeys, tagValues), exemplars, 0)));
                } else {
                    List<Double> buckets = new ArrayList<>();
                    List<Number> counts = new ArrayList<>();
                    buckets.add(histogramCounts[0].bucket());
                    counts.add(histogramCounts[0].count());
                    for (int i = 1; i < histogramCounts.length; i++) {
                        CountAtBucket countAtBucket = histogramCounts[i];
                        buckets.add(countAtBucket.bucket());
                        counts.add(countAtBucket.count() - histogramCounts[i - 1].count());
                    }
                    if (Double.isFinite(histogramCounts[histogramCounts.length - 1].bucket())) {
                        // ClassicHistogramBuckets is not cumulative
                        buckets.add(Double.POSITIVE_INFINITY);
                        double infCount = count - histogramCounts[histogramCounts.length - 1].count();
                        counts.add(infCount >= 0 ? infCount : 0);
                    }

                    Exemplars exemplars = summary.exemplars();
                    families.add(new MicrometerCollector.Family<>(
                            conventionName,
                            family -> new HistogramSnapshot(family.metadata, family.dataPointSnapshots),
                            getMetadata(conventionName, id.getDescription()),
                            new HistogramSnapshot.HistogramDataPointSnapshot(
                                    ClassicHistogramBuckets.of(buckets, counts),
                                    sum,
                                    Labels.of(tagKeys, tagValues),
                                    exemplars,
                                    0)));
                }

                families.add(new MicrometerCollector.Family<>(
                        conventionName + "_max",
                        family -> new GaugeSnapshot(family.metadata, family.dataPointSnapshots),
                        getMetadata(conventionName + "_max", id.getDescription()),
                        new GaugeSnapshot.GaugeDataPointSnapshot(summary.max(), Labels.of(tagKeys, tagValues), null)));

                return families.build();
            });
        });
    }

    private void registerGauge(Gauge meter) {
        Meter.Id id = meter.getId();
        applyToCollector(id, collector -> {
            List<String> tagValues = tagValues(id);
            if (id.getName().endsWith(".info")) {
                collector.add(
                        tagValues,
                        (conventionName, tagKeys) -> Stream.of(new MicrometerCollector.Family<>(
                                conventionName,
                                family -> new InfoSnapshot(family.metadata, family.dataPointSnapshots),
                                getMetadata(conventionName, id.getDescription()),
                                new InfoSnapshot.InfoDataPointSnapshot(Labels.of(tagKeys, tagValues)))));
            } else {
                collector.add(
                        tagValues,
                        (conventionName, tagKeys) -> Stream.of(new MicrometerCollector.Family<>(
                                conventionName,
                                family -> new GaugeSnapshot(family.metadata, family.dataPointSnapshots),
                                getMetadata(conventionName, id.getDescription()),
                                new GaugeSnapshot.GaugeDataPointSnapshot(
                                        meter.value(), Labels.of(tagKeys, tagValues), null))));
            }
        });
    }

    private void reportCounter(PrometheusCounter counter) {
        Meter.Id id = counter.getId();
        applyToCollector(id, collector -> {
            List<String> tagValues = tagValues(id);
            collector.add(
                    tagValues,
                    (conventionName, tagKeys) -> Stream.of(new MicrometerCollector.Family<>(
                            conventionName,
                            // CounterSnapshot 会加上 "_total" 后缀， 为了向下兼容，改用GaugeSnapshot
                            family -> new GaugeSnapshot(family.metadata, family.dataPointSnapshots),
                            getMetadata(conventionName, id.getDescription()),
                            new GaugeSnapshot.GaugeDataPointSnapshot(
                                    counter.count(), Labels.of(tagKeys, tagValues), counter.exemplar(), 0))));
        });
    }

    private static List<String> tagValues(Meter.Id id) {
        return stream(id.getTagsAsIterable().spliterator(), false)
                .map(Tag::getValue)
                .collect(toList());
    }

    private MetricMetadata getMetadata(String name, @Nullable String description) {
        String help = prometheusConfig.descriptions()
                ? Optional.ofNullable(description).orElse(" ")
                : " ";
        return new MetricMetadata(name, help, null);
    }

    private void onMeterRemoved(Meter meter) {
        MicrometerCollector collector = collectorMap.get(getConventionName(meter.getId()));
        if (Objects.nonNull(collector)) {
            collector.remove(tagValues(meter.getId()));
            if (collector.isEmpty()) {
                collectorMap.remove(getConventionName(meter.getId()));
            }
        }
    }
}
