package io.micrometer.prometheusmetrics;

import io.micrometer.core.instrument.Clock;
import io.prometheus.metrics.model.registry.PrometheusRegistry;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;

/**
 * Yee pay 定制的Prometheus指标注册表.
 */
@Slf4j
public class YeepayPrometheusMeterRegistry extends PrometheusMeterRegistry {

    public static final TimeUnit BASE_TIME_UNIT = TimeUnit.SECONDS;

    public YeepayPrometheusMeterRegistry(PrometheusConfig config, PrometheusRegistry registry, Clock clock) {
        super(config, registry, clock);
    }

    /**
     * 为了避免升级 spring boot 后，这块有变化，固定时间单位.
     *
     * @return 基础时间单位
     */
    @Override
    protected TimeUnit getBaseTimeUnit() {
        return BASE_TIME_UNIT;
    }
}
