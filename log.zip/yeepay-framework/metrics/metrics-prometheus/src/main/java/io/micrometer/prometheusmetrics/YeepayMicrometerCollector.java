package io.micrometer.prometheusmetrics;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.config.NamingConvention;
import lombok.Getter;

/**
 * 对 MicrometerCollector 增加 id, 用于判断类型.
 */
@Getter
public class YeepayMicrometerCollector extends MicrometerCollector {

    /**
     *  获取 Meter.Id.
     */
    private final Meter.Id id;

    /**
     * Instantiates a new Yeepay micrometer collector.
     *
     * @param name the name
     * @param id the id
     * @param convention the convention
     */
    public YeepayMicrometerCollector(String name, Meter.Id id, NamingConvention convention) {
        super(name, id, convention);
        this.id = id;
    }
}
