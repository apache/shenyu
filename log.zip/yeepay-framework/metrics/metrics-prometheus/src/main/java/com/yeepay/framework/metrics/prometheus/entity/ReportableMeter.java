package com.yeepay.framework.metrics.prometheus.entity;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Meter;
import io.micrometer.prometheusmetrics.PrometheusDistributionSummary;
import io.micrometer.prometheusmetrics.PrometheusTimer;
import lombok.Getter;
import lombok.Setter;

/**
 * 可报告的指标包装器.
 *
 * @param <T> 指标类型
 */
@Getter
@Setter
public class ReportableMeter<T extends Meter> {

    private final T meter;

    private double reportedCount;

    private long lastReportTime;

    private boolean registered;

    public ReportableMeter(T meter) {
        this.meter = meter;
    }

    /**
     * 检查是否可报告.
     *
     * @return 是否可报告
     */
    public boolean isReportable() {
        return getCount() > reportedCount;
    }

    private double getCount() {
        double count;
        if (meter instanceof PrometheusDistributionSummary) {
            PrometheusDistributionSummary summary = (PrometheusDistributionSummary) meter;
            count = summary.count();
        } else if (meter instanceof Counter) {
            Counter counter = (Counter) meter;
            count = counter.count();
        } else if (meter instanceof PrometheusTimer) {
            PrometheusTimer timer = (PrometheusTimer) meter;
            count = timer.count();
        } else {
            throw new IllegalStateException(meter.getClass().getName());
        }
        return count;
    }

    /**
     * 更新计数.
     */
    public void updateCount() {
        double count = getCount();
        if (count > reportedCount) {
            reportedCount = count;
            lastReportTime = System.currentTimeMillis();
        }
    }

    /**
     * 标记为已注册.
     */
    public void registered() {
        registered = true;
    }

    /**
     * 检查是否可以移除.
     *
     * @param diff 时间差值
     * @return 是否可以移除
     */
    public boolean isCanRemove(long diff) {
        return System.currentTimeMillis() - lastReportTime > diff;
    }
}
