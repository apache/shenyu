package com.yeepay.framework.metrics.prometheus.utils;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.config.NamingConvention;
import io.micrometer.prometheusmetrics.PrometheusNamingConvention;

/**
 * Prometheus名称工具类.
 */
public class PrometheusNameUtil {

    public static final NamingConvention NAMING_CONVENTION = new PrometheusNamingConvention() {
        @Override
        public String name(String name, Meter.Type type, String baseUnit) {
            return super.name(name, Meter.Type.GAUGE, null);
        }
    };

    /**
     * 转换为Prometheus名称.
     *
     * @param name 原始名称
     * @return Prometheus名称
     */
    public static String toPrometheusName(String name) {
        return NAMING_CONVENTION.name(name, Meter.Type.GAUGE, null);
    }

    /**
     * 转换为Prometheus标签.
     *
     * @param tag 原始标签
     * @return Prometheus标签
     */
    public static String toPrometheusTag(String tag) {
        return NAMING_CONVENTION.tagKey(tag);
    }
}
