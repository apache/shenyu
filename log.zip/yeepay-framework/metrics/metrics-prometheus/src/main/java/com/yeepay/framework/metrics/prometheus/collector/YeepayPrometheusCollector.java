package com.yeepay.framework.metrics.prometheus.collector;

import io.prometheus.metrics.model.registry.MultiCollector;
import io.prometheus.metrics.model.snapshots.MetricSnapshots;
import lombok.Setter;

/**
 * Yee pay Prometheus 收集器，实现多指标收集.
 */
@Setter
public class YeepayPrometheusCollector implements MultiCollector {

    private MetricSnapshots metricSnapshots = MetricSnapshots.builder().build();

    @Override
    public MetricSnapshots collect() {
        return metricSnapshots;
    }
}
