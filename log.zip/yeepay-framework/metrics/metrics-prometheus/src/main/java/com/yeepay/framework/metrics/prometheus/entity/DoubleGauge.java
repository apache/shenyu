package com.yeepay.framework.metrics.prometheus.entity;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Measurement;
import java.util.concurrent.atomic.DoubleAdder;

/**
 * 双精度浮点数计量器，同时实现了Gauge和Counter接口.
 */
public class DoubleGauge implements Gauge, Counter {

    private volatile double value;

    private final DoubleAdder counter = new DoubleAdder();

    private final Id id;

    public DoubleGauge(Id id) {
        this.id = id;
    }

    @Override
    public double value() {
        return value;
    }

    @Override
    public Iterable<Measurement> measure() {
        return Gauge.super.measure();
    }

    /**
     * 设置当前值.
     *
     * @param value 要设置的值
     */
    public void setValue(double value) {
        increment(1);
        this.value = value;
    }

    @Override
    public void increment() {
        Counter.super.increment();
    }

    @Override
    public void increment(double amount) {
        counter.add(amount);
    }

    @Override
    public double count() {
        return counter.longValue();
    }

    @Override
    public Id getId() {
        return this.id;
    }
}
