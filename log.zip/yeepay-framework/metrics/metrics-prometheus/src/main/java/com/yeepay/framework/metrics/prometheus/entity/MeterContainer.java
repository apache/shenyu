package com.yeepay.framework.metrics.prometheus.entity;

import io.micrometer.core.instrument.Meter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 指标容器，用于管理同一名称的多个指标实例.
 */
@Getter
@RequiredArgsConstructor
public class MeterContainer {

    private final String name;

    private final Meter.Type type;

    private ConcurrentMap<MeterTags, ReportableMeter<?>> meters = new ConcurrentHashMap<>();
}
