package com.yeepay.framework.metrics.prometheus.entity;

import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import lombok.Getter;

/**
 * 指标标签类，用于管理指标的标签信息.
 */
@Getter
public class MeterTags {

    private final String[] tags;

    private final Set<String> set;

    protected MeterTags(String... tags) {
        this.tags = tags;
        if (Objects.nonNull(tags) && tags.length > 0) {
            set = new HashSet<>(Math.max((int) (tags.length / .75f) + 1, 16));
            for (String tag : tags) {
                if (Objects.isNull(tag) || tag.isEmpty()) {
                    continue;
                }
                set.add(tag);
            }
        } else {
            set = Collections.emptySet();
        }
    }

    /**
     * 创建指标标签实例.
     *
     * @param args 标签参数
     * @return 指标标签实例
     */
    public static MeterTags of(String... args) {
        return new MeterTags(args);
    }

    /**
     * 检查标签是否为空.
     *
     * @return 是否为空
     */
    public boolean isEmpty() {
        return set.isEmpty();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (Objects.isNull(o) || this.getClass() != o.getClass()) {
            return false;
        }
        MeterTags meterTags1 = (MeterTags) o;
        if (set.size() != meterTags1.set.size()) {
            return false;
        }
        // tags 的值相同，但顺序不一样 java.util.AbstractSet.equals
        return Objects.equals(set, meterTags1.set);
    }

    @Override
    public int hashCode() {
        return set.hashCode();
    }

    @Override
    public String toString() {
        return set.toString();
    }
}
