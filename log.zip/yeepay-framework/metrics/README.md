# 指标上报（Metrics）

## 目录

1. [概述](#1-概述)
2. [快速开始](#2-快速开始)
3. [架构设计](#3-架构设计)
4. [配置详解](#4-配置详解)
5. [使用方式](#5-使用方式)
   - [5.1 注解方式](#51-注解方式)
   - [5.2 编程式 API](#52-编程式-api)
6. [SPI 扩展点](#6-spi-扩展点)
7. [原理详解](#7-原理详解)
8. [注意事项](#8-注意事项)
9. [常见问题](#9-常见问题)

---

## 1. 概述

指标上报模块提供 DataDog/StatsD 风格的指标上报接口，基于 **Micrometer + Prometheus** 实现。支持**注解声明式**（`@Time` / `@Count` / `@Gauge`）和**编程式 API**（`StatsDClient`）两种使用方式，内置全局标签注入、标签基数保护和指标保活机制。指标数据通过 Spring Boot Actuator 的 `/actuator/prometheus` 端点暴露，可直接对接 Prometheus + Grafana 监控体系。

### 核心特性

- **双模式上报**：既支持 AOP 注解零侵入采集，也支持 `StatsDClient` 编程式精细控制
- **多指标类型**：支持 Counter（计数）、Gauge（瞬时值）、Timer（耗时）和 Histogram（分布统计）四种指标类型
- **全局标签注入**：自动注入 `app`、`env` 等公共标签，支持业务自定义扩展
- **标签基数保护**：每个指标名下 tag 组合数有上限，超出自动丢弃，防止内存爆炸
- **指标自动清理**：长时间无更新的"死指标"自动过期移除，避免内存泄漏
- **时间单位固定**：强制使用秒作为基础时间单位，不受 Spring Boot 版本升级影响
- **Spring Boot 自动装配**：引入 starter 依赖即可使用，约定优于配置

### 适用场景

| 场景 | 说明 |
|------|------|
| 方法耗时监控 | 使用 `@Time` 统计接口/方法的执行耗时和调用次数 |
| 业务计数 | 使用 `@Count` 或 `StatsDClient.increment()` 统计订单量、消息量等 |
| 并发监控 | 使用 `@Gauge` 跟踪方法的实时并发执行数 |
| 资源状态上报 | 使用 `StatsDClient.gauge()` 上报线程池大小、队列长度、连接数等瞬时值 |
| 分布统计 | 使用 `StatsDClient.histogram()` 统计请求大小、响应大小等分布 |
| Grafana 看板 | 所有指标自动暴露为 Prometheus 格式，可直接配置 Grafana 面板 |

---

## 2. 快速开始

### 2.1 添加 Maven 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-metrics-prometheus</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### 2.2 添加配置

在 `application.yml` 中添加最少配置：

```yaml
yeepay:
  framework:
    metrics:
      prefix: myapp              # 指标名前缀，建议设置为应用名

# 暴露 Prometheus 端点
management:
  endpoints:
    web:
      exposure:
        include: prometheus
```

### 2.3 代码使用

```java
@RestController
public class OrderController {

    @Time("order_query")         // 自动统计方法耗时
    @Count("order_query")        // 自动统计调用次数
    @GetMapping("/order")
    public Result<Order> queryOrder(String orderId) {
        // 业务逻辑...
        return Result.success(order);
    }
}
```

启动后访问 `http://localhost:8080/actuator/prometheus`，搜索 `myapp_order_query` 即可看到指标数据。

---

## 3. 架构设计

### 模块结构

```
metrics/
├── metrics-api/                    # SPI 接口层
│   ├── StatsDClient.java          #   指标上报客户端接口（Counter/Gauge/Timer/Histogram）
│   ├── Metric.java                #   指标值封装（名称+值+时间戳+标签）
│   ├── FunctionalMetric.java      #   动态值指标（Supplier 驱动）
│   ├── PublicMetrics.java         #   自定义指标注册 SPI
│   ├── CommonTagCustom.java       #   全局标签自定义 SPI
│   └── config/MetricsConfig.java  #   配置基类
│
└── metrics-prometheus/            # Prometheus 实现层
    ├── YeepayPrometheusProxy.java       # StatsDClient 的 Prometheus 实现
    ├── YeepayMetricsReporter.java       # 定时上报引擎（收集→转换→推送）
    ├── YeepayPrometheusMeterRegistry.java  # 自定义 MeterRegistry（固定时间单位）
    ├── YeepayMicrometerCollector.java   # 指标收集器（携带 Meter.Id）
    ├── YeepayPrometheusCollector.java   # Prometheus MultiCollector
    ├── entity/
    │   ├── DoubleGauge.java             # 双重接口 Gauge（Gauge + Counter）
    │   ├── MeterContainer.java          # 指标容器（按名称分组管理）
    │   ├── MeterTags.java               # 标签封装（乱序兼容）
    │   └── ReportableMeter.java         # 可上报指标包装器（追踪更新状态）
    └── utils/PrometheusNameUtil.java    # 命名转换工具

springboot-starter/
└── springboot-starter-metrics-prometheus/   # Spring Boot 自动配置
    ├── PrometheusAutoConfiguration.java     #   自动装配（Bean 注册与条件控制）
    ├── annotation/Time.java                 #   @Time 注解
    ├── annotation/Count.java                #   @Count 注解
    ├── annotation/Gauge.java                #   @Gauge 注解
    ├── aspect/MetricsAspect.java            #   AOP 切面（处理三个注解）
    └── config/MetricsProperties.java        #   配置属性绑定
```

### 分层架构

```
┌──────────────────────────────────────┐
│         业务代码                       │
│   @Time / @Count / @Gauge  或  StatsDClient  │
├──────────────────────────────────────┤
│     MetricsAspect (AOP 切面)          │  ← 拦截注解，转为 StatsDClient 调用
├──────────────────────────────────────┤
│     YeepayPrometheusProxy             │  ← StatsDClient 实现，管理 Meter 生命周期
├──────────────────────────────────────┤
│  ConcurrentMap<String, MeterContainer>│  ← 指标容器，按名称 + 标签分组
├──────────────────────────────────────┤
│     YeepayMetricsReporter             │  ← 定时任务，收集指标 → 生成 Snapshot
├──────────────────────────────────────┤
│  YeepayPrometheusCollector            │  ← Prometheus MultiCollector，暴露数据
├──────────────────────────────────────┤
│  PrometheusRegistry → /actuator/prometheus │  ← Prometheus 抓取端点
└──────────────────────────────────────┘
```

### 激活机制

`PrometheusAutoConfiguration` 通过 Spring Boot 条件装配控制是否启用：

| 条件 | 说明 |
|------|------|
| `@ConditionalOnClass(PrometheusMeterRegistry.class)` | 类路径存在 Prometheus 依赖 |
| `@ConditionalOnBean(Clock.class)` | 存在 Micrometer Clock Bean |
| `@ConditionalOnProperty(name=enabled, matchIfMissing=true)` | 默认启用，可设 `false` 关闭 |

---

## 4. 配置详解

所有配置均在 `yeepay.framework.metrics` 前缀下。

### 4.1 完整配置属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | boolean | `true` | **总开关**。设为 `false` 则整个模块不加载，不会注册任何 Bean |
| `prefix` | String | — | **指标名前缀**。最终指标名格式为 `prefix_name`。建议设为应用名，避免多服务指标名冲突。不配置则无前缀 |
| `suffix` | String | — | **指标名后缀**。附加在指标名最后，可用于版本区分（如 `_v1`、`_v2`）。不配置则无后缀 |
| `tags` | Map\<String, String\> | — | **全局附加标签**。配置在此处的标签会附加到每一个指标上。适合放 `team`、`tier` 等组织维度的固定标签 |
| `schedule-threads` | int | `1` | **上报调度线程数**。控制 `YeepayMetricsReporter` 内部 `ScheduledThreadPoolExecutor` 的线程池大小。指标少时 1 个线程足够 |
| `publish-frequency` | Duration | `30s` | **指标推送间隔**。定时任务将内存中的指标数据转为 Prometheus Snapshot 的频率。值越小数据越实时，但 CPU 开销越大。开发环境可设 `10s`，生产环境建议 `30s`-`60s` |
| `tags-limit` | int | `1000` | **标签基数上限**。每个指标名称（如 `order_count`）下允许存在的最大 tag 组合数。超出后新的 tag 组合被丢弃并打印 ERROR 日志。用于防止高基数 tag（如 userId）导致的内存爆炸 |
| `keep-alive` | Duration | `2m` | **指标存活时间**。对于超过此时间没有任何更新的指标，框架会自动从 PrometheusRegistry 中移除。防止已废弃的指标持续占用内存。如果某些指标需要长期保留，需通过编程式 API 定期刷新 |

### 4.2 YAML 完整配置示例

```yaml
yeepay:
  framework:
    metrics:
      # ====== 基础配置 ======
      enabled: true                     # 启用指标模块【可选，默认true】

      # ====== 命名控制 ======
      prefix: yeepay                    # 指标名前缀【可选，建议配置为应用名】
                                        # 最终名格式：yeepay_<原始指标名>
      suffix: v1                        # 指标名后缀【可选，可用于版本区分】
                                        # 最终名格式：<prefix>_<原始指标名>_v1

      # ====== 全局标签（附加到所有指标） ======
      tags:
        team: framework                 # 团队标识
        tier: backend                   # 服务层级

      # ====== 上报调度 ======
      schedule-threads: 2               # 上报线程数【可选，默认1】
                                        # 指标数量大时可适当增加
      publish-frequency: 30s            # 推送间隔【可选，默认30s】
                                        # 开发环境可设10s，生产建议30s-60s

      # ====== 标签保护 ======
      tags-limit: 2000                  # 标签基数上限【可选，默认1000】
                                        # 超出后新标签组合被丢弃

      # ====== 指标清理 ======
      keep-alive: 5m                    # 无更新指标存活时间【可选，默认2m】
                                        # 超时后自动从注册表移除

# ====== Prometheus 端点暴露（Spring Boot Actuator） ======
management:
  endpoints:
    web:
      exposure:
        include: prometheus,health,metrics
  metrics:
    distribution:
      percentiles-histogram:
        http.server.requests: true      # 启用 HTTP 请求的直方图百分位
      percentiles:
        http.server.requests: 0.5, 0.9, 0.95, 0.99
```

---

## 5. 使用方式

### 5.1 注解方式

框架提供三个注解，通过 AOP 切面（`MetricsAspect`）自动拦截被标记的方法并上报指标。注解方式**零侵入**，适合对已有代码快速添加监控。

#### @Time — 统计方法耗时

记录方法执行耗时（纳秒精度），结果以 Histogram 形式上报。无论方法是正常返回还是抛异常，都会记录。自动附加 `successful` 标签（`true`/`false`）区分成功和失败的调用。

**注解定义：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `value` | String | `""` | 指标名称。为空时自动取 `类名.方法名` |
| `longTask` | boolean | `false` | 是否为长时间任务（当前版本预留，暂未实现特殊逻辑） |

**使用示例：**

```java
// 默认指标名 = 当前类名.方法名（如 OrderService.createOrder）
@Time
public void createOrder() {
    // ...
}

// 自定义指标名
@Time("order_processing")
public void processOrder() {
    // ...
}

// 同一个方法有多个指标是合法的
@Time("order_create_time")
@Count("order_create_count")
public Order createOrder(OrderDTO dto) {
    // ...
}
```

**生成的 Prometheus 指标**（以 `prefix=myapp`、指标名 `order_processing` 为例）：

| Prometheus 指标名 | 说明 |
|------|------|
| `myapp_order_processing_seconds_count` | 调用总次数 |
| `myapp_order_processing_seconds_sum` | 总耗时（秒） |
| `myapp_order_processing_seconds_max` | 最大单次耗时（秒） |

> 指标名中的 `-` 会被自动替换为 `_`。例如 `order-processing` → `order_processing`。

#### @Count — 统计调用次数

记录方法被调用的次数，以 Counter 形式上报。自动附加 `successful` 标签。

**注解定义：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `value` | String | `""` | 指标名称。为空时自动取 `类名.方法名` |

**使用示例：**

```java
// 默认指标名
@Count
public void sendNotification() {
    // ...
}

// 自定义指标名
@Count("notification_sent")
public void sendNotification() {
    // ...
}
```

**生成的 Prometheus 指标：**

| Prometheus 指标名 | 说明 |
|------|------|
| `myapp_notification_sent_total` | 累计调用次数（含 `successful` 标签） |

#### @Gauge — 跟踪并发执行数

跟踪方法的实时并发执行数。方法进入时 +1，退出时 -1。以 Gauge 形式上报。

**注解定义：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `value` | String | `""` | 指标名称。为空时自动取 `类名.方法名` |

**使用示例：**

```java
@Gauge("active_requests")
public Result handleRequest() {
    // 方法执行期间，myapp_active_requests 反映当前并发数
    // ...
}
```

**生成的 Prometheus 指标：**

| Prometheus 指标名 | 说明 |
|------|------|
| `myapp_active_requests` | 当前正在执行该方法的总次数 |

> **重要限制**：(1) 方法内使用异步线程池会导致退出时机不准；(2) Spring AOP 基于代理，同一类内部方法调用不会触发切面，注解不生效。

---

### 5.2 编程式 API

通过注入 `StatsDClient` Bean 直接调用上报方法，支持比注解更精细的控制。适合非方法粒度的指标、动态标签、条件上报等场景。

#### 5.2.1 注入 StatsDClient

```java
@Service
public class OrderService {

    @Autowired
    private StatsDClient statsDClient;

    // ...
}
```

#### 5.2.2 Counter — 计数器

计数器用于统计"发生了多少次"，值只会单调递增（或通过负 delta 递减）。典型场景：订单数、消息数、错误数。

```java
// 增加指定数值
statsDClient.count("order_created", 10, "channel", "app");
// long 和 double 都支持
statsDClient.count("revenue", 99.5, "currency", "CNY");

// 递增 1（最常用）
statsDClient.increment("order_total", "status", "success");

// 递减 1
statsDClient.decrement("pending_orders");
```

**参数说明：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `aspect` | String | 指标名称（必填） |
| `delta` | long / double | 计数器变化量。正数增加，负数减少 |
| `sampleRate` | double | **采样率**（0.0~1.0）。当前版本保留接口，实际不生效 |
| `tags` | String... | **可变标签**，格式为 `key, value, key, value...`，如 `"channel", "app", "status", "ok"` |

#### 5.2.3 Gauge — 瞬时值

Gauge 用于上报"当前是多少"，反映某个瞬时状态。典型场景：队列长度、连接池活跃数、内存使用量。

```java
// 上报队列当前长度
statsDClient.gauge("queue_size", 128, "queue", "order");

// 上报数据库连接池活跃连接数
statsDClient.recordGaugeValue("db_pool_active", 5);

// long 和 double 都支持
statsDClient.gauge("cpu_usage", 72.5, "host", "server01");
```

**参数说明：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `aspect` | String | 指标名称（必填） |
| `value` | long / double | 当前瞬时值 |
| `sampleRate` | double | 采样率。当前版本保留接口，实际不生效 |
| `tags` | String... | 可变标签，格式同 Counter |

> `gauge()` 是 `recordGaugeValue()` 的便捷简写，行为完全一致。

#### 5.2.4 Timer — 耗时统计

记录操作的执行耗时（毫秒）。典型场景：数据库查询耗时、外部 API 调用耗时。

```java
// 记录某次操作的耗时
long start = System.currentTimeMillis();
doSomething();
long elapsed = System.currentTimeMillis() - start;
statsDClient.time("db_query", elapsed, "table", "orders");

// 完整方法名
statsDClient.recordExecutionTime("api_call", 200L, "endpoint", "/api/user");
```

**参数说明：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `aspect` | String | 指标名称（必填） |
| `timeInMs` | long | 耗时，单位毫秒 |
| `sampleRate` | double | 采样率。当前版本保留接口，实际不生效 |
| `tags` | String... | 可变标签，格式同 Counter |

> `time()` 是 `recordExecutionTime()` 的便捷简写。

#### 5.2.5 Histogram — 分布统计

记录值的分布情况，与 Timer 共用同一个底层实现。典型场景：请求 Body 大小、响应 Payload 大小。

```java
// 记录请求大小分布
statsDClient.histogram("request_size", 1024L, "method", "POST");

// 记录响应大小分布
statsDClient.recordHistogramValue("response_size", 2048L, "status", "200");

// double 值也支持，底层转为 long
statsDClient.histogram("payload_kb", 3.5, "type", "json");
```

**参数说明：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `aspect` | String | 指标名称（必填） |
| `value` | long / double | 要记录的值。double 会转为 long |
| `sampleRate` | double | 采样率。当前版本保留接口，实际不生效 |
| `tags` | String... | 可变标签，格式同 Counter |

> `histogram()` 是 `recordHistogramValue()` 的便捷简写。当前版本 Histogram 与 Timer 底层都映射为 `DistributionSummary`。

#### 5.2.6 标签格式说明

标签以可变参数形式传递，**按顺序两两配对**（`key1, value1, key2, value2...`）：

```java
// 正确用法：key 和 value 交替
statsDClient.increment("orders", "channel", "app", "status", "ok");
// 产生标签：{channel="app", status="ok"}

// 单数标签：key 后无 value，value 默认为 "-"
statsDClient.increment("orders", "standalone");
// 产生标签：{standalone="-"}
```

> **注意**：标签必须成对出现（key, value）。如果传入奇数个，最后一个 key 的 value 默认为 `-`。空 key 或空 value 的标签会被忽略并打印 ERROR 日志。

#### 5.2.7 方法速查表

| 类别 | 简写方法 | 完整方法 | 说明 |
|------|---------|---------|------|
| Counter | `count(aspect, delta, tags...)` | — | ±delta（long/double） |
| Counter | `increment(aspect, tags...)` | `incrementCounter(aspect, tags...)` | +1 |
| Counter | `decrement(aspect, tags...)` | `decrementCounter(aspect, tags...)` | -1 |
| Gauge | `gauge(aspect, value, tags...)` | `recordGaugeValue(aspect, value, tags...)` | 设当前值（long/double） |
| Timer | `time(aspect, ms, tags...)` | `recordExecutionTime(aspect, ms, tags...)` | 记录毫秒耗时 |
| Histogram | `histogram(aspect, v, tags...)` | `recordHistogramValue(aspect, v, tags...)` | 记录分布值（long/double） |

---

## 6. SPI 扩展点

框架提供三个 SPI 接口，允许业务方扩展全局标签、自定义指标和动态值指标。

| 接口 | 包路径 | 说明 |
|------|--------|------|
| `CommonTagCustom` | `com.yeepay.framework.metrics.api` | 自定义全局标签注入 |
| `PublicMetrics` | `com.yeepay.framework.metrics.api` | 注册自定义指标 |
| `FunctionalMetric` | `com.yeepay.framework.metrics.api` | 动态值指标（Supplier 驱动） |

### 6.1 CommonTagCustom — 自定义全局标签

实现 `CommonTagCustom` 接口并注册为 Spring Bean，标签会自动附加到所有指标上。可以有多个实现，按顺序依次执行 `custom()`。

```java
@Component
public class AppVersionTagCustom implements CommonTagCustom {
    @Override
    public void custom(Map<String, String> tags) {
        tags.put("version", AppInfo.getVersion());    // 应用版本
        tags.put("region", RegionUtils.getRegion());  // 部署区域
    }
}
```

**框架默认注入的标签**（无需配置，自动生成）：

| 标签 key | 来源 | 示例值 |
|----------|------|--------|
| `app` | `ApplicationInfo.getName()` | `order-service` |
| `env` | `ApplicationInfo.getEnv()` | `dev` / `test` / `prod` |

### 6.2 PublicMetrics — 注册自定义指标

对于无法通过注解或简单 API 覆盖的场景（如系统级指标），实现 `PublicMetrics` 接口并注册为 Bean：

```java
@Component
public class SystemMetrics implements PublicMetrics {
    @Override
    public Collection<Metric<?>> metrics() {
        return List.of(
            new Metric<>("jvm.heap.used", Runtime.getRuntime().totalMemory()),
            new Metric<>("jvm.threads.active", Thread.activeCount())
        );
    }
}
```

### 6.3 FunctionalMetric — 动态值指标

对于需要每次读取时动态计算的指标，使用 `FunctionalMetric`，值通过 `Supplier` 惰性求值：

```java
// 每次抓取时都调用 Supplier.get() 获取最新值
new FunctionalMetric<>("heap_memory",
    () -> Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
)
```

`FunctionalMetric.getValue()` 和 `getTimestamp()` 每次调用都会实时计算，而普通 `Metric` 的值在构造时即固定。

---

## 7. 原理详解

### 7.1 数据流全景

```
┌─────────────────────────────────────────────────────────┐
│                     业务线程                              │
│  statsDClient.increment("orders", "status", "ok")       │
│  或 @Count("orders") 被 MetricsAspect 拦截               │
└──────────────────────┬──────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│              YeepayPrometheusProxy                       │
│  getOrCreateMeter("orders", COUNTER, "status", "ok")    │
│    │                                                    │
│    ├── meters.get("orders")  →  MeterContainer          │
│    │     └── 类型检查（同名的 Meter 必须同类型）          │
│    │     └── 标签包装：MeterTags.of("status", "ok")      │
│    │     └── 基数检查：subMap.size() > tagsLimit?        │
│    │           ├── 未超：创建 Meter + ReportableMeter    │
│    │           └── 超出：丢弃 + ERROR 日志               │
│    └── counter.increment(1)                             │
└──────────────────────┬──────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│              YeepayMetricsReporter（定时任务）            │
│  周期：publishFrequency（默认30s）                        │
│    │                                                    │
│    ├── 遍历所有 MeterContainer                           │
│    ├── 对每个 ReportableMeter：                           │
│    │     ├── 未注册 → register Gauge/Counter/Summary     │
│    │     ├── 有更新 → 更新 reportedCount + lastReportTime│
│    │     └── 过期   → 从 map 中移除                      │
│    └── 生成 MetricSnapshots → 写入 Collector             │
└──────────────────────┬──────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│         YeepayPrometheusCollector (MultiCollector)      │
│         PrometheusRegistry.scrape() → /actuator/prometheus│
└─────────────────────────────────────────────────────────┘
```

### 7.2 自定义 Meter 管理

`YeepayPrometheusProxy` 不直接使用 Micrometer 的 `MeterRegistry.counter()` 等方法创建 Meter，而是通过 `getOrCreateMeter` 自行管理 Meter 生命周期。

**`getOrCreateMeter` 流程：**

```
getOrCreateMeter(name, type, tags)
  ├── Step 1: 查找或创建 MeterContainer
  │     └── meters.get(name) → 不存在则 putIfAbsent
  │
  ├── Step 2: 类型一致性检查
  │     └── container.type ≠ type → ERROR 日志 + 返回 null
  │     （Prometheus 要求同名指标必须同类型）
  │
  ├── Step 3: 查找或创建 ReportableMeter
  │     ├── MeterTags.of(tags) → 封装标签为 Set
  │     └── container 内 ConcurrentMap<MeterTags, ReportableMeter>
  │
  ├── Step 4: 标签基数保护
  │     └── subMap.size() > tagsLimit → 丢弃 + 返回 null
  │
  └── Step 5: 构建 Meter 并包装为 ReportableMeter
        └── buildMeter(name, type, tags)
              ├── GAUGE           → DoubleGauge
              ├── COUNTER          → PrometheusCounter
              └── DISTRIBUTION_SUMMARY → PrometheusDistributionSummary
```

这样设计的原因：
- **标签基数保护**：需要在创建 Meter 前检查，原生 Micrometer API 无此限制
- **保活/过期清理**：需要通过 `ReportableMeter` 追踪每个 Meter 的活跃状态
- **类型冲突检测**：同名不同类的 Meter 在注册时就报错，而非等到抓取时

### 7.3 MeterTags — 标签乱序兼容

标签以 **`HashSet`** 存储，相等性基于 `Set.equals()`。这意味着以下两组标签被视为完全相同：

```java
statsDClient.increment("orders", "a", "1", "b", "2");  // {a=1, b=2}
statsDClient.increment("orders", "b", "2", "a", "1");  // {a=1, b=2} ← 同一组标签
```

如果不做乱序兼容，`"a:1, b:2"` 和 `"b:2, a:1"` 会创建两个不同的 Meter，导致指标重复。

### 7.4 标签基数保护

每个 `MeterContainer` 内部维护 `ConcurrentMap<MeterTags, ReportableMeter>`。当有新 tag 组合时：

```
if (subMap.size() > config.getTagsLimit()) {
    log.error("The tag count of `{}` meter reached limit, limit is {}.", name, limit);
    return null;  // 丢弃新组合，不上报
}
```

**典型触发场景**：将 `userId`、`orderId` 等高基数字段作为 tag 值。单个 `userId` tag 就可能产生数百万种组合，耗尽内存。

### 7.5 指标保活与过期清理

`ReportableMeter` 维护两个核心字段：

| 字段 | 作用 |
|------|------|
| `reportedCount` | 上次上报时的计数。如果当前 count > reportedCount，说明有新数据 |
| `lastReportTime` | 最后一次检测到新数据的时间戳 |

**清理逻辑**（每次 `report()` 执行）：

```
遍历每个 ReportableMeter:
  ├── isReportable() == false（当前 count 未增长）
  │     └── isCanRemove(keepAlive) == true（距今超时）
  │           └── iterator.remove() + 从 Prometheus 反注册
  └── isReportable() == true（有新数据）
        └── updateCount() → 更新 reportedCount 和 lastReportTime
```

简单来说：**持续有更新的指标永久保留，停止更新的指标在 `keep-alive` 后自动清理**。

### 7.6 定时上报流程

`YeepayMetricsReporter` 在构造时启动定时任务：

```
ScheduledThreadPoolExecutor:
  └── 初始延迟 1s
  └── 周期 = publishFrequency（默认 30s）
  └── 线程数 = scheduleThreads（默认 1）

每次执行 report():
  ├── 遍历所有 MeterContainer
  ├── 对每个 ReportableMeter:
  │     ├── 若未注册 → 按类型注册到 collector
  │     │     ├── Gauge        → registerGauge()
  │     │     ├── Counter      → reportCounter()
  │     │     └── DistSummary  → logDistributionSummary()
  │     └── updateCount()
  ├── 清理过期 Meter
  └── collector.setMetricSnapshots(snapshots)
```

### 7.7 命名转换

`PrometheusNameUtil` 使用自定义的 `PrometheusNamingConvention`，关键行为是将所有 Meter 类型统一按 `GAUGE` 格式命名：

```java
// 实际转换效果
"myapp.order_query"     → "myapp_order_query"
"order.query.count"     → "order_query_count"
"orderQueryCount"       → "orderQueryCount"    // 驼峰保持原样
```

建议指标名使用 snake_case，避免大写字母。

### 7.8 Counter 转 GaugeSnapshot

`reportCounter()` 中有一个刻意设计——Counter 数据被转为 `GaugeSnapshot` 上报而非 Prometheus 原生的 `CounterSnapshot`：

```java
// 实际使用 GaugeSnapshot 承载 Counter 数据
new GaugeSnapshot.GaugeDataPointSnapshot(
    counter.count(), Labels.of(tagKeys, tagValues), counter.exemplar(), 0)
```

原因是 `CounterSnapshot` 会自动给指标名追加 `_total` 后缀，为保证向上兼容历史版本的指标命名，框架改用 `GaugeSnapshot` 格式，后缀由业务方自行控制。

### 7.9 DoubleGauge — Gauge + Counter 双接口

`DoubleGauge` 同时实现 `Gauge` 和 `Counter` 接口：

| 接口 | 方法 | 返回 | 说明 |
|------|------|------|------|
| `Gauge` | `value()` | double | 最后设置的瞬时值 |
| `Counter` | `count()` | double | 累计 `setValue()` 调用次数 |

这个设计利用 Counter 的 count 变化来判断 Gauge 是否有更新——如果 `count() > reportedCount`，说明 `setValue()` 又被调用了，该指标仍活跃。

### 7.10 自动配置机制

`PrometheusAutoConfiguration` 注册的核心 Bean：

| Bean 名称 | 类型 | 说明 |
|-----------|------|------|
| `commonTags` | `CommonTags` | 全局标签，自动注入 `app` 和 `env` |
| `metricsCommonTags` | `MeterRegistryCustomizer` | 将全局标签同步到 Micrometer |
| `prometheusMeterRegistry` | `YeepayPrometheusMeterRegistry` | 自定义 Registry（固定时间单位为秒）。如果用户已提供则跳过 |
| `statsDClient` | `YeepayPrometheusProxy` | StatsD 客户端实现 |
| `metricsAspect` | `MetricsAspect` | AOP 切面，处理 `@Time`/`@Count`/`@Gauge`。仅在 `StatsDClient` Bean 存在时注册 |

---

## 8. 注意事项

1. **标签基数爆炸**：禁止使用 `userId`、`orderId`、`sessionId`、`requestId` 等高基数值作为 tag。`tags-limit` 默认为 1000，超出后新组合被静默丢弃。

2. **@Gauge 与异步方法**：`@Gauge` 通过 AOP 在方法进入时 +1、退出时 -1。如果方法内部使用了异步线程池，退出时机不准确，Gauge 值可能持续偏高。

3. **同类内部调用不触发 AOP**：Spring AOP 基于代理，同一类中 `this.methodB()` 调用不会经过代理，注解不生效。需要将 methodB 抽到另一个 Bean 中，或改为注入自身。

4. **keep-alive 调优**：如果你的指标不是持续更新的（如每天只更新几次的统计值），需要确保更新频率高于 `keep-alive`，否则指标会被当作"死指标"清理。建议定期刷新或适当增大 `keep-alive`。

5. **prefix 命名**：建议每个服务使用唯一的 `prefix`（通常是 `spring.application.name`），防止多个服务共享同一 Prometheus 实例时指标名冲突。

6. **时间单位**：`YeepayPrometheusMeterRegistry` 强制使用秒作为时间单位，不会随 Spring Boot 版本变化。使用 `@Time` 注解采集的耗时数据会自动以秒为单位上报。

7. **采样率不生效**：`StatsDClient` 接口中的 `sampleRate` 参数当前版本保留接口兼容性但**不实际控制采样**。所有调用 100% 上报。如果需要采样，请在业务层自行实现。

---

## 9. 常见问题

### Q1：指标已经上报了，但在 `/actuator/prometheus` 中看不到？

首次上报有延迟。框架在启动后 **1 秒**开始首次上报，然后按 `publish-frequency`（默认 30s）定时推送。新指标最多需要等待 `publish-frequency` 周期才能在端点中看到。

### Q2：为什么同一个指标名用不同标签上报，只有一个生效？

检查日志是否有 `reached limit` 错误。如果该指标名的标签组合数超过了 `tags-limit`（默认 1000），新组合会被丢弃。增大 `tags-limit` 或减少标签基数。

### Q3：指标在 Prometheus 中消失了？

检查 `keep-alive` 配置（默认 2m）。如果指标在 2 分钟内没有任何更新，会被自动清理。需要长期保留的指标请定期刷新或增大 `keep-alive`。

### Q4：标签中可以用中文吗？

技术上可以，但**不建议**。Prometheus 标签规范要求使用 ASCII 字符。非 ASCII 字符可能在某些监控工具中显示异常。

### Q5：如何为 HTTP 请求添加自定义指标？

Spring Boot Actuator 已自动暴露 `http_server_requests_seconds` 等指标。如果需要在业务维度统计，建议在自己的 Controller 方法上使用 `@Time` + `@Count` 注解。

### Q6：同一个方法可以加多个注解吗？

可以。`@Time`、`@Count`、`@Gauge` 互相独立，可以在同一个方法上同时使用：

```java
@Time("order_create_time")
@Count("order_create_count")
public Order createOrder(OrderDTO dto) {
    // ...
}
```

### Q7：可以用一个注解同时统计耗时和次数吗？

不能。三个注解各司其职，没有"组合注解"。如果需要同时统计，请分别添加 `@Time` 和 `@Count`。

### Q8：`@Time` 和 `@Count` 的差别是什么？

| | @Time | @Count |
|------|------|------|
| 指标类型 | Histogram（分布） | Counter（计数） |
| 记录内容 | 每次执行耗时 + 次数 | 仅执行次数 |
| 可计算 | P50/P95/P99 耗时、平均耗时 | 仅总次数/QPS |
| Prometheus 指标数 | 3 个（count、sum、max） | 1 个（total） |

"既要次数又要耗时" → 只用 `@Time` 即可，它自带了 `_count`。
