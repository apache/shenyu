package com.yeepay.framework.metrics.api.tag;

import java.util.Map;
import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * 通用标签类，用于存储指标的标签信息.
 */
@Data
@RequiredArgsConstructor
public class CommonTags {

    private final Map<String, String> tags;
}
