package com.yeepay.framework.metrics.api;

import java.util.Collection;

/**
 * 公共指标接口，用于提供应用程序的指标信息.
 */
public interface PublicMetrics {

    /**
     * Return an indication of current state through metrics.
     *
     * @return the public metrics
     */
    Collection<Metric<?>> metrics();
}
