package com.yeepay.framework.metrics.api;

import java.util.Map;

/**
 * 通用标签自定义接口，用于自定义标签.
 */
public interface CommonTagCustom {

    /**
     * 自定义标签.
     *
     * @param tags 标签映射
     */
    void custom(Map<String, String> tags);
}
