package com.yeepay.framework.metrics.api;

import java.util.Date;
import java.util.Objects;
import lombok.Getter;

/**
 * 指标类，表示具有名称、值和时间戳的测量指标.
 *
 * @param <T> 指标值的类型
 */
@Getter
public class Metric<T extends Number> {

    /**
     *  Returns the name of the metric.
     */
    private final String name;

    /**
     *  Returns the value of the metric.
     */
    private final T value;

    /**
     *  返回指标的时间戳.
     */
    private final Date timestamp;

    /**
     *  返回指标的标签.
     */
    private final String[] tags;

    /**
     * Create a new {@link Metric} instance for the current time.
     *
     * @param name  the name of the metric
     * @param value the value of the metric
     */
    public Metric(String name, T value) {
        this(name, value, new Date());
    }

    /**
     * Create a new {@link Metric} instance.
     *
     * @param name      the name of the metric
     * @param value     the value of the metric
     * @param timestamp the timestamp for the metric
     * @param tags      tags
     */
    public Metric(String name, T value, Date timestamp, String... tags) {
        Objects.requireNonNull(name, "Name must not be null");
        this.name = name;
        this.value = value;
        this.timestamp = timestamp;
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "Metric [name=" + this.name + ", value=" + this.value + ", timestamp=" + this.timestamp + "]";
    }

    /**
     * Create a new {@link Metric} with an incremented value.
     *
     * @param amount the amount that the new metric will differ from this one
     * @return a new {@link Metric} instance
     */
    public Metric<Long> increment(int amount) {
        return new Metric<Long>(this.getName(), this.getValue().longValue() + amount);
    }

    /**
     * Create a new {@link Metric} with a different value.
     *
     * @param <S>   the metric value type
     * @param value the value of the new metric
     * @return a new {@link Metric} instance
     */
    public <S extends Number> Metric<S> set(S value) {
        return new Metric<S>(this.getName(), value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, value, timestamp);
    }

    @Override
    public boolean equals(Object o) {
        if (Objects.isNull(o) || getClass() != o.getClass()) {
            return false;
        }
        Metric<?> metric = (Metric<?>) o;
        return Objects.equals(name, metric.name)
                && Objects.equals(value, metric.value)
                && Objects.equals(timestamp, metric.timestamp);
    }
}
