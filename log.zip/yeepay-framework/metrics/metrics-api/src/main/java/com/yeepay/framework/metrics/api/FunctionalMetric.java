package com.yeepay.framework.metrics.api;

import java.util.Date;
import java.util.function.Supplier;
import lombok.Getter;

/**
 * 函数式指标类，通过Supplier提供动态值的指标.
 *
 * @param <T> 指标值的类型
 */
@Getter
public class FunctionalMetric<T extends Number> extends Metric<T> {

    /**
     *  获取值提供者.
     */
    private final Supplier<T> supplier;

    /**
     * Instantiates a new Functional metric.
     *
     * @param name the name
     * @param supplier the supplier
     */
    public FunctionalMetric(String name, Supplier<T> supplier) {
        super(name, null);
        this.supplier = supplier;
    }

    @Override
    public T getValue() {
        return supplier.get();
    }

    @Override
    public Date getTimestamp() {
        return new Date();
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
