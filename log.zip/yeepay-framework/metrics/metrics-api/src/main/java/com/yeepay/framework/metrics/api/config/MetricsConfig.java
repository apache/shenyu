package com.yeepay.framework.metrics.api.config;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;

/**
 * HTX指标配置属性类.
 */
@Data
public class MetricsConfig {

    private String prefix;

    private String suffix;

    private Map<String, String> tags = new HashMap<>();

    private int scheduleThreads = 1;

    private Duration publishFrequency = Duration.ofSeconds(30);

    private int tagsLimit = 1000;

    private Duration keepAlive = Duration.ofMinutes(2);
}
