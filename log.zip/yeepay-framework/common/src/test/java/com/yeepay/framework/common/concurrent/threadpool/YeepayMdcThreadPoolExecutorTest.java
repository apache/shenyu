package com.yeepay.framework.common.concurrent.threadpool;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.common.concurrent.queue.MemorySafeTaskQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

class YeepayMdcThreadPoolExecutorTest {

    private YeepayMdcThreadPoolExecutor executor;

    @BeforeEach
    void setUp() {
        MemorySafeTaskQueue<Runnable> queue = new MemorySafeTaskQueue<>(1);
        executor = new YeepayMdcThreadPoolExecutor(
                2,
                4,
                60,
                TimeUnit.SECONDS,
                queue,
                YeepayThreadFactory.create("mdc-pool-"),
                new ThreadPoolExecutor.AbortPolicy());
    }

    @AfterEach
    void tearDown() {
        MDC.clear();
        executor.shutdownNow();
    }

    @Test
    void executePropagatesMdc() throws Exception {
        MDC.put("traceId", "abc123");
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> captured = new AtomicReference<>();
        executor.execute(() -> {
            captured.set(MDC.get("traceId"));
            latch.countDown();
        });
        latch.await(5, TimeUnit.SECONDS);
        assertThat(captured.get()).isEqualTo("abc123");
    }

    @Test
    void submitRunnablePropagatesMdc() throws Exception {
        MDC.put("traceId", "def456");
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> captured = new AtomicReference<>();
        executor.submit(() -> {
            captured.set(MDC.get("traceId"));
            latch.countDown();
        });
        latch.await(5, TimeUnit.SECONDS);
        assertThat(captured.get()).isEqualTo("def456");
    }

    @Test
    void submitCallablePropagatesMdc() throws Exception {
        MDC.put("traceId", "ghi789");
        Callable<String> task = () -> MDC.get("traceId");
        Future<String> future = executor.submit(task);
        assertThat(future.get(5, TimeUnit.SECONDS)).isEqualTo("ghi789");
    }

    @Test
    void mdcClearedAfterExecution() throws Exception {
        MDC.clear();
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> captured = new AtomicReference<>("not-null");
        executor.execute(() -> {
            captured.set(MDC.get("traceId"));
            latch.countDown();
        });
        latch.await(5, TimeUnit.SECONDS);
        assertThat(captured.get()).isNull();
    }
}
