package com.yeepay.framework.common.concurrent.threadpool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.common.concurrent.queue.MemorySafeTaskQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class YeepayThreadPoolExecutorTest {

    private YeepayThreadPoolExecutor executor;

    @BeforeEach
    void setUp() {
        MemorySafeTaskQueue<Runnable> queue = new MemorySafeTaskQueue<>(1);
        executor = new YeepayThreadPoolExecutor(
                2,
                4,
                60,
                TimeUnit.SECONDS,
                queue,
                YeepayThreadFactory.create("test-pool-"),
                new ThreadPoolExecutor.AbortPolicy());
    }

    @AfterEach
    void tearDown() {
        executor.shutdownNow();
    }

    @Test
    void executesTask() throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        executor.execute(latch::countDown);
        assertThat(latch.await(5, TimeUnit.SECONDS)).isTrue();
    }

    @Test
    void executeNullThrowsNpe() {
        assertThatThrownBy(() -> executor.execute(null)).isInstanceOf(NullPointerException.class);
    }

    @Test
    void poolSizeAndActiveCount() throws Exception {
        CountDownLatch started = new CountDownLatch(2);
        CountDownLatch finish = new CountDownLatch(1);
        for (int i = 0; i < 2; i++) {
            executor.execute(() -> {
                started.countDown();
                try {
                    finish.await(5, TimeUnit.SECONDS);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
            });
        }
        started.await(5, TimeUnit.SECONDS);
        assertThat(executor.getPoolSize()).isGreaterThanOrEqualTo(2);
        assertThat(executor.getActiveCount()).isGreaterThanOrEqualTo(1);
        finish.countDown();
    }
}
