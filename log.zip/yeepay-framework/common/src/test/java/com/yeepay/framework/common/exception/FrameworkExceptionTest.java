package com.yeepay.framework.common.exception;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class FrameworkExceptionTest {

    @Test
    void constructWithCodeAndMessage() {
        FrameworkException ex = new FrameworkException("E001", "bad request");
        assertThat(ex.getErrorCode()).isEqualTo("E001");
        assertThat(ex.getMessage()).isEqualTo("bad request");
        assertThat(ex.getCause()).isNull();
    }

    @Test
    void constructWithCause() {
        RuntimeException cause = new RuntimeException("root");
        FrameworkException ex = new FrameworkException("E002", "wrapper", cause);
        assertThat(ex.getErrorCode()).isEqualTo("E002");
        assertThat(ex.getMessage()).isEqualTo("wrapper");
        assertThat(ex.getCause()).isSameAs(cause);
    }

    @Test
    void isRuntimeException() {
        assertThat(new FrameworkException("E003", "msg")).isInstanceOf(RuntimeException.class);
    }
}
