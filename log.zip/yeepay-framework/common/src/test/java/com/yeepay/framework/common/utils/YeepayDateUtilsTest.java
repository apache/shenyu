package com.yeepay.framework.common.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Test;

class YeepayDateUtilsTest {

    @Test
    void parseByDayPattern() {
        Date date = YeepayDateUtils.parseByDayPattern("2024-03-15");
        assertThat(date).isNotNull();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertThat(cal.get(Calendar.YEAR)).isEqualTo(2024);
        assertThat(cal.get(Calendar.MONTH)).isEqualTo(Calendar.MARCH);
        assertThat(cal.get(Calendar.DAY_OF_MONTH)).isEqualTo(15);
    }

    @Test
    void parseByDateTimePattern() {
        Date date = YeepayDateUtils.parseByDateTimePattern("2024-03-15 14:30:00");
        assertThat(date).isNotNull();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertThat(cal.get(Calendar.HOUR_OF_DAY)).isEqualTo(14);
        assertThat(cal.get(Calendar.MINUTE)).isEqualTo(30);
    }

    @Test
    void parseDateInvalidThrowsRuntime() {
        assertThatThrownBy(() -> YeepayDateUtils.parseDate("not-a-date", "yyyy-MM-dd"))
                .isInstanceOf(RuntimeException.class);
    }

    @Test
    void formatDate() {
        Date date = YeepayDateUtils.parseByDayPattern("2024-06-01");
        String formatted = YeepayDateUtils.formatDate(date, "yyyy/MM/dd");
        assertThat(formatted).isEqualTo("2024/06/01");
    }

    @Test
    void formatByDayPattern() {
        Date date = YeepayDateUtils.parseByDayPattern("2024-12-25");
        assertThat(YeepayDateUtils.formatByDayPattern(date)).isEqualTo("2024-12-25");
    }

    @Test
    void formatByDayPatternNull() {
        assertThat(YeepayDateUtils.formatByDayPattern(null)).isNull();
    }

    @Test
    void formatByDateTimePattern() {
        Date date = YeepayDateUtils.parseByDateTimePattern("2024-01-01 00:00:00");
        assertThat(YeepayDateUtils.formatByDateTimePattern(date)).isEqualTo("2024-01-01 00:00:00");
    }

    @Test
    void getCurrentDayByDayPattern() {
        String today = YeepayDateUtils.getCurrentDayByDayPattern();
        assertThat(today).matches("\\d{4}-\\d{2}-\\d{2}");
    }

    @Test
    void defaultDate() {
        assertThat(YeepayDateUtils.DEFAULT_DATE).isNotNull();
        assertThat(YeepayDateUtils.formatByDayPattern(YeepayDateUtils.DEFAULT_DATE))
                .isEqualTo("1970-01-01");
    }

    @Test
    void constants() {
        assertThat(YeepayDateUtils.DAY_PATTERN).isEqualTo("yyyy-MM-dd");
        assertThat(YeepayDateUtils.DATETIME_PATTERN).isEqualTo("yyyy-MM-dd HH:mm:ss");
        assertThat(YeepayDateUtils.DATETIME_MS_PATTERN).isEqualTo("yyyy-MM-dd HH:mm:ss.SSS");
    }
}
