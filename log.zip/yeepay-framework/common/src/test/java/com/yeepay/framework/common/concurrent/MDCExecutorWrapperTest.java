package com.yeepay.framework.common.concurrent;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

class MDCExecutorWrapperTest {

    private final MDCExecutorWrapper wrapper = new MDCExecutorWrapper() {};

    @AfterEach
    void cleanup() {
        MDC.clear();
    }

    @Test
    void wrapRunnableSetsContext() throws Exception {
        Map<String, String> ctx = new HashMap<>();
        ctx.put("key", "val");
        AtomicReference<String> captured = new AtomicReference<>();
        Runnable wrapped = wrapper.wrap(() -> captured.set(MDC.get("key")), ctx);
        wrapped.run();
        assertThat(captured.get()).isEqualTo("val");
    }

    @Test
    void wrapRunnableClearsAfter() throws Exception {
        Map<String, String> ctx = new HashMap<>();
        ctx.put("key", "val");
        Runnable wrapped = wrapper.wrap(() -> {}, ctx);
        wrapped.run();
        assertThat(MDC.get("key")).isNull();
    }

    @Test
    void wrapRunnableWithNullContextClears() throws Exception {
        MDC.put("key", "should-be-cleared");
        AtomicReference<String> captured = new AtomicReference<>("not-null");
        Runnable wrapped = wrapper.wrap(() -> captured.set(MDC.get("key")), null);
        wrapped.run();
        assertThat(captured.get()).isNull();
    }

    @Test
    void wrapCallableSetsContext() throws Exception {
        Map<String, String> ctx = new HashMap<>();
        ctx.put("trace", "123");
        Callable<String> wrapped = wrapper.wrap(() -> MDC.get("trace"), ctx);
        assertThat(wrapped.call()).isEqualTo("123");
    }

    @Test
    void wrapCallableWithNullContextClears() throws Exception {
        MDC.put("trace", "old");
        Callable<String> wrapped = wrapper.wrap(() -> MDC.get("trace"), null);
        assertThat(wrapped.call()).isNull();
    }

    @Test
    void wrapCallableClearsAfter() throws Exception {
        Map<String, String> ctx = new HashMap<>();
        ctx.put("trace", "123");
        Callable<String> wrapped = wrapper.wrap(() -> "done", ctx);
        wrapped.call();
        assertThat(MDC.get("trace")).isNull();
    }
}
