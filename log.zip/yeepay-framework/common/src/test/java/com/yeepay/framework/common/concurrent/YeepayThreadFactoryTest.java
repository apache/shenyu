package com.yeepay.framework.common.concurrent;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.concurrent.ThreadFactory;
import org.junit.jupiter.api.Test;

class YeepayThreadFactoryTest {

    @Test
    void createWithNamePrefix() {
        ThreadFactory tf = YeepayThreadFactory.create("test-");
        Thread t = tf.newThread(() -> {});
        assertThat(t.getName()).startsWith("yeepay-test-");
        assertThat(t.isDaemon()).isFalse();
        assertThat(t.getPriority()).isEqualTo(Thread.NORM_PRIORITY);
    }

    @Test
    void createDaemonThread() {
        ThreadFactory tf = YeepayThreadFactory.create("daemon-", true);
        Thread t = tf.newThread(() -> {});
        assertThat(t.isDaemon()).isTrue();
    }

    @Test
    void createWithCustomPriority() {
        ThreadFactory tf = YeepayThreadFactory.create("prio-", false, Thread.MAX_PRIORITY);
        Thread t = tf.newThread(() -> {});
        assertThat(t.getPriority()).isEqualTo(Thread.MAX_PRIORITY);
    }

    @Test
    void threadsHaveIncrementingNames() {
        ThreadFactory tf = YeepayThreadFactory.create("inc-");
        Thread t1 = tf.newThread(() -> {});
        Thread t2 = tf.newThread(() -> {});
        assertThat(t1.getName()).isNotEqualTo(t2.getName());
    }
}
