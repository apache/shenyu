package com.yeepay.framework.common.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;

class PropertiesLoaderTest {

    @Test
    void loadExistingFile() {
        Properties props = PropertiesLoader.load("test-config", "sample.properties");
        assertThat(props).isNotNull();
        assertThat(props.getProperty("key1")).isEqualTo("value1");
    }

    @Test
    void loadWithSingleArgLocation() {
        Properties props = PropertiesLoader.load("test-config/sample.properties");
        assertThat(props).isNotNull();
        assertThat(props.getProperty("key1")).isEqualTo("value1");
    }

    @Test
    void loadNonExistentThrows() {
        assertThatThrownBy(() -> PropertiesLoader.load("nonexistent", "missing.properties"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void loadQuietlyReturnsNullForMissing() {
        Properties props = PropertiesLoader.loadQuietly("nonexistent", "missing.properties");
        assertThat(props).isNull();
    }

    @Test
    void loadQuietlyExistingFile() {
        Properties props = PropertiesLoader.loadQuietly("test-config", "sample.properties");
        assertThat(props).isNotNull();
        assertThat(props.getProperty("key1")).isEqualTo("value1");
    }

    @Test
    void hasKeyTrue() {
        Properties props = new Properties();
        props.setProperty("a", "hello");
        assertThat(PropertiesLoader.hasKey(props, "a")).isTrue();
    }

    @Test
    void hasKeyFalseWhenMissing() {
        Properties props = new Properties();
        assertThat(PropertiesLoader.hasKey(props, "a")).isFalse();
    }

    @Test
    void hasKeyFalseWhenBlank() {
        Properties props = new Properties();
        props.setProperty("a", "   ");
        assertThat(PropertiesLoader.hasKey(props, "a")).isFalse();
    }

    @Test
    void ifPresentCallsSetter() {
        Properties props = new Properties();
        props.setProperty("name", " alice ");
        AtomicReference<String> captured = new AtomicReference<>();
        PropertiesLoader.ifPresent(props, "name", captured::set);
        assertThat(captured.get()).isEqualTo("alice");
    }

    @Test
    void ifPresentSkipsBlank() {
        Properties props = new Properties();
        props.setProperty("name", "   ");
        AtomicReference<String> captured = new AtomicReference<>();
        PropertiesLoader.ifPresent(props, "name", captured::set);
        assertThat(captured.get()).isNull();
    }

    @Test
    void ifPresentSkipsMissing() {
        Properties props = new Properties();
        AtomicReference<String> captured = new AtomicReference<>();
        PropertiesLoader.ifPresent(props, "name", captured::set);
        assertThat(captured.get()).isNull();
    }

    @Test
    void ifPresentAnyPicksFirstNonBlank() {
        Properties props = new Properties();
        props.setProperty("b", "second");
        AtomicReference<String> captured = new AtomicReference<>();
        PropertiesLoader.ifPresentAny(props, captured::set, "a", "b", "c");
        assertThat(captured.get()).isEqualTo("second");
    }

    @Test
    void ifPresentAnyNoMatch() {
        Properties props = new Properties();
        AtomicReference<String> captured = new AtomicReference<>();
        PropertiesLoader.ifPresentAny(props, captured::set, "a", "b");
        assertThat(captured.get()).isNull();
    }

    @Test
    void splitAndTrim() {
        List<String> result = PropertiesLoader.splitAndTrim("  a , b , , c  ");
        assertThat(result).containsExactly("a", "b", "c");
    }

    @Test
    void splitAndTrimSingleValue() {
        List<String> result = PropertiesLoader.splitAndTrim("single");
        assertThat(result).containsExactly("single");
    }

    @Test
    void loadWithNullPath() {
        Properties props = PropertiesLoader.load(null, "test-config/sample.properties");
        assertThat(props).isNotNull();
    }

    @Test
    void loadWithEmptyPath() {
        Properties props = PropertiesLoader.load("", "test-config/sample.properties");
        assertThat(props).isNotNull();
    }

    @Test
    void loadWithTrailingSlashPath() {
        Properties props = PropertiesLoader.load("test-config/", "sample.properties");
        assertThat(props).isNotNull();
    }
}
