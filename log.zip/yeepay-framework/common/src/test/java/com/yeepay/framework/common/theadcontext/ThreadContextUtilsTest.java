package com.yeepay.framework.common.theadcontext;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class ThreadContextUtilsTest {

    @AfterEach
    void cleanup() {
        ThreadContextUtils.clearContext();
    }

    @Test
    void initAndGetContext() {
        ThreadContextUtils.initContext("myApp", "uid-1", ThreadContextType.WEB);
        assertThat(ThreadContextUtils.contextInitialized()).isTrue();
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx).isNotNull();
        assertThat(ctx.getType()).isEqualTo(ThreadContextType.WEB);
    }

    @Test
    void clearContextRemovesIt() {
        ThreadContextUtils.initContext("app", null, ThreadContextType.TASK);
        ThreadContextUtils.clearContext();
        assertThat(ThreadContextUtils.contextInitialized()).isFalse();
        assertThat(ThreadContextUtils.getContext()).isNull();
    }

    @Test
    void doubleInitDoesNotOverwrite() {
        ThreadContextUtils.initContext("app1", "uid-1", ThreadContextType.WEB);
        ThreadContextUtils.initContext("app2", "uid-2", ThreadContextType.TASK);
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getType()).isEqualTo(ThreadContextType.WEB);
    }

    @Test
    void initWithTransferLevel() {
        ThreadContextUtils.initContext("app", "uid", ThreadContextType.WEB, "2");
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getTransferLevel()).isEqualTo("2");
    }

    @Test
    void initWithSoaEnv() {
        ThreadContextUtils.initContext("app", "uid", ThreadContextType.WEB, "1", "dev");
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getSoaEnv()).isEqualTo("dev");
    }

    @Test
    void initWithSrcSoaApp() {
        ThreadContextUtils.initContext("app", "uid", ThreadContextType.WEB, "1", "dev", "srcApp");
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getSrcSoaApp()).isEqualTo("srcApp");
    }

    @Test
    void initWithDstSoaApp() {
        ThreadContextUtils.initContext("app", "uid", ThreadContextType.WEB, "1", "dev", "srcApp", "dstApp");
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getDstSoaApp()).isEqualTo("dstApp");
    }

    @Test
    void initFullArgs() {
        ThreadContextUtils.initContext("app", "uid", ThreadContextType.WEB, "1", "dev", "src", "dst", "soaCtx");
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getSoaContext()).isEqualTo("soaCtx");
    }

    @Test
    @SuppressWarnings("deprecation")
    void deprecatedInitContext() {
        ThreadContextUtils.initContext("uid-1", ThreadContextType.MANUAL);
        assertThat(ThreadContextUtils.contextInitialized()).isTrue();
    }

    @Test
    void getAppNameReturnsNonNull() {
        ThreadContextUtils.initContext("testApp", null, ThreadContextType.WEB);
        assertThat(ThreadContextUtils.getAppName()).isNotNull();
    }

    @Test
    void initDefaultTransferLevel() {
        ThreadContextUtils.initContext("app", null, ThreadContextType.WEB);
        ThreadContext ctx = ThreadContextUtils.getContext();
        assertThat(ctx.getTransferLevel()).isEqualTo(ThreadContextUtils.KEY_TRANSFER_LEVEL_START_VAL);
    }

    @Test
    void constants() {
        assertThat(ThreadContextUtils.KEY_GUID).isEqualTo("_thread_uid");
        assertThat(ThreadContextUtils.KEY_TRANSFER_LEVEL).isEqualTo("_transfer_level");
        assertThat(ThreadContextUtils.KEY_TRANSFER_LEVEL_START_VAL).isEqualTo("1");
        assertThat(ThreadContextUtils.KEY_SOA_ENV).isEqualTo("_soa_env");
        assertThat(ThreadContextUtils.KEY_SOA_CONTEXT).isEqualTo("_soa_context");
        assertThat(ThreadContextUtils.KEY_SRC_SOA_APP).isEqualTo("_src_soa_app");
    }

    @Test
    void initWithNullAppName() {
        ThreadContextUtils.initContext(null, "uid", ThreadContextType.WEB);
        assertThat(ThreadContextUtils.contextInitialized()).isTrue();
    }

    @Test
    void initWithBlankAppName() {
        ThreadContextUtils.initContext("   ", "uid", ThreadContextType.WEB);
        assertThat(ThreadContextUtils.contextInitialized()).isTrue();
    }
}
