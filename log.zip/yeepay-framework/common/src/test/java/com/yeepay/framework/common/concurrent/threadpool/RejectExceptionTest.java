package com.yeepay.framework.common.concurrent.threadpool;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class RejectExceptionTest {

    @Test
    void defaultConstructor() {
        RejectException ex = new RejectException();
        assertThat(ex.getMessage()).isNull();
        assertThat(ex.getCause()).isNull();
    }

    @Test
    void messageConstructor() {
        RejectException ex = new RejectException("full");
        assertThat(ex.getMessage()).isEqualTo("full");
    }

    @Test
    void messageAndCauseConstructor() {
        Throwable cause = new RuntimeException("root");
        RejectException ex = new RejectException("wrapped", cause);
        assertThat(ex.getMessage()).isEqualTo("wrapped");
        assertThat(ex.getCause()).isSameAs(cause);
    }

    @Test
    void causeConstructor() {
        Throwable cause = new RuntimeException("root");
        RejectException ex = new RejectException(cause);
        assertThat(ex.getCause()).isSameAs(cause);
    }

    @Test
    void isRuntimeException() {
        assertThat(new RejectException()).isInstanceOf(RuntimeException.class);
    }
}
