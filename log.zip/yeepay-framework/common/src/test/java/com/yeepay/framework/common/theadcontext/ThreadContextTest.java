package com.yeepay.framework.common.theadcontext;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class ThreadContextTest {

    @Test
    void constructWithMinArgs() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        assertThat(ctx.getAppName()).isEqualTo("app");
        assertThat(ctx.getThreadUID()).isNotNull().hasSize(32);
        assertThat(ctx.getNewThreadUID()).isNull();
        assertThat(ctx.getType()).isEqualTo(ThreadContextType.WEB);
        assertThat(ctx.getThreadStartTime()).isGreaterThan(0);
    }

    @Test
    void constructWithSourceUID() {
        ThreadContext ctx = new ThreadContext("app", "source-uid", ThreadContextType.TASK);
        assertThat(ctx.getThreadUID()).isEqualTo("source-uid");
        assertThat(ctx.getNewThreadUID()).isNotNull().hasSize(32);
    }

    @Test
    void constructWithTransferLevel() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "1");
        assertThat(ctx.getTransferLevel()).isEqualTo("1");
        assertThat(ctx.getPreTransferLevel()).isEqualTo("1");
    }

    @Test
    void constructWithSoaEnv() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "1", "dev");
        assertThat(ctx.getSoaEnv()).isEqualTo("dev");
    }

    @Test
    void constructWithSrcSoaApp() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "1", "dev", "srcApp");
        assertThat(ctx.getSrcSoaApp()).isEqualTo("srcApp");
    }

    @Test
    void constructWithDstSoaApp() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "1", "dev", "srcApp", "dstApp");
        assertThat(ctx.getDstSoaApp()).isEqualTo("dstApp");
    }

    @Test
    void constructFullArgs() {
        ThreadContext ctx =
                new ThreadContext("app", null, ThreadContextType.INTERFACE, "1", "staging", "src", "dst", "soaCtx");
        assertThat(ctx.getSoaContext()).isEqualTo("soaCtx");
        assertThat(ctx.getSoaEnv()).isEqualTo("staging");
    }

    @Test
    void upTransferLevelFromNull() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        String level = ctx.upTransferLevel();
        assertThat(level).isEqualTo("1");
    }

    @Test
    void upTransferLevelFromSingleDigit() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "1");
        String level = ctx.upTransferLevel();
        assertThat(level).isEqualTo("1.1");
    }

    @Test
    void upTransferLevelFromDotOne() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "1.1");
        String level = ctx.upTransferLevel();
        assertThat(level).contains(".1");
    }

    @Test
    void upTransferLevelFromUnrecognizedPattern() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB, "abc");
        String level = ctx.upTransferLevel();
        assertThat(level).isEqualTo("1");
    }

    @Test
    void addAndGetValue() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        assertThat(ctx.getValue("k")).isNull();
        ctx.addValue("k", "v");
        assertThat(ctx.getValue("k")).isEqualTo("v");
    }

    @Test
    void removeValueByKey() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        ctx.addValue("k", "v");
        ctx.removeValue("k");
        assertThat(ctx.getValue("k")).isNull();
    }

    @Test
    void removeValueByKeyWhenNullMap() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        ctx.removeValue("k");
        assertThat(ctx.getThreadValues()).isNull();
    }

    @Test
    void removeAllValues() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        ctx.addValue("a", 1);
        ctx.addValue("b", 2);
        ctx.removeValue();
        assertThat(ctx.getThreadValues()).isEmpty();
    }

    @Test
    void removeAllValuesWhenNullMap() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        ctx.removeValue();
        assertThat(ctx.getThreadValues()).isNull();
    }

    @Test
    void getValueWhenNullMap() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        assertThat(ctx.getValue("anything")).isNull();
    }

    @Test
    void transferLevelCountDefault() {
        ThreadContext ctx = new ThreadContext("app", null, ThreadContextType.WEB);
        assertThat(ctx.getTransferLevelCount()).isEqualTo(1);
    }
}
