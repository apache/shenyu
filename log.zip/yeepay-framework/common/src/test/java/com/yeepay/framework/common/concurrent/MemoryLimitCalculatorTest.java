package com.yeepay.framework.common.concurrent;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class MemoryLimitCalculatorTest {

    @Test
    void maxAvailableReturnsPositive() {
        long max = MemoryLimitCalculator.maxAvailable();
        assertThat(max).isGreaterThan(0);
    }

    @Test
    void calculateWithValidPercentage() {
        long result = MemoryLimitCalculator.calculate(0.5f);
        assertThat(result).isGreaterThan(0);
    }

    @Test
    void calculateWithOneHundredPercent() {
        long result = MemoryLimitCalculator.calculate(1.0f);
        assertThat(result).isGreaterThan(0);
    }

    @Test
    void calculateWithZeroThrows() {
        assertThatThrownBy(() -> MemoryLimitCalculator.calculate(0f)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void calculateWithNegativeThrows() {
        assertThatThrownBy(() -> MemoryLimitCalculator.calculate(-0.1f)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void calculateWithOverOneThrows() {
        assertThatThrownBy(() -> MemoryLimitCalculator.calculate(1.1f)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void defaultLimitReturnsPositive() {
        long limit = MemoryLimitCalculator.defaultLimit();
        assertThat(limit).isGreaterThan(0);
    }
}
