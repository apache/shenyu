package com.yeepay.framework.common.concurrent.queue;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.common.concurrent.threadpool.AbortPolicy;
import com.yeepay.framework.common.concurrent.threadpool.DiscardPolicy;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;

class MemorySafeLinkedBlockingQueueTest {

    @Test
    void offerWhenMemoryAvailable() {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(1);
        boolean offered = queue.offer("hello");
        assertThat(offered).isTrue();
        assertThat(queue).contains("hello");
    }

    @Test
    void hasRemainedMemoryTrue() {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(1);
        assertThat(queue.hasRemainedMemory()).isTrue();
    }

    @Test
    void defaultRejectorIsDiscardPolicy() {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(1);
        assertThat(queue.getRejector()).isInstanceOf(DiscardPolicy.class);
    }

    @Test
    void setRejector() {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(1);
        AbortPolicy<String> abortPolicy = new AbortPolicy<>();
        queue.setRejector(abortPolicy);
        assertThat(queue.getRejector()).isSameAs(abortPolicy);
    }

    @Test
    void maxFreeMemoryGetterSetter() {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(100);
        assertThat(queue.getMaxFreeMemory()).isEqualTo(100);
        queue.setMaxFreeMemory(200);
        assertThat(queue.getMaxFreeMemory()).isEqualTo(200);
    }

    @Test
    void offerWithTimeout() throws InterruptedException {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(1);
        boolean offered = queue.offer("item", 1, TimeUnit.SECONDS);
        assertThat(offered).isTrue();
    }

    @Test
    void putWhenMemoryAvailable() throws InterruptedException {
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(1);
        queue.put("item");
        assertThat(queue).hasSize(1);
    }

    @Test
    void constructWithCollection() {
        java.util.List<String> items = java.util.List.of("a", "b", "c");
        MemorySafeLinkedBlockingQueue<String> queue = new MemorySafeLinkedBlockingQueue<>(items, 1);
        assertThat(queue).hasSize(3).contains("a", "b", "c");
    }
}
