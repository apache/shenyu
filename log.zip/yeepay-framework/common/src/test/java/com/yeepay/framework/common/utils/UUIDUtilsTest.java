package com.yeepay.framework.common.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

class UUIDUtilsTest {

    @Test
    void randomV4UUIDHas32Chars() {
        String uuid = UUIDUtils.randomV4UUID();
        assertThat(uuid).hasSize(32);
    }

    @Test
    void randomV4UUIDIsHex() {
        String uuid = UUIDUtils.randomV4UUID();
        assertThat(uuid).matches("[0-9a-f]{32}");
    }

    @Test
    void randomV4UUIDVersionBits() {
        String uuid = UUIDUtils.randomV4UUID();
        char versionChar = uuid.charAt(12);
        assertThat(versionChar).isEqualTo('4');
    }

    @Test
    void randomV4UUIDVariantBits() {
        String uuid = UUIDUtils.randomV4UUID();
        char variantChar = uuid.charAt(16);
        int variantNibble = Character.digit(variantChar, 16);
        assertThat(variantNibble & 0xC).isEqualTo(0x8);
    }

    @Test
    void randomV4UUIDUniqueness() {
        Set<String> uuids = new HashSet<>();
        for (int i = 0; i < 1000; i++) {
            uuids.add(UUIDUtils.randomV4UUID());
        }
        assertThat(uuids).hasSize(1000);
    }

    @Test
    void compressV4UUIDIsBase64UrlSafe() {
        String compressed = UUIDUtils.compressV4UUID();
        assertThat(compressed).matches("[A-Za-z0-9_-]+");
    }

    @Test
    void compressV4UUIDHasExpectedLength() {
        String compressed = UUIDUtils.compressV4UUID();
        assertThat(compressed).hasSize(22);
    }

    @Test
    void compressV4UUIDUniqueness() {
        Set<String> uuids = new HashSet<>();
        for (int i = 0; i < 1000; i++) {
            uuids.add(UUIDUtils.compressV4UUID());
        }
        assertThat(uuids).hasSize(1000);
    }
}
