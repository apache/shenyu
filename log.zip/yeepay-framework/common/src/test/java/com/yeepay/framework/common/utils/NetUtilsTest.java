package com.yeepay.framework.common.utils;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class NetUtilsTest {

    @Test
    void getLocalAddressReturnsNonEmpty() {
        String addr = NetUtils.getLocalAddress();
        assertThat(addr).isNotNull().isNotEmpty();
    }

    @Test
    void getLocalInetAddressNotNull() throws Exception {
        assertThat(NetUtils.getLocalInetAddress()).isNotNull();
    }

    @Test
    void getLocalAddressIsIpFormat() {
        String addr = NetUtils.getLocalAddress();
        assertThat(addr).matches("\\d+\\.\\d+\\.\\d+\\.\\d+|[0-9a-fA-F:]+");
    }
}
