package com.yeepay.framework.common.concurrent.queue;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.common.concurrent.threadpool.YeepayThreadPoolExecutor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class TaskQueueTest {

    private YeepayThreadPoolExecutor executor;

    @AfterEach
    void tearDown() {
        if (executor != null) {
            executor.shutdownNow();
        }
    }

    @Test
    void retryOfferOnShutdownExecutorThrows() {
        MemorySafeTaskQueue<Runnable> queue = new MemorySafeTaskQueue<>(1);
        executor = new YeepayThreadPoolExecutor(
                1,
                1,
                0,
                TimeUnit.SECONDS,
                queue,
                YeepayThreadFactory.create("retry-"),
                new ThreadPoolExecutor.AbortPolicy());
        executor.shutdown();
        assertThatThrownBy(() -> queue.retryOffer(() -> {}, 0, TimeUnit.MILLISECONDS))
                .isInstanceOf(RejectedExecutionException.class);
    }

    @Test
    void doOfferDelegatesToSuper() {
        MemorySafeTaskQueue<Runnable> queue = new MemorySafeTaskQueue<>(1);
        executor = new YeepayThreadPoolExecutor(
                1,
                2,
                0,
                TimeUnit.SECONDS,
                queue,
                YeepayThreadFactory.create("do-offer-"),
                new ThreadPoolExecutor.AbortPolicy());
        Runnable task = () -> {};
        boolean result = queue.doOffer(task);
        assertThat(result).isTrue();
    }

    @Test
    void executorGetterSetter() {
        MemorySafeTaskQueue<Runnable> queue = new MemorySafeTaskQueue<>(1);
        assertThat(queue.getExecutor()).isNull();
        executor = new YeepayThreadPoolExecutor(
                1,
                1,
                0,
                TimeUnit.SECONDS,
                queue,
                YeepayThreadFactory.create("gs-"),
                new ThreadPoolExecutor.AbortPolicy());
        assertThat(queue.getExecutor()).isSameAs(executor);
    }

    @Test
    void constructWithCollection() {
        java.util.List<Runnable> items = java.util.List.of(() -> {}, () -> {});
        MemorySafeTaskQueue<Runnable> queue = new MemorySafeTaskQueue<>(items, 1);
        assertThat(queue).hasSize(2);
    }
}
