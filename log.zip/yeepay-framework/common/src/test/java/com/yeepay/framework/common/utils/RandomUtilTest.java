package com.yeepay.framework.common.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.security.SecureRandom;
import java.util.Random;
import org.junit.jupiter.api.Test;

class RandomUtilTest {

    @Test
    void secureRandomReturnsSameInstance() {
        SecureRandom sr1 = RandomUtil.secureRandom();
        SecureRandom sr2 = RandomUtil.secureRandom();
        assertThat(sr1).isNotNull().isSameAs(sr2);
    }

    @Test
    void getRandomReturnsThreadLocalRandom() {
        Random r = RandomUtil.getRandom();
        assertThat(r).isNotNull();
    }

    @Test
    void secureRandomProducesBytes() {
        byte[] buf = new byte[16];
        RandomUtil.secureRandom().nextBytes(buf);
        boolean allZero = true;
        for (byte b : buf) {
            if (b != 0) {
                allZero = false;
                break;
            }
        }
        assertThat(allZero).isFalse();
    }
}
