package com.yeepay.framework.common.theadcontext;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class ThreadContextTypeTest {

    @Test
    void allValuesExist() {
        assertThat(ThreadContextType.values())
                .containsExactly(
                        ThreadContextType.WEB,
                        ThreadContextType.INTERFACE,
                        ThreadContextType.TASK,
                        ThreadContextType.MANUAL);
    }

    @Test
    void valueOfWorks() {
        assertThat(ThreadContextType.valueOf("WEB")).isEqualTo(ThreadContextType.WEB);
        assertThat(ThreadContextType.valueOf("INTERFACE")).isEqualTo(ThreadContextType.INTERFACE);
        assertThat(ThreadContextType.valueOf("TASK")).isEqualTo(ThreadContextType.TASK);
        assertThat(ThreadContextType.valueOf("MANUAL")).isEqualTo(ThreadContextType.MANUAL);
    }
}
