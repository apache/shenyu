package com.yeepay.framework.common.concurrent.threadpool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.LinkedList;
import java.util.Queue;
import org.junit.jupiter.api.Test;

class RejectorPoliciesTest {

    @Test
    void abortPolicyThrowsRejectException() {
        AbortPolicy<String> policy = new AbortPolicy<>();
        Queue<String> queue = new LinkedList<>();
        assertThatThrownBy(() -> policy.reject("item", queue)).isInstanceOf(RejectException.class);
    }

    @Test
    void discardPolicyDoesNothing() {
        DiscardPolicy<String> policy = new DiscardPolicy<>();
        Queue<String> queue = new LinkedList<>();
        queue.add("existing");
        policy.reject("new", queue);
        assertThat(queue).containsExactly("existing");
    }

    @Test
    void discardOldestPolicyRemovesOldest() {
        DiscardOldestPolicy<String> policy = new DiscardOldestPolicy<>();
        Queue<String> queue = new LinkedList<>();
        queue.add("old");
        queue.add("middle");
        policy.reject("new", queue);
        assertThat(queue).containsExactly("middle", "new");
    }

    @Test
    void discardOldestPolicyOnEmptyQueue() {
        DiscardOldestPolicy<String> policy = new DiscardOldestPolicy<>();
        Queue<String> queue = new LinkedList<>();
        policy.reject("new", queue);
        assertThat(queue).containsExactly("new");
    }
}
