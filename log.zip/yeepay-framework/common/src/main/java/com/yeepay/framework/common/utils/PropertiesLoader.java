package com.yeepay.framework.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.function.Consumer;

/**
 * Classpath 属性文件加载工具.
 *
 * <p>支持按「目录 + 文件名」的方式从 classpath 加载 {@link Properties}，
 * 适用于需要从多个候选路径依次查找配置文件的场景。
 *
 * <p>使用示例：
 * <pre>
 * // 加载 runtimecfg/redis.properties，找不到则抛异常
 * Properties props = PropertiesLoader.load("runtimecfg", "redis.properties");
 *
 * // 静默加载，找不到返回 null
 * Properties props = PropertiesLoader.loadQuietly("runtimecfg", "redis.properties");
 * </pre>
 */
public final class PropertiesLoader {

    private PropertiesLoader() {}

    /**
     * 从 classpath 加载属性文件.
     *
     * @param path     classpath 下的目录路径，为 {@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @return 加载后的 {@link Properties}
     * @throws IllegalArgumentException 文件在 classpath 中未找到
     * @throws IllegalStateException    读取文件发生 IO 异常
     */
    public static Properties load(final String path, final String filename) {
        String location = buildLocation(path, filename);
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(location);
        if (Objects.isNull(is)) {
            try {
                is = loadFileFromUserDir(path, filename);
            } catch (FileNotFoundException e) {
                try {
                    is = loadFileFromUserDirParent(path, filename);
                } catch (FileNotFoundException ex) {
                    throw new IllegalArgumentException("配置文件未找到: " + location);
                }
            }
        }
        try (InputStream in = is) {
            Properties props = new Properties();
            props.load(in);
            return props;
        } catch (IOException e) {
            throw new IllegalStateException("加载配置文件失败: " + location, e);
        }
    }

    /**
     * 从 classpath 加载属性文件（直接指定完整路径）.
     *
     * @param location classpath 下的完整路径
     * @return 加载后的 {@link Properties}
     * @throws IllegalArgumentException 文件在 classpath 中未找到
     * @throws IllegalStateException    读取文件发生 IO 异常
     */
    public static Properties load(final String location) {
        return load(null, location);
    }

    /**
     * 静默加载，文件不存在时返回 {@code null}（不抛异常）.
     *
     * @param path     classpath 下的目录路径，为 {@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @return 加载后的 {@link Properties}，文件不存在或读取失败时返回 {@code null}
     */
    public static Properties loadQuietly(final String path, final String filename) {
        String location = buildLocation(path, filename);
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(location);
        if (Objects.isNull(is)) {
            return null;
        }
        try (InputStream in = is) {
            Properties props = new Properties();
            props.load(in);
            return props;
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * 判断属性值是否存在且非空.
     *
     * @param props 属性集
     * @param key   属性 key
     * @return 存在且 trim 后非空返回 {@code true}
     */
    public static boolean hasKey(final Properties props, final String key) {
        String value = props.getProperty(key);
        return Objects.nonNull(value) && !value.trim().isEmpty();
    }

    /**
     * 属性值存在且非空时执行 setter.
     *
     * @param props  属性集
     * @param key    属性 key
     * @param setter 值消费者，接收 trim 后的字符串
     */
    public static void ifPresent(final Properties props, final String key, final Consumer<String> setter) {
        String value = props.getProperty(key);
        if (Objects.nonNull(value) && !value.trim().isEmpty()) {
            setter.accept(value.trim());
        }
    }

    /**
     * 按优先级依次尝试多个 key，第一个存在且非空的值执行 setter.
     *
     * @param props  属性集
     * @param setter 值消费者
     * @param keys   按优先级排列的候选 key
     */
    public static void ifPresentAny(final Properties props, final Consumer<String> setter, final String... keys) {
        for (String key : keys) {
            String value = props.getProperty(key);
            if (Objects.nonNull(value) && !value.trim().isEmpty()) {
                setter.accept(value.trim());
                return;
            }
        }
    }

    /**
     * 按逗号拆分并 trim 每个元素，忽略空串.
     *
     * @param value 逗号分隔的字符串
     * @return trim 后的非空元素列表
     */
    public static List<String> splitAndTrim(final String value) {
        List<String> result = new ArrayList<>();
        for (String s : value.split(",")) {
            String trimmed = s.trim();
            if (!trimmed.isEmpty()) {
                result.add(trimmed);
            }
        }
        return result;
    }

    private static String buildLocation(final String path, final String filename) {
        if (Objects.isNull(path) || path.trim().isEmpty()) {
            return filename;
        }
        String dir = path.trim();
        if (dir.endsWith("/")) {
            return dir + filename;
        }
        return dir + "/" + filename;
    }

    private static InputStream loadFileFromUserDir(String path, String fileName) throws FileNotFoundException {
        String userDir = System.getProperty("user.dir");
        String filePath = processFilePath(userDir, path, fileName);
        return new FileInputStream(filePath);
    }

    private static InputStream loadFileFromUserDirParent(String path, String fileName) throws FileNotFoundException {
        String userDir = System.getProperty("user.dir");
        int last = userDir.lastIndexOf(File.separator);
        if (last > 0) {
            userDir = userDir.substring(0, last);
        }
        String filePath = processFilePath(userDir, path, fileName);
        return new FileInputStream(filePath);
    }

    private static String processFilePath(String userDir, String path, String fileName) {
        String location = buildLocation(path, fileName);
        if (location.startsWith("/")) {
            location = location.substring(1);
        }
        location = location.replace("/", File.separator);
        return userDir + File.separator + location;
    }
}
