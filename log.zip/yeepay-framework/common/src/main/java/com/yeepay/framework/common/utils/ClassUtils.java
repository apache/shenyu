package com.yeepay.framework.common.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * 类工具类.
 */
public class ClassUtils {

    /**
     * 基础类型集合.
     */
    private static final Set<Class<?>> BASIC_CLASS = new HashSet<>();

    /**
     * Instantiates a new Class utils.
     */
    public ClassUtils() {}

    static {
        BASIC_CLASS.add(Integer.TYPE);
        BASIC_CLASS.add(Double.TYPE);
        BASIC_CLASS.add(Float.TYPE);
        BASIC_CLASS.add(Byte.TYPE);
        BASIC_CLASS.add(Short.TYPE);
        BASIC_CLASS.add(Character.TYPE);
        BASIC_CLASS.add(String.class);
    }

    /**
     * Gets annotation.
     *
     * @param <T>        the type parameter
     * @param clazz      the clazz
     * @param annotation the annotation
     * @return the annotation
     */
    public static <T extends Annotation> T getAnnotation(Class<?> clazz, Class<T> annotation) {
        T ann = clazz.getAnnotation(annotation);
        return Objects.nonNull(ann)
                ? ann
                : (clazz.getSuperclass() != Object.class ? getAnnotation(clazz.getSuperclass(), annotation) : ann);
    }

    /**
     * Gets annotation.
     *
     * @param <T>        the type parameter
     * @param method     the method
     * @param annotation the annotation
     * @return the annotation
     */
    public static <T extends Annotation> T getAnnotation(Method method, Class<T> annotation) {
        T ann = method.getAnnotation(annotation);
        if (Objects.nonNull(ann)) {
            return ann;
        } else {
            Class<?> clazz = method.getDeclaringClass();
            Class<?> superClass = clazz.getSuperclass();
            if (superClass != Object.class) {
                try {
                    Method suMethod = superClass.getMethod(method.getName(), method.getParameterTypes());
                    return getAnnotation(suMethod, annotation);
                } catch (NoSuchMethodException exception) {
                    return null;
                }
            } else {
                return ann;
            }
        }
    }

    /**
     * Gets generic type by type.
     *
     * @param genType the gen type
     * @param index   the index
     * @return the generic type by type
     */
    public static Class<?> getGenericTypeByType(ParameterizedType genType, int index) {
        Type[] params = genType.getActualTypeArguments();
        if (index < params.length && index >= 0) {
            Object res = params[index];
            return res instanceof Class
                    ? (Class<?>) res
                    : (res instanceof ParameterizedType ? (Class<?>) ((ParameterizedType) res).getRawType() : null);
        } else {
            return null;
        }
    }

    /**
     * Gets generic type.
     *
     * @param clazz the clazz
     * @param index the index
     * @return the generic type
     */
    public static Class<?> getGenericType(Class<?> clazz, int index) {
        List<Type> arrays = new ArrayList<>();
        arrays.add(clazz.getGenericSuperclass());
        arrays.addAll(Arrays.asList(clazz.getGenericInterfaces()));
        return arrays.stream()
                .filter(Objects::nonNull)
                .map(type -> clazz != Object.class && !(type instanceof ParameterizedType)
                        ? getGenericType(clazz.getSuperclass(), index)
                        : getGenericTypeByType((ParameterizedType) type, index))
                .filter(Objects::nonNull)
                .filter(res -> res != Object.class)
                .findFirst()
                .orElse(Object.class);
    }

    /**
     * Gets generic type.
     *
     * @param clazz the clazz
     * @return the generic type
     */
    public static Class<?> getGenericType(Class<?> clazz) {
        return getGenericType(clazz, 0);
    }

    /**
     * Instance of boolean.
     *
     * @param clazz  the clazz
     * @param target the target
     * @return the boolean
     */
    public static boolean instanceOf(Class<?> clazz, Class<?> target) {
        if (Objects.isNull(clazz)) {
            return false;
        } else if (clazz == target) {
            return true;
        } else {
            Class<?>[] var2;
            int var3;
            int var4;
            Class<?> aClass;
            if (target.isInterface()) {
                var2 = clazz.getInterfaces();
                var3 = var2.length;

                for (var4 = 0; var4 < var3; ++var4) {
                    aClass = var2[var4];
                    if (aClass == target) {
                        return true;
                    }
                }
            }

            if (clazz.getSuperclass() == target) {
                return true;
            } else {
                if (clazz.isInterface()) {
                    var2 = clazz.getInterfaces();
                    var3 = var2.length;

                    for (var4 = 0; var4 < var3; ++var4) {
                        aClass = var2[var4];
                        if (instanceOf(aClass, target)) {
                            return true;
                        }
                    }
                }

                return instanceOf(clazz.getSuperclass(), target);
            }
        }
    }

    /**
     * Is basic class boolean.
     *
     * @param clazz the clazz
     * @return the boolean
     */
    public static boolean isBasicClass(Class<?> clazz) {
        return BASIC_CLASS.contains(clazz);
    }
}
