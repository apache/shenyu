package com.yeepay.framework.common.constants;

/**
 * The interface Common constants.
 */
public interface CommonConstants {

    /**
     * The constant PREFIX.
     */
    String PREFIX = "yeepay.framework";

    /**
     * Init.
     */
    default void init() {}
}
