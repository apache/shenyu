package com.yeepay.framework.common.utils;

import java.util.Objects;

/**
 * 枚举工具类.
 */
public class EnumUtils {

    /**
     * 检查是否为枚举类型.
     *
     * @param targetType the target type
     */
    public static void isEnumType(Class<?> targetType) {
        if (Objects.isNull(targetType)) {
            throw new IllegalArgumentException("The target type  is null");
        }
        if (!targetType.isEnum()) {
            throw new IllegalArgumentException(
                    "The target type " + targetType.getName() + " does not refer to an enum");
        }
    }
}
