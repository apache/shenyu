package com.yeepay.framework.common.theadcontext;

/**
 * 线程类型枚举.
 */
public enum ThreadContextType {

    /**
     * 产品层WEB请求的处理线程.
     */
    WEB,

    /**
     * 子系统接口请求的处理线程.
     */
    INTERFACE,

    /**
     * 通过线程组件创建的线程.
     */
    TASK,

    /**
     * 手动创建的线程.
     */
    MANUAL
}
