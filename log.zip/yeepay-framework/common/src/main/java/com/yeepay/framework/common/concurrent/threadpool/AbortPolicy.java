package com.yeepay.framework.common.concurrent.threadpool;

import java.util.Queue;

/**
 * A handler for rejected element that throws a
 * {@code RejectException}.
 *
 * @param <E> the type parameter
 */
public class AbortPolicy<E> implements Rejector<E> {

    @Override
    public void reject(final E e, final Queue<E> queue) {
        throw new RejectException("no more memory can be used !");
    }
}
