package com.yeepay.framework.common.concurrent.threadpool;

import java.util.Queue;

/**
 * A handler for rejected element that discards the oldest element.
 *
 * @param <E> the type parameter
 */
public class DiscardOldestPolicy<E> implements Rejector<E> {

    @Override
    public void reject(final E e, final Queue<E> queue) {
        queue.poll();
        queue.offer(e);
    }
}
