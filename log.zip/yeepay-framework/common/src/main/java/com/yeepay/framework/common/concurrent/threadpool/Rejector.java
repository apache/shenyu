package com.yeepay.framework.common.concurrent.threadpool;

import com.yeepay.framework.common.concurrent.queue.MemorySafeLinkedBlockingQueue;
import java.util.Queue;

/**
 * A {@link Rejector} is an object that may be used to reject an element.
 *
 * @param <E> the type parameter
 */
public interface Rejector<E> {

    /**
     * Method that may be invoked by a {@link MemorySafeLinkedBlockingQueue} when.
     * {@link MemorySafeLinkedBlockingQueue#hasRemainedMemory} return true.
     * This may occur when no more memory are available because their bounds would be exceeded.
     *
     * <p>In the absence of other alternatives, the method may throw an unchecked
     * {@link RejectException}, which will be propagated to the caller.
     *
     * @param e the element requested to be added
     * @param queue the queue attempting to add this element
     * @throws RejectException if there is no more memory
     */
    void reject(E e, Queue<E> queue);
}
