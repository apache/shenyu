package com.yeepay.framework.common.utils;

/**
 * UUID generator delegate for thread context.
 */
public final class UUIDGenerator {

    private UUIDGenerator() {}

    /**
     * Generate a random UUID string.
     *
     * @return 32-char hex UUID
     */
    public static String getUUID() {
        return UUIDUtils.randomV4UUID();
    }
}
