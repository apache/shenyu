package com.yeepay.framework.common.theadcontext;

import com.yeepay.framework.common.utils.UUIDGenerator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * 线程上下文对象.
 */
@Data
public class ThreadContext {

    /**
     * 应用名.
     */
    private String appName;

    /**
     * 线程请求唯一号(和线程号不同，每次运行都产生一个唯一号).
     */
    private String threadUID;

    /**
     * 线程请求唯一号(和线程号不同，每次运行都产生一个唯一号).
     */
    private String newThreadUID;

    /**
     * soa环境，用于指定跨环境.
     */
    private String soaEnv;

    /**
     * soa context.
     */
    private String soaContext;

    /**
     * 源soa服务应用名(消费者)，跨进程传递.
     */
    private String srcSoaApp;

    /**
     * 目标soa服务应用名，不跨进程传递.
     */
    private String dstSoaApp;

    /**
     * 线程启动时间.
     */
    private long threadStartTime;

    /**
     * 线程类型.
     */
    private ThreadContextType type;

    /**
     * 线程绑定参数.
     */
    private Map<String, Object> threadValues;

    /**
     * 调用层级顺序.
     */
    private int transferLevelCount = 1;

    private String transferLevel;

    private String preTransferLevel;

    /**
     * 构造线程上下文.
     *
     * @param appName   应用名
     * @param sourceUID 来源唯一标识
     * @param ctxType   上下文类型
     */
    public ThreadContext(String appName, String sourceUID, ThreadContextType ctxType) {
        this(appName, sourceUID, ctxType, null, null, null, null, null);
    }

    /**
     * 构造线程上下文.
     *
     * @param appName       应用名
     * @param sourceUID     来源唯一标识
     * @param ctxType       上下文类型
     * @param transferLevel 调用层级
     */
    public ThreadContext(String appName, String sourceUID, ThreadContextType ctxType, String transferLevel) {
        this(appName, sourceUID, ctxType, transferLevel, null, null, null, null);
    }

    /**
     * 构造线程上下文.
     *
     * @param appName       应用名
     * @param sourceUID     来源唯一标识
     * @param ctxType       上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv        soa环境
     */
    public ThreadContext(
            String appName, String sourceUID, ThreadContextType ctxType, String transferLevel, String soaEnv) {
        this(appName, sourceUID, ctxType, transferLevel, soaEnv, null, null, null);
    }

    /**
     * 构造线程上下文.
     *
     * @param appName       应用名
     * @param sourceUID     来源唯一标识
     * @param ctxType       上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv        soa环境
     * @param srcSoaApp     源soa应用名
     */
    public ThreadContext(
            String appName,
            String sourceUID,
            ThreadContextType ctxType,
            String transferLevel,
            String soaEnv,
            String srcSoaApp) {
        this(appName, sourceUID, ctxType, transferLevel, soaEnv, srcSoaApp, null, null);
    }

    /**
     * 构造线程上下文.
     *
     * @param appName       应用名
     * @param sourceUID     来源唯一标识
     * @param ctxType       上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv        soa环境
     * @param srcSoaApp     源soa应用名
     * @param dstSoaApp     目标soa应用名
     */
    public ThreadContext(
            String appName,
            String sourceUID,
            ThreadContextType ctxType,
            String transferLevel,
            String soaEnv,
            String srcSoaApp,
            String dstSoaApp) {
        this(appName, sourceUID, ctxType, transferLevel, soaEnv, srcSoaApp, dstSoaApp, null);
    }

    /**
     * 构造线程上下文(全参数).
     *
     * @param appName       应用名
     * @param sourceUID     来源唯一标识
     * @param ctxType       上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv        soa环境
     * @param srcSoaApp     源soa应用名
     * @param dstSoaApp     目标soa应用名
     * @param soaContext    soa上下文
     */
    public ThreadContext(
            String appName,
            String sourceUID,
            ThreadContextType ctxType,
            String transferLevel,
            String soaEnv,
            String srcSoaApp,
            String dstSoaApp,
            String soaContext) {
        this.appName = appName;
        initThreadUID(sourceUID);
        this.type = ctxType;
        this.preTransferLevel = transferLevel;
        this.transferLevel = transferLevel;
        this.soaEnv = soaEnv;
        this.srcSoaApp = srcSoaApp;
        this.dstSoaApp = dstSoaApp;
        this.soaContext = soaContext;
        this.threadStartTime = System.currentTimeMillis();
    }

    /**
     * 提升调用层级并返回当前层级.
     *
     * @return 当前调用层级
     */
    public String upTransferLevel() {
        if (Objects.isNull(this.preTransferLevel)) {
            this.preTransferLevel = "1";
            this.transferLevel = "1";
            return this.transferLevel;
        }

        if (this.preTransferLevel.length() == 1) {
            this.transferLevel = (this.transferLevelCount++) + ".1";
        } else if (this.preTransferLevel.contains(".1")) {
            String prefix = this.preTransferLevel.substring(0, this.preTransferLevel.lastIndexOf(".1"));
            this.transferLevel = prefix + "." + (++this.transferLevelCount) + ".1";
        } else {
            this.preTransferLevel = "1";
            this.transferLevel = "1";
        }
        return this.transferLevel;
    }

    /**
     * 添加线程绑定参数.
     *
     * @param key   参数键
     * @param value 参数值
     */
    public void addValue(String key, Object value) {
        if (Objects.isNull(threadValues)) {
            threadValues = new HashMap<>();
        }
        threadValues.put(key, value);
    }

    /**
     * 获取线程参数.
     *
     * @param key 参数键
     * @return 参数值
     */
    public Object getValue(String key) {
        return Objects.isNull(threadValues) ? null : threadValues.get(key);
    }

    /**
     * 移除指定线程绑定参数.
     *
     * @param key 参数键
     */
    public void removeValue(String key) {
        if (Objects.nonNull(threadValues)) {
            threadValues.remove(key);
        }
    }

    /**
     * 清除所有线程绑定参数.
     */
    public void removeValue() {
        if (Objects.nonNull(threadValues)) {
            threadValues.clear();
        }
    }

    private void initThreadUID(String sourceUID) {
        if (StringUtils.isEmpty(sourceUID)) {
            this.threadUID = UUIDGenerator.getUUID();
        } else {
            this.threadUID = sourceUID;
            this.newThreadUID = UUIDGenerator.getUUID();
        }
    }
}
