package com.yeepay.framework.common.utils.number;

import java.math.BigDecimal;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * BigDecimal 安全校验器，通过总长度和科学计数法指数值两个维度防止超大数字攻击.
 *
 * @since 1.2.20
 */
@Slf4j
public class BigDecimalSafetyValidator {

    private static final String ERROR_LENGTH = "Input too long: length %d exceeds maximum %d";

    private static final String ERROR_EXPONENT = "Exponent too large: absolute value %d exceeds maximum %d";

    /**
     * 科学计数法允许的最大指数绝对值，防止 {@code 5e+300}、{@code 1e9999} 等超大指数攻击.
     *
     * <p>例如设置为 5 表示指数范围为 [-5, 5]，即 {@code e5} 合法，{@code e+6} 不合法.
     */
    private final int exponent;

    /**
     * 输入字符串的最大总长度，防止超长字符串消耗内存.
     */
    private final int maxLength;

    /**
     * Instantiates a new Big decimal safety validator.
     *
     * @param exponent the exponent
     * @param maxLength the max length
     */
    public BigDecimalSafetyValidator(int exponent, int maxLength) {
        this.exponent = exponent;
        this.maxLength = maxLength;
    }

    /**
     * 安全解析 BigDecimal 字符串，校验总长度和指数值.
     *
     * @param text the text
     * @return the big decimal, or null if blank
     */
    public BigDecimal parseBigDecimal(String text) {
        if (StringUtils.isBlank(text)) {
            return null;
        }
        if (text.length() > maxLength) {
            log.error("BigDecimal {} 输入超长，原始长度：{}，最大允许：{}", text, text.length(), maxLength);
            throw new IllegalStateException(String.format(ERROR_LENGTH, text.length(), maxLength));
        }
        int eIndex = indexOfExponent(text);
        if (eIndex >= 0 && eIndex < text.length() - 1) {
            String expPart = text.substring(eIndex + 1);
            if (!expPart.isEmpty() && (expPart.charAt(0) == '+' || expPart.charAt(0) == '-')) {
                expPart = expPart.substring(1);
            }
            int expValue = parseExponentValue(expPart);
            if (expValue > exponent) {
                log.error("BigDecimal {}, 指数部分过大，指数绝对值：{}，最大允许：{}", text, expValue, exponent);
                throw new IllegalStateException(String.format(ERROR_EXPONENT, expValue, exponent));
            }
        }
        return new BigDecimal(text);
    }

    private static int parseExponentValue(String expPart) {
        if (expPart.isEmpty()) {
            return 0;
        }
        return Integer.parseInt(expPart);
    }

    private static int indexOfExponent(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == 'e' || text.charAt(i) == 'E') {
                return i;
            }
        }
        return -1;
    }
}
