package com.yeepay.framework.common.theadcontext;

import java.util.concurrent.Callable;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * The type Scheduled thread context pool executor.
 */
public class ScheduledThreadContextPoolExecutor extends ScheduledThreadPoolExecutor implements ThreadContextWrapper {

    /**
     * Instantiates a new Scheduled thread context pool executor.
     *
     * @param corePoolSize the core pool size
     */
    public ScheduledThreadContextPoolExecutor(int corePoolSize) {
        super(corePoolSize);
    }

    /**
     * Instantiates a new Scheduled thread context pool executor.
     *
     * @param corePoolSize the core pool size
     * @param threadFactory the thread factory
     */
    public ScheduledThreadContextPoolExecutor(int corePoolSize, ThreadFactory threadFactory) {
        super(corePoolSize, threadFactory);
    }

    /**
     * Instantiates a new Scheduled thread context pool executor.
     *
     * @param corePoolSize the core pool size
     * @param handler the handler
     */
    public ScheduledThreadContextPoolExecutor(int corePoolSize, RejectedExecutionHandler handler) {
        super(corePoolSize, handler);
    }

    /**
     * Instantiates a new Scheduled thread context pool executor.
     *
     * @param corePoolSize the core pool size
     * @param threadFactory the thread factory
     * @param handler the handler
     */
    public ScheduledThreadContextPoolExecutor(
            int corePoolSize, ThreadFactory threadFactory, RejectedExecutionHandler handler) {
        super(corePoolSize, threadFactory, handler);
    }

    @Override
    public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
        return super.schedule(wrap(command, ThreadContextUtils.getContext()), delay, unit);
    }

    @Override
    public <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
        return super.schedule(wrap(callable, ThreadContextUtils.getContext()), delay, unit);
    }

    @Override
    public ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
        return super.scheduleAtFixedRate(wrap(command, ThreadContextUtils.getContext()), initialDelay, period, unit);
    }

    @Override
    public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
        return super.scheduleWithFixedDelay(wrap(command, ThreadContextUtils.getContext()), initialDelay, delay, unit);
    }
}
