package com.yeepay.framework.common.utils.number;

import java.math.BigDecimal;

/**
 * The type Big decimal utils.
 */
public class BigDecimalUtils {

    private static final BigDecimalSafetyValidator DEFAULT_VALIDATOR = new BigDecimalSafetyValidator(5, 500);

    /**
     * Parse big decimal.
     *
     * @param value the value
     * @return the big decimal
     */
    public static BigDecimal parseBigDecimal(String value) {
        return DEFAULT_VALIDATOR.parseBigDecimal(value);
    }
}
