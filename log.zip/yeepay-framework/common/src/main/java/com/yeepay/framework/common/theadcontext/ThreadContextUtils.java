package com.yeepay.framework.common.theadcontext;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;

/**
 * 线程环境变量工具.
 */
public class ThreadContextUtils {

    /**
     * 线程唯一标识键.
     */
    public static final String KEY_GUID = "_thread_uid";

    /**
     * 调用层级键.
     */
    public static final String KEY_TRANSFER_LEVEL = "_transfer_level";

    /**
     * 调用层级起始值.
     */
    public static final String KEY_TRANSFER_LEVEL_START_VAL = "1";

    /**
     * SOA环境键.
     */
    public static final String KEY_SOA_ENV = "_soa_env";

    /**
     * SOA上下文键.
     */
    public static final String KEY_SOA_CONTEXT = "_soa_context";

    /**
     * 源SOA应用键.
     */
    public static final String KEY_SRC_SOA_APP = "_src_soa_app";

    // WeakHashMap allows ClassLoader to be GC'd during hot-redeploy
    private static final Map<ClassLoader, String> APP_NAME_CACHE = Collections.synchronizedMap(new WeakHashMap<>());

    private static final ThreadLocal<ThreadContext> THREAD_CONTEXT = new ThreadLocal<>();

    /**
     * 清除当前线程上下文.
     */
    public static void clearContext() {
        THREAD_CONTEXT.remove();
    }

    /**
     * 初始化线程上下文(不指定应用名).
     *
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     * @deprecated 使用 {@link #initContext(String, String, ThreadContextType)} 替代
     */
    @Deprecated
    public static void initContext(String sourceUID, ThreadContextType type) {
        initContext(null, sourceUID, type);
    }

    /**
     * 初始化线程上下文.
     *
     * @param appName 应用名
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     */
    public static void initContext(String appName, String sourceUID, ThreadContextType type) {
        initContext(appName, sourceUID, type, KEY_TRANSFER_LEVEL_START_VAL);
    }

    /**
     * 初始化线程上下文(指定调用层级).
     *
     * @param appName 应用名
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     * @param transferLevel 调用层级
     */
    public static void initContext(String appName, String sourceUID, ThreadContextType type, String transferLevel) {
        String soaEnv = System.getProperty("dubbo.application.environment", "product");
        initContext(appName, sourceUID, type, transferLevel, soaEnv);
    }

    /**
     * 初始化线程上下文(指定SOA环境).
     *
     * @param appName 应用名
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv SOA环境
     */
    public static void initContext(
            String appName, String sourceUID, ThreadContextType type, String transferLevel, String soaEnv) {
        initContext(appName, sourceUID, type, transferLevel, soaEnv, null);
    }

    /**
     * 初始化线程上下文(指定源SOA应用).
     *
     * @param appName 应用名
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv SOA环境
     * @param srcSoaApp 源SOA应用名
     */
    public static void initContext(
            String appName,
            String sourceUID,
            ThreadContextType type,
            String transferLevel,
            String soaEnv,
            String srcSoaApp) {
        initContext(appName, sourceUID, type, transferLevel, soaEnv, srcSoaApp, null);
    }

    /**
     * 初始化线程上下文(指定目标SOA应用).
     *
     * @param appName 应用名
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv SOA环境
     * @param srcSoaApp 源SOA应用名
     * @param dstSoaApp 目标SOA应用名
     */
    public static void initContext(
            String appName,
            String sourceUID,
            ThreadContextType type,
            String transferLevel,
            String soaEnv,
            String srcSoaApp,
            String dstSoaApp) {
        initContext(appName, sourceUID, type, transferLevel, soaEnv, srcSoaApp, dstSoaApp, null);
    }

    /**
     * 初始化线程上下文(全参数).
     *
     * @param appName 应用名
     * @param sourceUID 来源唯一标识
     * @param type 上下文类型
     * @param transferLevel 调用层级
     * @param soaEnv SOA环境
     * @param srcSoaApp 源SOA应用名
     * @param dstSoaApp 目标SOA应用名
     * @param soaContext SOA上下文
     */
    public static void initContext(
            String appName,
            String sourceUID,
            ThreadContextType type,
            String transferLevel,
            String soaEnv,
            String srcSoaApp,
            String dstSoaApp,
            String soaContext) {
        if (Objects.nonNull(THREAD_CONTEXT.get())) {
            return;
        }
        String resolvedAppName = resolveAppName(appName);
        ThreadContext context = new ThreadContext(
                resolvedAppName, sourceUID, type, transferLevel, soaEnv, srcSoaApp, dstSoaApp, soaContext);
        THREAD_CONTEXT.set(context);
    }

    private static String resolveAppName(String appName) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        if (Objects.isNull(cl)) {
            return appName;
        }
        String cachedAppName = APP_NAME_CACHE.get(cl);
        if (isBlank(appName)) {
            return cachedAppName;
        }
        if (isBlank(cachedAppName) && !"monitor".equals(appName)) {
            APP_NAME_CACHE.put(cl, appName);
        }
        return appName;
    }

    private static boolean isBlank(String str) {
        if (Objects.isNull(str) || str.isEmpty()) {
            return true;
        }
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断当前线程上下文是否已初始化.
     *
     * @return 已初始化返回true
     */
    public static boolean contextInitialized() {
        return Objects.nonNull(THREAD_CONTEXT.get());
    }

    /**
     * 获取当前线程上下文.
     *
     * @return 线程上下文对象
     */
    public static ThreadContext getContext() {
        return THREAD_CONTEXT.get();
    }

    /**
     * Sets context.
     *
     * @param context the context
     */
    public static void setContext(ThreadContext context) {
        THREAD_CONTEXT.set(context);
    }

    /**
     * 获取当前类加载器缓存的应用名.
     *
     * @return 应用名
     */
    public static String getAppName() {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        return Objects.isNull(cl) ? null : APP_NAME_CACHE.get(cl);
    }
}
