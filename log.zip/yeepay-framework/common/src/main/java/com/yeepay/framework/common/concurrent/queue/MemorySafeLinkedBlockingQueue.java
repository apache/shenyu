package com.yeepay.framework.common.concurrent.queue;

import com.yeepay.framework.common.concurrent.MemoryLimitCalculator;
import com.yeepay.framework.common.concurrent.threadpool.DiscardPolicy;
import com.yeepay.framework.common.concurrent.threadpool.Rejector;
import java.util.Collection;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import lombok.Getter;
import lombok.Setter;

/**
 * Can completely solve the OOM problem caused by {@link LinkedBlockingQueue}.
 * does not depend on {@link java.lang.instrument.Instrumentation} and is easier to use than,
 *
 * @param <E> the type parameter
 */
@Getter
@Setter
public class MemorySafeLinkedBlockingQueue<E> extends LinkedBlockingQueue<E> {

    /**
     * The Max free memory.
     */
    private int maxFreeMemory;

    /**
     * The rejector.
     */
    private Rejector<E> rejector;

    /**
     * Instantiates a new Memory safe linked blocking queue.
     *
     * @param maxFreeMemory the max free memory
     */
    public MemorySafeLinkedBlockingQueue(final int maxFreeMemory) {
        super(Integer.MAX_VALUE);
        this.maxFreeMemory = maxFreeMemory;
        // default as DiscardPolicy to ensure compatibility with the old version
        this.rejector = new DiscardPolicy<>();
    }

    /**
     * Instantiates a new Memory safe linked blocking queue.
     *
     * @param c             the c
     * @param maxFreeMemory the max free memory
     */
    public MemorySafeLinkedBlockingQueue(final Collection<? extends E> c, final int maxFreeMemory) {
        super(c);
        this.maxFreeMemory = maxFreeMemory;
        // default as DiscardPolicy to ensure compatibility with the old version
        this.rejector = new DiscardPolicy<>();
    }

    /**
     * determine if there is any remaining free memory.
     *
     * @return true if has free memory
     */
    public boolean hasRemainedMemory() {
        return MemoryLimitCalculator.maxAvailable() > maxFreeMemory;
    }

    @Override
    public void put(final E e) throws InterruptedException {
        if (hasRemainedMemory()) {
            super.put(e);
        }
        rejector.reject(e, this);
    }

    @Override
    public boolean offer(final E e, final long timeout, final TimeUnit unit) throws InterruptedException {
        if (!hasRemainedMemory()) {
            rejector.reject(e, this);
            return false;
        }
        return super.offer(e, timeout, unit);
    }

    @Override
    public boolean offer(final E e) {
        if (!hasRemainedMemory()) {
            rejector.reject(e, this);
            return false;
        }
        return super.offer(e);
    }
}
