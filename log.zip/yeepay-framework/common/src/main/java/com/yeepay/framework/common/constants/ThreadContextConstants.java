package com.yeepay.framework.common.constants;

/**
 * 线程上下文相关常量.
 */
public final class ThreadContextConstants {

    // -------- HTTP Header 名称 --------

    public static final String HEADER_THREAD_UID = "_thread_uid";

    public static final String HEADER_SOA_ENV = "_soa_env";

    public static final String HEADER_SOA_CONTEXT = "_soa_context";

    public static final String HEADER_SRC_SOA_APP = "_src_soa_app";

    public static final String HEADER_TRANSFER_LEVEL = "_transfer_level";

    public static final String HEADER_CDN_LANE = "x-yeepay-cdn-lane";

    public static final String HEADER_CDN_CONTEXT = "x-yeepay-cdn-context";

    // -------- Content-Type --------

    public static final String CONTENT_TYPE_HESSIAN = "x-application/hessian";

    public static final String CONTENT_TYPE_JAVA_SERIALIZED = "application/x-java-serialized-object";

    // -------- 系统属性 & 默认值 --------

    public static final String PROP_DUBBO_APP_ENV = "dubbo.application.environment";

    public static final String DEFAULT_SOA_ENV = "product";

    public static final String DEFAULT_TRANSFER_LEVEL = "1";

    private ThreadContextConstants() {}
}
