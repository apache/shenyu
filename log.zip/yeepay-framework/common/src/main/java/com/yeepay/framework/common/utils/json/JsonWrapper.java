package com.yeepay.framework.common.utils.json;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.StringTokenizer;
import lombok.Getter;

/**
 * 手动解释Json工具类.
 */
@Getter
public class JsonWrapper {

    /**
     * 根节点.
     */
    private final JsonNode root;

    /**
     * Instantiates a new Json wrapper.
     *
     * @param json the json
     * @throws Exception the exception
     */
    public JsonWrapper(String json) throws Exception {
        this.root = JsonUtils.toJsonTree(json);
    }

    /**
     * Instantiates a new Json wrapper.
     *
     * @param root the root
     */
    public JsonWrapper(JsonNode root) {
        this.root = root;
    }

    /**
     * 根据路径取值，如：{\"data\":{\"id\":1}}，wrapper.getValeByPath("data.id").
     *
     * @param path 节点路径，如：data.id
     * @return 节点字符串格式的值 value by path
     */
    public Optional<String> getValueByPath(String path) {
        Optional<JsonNode> node = getJsonNode(path);
        String value = null;
        if (node.isPresent()) {
            value = node.get().asText();
        }
        if ("null".equals(value)) {
            value = null;
        }
        return Objects.isNull(value) ? Optional.empty() : Optional.of(value);
    }

    /**
     * 根据路径节点，如：{\"data\":{\"id\":1}}，wrapper.getJsonNode("data.id").
     *
     * @param path 节点路径，如：data.id
     * @return 节点 json node
     */
    public Optional<JsonNode> getJsonNode(String path) {
        if (Objects.isNull(path) || path.isEmpty() || Objects.isNull(this.root)) {
            return Optional.empty();
        }
        JsonNode node = this.root;
        StringTokenizer st = new StringTokenizer(path, ".");
        while (st.hasMoreTokens()) {
            String nodeName = st.nextToken().trim();
            if (nodeName.isEmpty() || Objects.isNull(node = node.get(nodeName))) {
                return Optional.empty();
            }
        }
        return Optional.of(node);
    }

    /**
     * 根据路径节点数组.
     *
     * @param path 节点路径，如：data.id
     * @return 节点返回数组 node list
     */
    public List<JsonNode> getNodeList(String path) {
        Optional<JsonNode> node = getJsonNode(path);
        List<JsonNode> result = new ArrayList<JsonNode>();
        if (node.isEmpty()) {
            return result;
        }
        Iterator<JsonNode> iter = node.get().elements();
        while (iter.hasNext()) {
            result.add(iter.next());
        }
        return result;
    }

    /**
     * 根据路径节点数组.
     *
     * @param path 节点路径，如：data.id
     * @return 节点返回数组 list wrapper
     */
    public List<JsonWrapper> getListWrapper(String path) {
        Optional<JsonNode> node = getJsonNode(path);
        List<JsonWrapper> result = new ArrayList<>();
        if (node.isEmpty()) {
            return result;
        }
        Iterator<JsonNode> iter = node.get().elements();
        while (iter.hasNext()) {
            result.add(new JsonWrapper(iter.next()));
        }
        return result;
    }

    /**
     * 判断是否为空.
     *
     * @return 是否为空 boolean
     */
    public boolean isEmpty() {
        return Objects.isNull(this.root) || this.root.isEmpty();
    }
}
