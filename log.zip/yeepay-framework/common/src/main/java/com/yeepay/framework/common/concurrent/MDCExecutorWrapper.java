package com.yeepay.framework.common.concurrent;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import org.slf4j.MDC;

/**
 * The interface Mdc executor wrapper.
 */
public interface MDCExecutorWrapper {

    /**
     * Wrap callable.
     *
     * @param <T> the type parameter
     * @param callable the callable
     * @param context the context
     * @return the callable
     */
    default <T> Callable<T> wrap(final Callable<T> callable, final Map<String, String> context) {
        return () -> {
            if (Objects.isNull(context)) {
                MDC.clear();
            } else {
                MDC.setContextMap(context);
            }
            try {
                return callable.call();
            } finally {
                MDC.clear();
            }
        };
    }

    /**
     * Wrap runnable.
     *
     * @param runnable the runnable
     * @param context the context
     * @return the runnable
     */
    default Runnable wrap(final Runnable runnable, final Map<String, String> context) {
        return () -> {
            if (Objects.isNull(context)) {
                MDC.clear();
            } else {
                MDC.setContextMap(context);
            }
            try {
                runnable.run();
            } finally {
                MDC.clear();
            }
        };
    }
}
