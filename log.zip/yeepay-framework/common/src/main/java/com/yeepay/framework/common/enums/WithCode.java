package com.yeepay.framework.common.enums;

import com.yeepay.framework.common.utils.EnumUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * The interface With code.
 *
 * @param <T> the type parameter
 */
public interface WithCode<T> {

    /**
     * Gets code.
     *
     * @return the code
     */
    T getCode();

    /**
     * To code map.
     *
     * @param <K> the type parameter
     * @param <V> the type parameter
     * @param cls the cls
     * @return the map
     */
    static <K, V extends Enum<V> & WithCode<K>> Map<K, V> toCodeMap(Class<V> cls) {
        EnumUtils.isEnumType(cls);
        V[] enums = cls.getEnumConstants();
        if (Objects.isNull(enums)) {
            throw new IllegalArgumentException(cls.getName() + " does not represent an enum type.");
        }
        Map<K, V> codes = new HashMap<>(enums.length);
        for (V withCode : enums) {
            K code = withCode.getCode();
            if (codes.containsKey(code)) {
                throw new IllegalArgumentException("code: " + code + " is duplicate for " + cls.getName());
            }
            codes.put(code, withCode);
        }
        return codes;
    }
}
