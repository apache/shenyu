package com.yeepay.framework.common.concurrent.threadpool;

import java.util.Queue;

/**
 * A handler for rejected element that silently discards the
 * rejected element.
 *
 * @param <E> the type parameter
 */
public class DiscardPolicy<E> implements Rejector<E> {

    @Override
    public void reject(final E e, final Queue<E> queue) {}
}
