package com.yeepay.framework.common.exception;

import lombok.Getter;

/**
 * 框架统一运行时异常，携带业务错误码.
 */
@Getter
public class FrameworkException extends RuntimeException {

    /**
     * -- GETTER --
     *  获取业务错误码.
     *
     * @return 错误码
     */
    private final String errorCode;

    /**
     * 构造异常.
     *
     * @param errorCode 业务错误码
     * @param message   错误描述
     */
    public FrameworkException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    /**
     * 构造携带原始异常的框架异常.
     *
     * @param errorCode 业务错误码
     * @param message   错误描述
     * @param cause     原始异常
     */
    public FrameworkException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }
}
