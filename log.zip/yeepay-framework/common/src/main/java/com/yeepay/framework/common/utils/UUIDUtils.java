package com.yeepay.framework.common.utils;

import java.util.Base64;

/**
 * UUID generation utilities.
 */
public final class UUIDUtils {

    private UUIDUtils() {}

    private static String digits(long val, int digits) {
        long hi = 1L << (digits * 4);
        return Long.toHexString(hi | (val & (hi - 1))).substring(1);
    }

    /**
     * Generate a version 4 UUID (128bit).
     *
     * @return 32-char hex UUID without dashes
     */
    public static String randomV4UUID() {
        byte[] randomBytes = new byte[16];
        RandomUtil.secureRandom().nextBytes(randomBytes);
        randomBytes[6] &= 0x0f;
        randomBytes[6] |= 0x40;
        randomBytes[8] &= 0x3f;
        randomBytes[8] |= (byte) 0x80;

        long msb = 0;
        long lsb = 0;
        for (int i = 0; i < 8; i++) {
            msb = (msb << 8) | (randomBytes[i] & 0xff);
        }
        for (int i = 8; i < 16; i++) {
            lsb = (lsb << 8) | (randomBytes[i] & 0xff);
        }

        return digits(msb >> 32, 8) + digits(msb >> 16, 4) + digits(msb, 4) + digits(lsb >> 48, 4) + digits(lsb, 12);
    }

    /**
     * Generate a version 4 UUID in compressed Base64 form (88bit, 31.25% shorter, url safe).
     *
     * @return URL-safe Base64 encoded UUID without padding
     */
    public static String compressV4UUID() {
        byte[] randomBytes = new byte[16];
        RandomUtil.secureRandom().nextBytes(randomBytes);
        randomBytes[6] &= 0x0f;
        randomBytes[6] |= 0x40;
        randomBytes[8] &= 0x3f;
        randomBytes[8] |= (byte) 0x80;

        return Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);
    }
}
