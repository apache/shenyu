package com.yeepay.framework.common.utils;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The type Random util.
 */
public final class RandomUtil {

    private static final SecureRandom SECURE_RANDOM;

    static {
        SecureRandom sr;
        try {
            sr = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            sr = new SecureRandom();
        }
        SECURE_RANDOM = sr;
    }

    private RandomUtil() {}

    /**
     * Secure random.
     *
     * @return the secure random
     */
    public static SecureRandom secureRandom() {
        return SECURE_RANDOM;
    }

    /**
     * Gets random.
     *
     * @return the random
     */
    public static Random getRandom() {
        return ThreadLocalRandom.current();
    }
}
