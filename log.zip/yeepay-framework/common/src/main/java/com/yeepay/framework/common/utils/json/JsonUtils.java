package com.yeepay.framework.common.utils.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ValueNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
import java.io.IOException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

/**
 * The type Json util.
 */
public class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE = new TypeReference<>() {};

    static {
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(
                LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        javaTimeModule.addSerializer(
                LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        javaTimeModule.addSerializer(LocalTime.class, new LocalTimeSerializer(DateTimeFormatter.ofPattern("HH:mm:ss")));
        javaTimeModule.addDeserializer(
                LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        javaTimeModule.addDeserializer(
                LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        javaTimeModule.addDeserializer(
                LocalTime.class, new LocalTimeDeserializer(DateTimeFormatter.ofPattern("HH:mm:ss")));
        MAPPER.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
                .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
                .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
                .configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true)
                .configure(JsonReadFeature.ALLOW_UNESCAPED_CONTROL_CHARS.mappedFeature(), true)
                .setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))
                .registerModule(javaTimeModule)
                .addMixIn(Map.class, IgnoreType.class);
    }

    /**
     * 获取JavaType.
     *
     * @param type 类型
     * @return JavaType对象 java type
     */
    public static JavaType getJavaType(Type type) {
        return MAPPER.getTypeFactory().constructType(type);
    }

    /**
     * 读取值.
     *
     * @param <T>       泛型类型
     * @param json      JSON字符串
     * @param valueType 值类型
     * @return 结果对象 t
     * @throws IOException          IO异常
     * @throws JsonParseException   JSON解析异常
     * @throws JsonMappingException JSON映射异常
     */
    public static <T> T readValue(String json, JavaType valueType)
            throws IOException, JsonParseException, JsonMappingException {
        if (Objects.isNull(json) || json.isEmpty()) {
            return null;
        }
        return MAPPER.readValue(json, valueType);
    }

    /**
     * 将JSON字符串转化为指定类型.
     *
     * @param <T>  泛型类型
     * @param json json字符串
     * @param c    期望类型
     * @return T 结果
     */
    public static <T> T readValue(String json, Class<T> c) {
        T t = null;
        try {
            if (Objects.nonNull(json) && !json.trim().isEmpty()) {
                t = MAPPER.readValue(json, c);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return t;
    }

    /**
     * 将JSON字符串转化为指定类型.
     *
     * @param <T>  泛型类型
     * @param json json字符串
     * @param c    期望类型
     * @return T 结果
     */
    public static <T> T readValue(String json, TypeReference<T> c) {
        T t = null;
        try {
            if (Objects.nonNull(json) && !json.trim().isEmpty()) {
                t = MAPPER.readValue(json, c);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return t;
    }

    /**
     * 将JsonNode转化为指定类型.
     *
     * @param <T>  泛型类型
     * @param node JsonNode
     * @param c    期望类型
     * @return T 结果
     */
    public static <T> T readValue(JsonNode node, TypeReference<T> c) {
        T t = null;
        try {
            if (Objects.nonNull(node)) {
                ObjectReader reader = MAPPER.readerFor(c);
                t = reader.readValue(node);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return t;
    }

    /**
     * 生成JSON字符串.
     *
     * @param obj 对象
     * @return JSON字符串 string
     * @throws RuntimeException JSON处理异常
     */
    public static String objectToJson(Object obj) {
        if (Objects.isNull(obj)) {
            return null;
        }
        try {
            return MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 生成JSON字符串.
     *
     * @param obj               对象
     * @param serializationView 序列化视图
     * @return JSON字符串 string
     * @throws JsonProcessingException JSON处理异常
     */
    public static String objectToJson(Object obj, Class<?> serializationView) throws JsonProcessingException {
        if (Objects.isNull(obj)) {
            return null;
        }
        if (Objects.nonNull(serializationView)) {
            return MAPPER.writerWithView(serializationView).writeValueAsString(obj);
        } else {
            return MAPPER.writeValueAsString(obj);
        }
    }

    /**
     * 获取Json树.
     *
     * @param json JSON字符串
     * @return JsonNode对象 json node
     */
    public static JsonNode toJsonTree(String json) {
        try {
            if (Objects.nonNull(json) && !json.trim().isEmpty()) {
                return MAPPER.readTree(json);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    /**
     * 遍历JsonNode.
     *
     * @param node     JsonNode对象
     * @param consumer 处理函数
     */
    public static void jsonNodeForEach(JsonNode node, Function<ValueNode, ValueNode> consumer) {
        if (Objects.isNull(node)) {
            return;
        }
        if (node instanceof ObjectNode parentNode) {
            Iterator<Map.Entry<String, JsonNode>> iterator = node.fields();
            while (iterator.hasNext()) {
                Map.Entry<String, JsonNode> item = iterator.next();
                JsonNode itemValue = item.getValue();
                if (itemValue instanceof ValueNode valueNode) {
                    ValueNode temp = consumer.apply(valueNode);
                    if (Objects.isNull(temp)) {
                        parentNode.remove(item.getKey());
                    } else {
                        parentNode.replace(item.getKey(), temp);
                    }
                } else {
                    jsonNodeForEach(itemValue, consumer);
                }
            }
        } else if (node instanceof ArrayNode arrayNode) {
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode item = arrayNode.get(i);
                if (item instanceof ValueNode valueNode) {
                    ValueNode temp = consumer.apply(valueNode);
                    if (Objects.isNull(temp)) {
                        arrayNode.remove(i);
                    } else {
                        arrayNode.set(i, temp);
                    }
                } else {
                    jsonNodeForEach(item, consumer);
                }
            }
        }
    }

    @JsonIgnoreProperties("class")
    @interface IgnoreType {}
}
