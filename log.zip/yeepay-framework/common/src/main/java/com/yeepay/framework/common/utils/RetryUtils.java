package com.yeepay.framework.common.utils;

import java.util.Objects;
import java.util.function.Supplier;

/**
 * 本地重试工具类.
 */
public class RetryUtils {

    /**
     * 有返回值的重试任务.
     * @param maxRetries 最大重试次数
     * @param retryDelayMs 重试时间间隔
     * @param supplier 需要重试的任务
     * @param <V> V
     * @return V
     * @throws Throwable 最后一次执行时的异常
     */
    public static <V> V doRetry(int maxRetries, long retryDelayMs, Supplier<V> supplier) throws Throwable {
        int attempt = 0;
        Throwable ex;
        do {
            try {
                attempt++;
                return supplier.get();
            } catch (Throwable e) {
                ex = e;
            }
            try {
                Thread.sleep(retryDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw e;
            }
        } while (attempt < maxRetries);
        throw ex;
    }

    /**
     * 没有返回值的重试任务.
     * @param maxRetries 最大重试次数
     * @param retryDelayMs 重试时间间隔
     * @param runnable 需要重试的任务
     * @throws Throwable 最后一次执行时的异常
     */
    public static void doRetry(int maxRetries, long retryDelayMs, Runnable runnable) throws Throwable {
        int attempt = 0;
        Throwable ex = null;
        do {
            try {
                attempt++;
                runnable.run();
                break;
            } catch (Throwable e) {
                ex = e;
            }
            try {
                Thread.sleep(retryDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw e;
            }
        } while (attempt < maxRetries);
        if (Objects.nonNull(ex)) {
            throw ex;
        }
    }
}
