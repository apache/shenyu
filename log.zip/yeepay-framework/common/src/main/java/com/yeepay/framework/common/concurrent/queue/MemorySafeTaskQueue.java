package com.yeepay.framework.common.concurrent.queue;

import com.yeepay.framework.common.concurrent.EagerExecutorService;
import java.util.Collection;

/**
 * It offers a task if the executor's submittedTaskCount less than currentPoolThreadSize
 * or the currentPoolThreadSize more than executor's maximumPoolSize.
 * That can make the executor create new worker
 * when the task num is bigger than corePoolSize but less than maximumPoolSize.
 *
 * @param <R> the type parameter
 */
public class MemorySafeTaskQueue<R extends Runnable> extends MemorySafeLinkedBlockingQueue<Runnable>
        implements TaskQueue<Runnable> {

    /**
     * The Executor.
     */
    private EagerExecutorService executor;

    /**
     * Instantiates a new Memory safe task queue.
     *
     * @param maxFreeMemory the max free memory
     */
    public MemorySafeTaskQueue(final int maxFreeMemory) {
        super(maxFreeMemory);
    }

    /**
     * Instantiates a new Memory safe task queue.
     *
     * @param c             the c
     * @param maxFreeMemory the max free memory
     */
    public MemorySafeTaskQueue(final Collection<? extends Runnable> c, final int maxFreeMemory) {
        super(c, maxFreeMemory);
    }

    @Override
    public EagerExecutorService getExecutor() {
        return this.executor;
    }

    @Override
    public void setExecutor(final EagerExecutorService executor) {
        this.executor = executor;
    }

    @Override
    public boolean doOffer(final Runnable runnable) {
        return super.offer(runnable);
    }
}
