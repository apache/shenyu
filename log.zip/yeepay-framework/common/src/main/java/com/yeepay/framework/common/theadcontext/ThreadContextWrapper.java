package com.yeepay.framework.common.theadcontext;

import java.util.Objects;
import java.util.concurrent.Callable;

/**
 * The  thread context wrapper.
 */
public interface ThreadContextWrapper {

    /**
     * Wrap callable.
     *
     * @param <T> the type parameter
     * @param callable the callable
     * @param context the context
     * @return the callable
     */
    default <T> Callable<T> wrap(final Callable<T> callable, final ThreadContext context) {
        return () -> {
            if (Objects.isNull(context)) {
                ThreadContextUtils.clearContext();
            } else {
                ThreadContextUtils.setContext(context);
            }
            try {
                return callable.call();
            } finally {
                ThreadContextUtils.clearContext();
            }
        };
    }

    /**
     * Wrap runnable.
     *
     * @param runnable the runnable
     * @param context the context
     * @return the runnable
     */
    default Runnable wrap(final Runnable runnable, final ThreadContext context) {
        return () -> {
            if (Objects.isNull(context)) {
                ThreadContextUtils.clearContext();
            } else {
                ThreadContextUtils.setContext(context);
            }
            try {
                runnable.run();
            } finally {
                ThreadContextUtils.clearContext();
            }
        };
    }
}
