# 通用工具 (Common)

## 概述

Common 模块是框架的最底层基础设施
## 快速开始

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>common</artifactId>
</dependency>
```

Common 作为所有其他模块的传递依赖，通常不需要显式引入。但如果你的项目仅需使用 `ThreadContext`、`Result` 或线程池工具类，可以直接引入。

## 一、ThreadContext 线程上下文

### 1.1 核心概念

| 类 | 作用 |
|----|------|
| `ThreadContext` | 线程级请求上下文 POJO，携带 GUID、SOA 环境、应用名、调用层级等信息 |
| `ThreadContextUtils` | 基于 `ThreadLocal` 的上下文管理器，提供 init/get/clear |
| `ThreadContextType` | 枚举：`WEB` / `INTERFACE` / `TASK` / `MANUAL` |
| `ThreadContextConstants` | HTTP 请求头名、Content-Type、系统属性名等常量 |
| `ThreadContextWrapper` | 上下文传播 mixin 接口，提供 `wrap(Runnable/Callable)` 默认方法 |
| `ThreadContextPoolExecutor` | 自动传播 ThreadContext 的线程池 |
| `ScheduledThreadContextPoolExecutor` | 自动传播 ThreadContext 的调度线程池 |

### 1.2 ThreadContext 字段速查

| 字段 | 类型 | 说明 |
|------|------|------|
| `threadUID` | `String` | 全局唯一请求 ID（UUID v4，32 位 hex，无横线） |
| `newThreadUID` | `String` | 同上；在继承场景下区分原始 UID 和新 UID |
| `appName` | `String` | 当前应用名 |
| `type` | `ThreadContextType` | 上下文来源：`WEB`（HTTP 请求）/ `INTERFACE`（内部 RPC）/ `TASK`（框架线程池）/ `MANUAL`（手动创建） |
| `soaEnv` | `String` | SOA 环境标识（如 `product`、`staging`、灰度泳道名） |
| `soaContext` | `String` | SOA 上下文元数据 |
| `srcSoaApp` | `String` | 上游调用方应用名（跨进程传播） |
| `dstSoaApp` | `String` | 下游目标应用名（仅本进程使用） |
| `transferLevel` | `String` | 当前调用层级（默认 `"1"`） |
| `preTransferLevel` | `String` | 上一调用层级 |
| `transferLevelCount` | `int` | 层级计数器（默认 1） |
| `threadStartTime` | `long` | 上下文创建时间戳（`System.currentTimeMillis()`） |
| `threadValues` | `Map<String, Object>` | 任意扩展键值对（lazy-initialized HashMap） |

`ThreadContext` 有 7 个重载构造器，从 3 参数到 8 参数逐级叠加。所有字段通过 Lombok `@Data` 生成 getter/setter。

### 1.3 ThreadContextUtils 使用方式

```java
// 获取当前线程的上下文
ThreadContext ctx = ThreadContextUtils.getContext();

// 判断上下文是否已初始化
if (ThreadContextUtils.contextInitialized()) { ... }

// 最简初始化（8 参数全量版本）
ThreadContextUtils.initContext(
    "order-service",                              // appName
    UUIDGenerator.getUUID(),                      // guid
    ThreadContextType.WEB,                        // contextType
    "1",                                          // transferLevel
    "product",                                    // soaEnv
    "gateway-service",                            // srcSoaApp
    "",                                           // dstSoaApp
    ""                                            // soaContext
);

// 清理上下文
ThreadContextUtils.clearContext();
```

**关键行为：**
- `initContext` 有首次写入获胜语义：如果 `ThreadLocal` 上已有上下文，后续调用是空操作，不会覆盖。
- `clearContext` 移除 `ThreadLocal` 中的上下文。
- `resolveAppName` 使用 `WeakHashMap<ClassLoader, String>` 缓存应用名，支持热部署场景下 ClassLoader 被 GC 回收。

### 1.4 上下文传播

`ThreadContextWrapper` 提供 `wrap(Runnable)` 和 `wrap(Callable)` 默认方法，捕获提交时刻的上下文快照，在 worker 线程执行前恢复，执行后清理。

**标准线程池：**

```java
// ThreadContext 自动从父线程传播到子线程
ExecutorService executor = new ThreadContextPoolExecutor(
    10, 20, 60, TimeUnit.SECONDS,
    new LinkedBlockingQueue<>(1000)
);

executor.submit(() -> {
    ThreadContext ctx = ThreadContextUtils.getContext();
    // ctx 与提交任务的线程完全一致
});
```

**调度线程池：**

```java
ScheduledExecutorService scheduler = new ScheduledThreadContextPoolExecutor(4);

scheduler.scheduleAtFixedRate(() -> {
    // 定时任务中也能获取到提交时刻的 ThreadContext 快照
    String uid = ThreadContextUtils.getContext().getThreadUID();
}, 0, 10, TimeUnit.SECONDS);
```

> **注意：** 定时任务在提交时刻捕获一次上下文，后续每次执行复用同一份快照，不会在执行时刷新。

### 1.5 手动管理上下文

非 Web/线程池场景（定时任务入口、MQ 消费、启动初始化）：

```java
public void handleMessage(Message msg) {
    ThreadContextUtils.initContext(
        "consumer-app",
        UUIDGenerator.getUUID(),
        ThreadContextType.MANUAL,
        "1",
        System.getProperty("dubbo.application.environment", "product"),
        "",
        "",
        ""
    );
    try {
        processMessage(msg);
    } finally {
        ThreadContextUtils.clearContext(); // 必须清理
    }
}
```

### 1.6 扩展键值对

```java
ThreadContext ctx = ThreadContextUtils.getContext();
ctx.addValue("businessLine", "payment");
ctx.addValue("featureFlag", "new_checkout");

// 下游代码读取
String biz = (String) ctx.getValue("businessLine");
ctx.removeValue("featureFlag");
ctx.removeValue(); // 清空全部扩展值
```

### 1.7 调用层级追踪

```java
ThreadContext ctx = ThreadContextUtils.getContext();
String level = ctx.upTransferLevel();
// "1" → "1.1", "1.1" → "1.2", "1.1.1" → "1.1.2"
```

使用点号分隔的层级体系，每次调用 `upTransferLevel()` 递增最末段序号。

### 1.8 ThreadContextConstants — 请求头常量

| 常量 | 值 | 说明 |
|------|----|------|
| `HEADER_THREAD_UID` | `_thread_uid` | 全链路追踪 ID |
| `HEADER_SOA_ENV` | `_soa_env` | SOA 环境标识 |
| `HEADER_SOA_CONTEXT` | `_soa_context` | SOA 上下文 |
| `HEADER_SRC_SOA_APP` | `_src_soa_app` | 上游应用名 |
| `HEADER_TRANSFER_LEVEL` | `_transfer_level` | 调用层级 |
| `HEADER_CDN_LANE` | `x-yeepay-cdn-lane` | CDN 灰度泳道 |
| `HEADER_CDN_CONTEXT` | `x-yeepay-cdn-context` | CDN 上下文 |
| `CONTENT_TYPE_HESSIAN` | `x-application/hessian` | Hessian 序列化类型 |
| `CONTENT_TYPE_JAVA_SERIALIZED` | `application/x-java-serialized-object` | Java 序列化类型 |
| `PROP_DUBBO_APP_ENV` | `dubbo.application.environment` | Dubbo 环境系统属性 |
| `DEFAULT_SOA_ENV` | `product` | 默认 SOA 环境 |
| `DEFAULT_TRANSFER_LEVEL` | `1` | 默认调用层级 |

---

## 二、线程池与任务队列

### 2.1 核心概念

| 类 | 作用 |
|----|------|
| `YeepayThreadPoolExecutor` | 急切线程池：优先创建线程到 max 再入队 |
| `YeepayMdcThreadPoolExecutor` | 急切线程池 + SLF4J MDC 自动传播 |
| `ThreadContextPoolExecutor` | 标准线程池 + ThreadContext 自动传播 |
| `ScheduledThreadContextPoolExecutor` | 调度线程池 + ThreadContext 自动传播 |
| `TaskQueue<E>` | SPI 接口，急切入队决策算法 |
| `MemorySafeLinkedBlockingQueue<E>` | 有内存保护的 LinkedBlockingQueue |
| `MemorySafeTaskQueue` | MemorySafeLinkedBlockingQueue + TaskQueue 的组合 |
| `MemoryLimitCalculator` | 后台刷新 JVM 空闲内存（每 50ms） |
| `Rejector<E>` | SPI 接口，内存不足时的拒绝策略 |
| `YeepayThreadFactory` | 统一线程工厂（"yeepay" 线程组） |
| `EagerExecutorService` | SPI 接口，暴露线程池状态给 TaskQueue |

### 2.2 YeepayThreadPoolExecutor — 急切线程池

标准 `ThreadPoolExecutor` 在达到 corePoolSize 后直接将任务入队，不创建新线程。`YeepayThreadPoolExecutor` 翻转这一逻辑：**优先创建新线程直到 maximumPoolSize，然后才入队**。这能更快响应突发流量。

```java
TaskQueue<Runnable> queue = new MemorySafeTaskQueue(16 * 1024 * 1024); // 16MB 阈值
ExecutorService executor = new YeepayThreadPoolExecutor(
    10, 50, 60, TimeUnit.SECONDS,
    queue,
    YeepayThreadFactory.create("biz", false),
    new ThreadPoolExecutor.CallerRunsPolicy()
);
```

**重试机制：** `execute` 方法捕获 `RejectedExecutionException` 后，会调用 `queue.retryOffer()` 再尝试入队一次，失败了才抛出异常。这样在队列刚满、线程数未达上限时不会立刻拒绝。

### 2.3 ThreadContextPoolExecutor — 上下文传播线程池

标准线程池在子线程中丢失 `ThreadContext`。使用 `ThreadContextPoolExecutor` 替代：

```java
ExecutorService executor = new ThreadContextPoolExecutor(
    10, 20, 60, TimeUnit.SECONDS,
    new LinkedBlockingQueue<>(1000)
);
executor.submit(() -> {
    // 子线程自动继承父线程的 ThreadContext
});
```

注意这是标准 `ThreadPoolExecutor`（非急切模式），不包含 retryOffer 逻辑。

### 2.4 YeepayMdcThreadPoolExecutor — MDC 传播线程池

```java
ExecutorService executor = new YeepayMdcThreadPoolExecutor(
    10, 50, 60, TimeUnit.SECONDS,
    new MemorySafeTaskQueue(16 * 1024 * 1024),
    YeepayThreadFactory.create("mdc", false),
    new ThreadPoolExecutor.CallerRunsPolicy()
);
executor.submit(() -> {
    // 子线程自动继承父线程的 MDC
    log.info("MDC 中的 traceId 自动传递到子线程");
});
```

### 2.5 MemorySafeLinkedBlockingQueue — 内存保护队列

容量为 `Integer.MAX_VALUE` 的 LinkedBlockingQueue，但在入队前检查 JVM 空闲内存是否低于阈值。低于阈值时触发 `Rejector` 拒绝策略。

```java
MemorySafeLinkedBlockingQueue<Runnable> queue =
    new MemorySafeLinkedBlockingQueue<>(64 * 1024 * 1024); // 最少保留 64MB 空闲

queue.setRejector(new DiscardOldestPolicy<>()); // 内存不足时丢弃最老的任务
```

**三个内置拒绝策略：**

| 策略 | 行为 |
|------|------|
| `DiscardPolicy`（默认） | 静默丢弃新任务 |
| `AbortPolicy` | 抛出 `RejectException("no more memory can be used !")` |
| `DiscardOldestPolicy` | 丢弃队列头部（最老）任务，再插入新任务 |

自定义拒绝策略：

```java
queue.setRejector((e, q) -> {
    log.warn("内存不足，任务被拒绝，队列大小={}", q.size());
    // 自定义降级逻辑
});
```

### 2.6 MemorySafeTaskQueue — 组合队列

`MemorySafeLinkedBlockingQueue` + `TaskQueue` 的组合，同时拥有内存保护和急切线程创建两个特性。是 `YeepayThreadPoolExecutor` 的标准队列类型。

```java
MemorySafeTaskQueue queue = new MemorySafeTaskQueue(32 * 1024 * 1024);
// 通过 setExecutor() 关联线程池后，offer() 会先尝试创建新线程再入队
```

### 2.7 MemoryLimitCalculator — 内存监控

```java
// 当前 JVM 空闲内存（后台线程每 50ms 刷新一次）
long free = MemoryLimitCalculator.maxAvailable();

// 空闲内存的 80%
long limit = MemoryLimitCalculator.defaultLimit();

// 空闲内存的自定义百分比
long pct = MemoryLimitCalculator.calculate(0.5f); // 50%
```

首次调用时自动启动后台刷新线程（`ScheduledThreadPoolExecutor`，core=1），JVM 关闭时自动停止。

### 2.8 YeepayThreadFactory — 线程工厂

```java
// 非守护线程，普通优先级，名字格式 yeepay-biz-1
ThreadFactory tf1 = YeepayThreadFactory.create("biz");

// 守护线程
ThreadFactory tf2 = YeepayThreadFactory.create("daemon", true);

// 守护线程 + 自定义优先级
ThreadFactory tf3 = YeepayThreadFactory.create("low-prio", true, Thread.MIN_PRIORITY);
```

所有由此工厂创建的线程属于 `"yeepay"` ThreadGroup，名称为 `yeepay-{prefix}-{seq}`，seq 是全局自增序号（`AtomicLong`）。

---


## 三、工具类

### UUIDGenerator — 推荐入口

```java
String guid = UUIDGenerator.getUUID();
// 返回 32 位十六进制字符串，如 "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6"
```

### UUIDUtils — 底层实现

```java
// UUID v4（随机），32 位 hex，无横线
String uuid = UUIDUtils.randomV4UUID();

// 压缩版 UUID v4，URL 安全 Base64，22 字符（比 hex 版本短约 30%）
String shortUuid = UUIDUtils.compressV4UUID();
```

使用 `SecureRandom`（优先 SHA1PRNG 算法）生成随机字节，设置 UUID v4 标准的 version 和 variant 位。

### RandomUtil — 随机数

```java
SecureRandom sr = RandomUtil.secureRandom();  // 安全的随机数
Random r = RandomUtil.getRandom();             // ThreadLocalRandom，高性能
```

### YeepayDateUtils

```java
// 解析
Date d1 = YeepayDateUtils.parseByDayPattern("2026-01-15");
Date d2 = YeepayDateUtils.parseByDateTimePattern("2026-01-15 14:30:00");
Date d3 = YeepayDateUtils.parseDate("15/01/2026", "dd/MM/yyyy");

// 格式化
String s1 = YeepayDateUtils.formatByDayPattern(date);        // "2026-01-15"
String s2 = YeepayDateUtils.formatByDateTimePattern(date);   // "2026-01-15 14:30:00"
String s3 = YeepayDateUtils.formatDate(date, "MM/yyyy");

// 今天
String today = YeepayDateUtils.getCurrentDayByDayPattern();
```

继承 `org.apache.commons.lang3.time.DateUtils`，可以使用 `addDays`、`truncate`、`parseDate`（多格式）等附加方法。

**内置常量：**

| 常量 | 值 |
|------|----|
| `DAY_PATTERN` | `"yyyy-MM-dd"` |
| `DATETIME_PATTERN` | `"yyyy-MM-dd HH:mm:ss"` |
| `DATETIME_MS_PATTERN` | `"yyyy-MM-dd HH:mm:ss.SSS"` |
| `DEFAULT_DATE` | `1970-01-01` |

### NetUtils

```java
String ip = NetUtils.getLocalAddress();      // 本机 IP，如 "192.168.1.100"
InetAddress addr = NetUtils.getLocalInetAddress();
```

以静态初始化的方式获取本机第一个非回环、非链路本地的网络地址并缓存。如果找不到任何有效地址，抛出 `ExceptionInInitializerError`。

### PropertiesLoader

```java
// 从 classpath 加载（失败抛异常）
Properties props = PropertiesLoader.load("config/app.properties");

// 静默加载（失败返回 null）
Properties props = PropertiesLoader.loadQuietly("config", "app.properties");

// 条件读取
PropertiesLoader.ifPresent(props, "server.port", value -> port = Integer.parseInt(value));

// 多 key 依次尝试
PropertiesLoader.ifPresentAny(props, setter, "app.name", "spring.application.name");

// 逗号分割取值
List<String> items = PropertiesLoader.splitAndTrim("a, b ,c"); // ["a", "b", "c"]
```

`load()` 加载优先级：classpath → `user.dir` → `user.dir/..`。`loadQuietly()` 仅从 classpath 加载。

### JsonUtils — JSON 序列化/反序列化

底层使用共享的 `ObjectMapper` 单例，预设了宽松解析配置：

- 允许 JSON 注释、字段名无引号、单引号、未转义控制字符
- 忽略未知属性，空 Bean 不抛异常
- Java 8 时间类型自动序列化/反序列化（`LocalDateTime` → `yyyy-MM-dd HH:mm:ss`，`LocalDate` → `yyyy-MM-dd`，`LocalTime` → `HH:mm:ss`）

```java
// JSON → 对象
User user = JsonUtils.readValue(jsonStr, User.class);
List<User> users = JsonUtils.readValue(jsonStr, new TypeReference<List<User>>() {});

// 对象 → JSON
String json = JsonUtils.objectToJson(user);
String json = JsonUtils.objectToJson(user, UserView.Summary.class); // 带序列化视图

// JSON → JsonNode 树
JsonNode node = JsonUtils.toJsonTree(jsonStr);

// JsonNode → 对象
User user = JsonUtils.readValue(jsonNode, new TypeReference<User>() {});

// 递归遍历叶子节点，返回 null 删除节点，返回新节点替换
JsonUtils.jsonNodeForEach(node, valueNode -> "secret".equals(valueNode.asText()) ? null : valueNode);
```

输入 `null` 或空字符串时，`readValue` 返回 `null`，`objectToJson` 返回 `null`。

### JsonWrapper — JSON 路径导航

手动解析 JSON，通过点号分隔的路径访问嵌套字段，无需定义 POJO。

```java
JsonWrapper wrapper = new JsonWrapper("{\"data\":{\"user\":{\"name\":\"Alice\"}}}");
String name = wrapper.getValueByPath("data.user.name").orElse(null);
List<JsonNode> items = wrapper.getNodeList("data.items");
List<JsonWrapper> items = wrapper.getListWrapper("data.items");
boolean empty = wrapper.isEmpty();
```

### BigDecimalSafetyValidator — 安全数值解析

防止构造超大 `BigDecimal` 字符串导致内存溢出（如 `5e+300`、`1e9999`）。

```java
BigDecimalSafetyValidator validator = new BigDecimalSafetyValidator(5, 500);
BigDecimal bd = validator.parseBigDecimal("3.14");  // 合法
BigDecimal bd = validator.parseBigDecimal("1e6");   // 抛 IllegalStateException（指数 6 > 5）
```

| 校验维度 | 默认值 | 说明 |
|---------|--------|------|
| `maxLength` | 500 | 输入字符串最大长度 |
| `exponent` | 5 | 科学计数法指数范围 [-5, 5] |

### BigDecimalUtils — 安全解析入口

```java
BigDecimal bd = BigDecimalUtils.parseBigDecimal("999999999.99");
```

使用预设参数（指数上限 5，长度上限 500）。

### IpUtils — IP 地址获取

获取本机 IP，自动跳过 Docker 虚拟网卡（`docker`、`br-`、`veth`），支持通配符过滤。

```java
String ip = IpUtils.getHost();              // 本机 IP
String ip = IpUtils.getHost("192.168.*");   // 按 pattern 过滤
boolean valid = IpUtils.isCompleteHost("192.168.1.100"); // 合法 IPv4 判断
```

获取优先级：环境变量 `docker_host_ip` → 扫描网络接口（IPv4 优先）→ 按 `networkInterface.priority` 排序（默认 `enp<eth<bond`）→ 回退 `127.0.0.1`。

```java
// Zookeeper 地址解析/替换
String host = IpUtils.getZookeeperHost("zk://192.168.1.100:2181");
String url = IpUtils.replaceZookeeperHost("zk://zk-server:2181", "192.168.1.100");
```

### ClassUtils — 反射工具类

```java
// 递归获取类/方法上的注解（沿继承树向上查找）
Service ann = ClassUtils.getAnnotation(MyService.class, Service.class);
GetMapping ann = ClassUtils.getAnnotation(method, GetMapping.class);

// 获取泛型参数类型
Class<?> type = ClassUtils.getGenericType(MyService.class, 0);

// 沿继承树类型判断
boolean match = ClassUtils.instanceOf(MyService.class, ServiceInterface.class);

// 基本类型判断（int, double, float, byte, short, char, String）
boolean basic = ClassUtils.isBasicClass(String.class); // true
```

### EnumUtils — 枚举校验

```java
EnumUtils.isEnumType(StatusEnum.class); // 非枚举类型抛 IllegalArgumentException
```


## 四、枚举与常量

### WithCode\<T\> — 编码枚举接口

枚举实现此接口后，通过 `toCodeMap()` 生成 code → enum 映射表。

```java
public enum StatusEnum implements WithCode<Integer> {
    ENABLED(1), DISABLED(0);
    private final Integer code;
    StatusEnum(Integer code) { this.code = code; }
    @Override
    public Integer getCode() { return code; }
}

Map<Integer, StatusEnum> map = WithCode.toCodeMap(StatusEnum.class);
StatusEnum e = map.get(1); // ENABLED
```

### CommonConstants

```java
String prefix = CommonConstants.PREFIX; // "yeepay.framework"
```

---
