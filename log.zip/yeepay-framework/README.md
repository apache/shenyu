# Yeepay Framework

Yeepay 内部 Java 企业级中间件框架，为业务服务提供**分布式锁**、**限流**、**全局唯一 ID 生成**等功能。基于 Spring Boot 3.4 自动装配，业务方引入对应 starter 依赖、加配置就可使用。

## 对业务的价值

**让业务团队聚焦业务逻辑，不用重复造中间件的轮子。**

- **降低接入成本**：业务引入一个 starter 依赖，无须再关注版本依赖问题，快速使用
- **统一技术标准**：全公司使用统一基础组件，形成统一的依赖，以及统一的代码开发规范等

## 技术栈

| 类别 | 技术 | 版本      |
|------|------|---------|
| 语言 | Java | 17+     |
| 框架 | Spring Boot | 3.4.x+  |
| 构建 | Maven | —       |
| 代码生成 | Lombok | 1.18.42 |
| 测试 | JUnit 5 + Mockito + AssertJ | —       |
| 代码质量 | Palantir Java Format + Checkstyle + SpotBugs + FindSecBugs |

## 项目结构

```
yeepay-framework/
├── common/                     # 通用工具：ThreadContext、线程池、Result、UUID 生成器
├── web/                        # Web 层支持：ThreadContextFilter 请求追踪过滤器
├── logging/                    # 日志增强：缓冲控制台追加器、Fluentd 追加器、动态日志级别
├── infra/                      # 基础设施客户端工厂（Jedis / Redisson / ZooKeeper）
│   ├── infra-jedis
│   ├── infra-redisson
│   └── infra-zookeeper
├── lock/                       # 分布式锁
├── rate-limit/                 # 限流（令牌桶 / 滑动窗口 / 漏桶 / 并发请求）
├── global-id/                  # 全局唯一 ID（雪花算法）
├── metrics/                    # 指标上报
├── springboot-starter/         # Spring Boot 自动装配
│   ├── springboot-starter-xxx   #   每个核心能力一个 starter 模块，自动装配对应功能
├── bom/                        # 统一版本管理 BOM
├── shared-resources/           # Checkstyle / SpotBugs 规则文件
└── examples/                   # 使用示例
    ├── examples-xx/
```


## 构建与测试

```bash
# 完整构建（含 Checkstyle、SpotBugs、Spotless 检查）
mvn clean package

# 快速构建（跳过所有检查）
mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip

# 运行全部测试
mvn test

# 运行单个测试类
mvn test -pl lock/lock-api -Dtest=LockManagerTest

# 运行单个测试方法
mvn test -pl lock/lock-api -Dtest=LockManagerTest#testLockSuccess
```

要求 Java 17，项目未包含 Maven Wrapper，请使用系统 `mvn`。

## 代码规范

| 工具 | 用途 | 执行阶段 |
|------|------|----------|
| **Spotless** (Palantir Java Format) | 代码格式化 | `process-sources` |
| **Checkstyle** | 编码风格检查 | `validate` |
| **SpotBugs** + FindSecBugs | 静态缺陷 & 安全漏洞检查 | `package` |
| **JaCoCo** | 测试覆盖率采集 | `prepare-agent` |

以上工具均在构建流程中自动执行，违规将导致构建失败。

```bash
# 提交前格式化代码
mvn spotless:apply
```

### 编码约定

- 格式化工具：**Palantir Java Format**，提交前务必执行 `mvn spotless:apply`
- Checkstyle 规则文件：`shared-resources/src/main/resources/codestyle/yeepay_checkstyle.xml`
- SpotBugs 配置文件：`shared-resources/src/main/resources/spotbugs/spotbugs-include.xml` / `spotbugs-exclude.xml`
- 使用 **Lombok** 减少样板代码（`@Data`、`@Builder`、`@RequiredArgsConstructor` 等）
- 编译参数启用 `-parameters`（保留方法参数名，支持 SpEL 锁 key 解析）和 `-Xlint:all`
- 文件不得包含 Tab 字符，单文件不超过 2500 行

## 发布

```bash
# 部署到内部 Maven 仓库
mvn clean deploy

# 版本发布（自动打 Tag 并更新子模块版本）
mvn release:prepare release:perform
```

Tag 格式：`PRD_H{version}`，发布至内部 Artifactory 仓库。
