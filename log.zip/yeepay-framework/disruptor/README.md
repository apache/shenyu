#  Yeepay Framework disruptor 使用文档

## 简介
基于 LMAX Disruptor 的轻量级事件驱动 Starter，提供开箱即用的发布/订阅模型与并行消费能力，并支持按数据类型路由消费与可配置的线程/缓冲策略。

## 依赖引入
```xml
<dependency>
  <groupId>com.yeepay.framework</groupId>
  <artifactId>springboot-starter-disruptor</artifactId>
  <version>${yeepay.framework.version}</version>
</dependency>
```

## 自动装配
- `DisruptorAutoConfiguration` 在 `yeepay.framework.disruptor.enabled=true`（默认）时生效。
- 暴露 Bean：
  - `QueueConsumerFactory<T>`（默认实现：`CommonConsumerExecutorFactory`）
  - `DisruptorPublisher<T>`（事件发布入口，容器销毁时自动关闭）

## 配置项（application.yml）
```yaml
yeepay:
  framework:
     disruptor:
       enabled: true            # 是否启用（默认 true）
       consumer-size: 8         # 业务线程数（默认 CPU*2）
       ring-buffer-size: 16384  # RingBuffer 大小（默认 16384，建议 2 的幂）
       orderly: false           # 事件是否有严格的顺序（默认 false）
       monitor : true            # 是否启用 集成Spring Boot Actuator 监控（默认 true）
       queueCapacity: 8192     # 业务线程池队列大小（默认 8192）
       rejectionPolicy: CALLER_RUNS # 业务线程池拒绝策略（CALLER_RUNS, ABORT, DISCARD, DISCARD_OLDEST 默认： CALLER_RUNS）
       waitStrategy: BLOCKING       # 等待策略（BLOCKING, SLEEP, YIELD, BUSY_SPIN, LITE_BLOCKING 默认： BLOCKING）
```


## 发布事件
在任意 Spring 组件中注入 `DisruptorPublisher`，调用 `publishEvent(T data)` 即可：

```java
@RequiredArgsConstructor
@RestController
@RequestMapping("/disruptor")
public class DisruptorController {

  private final DisruptorPublisher<Object> disruptorPublisher;

  @GetMapping("/user")
  public void sendUser() {
    disruptorPublisher.publishEvent(new UserEntity());
  }

  @GetMapping("/order")
  public void sendOrder() {
    disruptorPublisher.publishEvent(new OrderEntity());
  }
}
```

## 订阅者（消费逻辑）
实现 `ExecutorSubscriber<T>`，由 Spring 扫描注册为 Bean 后会自动装配进工厂，按事件对象的“具体类型”进行路由。

```java
@Component
@Slf4j
public class UserExecutorSubscriber implements ExecutorSubscriber<UserEntity> {
  @Override
  public void executor(UserEntity data) {
    log.info("consume user: {}", data);
  }
}
```

```java
@Component
@Slf4j
public class OrderExecutorSubscriber implements ExecutorSubscriber<OrderEntity> {
  @Override
  public void executor(OrderEntity entity) {
    log.info("consume order: {}", entity);
  }
}
```

## 并行与顺序
- Starter 默认并行消费（`consumer-size` 决定并发度）。

### 顺序消费

* 接口定义

```

/**
 * 顺序一致性时候，线程选择策略接口.
 *
 * @param <T> the type parameter
 */
public interface ThreadSelectionStrategy<T> {

    /**
     * Initialize.
     *
     * @param virtualExecutors the virtual executors
     */
    void initialize(SingletonExecutor[] virtualExecutors);

    /**
     * Select singleton executor.
     *
     * @param event the event
     * @return the singleton executor
     */
    SingletonExecutor select(DataEvent<T> event);
}
```

### 内置策略

- **HASH_MOD**：使用方，可以继承该类，实现 `getHashCode`,这样会对执行器数量取模，落到固定单线程。

```

/**
 * 抽象哈希取模策略.
 *
 * @param <T> the type parameter
 */
public abstract class AbstractHashModThreadStrategy<T> implements ThreadSelectionStrategy<T> {

    private SingletonExecutor[] executors;

    @Override
    public void initialize(final SingletonExecutor[] virtualExecutors) {
        this.executors = virtualExecutors;
    }

    @Override
    public SingletonExecutor select(final DataEvent<T> event) {
        int index = Math.abs(getHashCode(event)) % executors.length;
        return executors[index];
    }

    protected abstract int getHashCode(final DataEvent<T> event);
}
```

- **CONSISTENT_HASH**：一致性哈希，使用方，可以继承该类，实现 `getHashCode`方法，这样会映射到稳定的单线程，节点数量变化时抖动更小。

```
public abstract class AbstractConsistentHashThreadStrategy<T> implements ThreadSelectionStrategy<T> {

    private static final ThreadSelector THREAD_SELECTOR = new ThreadSelector();

    private final ConcurrentSkipListMap<Long, SingletonExecutor> virtualExecutors = new ConcurrentSkipListMap<>();

    @Override
    public void initialize(final SingletonExecutor[] virtualExecutors) {
        for (SingletonExecutor executor : virtualExecutors) {
            String hash = executor.hashCode() + "";
            byte[] bytes = THREAD_SELECTOR.sha(hash);
            for (int i = 0; i < 4; i++) {
                this.virtualExecutors.put(THREAD_SELECTOR.hash(bytes, i), executor);
            }
        }
    }

    @Override
    public SingletonExecutor select(final DataEvent<T> event) {
        long select = THREAD_SELECTOR.select(getHashCode(event));
        if (!virtualExecutors.containsKey(select)) {
            SortedMap<Long, SingletonExecutor> tailMap = virtualExecutors.tailMap(select);
            if (tailMap.isEmpty()) {
                select = virtualExecutors.firstKey();
            } else {
                select = tailMap.firstKey();
            }
        }
        return virtualExecutors.get(select);
    }

    protected abstract String getHashCode(final DataEvent<T> event);

    /**
     * 线程选择器.
     * 负责计算哈希值
     */
    private static final class ThreadSelector {

        /**
         * 选择哈希值.
         *
         * @param hash the hash
         * @return the long
         */
        public long select(String hash) {
            byte[] digest = sha(hash);
            return hash(digest, 0);
        }

        /**
         * Ketama 哈希算法.
         */
        private long hash(byte[] digest, int number) {
            return (((long) (digest[3 + number * 4] & 0xFF) << 24)
                            | ((long) (digest[2 + number * 4] & 0xFF) << 16)
                            | ((long) (digest[1 + number * 4] & 0xFF) << 8)
                            | (digest[number * 4] & 0xFF))
                    & 0xFFFFFFFFL;
        }

        private byte[] sha(String hash) {
            byte[] bytes = hash.getBytes(StandardCharsets.UTF_8);
            return Hashing.sha256().newHasher().putBytes(bytes).hash().asBytes();
        }
    }
}

```

### 自定义策略

你可以基于业务类型 `T` 自定义实现，并通过 Spring 注册以覆盖默认策略：

```java
@Component
public class UserHashModThreadStrategy implements ThreadSelectionStrategy<UserEntity> {

  private SingletonExecutor[] executors;

  @Override
  public void initialize(SingletonExecutor[] virtualExecutors) {
    this.executors = virtualExecutors;
  }

  @Override
  public SingletonExecutor select(DataEvent<UserEntity> event) {
    // 从事件中获取用于有序性的哈希键（发布有序事件时应设置）
    String key = event.getHash();
    int index = Math.abs(key.hashCode()) % executors.length;
    return executors[index];
  }
}
```

要点：
- **生效范围**：自定义策略通过其泛型类型 `T` 与业务实体绑定，仅对该类型的事件生效。
- **自动装配**：Starter 会收集容器中的 `ThreadSelectionStrategy<T>` 实例进行注册；找不到该类型的自定义实现时，会使用无序的线程池进行处理。

## 性能调优建议
- 将 `ring-buffer-size` 设为足够大的 2 的幂（如 16384/32768/65536）。
- `consumer-size` 建议以 `CPU*2` 起步，并根据实际消费逻辑（CPU/IO）调整。
- 消费逻辑避免长时间阻塞；必要时进一步拆分或异步化。


## Spring Boot 监控集成

#### 指标清单

- 事件计数（Counter）
  - `disruptor_events_submitted`: 事件提交次数
  - `disruptor_events_processed`: 事件处理完成次数
  - `disruptor_events_rejected`: 事件被拒绝次数

- 业务线程池（Gauge，标签：`pool`）
  - `disruptor_biz_executor_active_count`: 活跃线程数
  - `disruptor_biz_executor_pool_size`: 当前线程池大小
  - `disruptor_biz_executor_core_pool_size`: 核心线程数
  - `disruptor_biz_executor_max_pool_size`: 最大线程数
  - `disruptor_biz_executor_largest_pool_size`: 曾达到的最大线程数
  - `disruptor_biz_executor_completed_task_count`: 已完成任务数
  - `disruptor_biz_executor_task_count`: 调度过的任务总数
  - `disruptor_biz_executor_queue_size`: 队列当前大小
  - `disruptor_biz_executor_queue_remaining`: 队列剩余容量
  - `disruptor_biz_executor_queue_usage`: 队列使用率（size/capacity）
  - `disruptor_biz_executor_thread_usage`: 线程使用率（active/max）

- RingBuffer（Gauge，标签：`name`）
  - `disruptor_ring_buffer_size`: Buffer 总大小
  - `disruptor_ring_buffer_remaining_capacity`: 剩余容量
  - `disruptor_ring_buffer_cursor`: 生产者游标（已发布序列）
  - `disruptor_ring_buffer_utilization`: Buffer 占用率（(size-remaining)/size）
  - `disruptor_consumer_min_sequence`: 消费者最小序列（消费进度）
  - `disruptor_ring_buffer_backlog`: 积压量（cursor - minSequence）


## 架构流程图

### 1. 项目初始化流程

```
┌─────────────────────┐
│   Spring Boot 启动   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────┐
│ DisruptorAutoConfiguration  │
│        自动装配              │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│    读取 DisruptorConfig     │
│        配置                 │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│   创建 QueueConsumerFactory │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  扫描 ExecutorSubscriber    │
│      实现类                 │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│   创建 DisruptorPublisher   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ 创建 DisruptorProviderManager│
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│   初始化 Disruptor 实例     │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│      创建 RingBuffer        │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│    创建消费者线程池         │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│      启动 Disruptor         │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│        系统就绪             │
└─────────────────────────────┘
```

**初始化流程说明：**
1. Spring Boot 启动时自动装配 DisruptorAutoConfiguration
2. 读取配置文件中的 Disruptor 相关配置
3. 创建消费者工厂和扫描订阅者实现类
4. 创建发布者和 Disruptor 实例管理器
5. 初始化 Disruptor 实例和 RingBuffer
6. 创建消费者线程池并启动系统

### 2. 事件发布和消费流程

```
┌─────────────────────────────┐
│  业务代码调用 publishEvent   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ DisruptorPublisher.publishEvent│
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│    获取 DisruptorProvider   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│    调用 provider.onData     │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│   RingBuffer.publishEvent   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│    事件写入 RingBuffer      │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  QueueConsumer 接收事件     │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  OrderlyExecutor 选择线程   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ 创建 QueueConsumerExecutor  │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ CommonConsumerExecutor 执行 │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ 根据数据类型路由到具体订阅者 │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ExecutorSubscriber.executor  │
│      执行业务逻辑           │
└─────────────────────────────┘
```

**事件处理流程说明：**
1. 业务代码调用 `publishEvent()` 发布事件
2. 通过 DisruptorPublisher 获取 DisruptorProvider
3. 调用 provider 的 onData 方法将事件写入 RingBuffer
4. QueueConsumer 从 RingBuffer 接收事件
5. OrderlyExecutor 选择合适的线程执行
6. 创建执行器并根据数据类型路由到具体订阅者
7. 最终执行业务逻辑

### 3. 顺序消费流程（orderly=true）

```
┌─────────────────────────────┐
│  调用 publishOrderlyEvent   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│DisruptorProvider.onOrderlyData│
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│        计算哈希值           │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ RingBuffer.publishEvent     │
│        带哈希               │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  QueueConsumer 接收事件     │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ 检查是否为 OrderlyDataEvent │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│OrderlyExecutor.select       │
│    根据哈希选择线程         │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ SingletonExecutor 单线程执行│
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│ 保证相同哈希的事件顺序执行   │
└─────────────────────────────┘
```

**顺序消费说明：**
1. 调用 `publishOrderlyEvent()` 发布有序事件
2. 计算事件的哈希值用于路由
3. 将带哈希的事件写入 RingBuffer
4. QueueConsumer 检查事件类型
5. 根据哈希值选择特定的单线程执行器
6. 确保相同哈希的事件按顺序执行

## 线程模型

### 1. 整体线程架构

```
┌─────────────────────────────────────────────────────────────────┐
│                            主线程                              │
│                    ┌─────────────────┐                        │
│                    │ Spring Boot 主线程 │                        │
│                    └─────────┬───────┘                        │
│                              │                                │
│                              ▼                                │
└──────────────────────────────┼────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Disruptor 线程池                        │
│  ┌─────────────────┐              ┌─────────────────┐          │
│  │DisruptorProvider│              │RingBuffer 内部线程│          │
│  │     线程        │              │                │          │
│  └─────────┬───────┘              └─────────┬───────┘          │
│            │                                │                  │
│            └────────────┬───────────────────┘                  │
└─────────────────────────┼─────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                        消费者线程池                            │
│                    ┌─────────────────┐                        │
│                    │OrderlyExecutor  │                        │
│                    │    线程池       │                        │
│                    └─────────┬───────┘                        │
│                              │                                │
│        ┌─────────────────────┼─────────────────────┐          │
│        │                     │                     │          │
│        ▼                     ▼                     ▼          │
│┌─────────────┐    ┌─────────────┐    ┌─────────────┐         │
││Consumer-1   │    │Consumer-2   │    │Consumer-N   │         │
││   线程      │    │   线程      │    │   线程      │         │
│└─────────────┘    └─────────────┘    └─────────────┘         │
└─────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                      顺序消费线程池                            │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐         │
│  │Singleton    │    │Singleton    │    │Singleton    │         │
│  │Executor-1   │    │Executor-2   │    │Executor-N   │         │
│  └─────────────┘    └─────────────┘    └─────────────┘         │
└─────────────────────────────────────────────────────────────────┘
```

**线程架构说明：**
- **主线程**: Spring Boot 应用启动线程
- **Disruptor 线程池**: 管理 RingBuffer 和事件分发的线程
- **消费者线程池**: 默认 CPU*2 个线程，并行处理事件
- **顺序消费线程池**: 当 orderly=true 时，使用单线程保证顺序

### 2. 详细线程模型

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                生产者端                                        │
│  ┌─────────────┐    ┌─────────────────┐    ┌─────────────────┐                │
│  │  业务线程   │───▶│ DisruptorPublisher│───▶│ DisruptorProvider│                │
│  └─────────────┘    └─────────────────┘    └─────────┬───────┘                │
│                                                     │                        │
│                                                     ▼                        │
│                                              ┌─────────────────┐              │
│                                              │   RingBuffer    │              │
│                                              └─────────┬───────┘              │
└───────────────────────────────────────────────────────┼───────────────────────┘
                                                        │
                                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              Disruptor 核心                                    │
│                                              ┌─────────────────┐              │
│                                              │RingBuffer 环形  │              │
│                                              │    缓冲区       │              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │ WorkHandler 接口│              │
│                                              └─────────┬───────┘              │
└───────────────────────────────────────────────────────┼───────────────────────┘
                                                        │
                                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                消费者端                                        │
│                                              ┌─────────────────┐              │
│                                              │QueueConsumer 数组│              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │OrderlyExecutor  │              │
│                                              │    线程池       │              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │QueueConsumer    │              │
│                                              │   Executor      │              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │CommonConsumer   │              │
│                                              │   Executor      │              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │ExecutorSubscriber│              │
│                                              │    实现类        │              │
│                                              └─────────────────┘              │
└─────────────────────────────────────────────────────────────────────────────────┘
                                                        │
                                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              顺序消费（可选）                                   │
│                                              ┌─────────────────┐              │
│                                              │    哈希计算     │              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │SingletonExecutor│              │
│                                              │     选择        │              │
│                                              └─────────┬───────┘              │
│                                                        │                      │
│                                                        ▼                      │
│                                              ┌─────────────────┐              │
│                                              │ 单线程顺序执行   │              │
│                                              └─────────────────┘              │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**详细线程模型说明：**
- **生产者端**: 业务线程通过 DisruptorPublisher 发布事件到 RingBuffer
- **Disruptor 核心**: RingBuffer 作为高性能环形缓冲区，通过 WorkHandler 分发事件
- **消费者端**: QueueConsumer 从 RingBuffer 消费事件，通过线程池执行具体业务逻辑
- **顺序消费**: 通过哈希计算选择特定的单线程执行器，保证相同哈希事件的顺序性

## 核心组件说明

### 1. 初始化阶段
- **DisruptorAutoConfiguration**: Spring Boot 自动装配入口
- **DisruptorConfig**: 配置管理（线程数、缓冲区大小、是否顺序等）
- **QueueConsumerFactory**: 消费者工厂，负责创建消费者
- **DisruptorProviderManager**: Disruptor 实例管理器

### 2. 运行时阶段
- **DisruptorPublisher**: 事件发布入口，提供 `publishEvent()` 和 `publishOrderlyEvent()` 方法
- **DisruptorProvider**: 实际的 Disruptor 提供者，负责向 RingBuffer 发布事件
- **QueueConsumer**: 实现 WorkHandler 接口，从 RingBuffer 消费事件
- **ConsumerExecutor**: 自定义线程池，支持顺序消费
- **CommonConsumerExecutor**: 根据数据类型路由到具体订阅者

### 3. 线程配置
- **消费者线程数**: 默认 `CPU核心数 * 2`，可通过 `yeepay.framework.disruptor.consumer-size` 配置
- **RingBuffer 大小**: 默认 16384，可通过 `yeepay.framework.disruptor.ring-buffer-size` 配置

### 4. 事件路由机制
- 通过反射获取 `ExecutorSubscriber<T>` 的泛型类型
- 根据事件对象的实际类型匹配对应的订阅者
- 支持多订阅者并行消费同一类型的事件

### 关键类一览
- `DisruptorAutoConfiguration`：自动装配入口
- `DisruptorPublisher`：事件发布与生命周期管理
- `DisruptorProviderManager` / `DisruptorProvider`：Disruptor 实例管理与投递
- `ExecutorSubscriber` / `CommonConsumerExecutor`：按类型路由到具体订阅者



