package com.yeepay.framework.disruptor.config;

import com.yeepay.framework.common.constants.CommonConstants;
import com.yeepay.framework.disruptor.enums.RejectionPolicy;
import com.yeepay.framework.disruptor.enums.WaitStrategy;
import lombok.Data;

/**
 * The type Disruptor config.
 */
@Data
public class DisruptorProperties {

    public static final String PREFIX = CommonConstants.PREFIX + ".disruptor";

    /**
     * 是否开启 disruptor 功能.
     */
    private boolean enabled = true;

    /**
     * 消费者数量, 默认 2 * CPU 核数.
     */
    private int consumerSize = Runtime.getRuntime().availableProcessors() << 1;

    /**
     * ringBufferSize, 必须是 2 的 N 次方, 默认 4096 * 4.
     */
    private int ringBufferSize = 4096 << 1 << 1;

    /**
     * 是否监控 disruptor 运行状态, 默认 true.
     */
    private boolean monitor = true;

    /**
     * 队列容量.
     */
    private int queueCapacity = 8192;

    /**
     * 拒绝策略 {@link RejectionPolicy}.
     * caller_runs, abort, discard, discard_oldest
     */
    private RejectionPolicy rejectionPolicy = RejectionPolicy.CALLER_RUNS;

    /**
     * 等待策略 {@link WaitStrategy}.
     * blocking, sleeping, yielding, busy_spin
     */
    private WaitStrategy waitStrategy = WaitStrategy.BLOCKING;
}
