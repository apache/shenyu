package com.yeepay.framework.disruptor.consumer;

import com.yeepay.framework.disruptor.subsriber.AbstractQueueConsumerFactory;
import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import java.lang.reflect.ParameterizedType;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * The type Consumer executor.
 *
 * @param <T> the type parameter
 */
public final class CommonConsumerExecutorFactory<T> extends AbstractQueueConsumerFactory<T> {

    private volatile Map<Class<T>, ExecutorSubscriber<T>> cachedMaps;

    @Override
    public QueueConsumerExecutor<T> create() {
        if (Objects.isNull(cachedMaps)) {
            synchronized (this) {
                if (Objects.isNull(cachedMaps)) {
                    cachedMaps = getSubscribers().stream().collect(Collectors.toMap(this::apply, e -> e));
                }
            }
        }
        return new CommonConsumerExecutor<>(cachedMaps);
    }

    @Override
    public String fixName() {
        return "common-disruptor";
    }

    private Class<T> apply(final ExecutorSubscriber<T> subscriber) {
        ParameterizedType parameterizedType =
                (ParameterizedType) subscriber.getClass().getGenericInterfaces()[0];
        return (Class<T>) parameterizedType.getActualTypeArguments()[0];
    }
}
