package com.yeepay.framework.disruptor.consumer;

import com.lmax.disruptor.WorkHandler;
import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.executor.ConsumerExecutor;
import java.util.Objects;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * The type Queue consumer.
 *
 * @param <T> the type parameter
 */
public class QueueConsumer<T> implements WorkHandler<DataEvent<T>> {

    private final ConsumerExecutor<T> executor;

    private final QueueConsumerFactory<T> factory;

    /**
     * Instantiates a new Queue consumer.
     *
     * @param executor the executor
     * @param factory the factory
     */
    public QueueConsumer(final ConsumerExecutor<T> executor, final QueueConsumerFactory<T> factory) {
        this.executor = executor;
        this.factory = factory;
    }

    @Override
    public void onEvent(final DataEvent<T> t) {
        if (Objects.nonNull(t)) {
            ThreadPoolExecutor executor = selector(t);
            QueueConsumerExecutor<T> queueConsumerExecutor = factory.create();
            queueConsumerExecutor.setData(t.getData());
            // help gc
            t.setData(null);
            executor.execute(queueConsumerExecutor);
        }
    }

    private ThreadPoolExecutor selector(final DataEvent<T> dataEvent) {
        return executor.select(dataEvent);
    }
}
