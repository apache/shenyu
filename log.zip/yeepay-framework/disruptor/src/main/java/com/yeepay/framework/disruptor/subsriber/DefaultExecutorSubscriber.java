package com.yeepay.framework.disruptor.subsriber;

import lombok.extern.slf4j.Slf4j;

/**
 * The type default executor subscriber.
 *
 * @param <T> the type parameter
 */
@Slf4j
public class DefaultExecutorSubscriber<T> implements ExecutorTypeSubscriber<T> {

    @Override
    public String getType() {
        return "";
    }

    @Override
    public void executor(final T data) {
        log.error("can not match data type :{}", data.toString());
    }
}
