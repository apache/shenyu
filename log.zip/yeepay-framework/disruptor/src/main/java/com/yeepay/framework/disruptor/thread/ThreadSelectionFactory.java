package com.yeepay.framework.disruptor.thread;

import java.util.List;

/**
 * The interface Thread selection strategy factory.
 *
 * @param <T> the type parameter
 */
public interface ThreadSelectionFactory<T> {

    /**
     * Gets strategies.
     *
     * @return the strategies
     */
    List<ThreadSelectionStrategy<T>> getAllStrategies();

    /**
     * Create thread selection strategy.
     *
     * @param clazz the clazz
     * @return the thread selection strategy
     */
    ThreadSelectionStrategy<T> create(Class<T> clazz);
}
