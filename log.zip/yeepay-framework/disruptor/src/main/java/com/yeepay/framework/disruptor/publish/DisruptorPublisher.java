package com.yeepay.framework.disruptor.publish;

import com.yeepay.framework.disruptor.config.DisruptorProperties;
import com.yeepay.framework.disruptor.consumer.QueueConsumerFactory;
import com.yeepay.framework.disruptor.provider.DisruptorProvider;
import com.yeepay.framework.disruptor.provider.DisruptorProviderManager;
import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import com.yeepay.framework.disruptor.thread.ThreadSelectionFactory;
import java.util.List;
import lombok.Getter;

/**
 * The type Disruptor publisher.
 *
 * @param <T> the type parameter
 */
@Getter
public class DisruptorPublisher<T> {

    private final DisruptorProviderManager<T> providerManager;

    /**
     * Instantiates a new Disruptor publisher.
     *
     * @param factory the factory
     * @param selectionFactory the selection factory
     * @param subscriberList the subscriber list
     * @param config the disruptor config
     */
    public DisruptorPublisher(
            final QueueConsumerFactory<T> factory,
            final ThreadSelectionFactory<T> selectionFactory,
            final List<ExecutorSubscriber<T>> subscriberList,
            final DisruptorProperties config) {
        for (ExecutorSubscriber<T> subscriber : subscriberList) {
            factory.addSubscribers(subscriber);
        }
        providerManager = new DisruptorProviderManager<>(factory, config, selectionFactory);
        providerManager.startup();
    }

    /**
     * Publish event.
     *
     * @param data the data
     */
    public void publishEvent(final T data) {
        DisruptorProvider<T> provider = providerManager.getProvider();
        provider.onData(data);
    }

    /**
     * Destroy.
     */
    public void destroy() {
        providerManager.getProvider().shutdown();
    }
}
