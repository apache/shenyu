package com.yeepay.framework.disruptor.thread;

import com.google.common.hash.Hashing;
import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.executor.SingletonExecutor;
import java.nio.charset.StandardCharsets;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentSkipListMap;

/**
 * 一致性哈希线程选择策略.
 *
 * @param <T> the type parameter
 */
public abstract class AbstractConsistentHashThreadStrategy<T> implements ThreadSelectionStrategy<T> {

    private static final ThreadSelector THREAD_SELECTOR = new ThreadSelector();

    private final ConcurrentSkipListMap<Long, SingletonExecutor> virtualExecutors = new ConcurrentSkipListMap<>();

    @Override
    public void initialize(final SingletonExecutor[] virtualExecutors) {
        for (SingletonExecutor executor : virtualExecutors) {
            String hash = executor.hashCode() + "";
            byte[] bytes = THREAD_SELECTOR.sha(hash);
            for (int i = 0; i < 4; i++) {
                this.virtualExecutors.put(THREAD_SELECTOR.hash(bytes, i), executor);
            }
        }
    }

    @Override
    public SingletonExecutor select(final DataEvent<T> event) {
        long select = THREAD_SELECTOR.select(getHashCode(event));
        if (!virtualExecutors.containsKey(select)) {
            SortedMap<Long, SingletonExecutor> tailMap = virtualExecutors.tailMap(select);
            if (tailMap.isEmpty()) {
                select = virtualExecutors.firstKey();
            } else {
                select = tailMap.firstKey();
            }
        }
        return virtualExecutors.get(select);
    }

    /**
     * Gets hash code.
     *
     * @param event the event
     * @return the hash code
     */
    protected abstract String getHashCode(DataEvent<T> event);

    /**
     * 线程选择器.
     * 负责计算哈希值
     */
    private static final class ThreadSelector {

        /**
         * 选择哈希值.
         *
         * @param hash the hash
         * @return the long
         */
        public long select(String hash) {
            byte[] digest = sha(hash);
            return hash(digest, 0);
        }

        /**
         * Ketama 哈希算法.
         */
        private long hash(byte[] digest, int number) {
            return (((long) (digest[3 + number * 4] & 0xFF) << 24)
                            | ((long) (digest[2 + number * 4] & 0xFF) << 16)
                            | ((long) (digest[1 + number * 4] & 0xFF) << 8)
                            | (digest[number * 4] & 0xFF))
                    & 0xFFFFFFFFL;
        }

        private byte[] sha(String hash) {
            byte[] bytes = hash.getBytes(StandardCharsets.UTF_8);
            return Hashing.sha256().newHasher().putBytes(bytes).hash().asBytes();
        }
    }
}
