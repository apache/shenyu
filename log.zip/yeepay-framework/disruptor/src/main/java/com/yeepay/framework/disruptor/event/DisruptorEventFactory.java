package com.yeepay.framework.disruptor.event;

import com.lmax.disruptor.EventFactory;

/**
 * DisruptorEventFactory .
 * disruptor Create a factory implementation of the object.
 * @param <T> the type parameter
 */
public class DisruptorEventFactory<T> implements EventFactory<DataEvent<T>> {

    @Override
    public DataEvent<T> newInstance() {
        return new DataEvent<>();
    }
}
