package com.yeepay.framework.disruptor.subsriber;

import com.yeepay.framework.disruptor.consumer.QueueConsumerFactory;
import java.util.HashSet;
import java.util.Set;
import lombok.Getter;

/**
 * The type Abstract queue consumer factory.
 *
 * @param <T> the type parameter
 */
@Getter
public abstract class AbstractQueueConsumerFactory<T> implements QueueConsumerFactory<T> {

    private final Set<ExecutorSubscriber<T>> subscribers = new HashSet<>();

    @Override
    public void addSubscribers(final ExecutorSubscriber<T> subscriber) {
        subscribers.add(subscriber);
    }
}
