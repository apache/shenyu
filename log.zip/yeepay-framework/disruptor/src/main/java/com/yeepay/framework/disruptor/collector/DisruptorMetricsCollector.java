package com.yeepay.framework.disruptor.collector;

import com.lmax.disruptor.RingBuffer;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Disruptor监控指标.
 */
public class DisruptorMetricsCollector {

    private static final DisruptorMetricsCollector INSTANCE = new DisruptorMetricsCollector();

    private final AtomicBoolean initialized = new AtomicBoolean(false);

    private MeterRegistry meterRegistry;

    private Counter submittedCounter;

    private Counter processedCounter;

    private Counter rejectedCounter;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static DisruptorMetricsCollector getInstance() {
        return INSTANCE;
    }

    /**
     * Init.
     *
     * @param meterRegistry the meter registry
     */
    public void init(MeterRegistry meterRegistry) {
        if (!initialized.compareAndSet(false, true)) {
            return;
        }
        this.meterRegistry = meterRegistry;
        // 初始化计数器
        this.submittedCounter = Counter.builder("disruptor_events_submitted")
                .description("Total number of events submitted to disruptor")
                .register(meterRegistry);
        this.processedCounter = Counter.builder("disruptor_events_processed")
                .description("Total number of events processed by disruptor")
                .register(meterRegistry);

        this.rejectedCounter = Counter.builder("disruptor_events_rejected")
                .description("Total number of events rejected by disruptor")
                .register(meterRegistry);
    }

    /**
     * 记录事件提交.
     */
    public void recordEventSubmitted() {
        if (!initialized.get()) {
            return;
        }
        submittedCounter.increment();
    }

    /**
     * 记录事件处理完成.
     */
    public void recordEventProcessed() {
        if (!initialized.get()) {
            return;
        }
        processedCounter.increment();
    }

    /**
     * 记录事件被拒绝.
     */
    public void recordEventRejected() {
        if (!initialized.get()) {
            return;
        }
        rejectedCounter.increment();
    }

    /**
     * 绑定并监控业务 ThreadPoolExecutor 指标.
     *
     * @param executor the executor
     * @param poolName the pool name
     */
    public void registerThreadPoolExecutor(final ThreadPoolExecutor executor, final String poolName) {
        if (!initialized.get()) {
            return;
        }
        // 线程相关
        Gauge.builder("disruptor_biz_executor_active_count", executor, ThreadPoolExecutor::getActiveCount)
                .description("Active threads in executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_pool_size", executor, ThreadPoolExecutor::getPoolSize)
                .description("Current pool size of executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_core_pool_size", executor, ThreadPoolExecutor::getCorePoolSize)
                .description("Core pool size of executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_max_pool_size", executor, ThreadPoolExecutor::getMaximumPoolSize)
                .description("Maximum pool size of executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_largest_pool_size", executor, ThreadPoolExecutor::getLargestPoolSize)
                .description("Largest pool size reached by executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_completed_task_count", executor, e -> (double) e.getCompletedTaskCount())
                .description("Completed task count of executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_task_count", executor, e -> (double) e.getTaskCount())
                .description("Total task count scheduled for executor")
                .tag("pool", poolName)
                .register(meterRegistry);

        // 队列相关
        Gauge.builder("disruptor_biz_executor_queue_size", executor, e ->
                        (double) e.getQueue().size())
                .description("Current size of executor work queue")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_queue_remaining", executor, e ->
                        (double) e.getQueue().remainingCapacity())
                .description("Remaining capacity of executor work queue")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_queue_usage", executor, this::calculateQueueUsage)
                .description("Queue usage ratio (size/capacity)")
                .tag("pool", poolName)
                .register(meterRegistry);

        Gauge.builder("disruptor_biz_executor_thread_usage", executor, this::calculateThreadUsage)
                .description("Thread usage ratio (active/max)")
                .tag("pool", poolName)
                .register(meterRegistry);
    }

    private double calculateQueueUsage(ThreadPoolExecutor executor) {
        int queueSize = executor.getQueue().size();
        int queueCapacity = executor.getQueue().remainingCapacity() + queueSize;
        return queueCapacity > 0 ? (double) queueSize / queueCapacity : 0.0;
    }

    private double calculateThreadUsage(ThreadPoolExecutor executor) {
        int activeThreads = executor.getActiveCount();
        int maxThreads = executor.getMaximumPoolSize();
        return maxThreads > 0 ? (double) activeThreads / maxThreads : 0.0;
    }

    /**
     * 注册 Disruptor RingBuffer 指标.
     *
     * @param ringBuffer ring buffer 实例
     * @param name 指标名称标签
     */
    public void registerRingBuffer(final RingBuffer<?> ringBuffer, final String name) {
        if (!initialized.get()) {
            return;
        }
        Gauge.builder("disruptor_ring_buffer_size", ringBuffer, rb -> (double) rb.getBufferSize())
                .description("RingBuffer total size")
                .tag("name", name)
                .register(meterRegistry);

        Gauge.builder("disruptor_ring_buffer_remaining_capacity", ringBuffer, rb -> (double) rb.remainingCapacity())
                .description("RingBuffer remaining capacity")
                .tag("name", name)
                .register(meterRegistry);

        Gauge.builder("disruptor_ring_buffer_cursor", ringBuffer, rb -> (double) rb.getCursor())
                .description("RingBuffer published cursor")
                .tag("name", name)
                .register(meterRegistry);

        Gauge.builder("disruptor_ring_buffer_utilization", ringBuffer, this::buildRingBufferUtilizationRatio)
                .description("RingBuffer utilization ratio")
                .tag("name", name)
                .register(meterRegistry);

        // 最小消费者序列（无需直接访问 Sequencer）
        Gauge.builder("disruptor_consumer_min_sequence", ringBuffer, rb -> (double) rb.getMinimumGatingSequence())
                .description("Minimum sequence across all consumers")
                .tag("name", name)
                .register(meterRegistry);

        // 精确 backlog = cursor - min(consumerSequences)
        Gauge.builder("disruptor_ring_buffer_backlog", ringBuffer, this::buildRingBufferBacklog)
                .description("Backlog pending elements in RingBuffer")
                .tag("name", name)
                .register(meterRegistry);
    }

    private Double buildRingBufferUtilizationRatio(final RingBuffer<?> rb) {
        double size = rb.getBufferSize();
        double remaining = rb.remainingCapacity();
        return size > 0 ? (size - remaining) / size : 0.0;
    }

    private Double buildRingBufferBacklog(final RingBuffer<?> rb) {
        long cursor = rb.getCursor();
        long minConsumer = rb.getMinimumGatingSequence();
        long backlog = Math.max(0, cursor - minConsumer);
        return (double) backlog;
    }
}
