package com.yeepay.framework.disruptor.thread;

import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.executor.SingletonExecutor;

/**
 * 自定义哈希取模策略.
 *
 * @param <T> the type parameter
 */
public abstract class AbstractHashModThreadStrategy<T> implements ThreadSelectionStrategy<T> {

    private SingletonExecutor[] executors;

    @Override
    public void initialize(final SingletonExecutor[] virtualExecutors) {
        this.executors = virtualExecutors;
    }

    @Override
    public SingletonExecutor select(final DataEvent<T> event) {
        int index = Math.abs(getHashCode(event)) % executors.length;
        return executors[index];
    }

    /**
     * Gets hash code.
     *
     * @param event the event
     * @return the hash code
     */
    protected abstract int getHashCode(DataEvent<T> event);
}
