package com.yeepay.framework.disruptor.subsriber;

/**
 * The interface Executor type subscriber.
 *
 * @param <T> the type parameter
 */
public interface ExecutorTypeSubscriber<T> extends ExecutorSubscriber<T> {

    /**
     * Gets type.
     *
     * @return the type
     */
    String getType();
}
