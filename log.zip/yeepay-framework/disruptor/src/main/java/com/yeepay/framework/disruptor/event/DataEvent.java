package com.yeepay.framework.disruptor.event;

import lombok.Data;

/**
 * DataEvent.
 * disruptor data carrier .
 *
 * @param <T> the type parameter
 */
@Data
public class DataEvent<T> {

    private T data;
}
