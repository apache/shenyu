package com.yeepay.framework.disruptor.provider;

import com.lmax.disruptor.EventTranslatorOneArg;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.dsl.Disruptor;
import com.yeepay.framework.disruptor.collector.DisruptorMetricsCollector;
import com.yeepay.framework.disruptor.event.DataEvent;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;

/**
 * disruptor provider definition.
 *
 * @param <T> the type parameter
 */
@Slf4j
public class DisruptorProvider<T> {

    private final RingBuffer<DataEvent<T>> ringBuffer;

    private final Disruptor<DataEvent<T>> disruptor;

    private final EventTranslatorOneArg<DataEvent<T>, T> translatorOneArg = (event, sequence, data) -> {
        event.setData(data);
    };

    /**
     * Instantiates a new Disruptor provider.
     *
     * @param ringBuffer the ring buffer
     * @param disruptor  the disruptor
     */
    public DisruptorProvider(final RingBuffer<DataEvent<T>> ringBuffer, final Disruptor<DataEvent<T>> disruptor) {
        this.ringBuffer = ringBuffer;
        this.disruptor = disruptor;
    }

    /**
     * Send a data.
     *
     * @param data the data
     */
    public void onData(final T data) {
        boolean result = ringBuffer.tryPublishEvent(translatorOneArg, data);
        if (!result) {
            DisruptorMetricsCollector.getInstance().recordEventRejected();
            throw new IllegalArgumentException("ringBuffer is full.");
        } else {
            DisruptorMetricsCollector.getInstance().recordEventSubmitted();
        }
    }

    /**
     * Shutdown.
     */
    public void shutdown() {
        if (Objects.nonNull(disruptor)) {
            disruptor.shutdown();
        }
    }
}
