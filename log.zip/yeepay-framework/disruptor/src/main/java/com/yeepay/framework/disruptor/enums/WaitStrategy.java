package com.yeepay.framework.disruptor.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 等待策略枚举.
 */
@RequiredArgsConstructor
@Getter
public enum WaitStrategy {

    /**
     * 阻塞等待策略.
     */
    BLOCKING("blocking"),

    /**
     * 睡眠等待策略.
     */
    SLEEP("sleep"),

    /**
     * 让出等待策略.
     */
    YIELD("yield"),

    /**
     * 忙等待策略.
     */
    BUSY_SPIN("busySpin"),

    /**
     * 轻量级阻塞等待策略.
     */
    LITE_BLOCKING("liteBlocking");

    private final String value;
}
