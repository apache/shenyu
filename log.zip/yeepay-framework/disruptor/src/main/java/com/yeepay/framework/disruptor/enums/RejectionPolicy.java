package com.yeepay.framework.disruptor.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 拒绝策略枚举.
 */
@RequiredArgsConstructor
@Getter
public enum RejectionPolicy {

    /**
     * 调用者运行策略.
     */
    CALLER_RUNS("caller_runs"),

    /**
     * 中止策略.
     */
    ABORT("abort"),

    /**
     * 丢弃策略.
     */
    DISCARD("discard"),

    /**
     * 丢弃最老的策略.
     */
    DISCARD_OLDEST("discard_oldest");

    private final String value;
}
