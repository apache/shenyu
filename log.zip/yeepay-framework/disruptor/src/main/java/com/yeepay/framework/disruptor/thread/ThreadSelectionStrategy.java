package com.yeepay.framework.disruptor.thread;

import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.executor.SingletonExecutor;

/**
 * 顺序一致性时候，线程选择策略接口.
 *
 * @param <T> the type parameter
 */
public interface ThreadSelectionStrategy<T> {

    /**
     * Initialize.
     *
     * @param virtualExecutors the virtual executors
     */
    void initialize(SingletonExecutor[] virtualExecutors);

    /**
     * Select singleton executor.
     *
     * @param event the event
     * @return the singleton executor
     */
    SingletonExecutor select(DataEvent<T> event);
}
