package com.yeepay.framework.disruptor.consumer;

import com.yeepay.framework.disruptor.subsriber.DefaultExecutorSubscriber;
import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import java.util.Map;

/**
 * The type Consumer executor.
 *
 * @param <T> the type parameter
 */
public final class CommonConsumerExecutor<T> extends QueueConsumerExecutor<T> {

    private static final ExecutorSubscriber DEFAULT_SUBSCRIBER = new DefaultExecutorSubscriber<>();

    private final Map<Class<T>, ExecutorSubscriber<T>> subscribers;

    /**
     * Instantiates a new Common consumer executor.
     *
     * @param maps the maps
     */
    public CommonConsumerExecutor(final Map<Class<T>, ExecutorSubscriber<T>> maps) {
        this.subscribers = maps;
    }

    @Override
    public void run() {
        final T data = getData();
        subscribers.getOrDefault(data.getClass(), DEFAULT_SUBSCRIBER).executor(data);
    }
}
