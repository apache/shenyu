package com.yeepay.framework.disruptor.thread;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The type Common thread selection factory.
 *
 * @param <T> the type parameter
 */
public class CommonThreadSelectionFactory<T> implements ThreadSelectionFactory<T> {

    private final List<ThreadSelectionStrategy<T>> strategies;

    private final Map<Class<T>, ThreadSelectionStrategy<T>> customedMaps;

    /**
     * Instantiates a new Common thread selection factory.
     *
     * @param strategies the strategies
     */
    public CommonThreadSelectionFactory(List<ThreadSelectionStrategy<T>> strategies) {
        this.strategies = strategies;
        customedMaps = strategies.stream().collect(Collectors.toMap(this::apply, e -> e));
    }

    @Override
    public List<ThreadSelectionStrategy<T>> getAllStrategies() {
        return new ArrayList<>(strategies);
    }

    @Override
    public ThreadSelectionStrategy<T> create(final Class<T> clazz) {
        return customedMaps.get(clazz);
    }

    private Class<T> apply(final ThreadSelectionStrategy<T> selectionStrategy) {
        Class<?> strategyClass = selectionStrategy.getClass();
        Type[] genericInterfaces = strategyClass.getGenericInterfaces();
        ParameterizedType parameterizedType;
        if (genericInterfaces.length > 0) {
            // 如果实现了接口，从接口中获取泛型类型
            parameterizedType = (ParameterizedType) genericInterfaces[0];
        } else {
            // 如果没有实现接口，从父类中获取泛型类型
            parameterizedType = (ParameterizedType) strategyClass.getGenericSuperclass();
        }
        return (Class<T>) parameterizedType.getActualTypeArguments()[0];
    }
}
