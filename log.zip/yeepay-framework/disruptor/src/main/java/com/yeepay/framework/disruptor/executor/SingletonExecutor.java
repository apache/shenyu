package com.yeepay.framework.disruptor.executor;

import com.yeepay.framework.common.concurrent.MDCExecutorWrapper;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.slf4j.MDC;

/**
 * SingletonExecutor .
 * A thread pool with a corePoolSize of 1.
 */
public class SingletonExecutor extends ThreadPoolExecutor implements MDCExecutorWrapper {

    /**
     * Instantiates a new Singleton executor.
     *
     * @param factory the factory
     * @param workQueue the work queue
     */
    public SingletonExecutor(final ThreadFactory factory, final BlockingQueue<Runnable> workQueue) {
        super(1, 1, 0L, TimeUnit.MILLISECONDS, workQueue, factory);
    }

    @Override
    public void execute(final Runnable command) {
        super.execute(wrap(command, MDC.getCopyOfContextMap()));
    }

    @Override
    public Future<?> submit(final Runnable task) {
        return super.submit(wrap(task, MDC.getCopyOfContextMap()));
    }

    @Override
    public <T> Future<T> submit(final Callable<T> task) {
        return super.submit(wrap(task, MDC.getCopyOfContextMap()));
    }
}
