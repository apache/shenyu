package com.yeepay.framework.disruptor.provider;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.BusySpinWaitStrategy;
import com.lmax.disruptor.EventFactory;
import com.lmax.disruptor.IgnoreExceptionHandler;
import com.lmax.disruptor.LiteBlockingWaitStrategy;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.SleepingWaitStrategy;
import com.lmax.disruptor.YieldingWaitStrategy;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.disruptor.collector.DisruptorMetricsCollector;
import com.yeepay.framework.disruptor.config.DisruptorProperties;
import com.yeepay.framework.disruptor.consumer.QueueConsumer;
import com.yeepay.framework.disruptor.consumer.QueueConsumerFactory;
import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.event.DisruptorEventFactory;
import com.yeepay.framework.disruptor.executor.ConsumerExecutor;
import com.yeepay.framework.disruptor.thread.ThreadSelectionFactory;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import lombok.Getter;

/**
 * disruptor provider manager.
 *
 * @param <T> the type parameter
 */
public class DisruptorProviderManager<T> {

    private final QueueConsumerFactory<T> consumerFactory;

    private final ThreadSelectionFactory<T> selectionFactory;

    private final DisruptorProperties config;

    @Getter
    private DisruptorProvider<T> provider;

    /**
     * Instantiates a new Disruptor provider manager.
     *
     * @param consumerFactory the consumer factory
     * @param config the config
     */
    public DisruptorProviderManager(
            final QueueConsumerFactory<T> consumerFactory,
            final DisruptorProperties config,
            final ThreadSelectionFactory<T> selectionFactory) {
        this.config = config;
        this.consumerFactory = consumerFactory;
        this.selectionFactory = selectionFactory;
    }

    /**
     * start disruptor.
     */
    public void startup() {
        int consumerSize = config.getConsumerSize();
        ConsumerExecutor<T> executor = new ConsumerExecutor<>(
                consumerSize,
                consumerSize,
                0,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(config.getQueueCapacity()),
                YeepayThreadFactory.create("disruptor_consumer_", false),
                buildHandler(),
                selectionFactory);
        EventFactory<DataEvent<T>> eventFactory;
        eventFactory = new DisruptorEventFactory<>();
        Disruptor<DataEvent<T>> disruptor = new Disruptor<>(
                eventFactory,
                config.getRingBufferSize(),
                YeepayThreadFactory.create("disruptor_provider_" + consumerFactory.fixName(), false),
                ProducerType.MULTI,
                buildWaitStrategy());

        QueueConsumer<T>[] consumers = new QueueConsumer[consumerSize];
        for (int i = 0; i < consumerSize; i++) {
            consumers[i] = new QueueConsumer<>(executor, consumerFactory);
        }
        disruptor.handleEventsWithWorkerPool(consumers);
        disruptor.setDefaultExceptionHandler(new IgnoreExceptionHandler());
        disruptor.start();
        RingBuffer<DataEvent<T>> ringBuffer = disruptor.getRingBuffer();
        provider = new DisruptorProvider<>(ringBuffer, disruptor);
        DisruptorMetricsCollector.getInstance().registerThreadPoolExecutor(executor, "disruptor_consumer_biz");
        DisruptorMetricsCollector.getInstance().registerRingBuffer(ringBuffer, consumerFactory.fixName());
    }

    private com.lmax.disruptor.WaitStrategy buildWaitStrategy() {
        return switch (config.getWaitStrategy()) {
            case SLEEP -> new SleepingWaitStrategy();
            case YIELD -> new YieldingWaitStrategy();
            case BUSY_SPIN -> new BusySpinWaitStrategy();
            case LITE_BLOCKING -> new LiteBlockingWaitStrategy();
            default -> new BlockingWaitStrategy();
        };
    }

    private RejectedExecutionHandler buildHandler() {
        return switch (config.getRejectionPolicy()) {
            case DISCARD -> new ThreadPoolExecutor.DiscardPolicy();
            case DISCARD_OLDEST -> new ThreadPoolExecutor.DiscardOldestPolicy();
            case CALLER_RUNS -> new ThreadPoolExecutor.CallerRunsPolicy();
            default -> new ThreadPoolExecutor.AbortPolicy();
        };
    }
}
