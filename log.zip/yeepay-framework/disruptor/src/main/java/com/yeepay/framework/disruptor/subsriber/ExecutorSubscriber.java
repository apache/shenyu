package com.yeepay.framework.disruptor.subsriber;

import java.util.Collection;

/**
 * The interface Executor subscriber.
 *
 * @param <T> the type parameter
 */
public interface ExecutorSubscriber<T> {

    /**
     * Executor.
     *
     * @param dataList the data list
     */
    default void executor(Collection<T> dataList) {
        for (T data : dataList) {
            executor(data);
        }
    }

    /**
     * Executor.
     *
     * @param data the data
     */
    default void executor(T data) {}
}
