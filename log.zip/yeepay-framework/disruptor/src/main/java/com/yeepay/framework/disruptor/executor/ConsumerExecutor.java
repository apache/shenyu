package com.yeepay.framework.disruptor.executor;

import com.yeepay.framework.common.concurrent.MDCExecutorWrapper;
import com.yeepay.framework.disruptor.event.DataEvent;
import com.yeepay.framework.disruptor.thread.ThreadSelectionFactory;
import com.yeepay.framework.disruptor.thread.ThreadSelectionStrategy;
import java.util.Objects;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.slf4j.MDC;

/**
 * ConsumerExecutor .
 * 支持可扩展的线程选择策略的有序执行器
 *
 * @param <T> the type parameter
 */
public class ConsumerExecutor<T> extends ThreadPoolExecutor implements MDCExecutorWrapper {

    private final ThreadSelectionFactory<T> selectionFactory;

    /**
     * Instantiates a new Orderly executor with custom thread selection strategy.
     *
     * @param corePoolSize the core pool size
     * @param maximumPoolSize the maximum pool size
     * @param keepAliveTime the keep alive time
     * @param unit the unit
     * @param workQueue the work queue
     * @param threadFactory the thread factory
     * @param handler the handler
     * @param selectionFactory the selection factory
     */
    public ConsumerExecutor(
            final int corePoolSize,
            final int maximumPoolSize,
            final long keepAliveTime,
            final TimeUnit unit,
            final BlockingQueue<Runnable> workQueue,
            final ThreadFactory threadFactory,
            final RejectedExecutionHandler handler,
            final ThreadSelectionFactory<T> selectionFactory) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory, handler);
        // 使用自定义策略或默认的一致性哈希策略
        SingletonExecutor[] executors = new SingletonExecutor[corePoolSize];
        for (int i = 0; i < corePoolSize; i++) {
            executors[i] = new SingletonExecutor(threadFactory, workQueue);
        }
        this.selectionFactory = selectionFactory;
        selectionFactory.getAllStrategies().forEach(selectionStrategy -> selectionStrategy.initialize(executors));
    }

    @Override
    public void execute(final Runnable command) {
        super.execute(wrap(command, MDC.getCopyOfContextMap()));
    }

    @Override
    public Future<?> submit(final Runnable task) {
        return super.submit(wrap(task, MDC.getCopyOfContextMap()));
    }

    @Override
    public <T> Future<T> submit(final Callable<T> task) {
        return super.submit(wrap(task, MDC.getCopyOfContextMap()));
    }

    /**
     * Select thread pool executor.
     *
     * @param dataEvent the data event
     * @return the thread pool executor
     */
    public ThreadPoolExecutor select(final DataEvent<T> dataEvent) {
        Class<T> clazz = (Class<T>) dataEvent.getData().getClass();
        ThreadSelectionStrategy<T> selectionStrategy = selectionFactory.create(clazz);
        if (Objects.isNull(selectionStrategy)) {
            return this;
        }
        return selectionStrategy.select(dataEvent);
    }
}
