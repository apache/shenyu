package com.yeepay.framework.disruptor.consumer;

import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;

/**
 * The interface Queue consumer factory.
 *
 * @param <T> the type parameter
 */
public interface QueueConsumerFactory<T> extends ExecutorFactory {

    /**
     * Create queue consumer executor.
     *
     * @return the queue consumer executor
     */
    QueueConsumerExecutor<T> create();

    /**
     * Fix name string.
     *
     * @return the string
     */
    String fixName();

    /**
     * Add subscribers.
     *
     * @param subscriber the subscriber
     */
    default void addSubscribers(final ExecutorSubscriber<T> subscriber) {}
}
