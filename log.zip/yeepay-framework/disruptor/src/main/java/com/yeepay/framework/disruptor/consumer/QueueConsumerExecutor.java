package com.yeepay.framework.disruptor.consumer;

import lombok.Getter;
import lombok.Setter;

/**
 * The type Queue consumer executor.
 *
 * @param <T> the type parameter
 */
@Setter
@Getter
public abstract class QueueConsumerExecutor<T> implements Runnable {

    private T data;
}
