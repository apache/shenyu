package com.yeepay.framework.disruptor.consumer;

/**
 * The interface Executor factory.
 */
public interface ExecutorFactory {}
