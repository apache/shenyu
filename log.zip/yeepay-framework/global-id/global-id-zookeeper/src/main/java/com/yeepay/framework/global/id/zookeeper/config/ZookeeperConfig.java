package com.yeepay.framework.global.id.zookeeper.config;

import java.time.Duration;
import lombok.Data;

/**
 * 基于 ZooKeeper 的 workerId 分配器配置.
 */
@Data
public class ZookeeperConfig {

    /**
     * 连接串，多个节点逗号分隔，如 {@code 10.0.0.1:2181,10.0.0.2:2181}.
     */
    private String connectString;

    /**
     * 命名空间，所有 znode 路径会自动加上 {@code /namespace} 前缀；留空则不启用 namespace.
     */
    private String namespace;

    /**
     * 会话超时. 决定 EPHEMERAL 节点回收时机.
     * 设置过小会导致网络抖动误删节点，30s 是兼顾滚动发布速度与稳定性的平衡值.
     */
    private Duration sessionTimeout = Duration.ofSeconds(30);

    /**
     * 连接建立超时.
     */
    private Duration connectionTimeout = Duration.ofSeconds(15);

    /**
     * 指数退避重试初始等待.
     */
    private Duration baseSleepTime = Duration.ofSeconds(1);

    /**
     * 指数退避最大重试次数.
     */
    private int maxRetries = 3;

    /**
     * digest 认证字符串（{@code username:password}），留空则不启用认证.
     */
    private String digestAuth;

    /**
     * workerId 分配根路径. 实际 worker 节点在 {@code basePath/{workerName}/worker-} 下创建.
     */
    private String basePath = "/yeepay/global-id";

    /**
     * 允许的最大 workerId（与雪花算法的 workerBits 对齐）.
     * 当 EPHEMERAL_SEQUENTIAL 计数器越过该上限时，直接抛 {@code UidGenerateException}，
     * 避免回绕到合法范围与未过期槽位撞 ID. 默认对应 workerBits=18 的上限.
     */
    private long maxWorkerId = (1L << 18) - 1;
}
