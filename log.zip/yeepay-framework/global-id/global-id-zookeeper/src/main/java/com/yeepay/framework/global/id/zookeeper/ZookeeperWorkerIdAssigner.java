package com.yeepay.framework.global.id.zookeeper;

import com.yeepay.framework.common.utils.NetUtils;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.exception.UidGenerateException;
import com.yeepay.framework.global.id.zookeeper.config.ZookeeperConfig;
import com.yeepay.framework.infra.zookeeper.CuratorClientFactory;
import com.yeepay.framework.infra.zookeeper.config.ZkConfig;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import lombok.extern.slf4j.Slf4j;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.state.ConnectionStateListener;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;

/**
 * 基于 ZooKeeper EPHEMERAL 节点的 workerId 分配器（全局共享池模型）.
 *
 * <p>语义：
 * <ol>
 *   <li>所有应用共享同一父路径 {@code basePath/pool}（保证 workerId 跨应用唯一）</li>
 *   <li>通过 getChildren 扫描当前已占用的槽位，找到最小可用 ID，
 *       创建 EPHEMERAL 节点 {@code worker-{id}} 占位</li>
 *   <li>节点 data 记录 {@code workerName:hostName}，便于运维查看每个 workerId 被哪个应用占用</li>
 *   <li>会话断开（session expired）时 EPHEMERAL 节点自动删除，
 *       workerId 立即可被其他实例复用，无需心跳轮询</li>
 *   <li>当所有 [0, maxWorkerId] 槽位均被占用时 strict-fail</li>
 * </ol>
 *
 * <p>会话丢失（{@link org.apache.curator.framework.state.ConnectionState#LOST}）时仅 ERROR 日志告警，
 * 不自动重新分配 workerId —— 与 DB 版"心跳丢失只告警让运维介入"语义对齐.
 *
 * <p>资源管理：实现 {@link AutoCloseable}. Spring 环境通过 {@code @Bean(destroyMethod = "close")} 触发关闭.
 */
@Slf4j
public class ZookeeperWorkerIdAssigner implements WorkerIdAssigner<ZookeeperConfig>, AutoCloseable {

    private static final String NODE_PREFIX = "worker-";

    private static final int NODE_ID_WIDTH = 10;

    private static final String POOL_NAME = "pool";

    private CuratorFramework client;

    private long maxWorkerId;

    private String basePath;

    private final AtomicBoolean closed = new AtomicBoolean(false);

    @Override
    public void init(final ZookeeperConfig config) {
        Objects.requireNonNull(config, "ZookeeperConfig 不能为 null");
        this.client = CuratorClientFactory.create(toZkConfig(config));
        this.maxWorkerId = config.getMaxWorkerId();
        this.basePath = config.getBasePath();
        this.client.getConnectionStateListenable().addListener(stateListener());
    }

    @Override
    public long assignWorkerId(final String workerName) {
        if (Objects.isNull(workerName) || workerName.isBlank()) {
            throw new IllegalArgumentException("workerName 不能为空");
        }

        String parentPath = basePath + "/" + POOL_NAME;
        String hostName = NetUtils.getLocalAddress();
        String dataStr = workerName.trim() + ":" + hostName + ":"
                + UUID.randomUUID().toString().substring(0, 8);
        byte[] data = dataStr.getBytes(StandardCharsets.UTF_8);

        ensureParentExists(parentPath);

        Set<Long> occupied = getOccupiedSlots(parentPath);

        long total = maxWorkerId + 1;
        long startId = ThreadLocalRandom.current().nextLong(total);
        for (long offset = 0; offset < total; offset++) {
            long id = (startId + offset) % total;
            if (occupied.contains(id)) {
                continue;
            }
            String nodePath = parentPath + "/" + formatNodeName(id);
            try {
                client.create().withMode(CreateMode.EPHEMERAL).forPath(nodePath, data);
                log.info(
                        "ZK assigned workerId: workerId={}, workerName={}, path={}, host={}",
                        id,
                        workerName,
                        nodePath,
                        hostName);
                return id;
            } catch (KeeperException.NodeExistsException e) {
                log.debug("Slot {} already claimed by another node, trying next", id);
            } catch (Exception e) {
                throw new UidGenerateException("ZK 创建 worker 节点失败: " + nodePath, e);
            }
        }

        throw new UidGenerateException(
                "所有 workerId [0, %d] 均已被占用. workerName=%s, parentPath=%s. "
                        + "请检查是否存在僵尸会话，或调大 ZookeeperConfig.maxWorkerId / workerBits.",
                maxWorkerId, workerName, parentPath);
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        if (Objects.nonNull(client)) {
            try {
                client.close();
            } catch (RuntimeException e) {
                log.warn("Failed to close CuratorFramework", e);
            }
        }
        log.info("ZookeeperWorkerIdAssigner closed.");
    }

    private void ensureParentExists(final String parentPath) {
        try {
            if (Objects.isNull(client.checkExists().forPath(parentPath))) {
                client.create().creatingParentsIfNeeded().forPath(parentPath);
            }
        } catch (KeeperException.NodeExistsException e) {
            // 并发创建，忽略
        } catch (Exception e) {
            throw new UidGenerateException("ZK 创建父路径失败: " + parentPath, e);
        }
    }

    private Set<Long> getOccupiedSlots(final String parentPath) {
        List<String> children;
        try {
            children = client.getChildren().forPath(parentPath);
        } catch (Exception e) {
            throw new UidGenerateException("ZK 获取子节点失败: " + parentPath, e);
        }
        Set<Long> occupied = new HashSet<>();
        for (String child : children) {
            if (child.startsWith(NODE_PREFIX)) {
                try {
                    occupied.add(Long.parseLong(child.substring(NODE_PREFIX.length())));
                } catch (NumberFormatException e) {
                    log.warn("忽略非法子节点: {}/{}", parentPath, child);
                }
            }
        }
        return occupied;
    }

    private static String formatNodeName(final long id) {
        return NODE_PREFIX + String.format("%0" + NODE_ID_WIDTH + "d", id);
    }

    private ConnectionStateListener stateListener() {
        return (curator, newState) -> {
            if (closed.get()) {
                return;
            }
            switch (newState) {
                case LOST ->
                    log.error("ZK session LOST: ephemeral worker 节点已被删除，本实例 workerId 已失效. "
                            + "继续生成 UID 将与新会话分配的 workerId 撞 ID，请立即重启本实例.");
                case SUSPENDED -> log.warn("ZK session SUSPENDED: 连接挂起，超过 sessionTimeout 未恢复将转为 LOST.");
                case RECONNECTED -> log.info("ZK session RECONNECTED: 会话已恢复.");
                case READ_ONLY -> log.warn("ZK session READ_ONLY: 集群可能丢失多数派.");
                default -> {
                    /* CONNECTED 初次连接不打印 */
                }
            }
        };
    }

    private static ZkConfig toZkConfig(final ZookeeperConfig src) {
        ZkConfig dst = new ZkConfig();
        dst.setConnectString(src.getConnectString());
        dst.setNamespace(src.getNamespace());
        dst.setSessionTimeout(src.getSessionTimeout());
        dst.setConnectionTimeout(src.getConnectionTimeout());
        dst.setDigestAuth(src.getDigestAuth());
        dst.getRetry().setBaseSleepTime(src.getBaseSleepTime());
        dst.getRetry().setMaxRetries(src.getMaxRetries());
        return dst;
    }
}
