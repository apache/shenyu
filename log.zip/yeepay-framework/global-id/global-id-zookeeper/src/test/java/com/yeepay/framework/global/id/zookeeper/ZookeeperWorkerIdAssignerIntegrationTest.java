package com.yeepay.framework.global.id.zookeeper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.global.id.api.exception.UidGenerateException;
import com.yeepay.framework.global.id.zookeeper.config.ZookeeperConfig;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import org.apache.curator.test.TestingServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * 基于 Curator {@link TestingServer} 的集成测试.
 *
 * <p>覆盖：
 * <ul>
 *   <li>同一 workerName 下连续分配的 workerId 互不相同且在有效范围内</li>
 *   <li>不同 workerName 槽位池独立</li>
 *   <li>close 后 EPHEMERAL 节点被清理，workerId 可被复用</li>
 *   <li>所有槽位占满后 strict-fail</li>
 *   <li>close 多次幂等；空 workerName 拒绝</li>
 * </ul>
 */
class ZookeeperWorkerIdAssignerIntegrationTest {

    private static TestingServer server;

    private static final AtomicLong PATH_SEQ = new AtomicLong();

    @BeforeAll
    static void startZk() throws Exception {
        server = new TestingServer();
    }

    @AfterAll
    static void stopZk() throws Exception {
        if (server != null) {
            server.close();
        }
    }

    private ZookeeperConfig newConfig() {
        ZookeeperConfig c = new ZookeeperConfig();
        c.setConnectString(server.getConnectString());
        c.setBasePath("/test/global-id/" + PATH_SEQ.incrementAndGet() + "-" + System.nanoTime());
        c.setSessionTimeout(Duration.ofSeconds(10));
        c.setConnectionTimeout(Duration.ofSeconds(5));
        c.setBaseSleepTime(Duration.ofMillis(200));
        c.setMaxRetries(2);
        return c;
    }

    @Test
    @DisplayName("同 workerName 多次分配应得到互不相同的 workerId，且均在有效范围内")
    void assigns_unique_ids_under_same_workerName() {
        ZookeeperConfig config = newConfig();

        ZookeeperWorkerIdAssigner a1 = new ZookeeperWorkerIdAssigner();
        ZookeeperWorkerIdAssigner a2 = new ZookeeperWorkerIdAssigner();
        ZookeeperWorkerIdAssigner a3 = new ZookeeperWorkerIdAssigner();
        try {
            a1.init(config);
            a2.init(config);
            a3.init(config);

            long id1 = a1.assignWorkerId("order");
            long id2 = a2.assignWorkerId("order");
            long id3 = a3.assignWorkerId("order");

            Set<Long> ids = Set.of(id1, id2, id3);
            assertThat(ids).hasSize(3);
            assertThat(ids).allMatch(id -> id >= 0 && id <= config.getMaxWorkerId());
        } finally {
            a3.close();
            a2.close();
            a1.close();
        }
    }

    @Test
    @DisplayName("不同 workerName 在共享池中获得不同的 workerId")
    void different_workerNames_get_unique_ids_in_shared_pool() {
        ZookeeperConfig config = newConfig();

        ZookeeperWorkerIdAssigner a = new ZookeeperWorkerIdAssigner();
        ZookeeperWorkerIdAssigner b = new ZookeeperWorkerIdAssigner();
        try {
            a.init(config);
            b.init(config);

            long groupA = a.assignWorkerId("group-a");
            long groupB = b.assignWorkerId("group-b");

            assertThat(groupA).isNotEqualTo(groupB);
            assertThat(Set.of(groupA, groupB)).allMatch(id -> id >= 0 && id <= config.getMaxWorkerId());
        } finally {
            a.close();
            b.close();
        }
    }

    @Test
    @DisplayName("close 后 EPHEMERAL 节点被回收，workerId 可被复用")
    void workerId_reused_after_close() {
        ZookeeperConfig config = newConfig();
        config.setMaxWorkerId(0L);

        ZookeeperWorkerIdAssigner a1 = new ZookeeperWorkerIdAssigner();
        a1.init(config);
        long first = a1.assignWorkerId("reuse");
        assertThat(first).isEqualTo(0L);
        a1.close();

        ZookeeperWorkerIdAssigner a2 = new ZookeeperWorkerIdAssigner();
        try {
            a2.init(config);
            long second = a2.assignWorkerId("reuse");
            assertThat(second).isEqualTo(0L);
        } finally {
            a2.close();
        }
    }

    @Test
    @DisplayName("所有槽位占满后抛 UidGenerateException")
    void overflow_throws_strict_fail() {
        ZookeeperConfig config = newConfig();
        config.setMaxWorkerId(0L);

        ZookeeperWorkerIdAssigner a1 = new ZookeeperWorkerIdAssigner();
        ZookeeperWorkerIdAssigner a2 = new ZookeeperWorkerIdAssigner();
        try {
            a1.init(config);
            a2.init(config);

            assertThat(a1.assignWorkerId("overflow")).isEqualTo(0L);
            assertThatThrownBy(() -> a2.assignWorkerId("overflow"))
                    .isInstanceOf(UidGenerateException.class)
                    .hasMessageContaining("均已被占用");
        } finally {
            a1.close();
            a2.close();
        }
    }

    @Test
    @DisplayName("close 多次调用应幂等")
    void close_is_idempotent() {
        ZookeeperConfig config = newConfig();
        ZookeeperWorkerIdAssigner a = new ZookeeperWorkerIdAssigner();
        a.init(config);
        a.assignWorkerId("idempotent");
        a.close();
        a.close();
        a.close();
    }

    @Test
    @DisplayName("空 / null workerName 应被拒绝")
    void empty_worker_name_rejected() {
        ZookeeperConfig config = newConfig();
        ZookeeperWorkerIdAssigner a = new ZookeeperWorkerIdAssigner();
        try {
            a.init(config);
            assertThatThrownBy(() -> a.assignWorkerId("")).isInstanceOf(IllegalArgumentException.class);
            assertThatThrownBy(() -> a.assignWorkerId("   ")).isInstanceOf(IllegalArgumentException.class);
            assertThatThrownBy(() -> a.assignWorkerId(null)).isInstanceOf(IllegalArgumentException.class);
        } finally {
            a.close();
        }
    }

    @Test
    @DisplayName("槽位释放后优先填补空洞")
    void fills_gaps_after_slot_released() {
        ZookeeperConfig config = newConfig();
        config.setMaxWorkerId(2L);

        ZookeeperWorkerIdAssigner a0 = new ZookeeperWorkerIdAssigner();
        ZookeeperWorkerIdAssigner a1 = new ZookeeperWorkerIdAssigner();
        ZookeeperWorkerIdAssigner a2 = new ZookeeperWorkerIdAssigner();
        a0.init(config);
        a1.init(config);
        a2.init(config);

        long id0 = a0.assignWorkerId("gap");
        long id1 = a1.assignWorkerId("gap");
        long id2 = a2.assignWorkerId("gap");
        assertThat(Set.of(id0, id1, id2)).containsExactlyInAnyOrder(0L, 1L, 2L);

        // 释放中间的槽位
        a1.close();

        ZookeeperWorkerIdAssigner a3 = new ZookeeperWorkerIdAssigner();
        try {
            a3.init(config);
            long reused = a3.assignWorkerId("gap");
            assertThat(reused).isEqualTo(id1);
        } finally {
            a0.close();
            a2.close();
            a3.close();
        }
    }
}
