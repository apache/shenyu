package com.yeepay.framework.global.id.core.buffer;

import java.util.List;

/**
 * 缓冲UID提供器.
 */
@FunctionalInterface
public interface BufferedUidProvider {

    /**
     * Provides UID in one second.
     *
     * @param momentInSecond 时间秒数
     * @return UID列表
     */
    List<Long> provide(long momentInSecond);
}
