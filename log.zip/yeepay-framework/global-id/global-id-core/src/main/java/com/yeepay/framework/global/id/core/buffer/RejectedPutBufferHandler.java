package com.yeepay.framework.global.id.core.buffer;

/**
 * 拒绝放入缓冲区处理器.
 */
@FunctionalInterface
public interface RejectedPutBufferHandler {

    /**
     * Reject put buffer request.
     *
     * @param ringBuffer 环形缓冲区
     * @param uid        UID值
     */
    void rejectPutBuffer(RingBuffer ringBuffer, long uid);
}
