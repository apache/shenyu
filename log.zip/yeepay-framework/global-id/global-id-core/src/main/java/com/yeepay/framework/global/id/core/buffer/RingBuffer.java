package com.yeepay.framework.global.id.core.buffer;

import com.google.common.base.Preconditions;
import java.util.concurrent.atomic.AtomicLong;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 环形缓冲区.
 * 用于高性能UID生成的缓冲机制.
 */
public class RingBuffer {

    private static final Logger LOGGER = LoggerFactory.getLogger(RingBuffer.class);

    /**
     * 开始位置常量.
     */
    private static final int START_POINT = -1;

    /**
     * 可放入标志.
     */
    private static final long CAN_PUT_FLAG = 0L;

    /**
     * 可取出标志.
     */
    private static final long CAN_TAKE_FLAG = 1L;

    /**
     * 默认填充百分比.
     */
    private static final int DEFAULT_PADDING_PERCENT = 50;

    /**
     * RingBuffer插槽的大小，每个插槽保存一个UID.
     */
    private final int bufferSize;

    /**
     * 索引掩码.
     */
    private final long indexMask;

    /**
     * 插槽数组.
     */
    private final long[] slots;

    /**
     * 标志数组.
     */
    private final PaddedAtomicLong[] flags;

    /**
     * 尾部：生产的最后位置序列.
     */
    private final AtomicLong tail = new PaddedAtomicLong(START_POINT);

    /**
     * 游标：消费的当前位置序列.
     */
    private final AtomicLong cursor = new PaddedAtomicLong(START_POINT);

    /**
     * 触发填充缓冲区的阈值.
     */
    private final int paddingThreshold;

    /**
     * 拒绝PUT缓冲区处理策略.
     */
    private RejectedPutBufferHandler rejectedPutHandler = this::discardPutBuffer;

    /**
     * 拒绝TAKE缓冲区处理策略.
     */
    @Setter
    private RejectedTakeBufferHandler rejectedTakeHandler = this::exceptionRejectedTakeBuffer;

    /**
     * 缓冲区填充执行器.
     */
    @Setter
    private BufferPaddingExecutor bufferPaddingExecutor;

    /**
     * 构造函数，使用默认填充因子.
     *
     * @param bufferSize 缓冲区大小，必须是正数且是2的幂
     */
    public RingBuffer(int bufferSize) {
        this(bufferSize, DEFAULT_PADDING_PERCENT);
    }

    /**
     * 构造函数，指定缓冲区大小和填充因子.
     *
     * @param bufferSize    缓冲区大小，必须是正数且是2的幂
     * @param paddingFactor 填充因子百分比(0-100)。当剩余可用UID达到阈值时，
     *                      将触发填充缓冲区。
     *                      例如：paddingFactor=20, bufferSize=1000 -&gt;
     *                      threshold=1000 * 20 /100,
     *                      当tail-cursor&lt;threshold时触发填充缓冲区
     */
    public RingBuffer(int bufferSize, int paddingFactor) {
        // check buffer size is positive & a power of 2;
        // padding factor in (0, 100)
        Preconditions.checkArgument(bufferSize > 0L, "RingBuffer size must be positive");
        Preconditions.checkArgument(Integer.bitCount(bufferSize) == 1, "RingBuffer size must be a power of 2");
        Preconditions.checkArgument(
                paddingFactor > 0 && paddingFactor < 100, "paddingFactor must be between 0 and 100");
        this.bufferSize = bufferSize;
        this.indexMask = bufferSize - 1;
        this.slots = new long[bufferSize];
        this.flags = initFlags(bufferSize);
        this.paddingThreshold = bufferSize * paddingFactor / 100;
    }

    /**
     * 设置 RejectedPutBufferHandler.
     * @param rejectedPutHandler RejectedPutBufferHandler
     */
    public synchronized void setRejectedPutHandler(RejectedPutBufferHandler rejectedPutHandler) {
        this.rejectedPutHandler = rejectedPutHandler;
    }

    /**
     * 在环中放入UID并移动尾部.
     * 我们使用 synchronized 来保证UID填入插槽和发布新尾部序列的原子操作.
     * <b>注意：</b> 建议以串行方式放入UID，因为我们曾经批量生成一系列UID
     * 并逐个放入缓冲区，所以没必要多线程放入
     *
     * @param uid 要放入的UID
     * @return false表示缓冲区已满，应用{@link RejectedPutBufferHandler}
     */
    public synchronized boolean put(long uid) {
        long currentTail = tail.get();
        long currentCursor = cursor.get();
        // tail catches the cursor, means that you can't put any cause of
        // bufferSize overflow
        long distance = currentTail - (currentCursor == START_POINT ? 0 : currentCursor);
        if (distance == bufferSize - 1) {
            rejectedPutHandler.rejectPutBuffer(this, uid);
            return false;
        }
        // 1. pre-check whether the flag is CAN_PUT_FLAG
        int nextTailIndex = calSlotIndex(currentTail + 1);
        if (flags[nextTailIndex].get() != CAN_PUT_FLAG) {
            rejectedPutHandler.rejectPutBuffer(this, uid);
            return false;
        }

        // 2. put UID in the next slot
        // 3. update next slot' flag to CAN_TAKE_FLAG
        // 4. publish tail with sequence increase by one
        slots[nextTailIndex] = uid;
        flags[nextTailIndex].set(CAN_TAKE_FLAG);
        tail.incrementAndGet();
        // The atomicity of operations above, guarantees by 'synchronized'. In
        // another word,
        // ONLY ONE Consumer thread take UID by atom operation consume a slot
        // ONLY ONE Producer thread fills a slot by atom operation produce a
        // slot
        return true;
    }

    /**
     * 从环中取出UID.
     *
     * @return 取出的UID
     */
    public long take() {
        // spin get next available cursor
        long currentCursor = cursor.get();
        long nextCursor = cursor.updateAndGet(old -> old == tail.get() ? old : old + 1);
        // check for safety consideration, it never occurs
        Preconditions.checkArgument(nextCursor >= currentCursor, "Curosr can't move back");
        // trigger padding in an async-mode if reach the threshold
        long currentTail = tail.get();
        if (currentTail - nextCursor < paddingThreshold) {
            LOGGER.info(
                    "Reach the padding threshold:{}. tail:{}, " + "cursor:{}, rest:{}",
                    paddingThreshold,
                    currentTail,
                    nextCursor,
                    currentTail - nextCursor);
            bufferPaddingExecutor.asyncPadding();
        }
        // cursor catch the tail, means that there is no more available UID
        // to take
        if (nextCursor == currentCursor) {
            rejectedTakeHandler.rejectTakeBuffer(this);
        }
        // 1. check next slot flag is CAN_TAKE_FLAG
        int nextCursorIndex = calSlotIndex(nextCursor);
        Preconditions.checkArgument(flags[nextCursorIndex].get() == CAN_TAKE_FLAG, "Curosr not in can take status");
        // 2. get UID from next slot
        // 3. set next slot flag as CAN_PUT_FLAG.
        long uid = slots[nextCursorIndex];
        flags[nextCursorIndex].set(CAN_PUT_FLAG);
        // Note that: Step 2,3 can not swap. If we set flag before get value
        // of slot, the producer may overwrite the
        // slot with a new UID, and this may cause the consumer take the UID
        // twice after walk a round the ring
        return uid;
    }

    /**
     * 使用插槽序列计算插槽索引 (sequence % bufferSize).
     *
     * @param sequence 序列号
     * @return 插槽索引
     */
    protected int calSlotIndex(long sequence) {
        return (int) (sequence & indexMask);
    }

    /**
     * {@link RejectedPutBufferHandler}的丢弃策略，我们只记录日志.
     *
     * @param ringBuffer 环形缓冲区
     * @param uid        被拒绝的UID
     */
    private void discardPutBuffer(RingBuffer ringBuffer, long uid) {
        LOGGER.warn("Rejected putting buffer for uid:{}. {}", uid, ringBuffer);
    }

    /**
     * {@link RejectedTakeBufferHandler}的异常策略，抛出异常.
     *
     * @param ringBuffer 环形缓冲区
     */
    private void exceptionRejectedTakeBuffer(RingBuffer ringBuffer) {
        LOGGER.warn("Rejected take buffer. {}", ringBuffer);
        throw new RuntimeException("Rejected take buffer. " + ringBuffer);
    }

    /**
     * 初始化标志数组.
     *
     * @param bufferSize 缓冲区大小
     * @return 标志数组
     */
    private PaddedAtomicLong[] initFlags(int bufferSize) {
        PaddedAtomicLong[] flags = new PaddedAtomicLong[bufferSize];
        for (int i = 0; i < bufferSize; i++) {
            flags[i] = new PaddedAtomicLong(CAN_PUT_FLAG);
        }
        return flags;
    }

    /**
     * 返回字符串表示.
     *
     * @return 字符串表示
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RingBuffer [bufferSize=")
                .append(bufferSize)
                .append(", tail=")
                .append(tail)
                .append(", cursor=")
                .append(cursor)
                .append(", paddingThreshold=")
                .append(paddingThreshold)
                .append("]");
        return builder.toString();
    }
}
