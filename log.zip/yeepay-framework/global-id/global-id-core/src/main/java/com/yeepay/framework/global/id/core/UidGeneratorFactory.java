package com.yeepay.framework.global.id.core;

import com.google.common.base.Preconditions;
import com.yeepay.framework.common.utils.YeepayDateUtils;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.core.buffer.RejectedPutBufferHandler;
import com.yeepay.framework.global.id.core.buffer.RejectedTakeBufferHandler;
import com.yeepay.framework.global.id.core.service.BitsAllocator;
import com.yeepay.framework.global.id.core.service.CachedUidGenerator;
import java.util.Date;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * The type Uid generator factory.
 */
@Slf4j
public final class UidGeneratorFactory {

    // 私有构造函数，防止实例化
    private UidGeneratorFactory() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Create cached uid generator.
     *
     * @param <T> the type parameter
     * @param config the config
     * @param workerIdAssigner the worker id assigner
     * @return the cached uid generator
     */
    public static <T> CachedUidGenerator create(GlobalIdConfig config, WorkerIdAssigner<T> workerIdAssigner) {
        validate(config, workerIdAssigner);
        CachedUidGenerator cachedUidGenerator = new CachedUidGenerator();
        cachedUidGenerator.setWorkerIdAssigner(workerIdAssigner);
        cachedUidGenerator.setTimeBits(config.getTimeBits());
        cachedUidGenerator.setWorkerBits(config.getWorkerBits());
        cachedUidGenerator.setSeqBits(config.getSeqBits());
        cachedUidGenerator.setEpochStr(config.getEpochStr());
        cachedUidGenerator.setBoostPower(config.getBoostPower());
        cachedUidGenerator.setPaddingFactor(config.getPaddingFactor());
        cachedUidGenerator.setScheduleInterval(config.getScheduleInterval());
        cachedUidGenerator.setRejectedPutBufferHandler(rejectedPutBufferHandler());
        cachedUidGenerator.setRejectedTakeBufferHandler(rejectedTakeBufferHandler());
        cachedUidGenerator.setWorkerName(config.getWorkerName());
        cachedUidGenerator.init();
        return cachedUidGenerator;
    }

    /**
     * 校验工厂入参，所有不合法配置在创建前快速失败，避免延迟到 init() 阶段才暴露问题.
     *
     * @param config           全局 ID 配置
     * @param workerIdAssigner 工作节点 ID 分配器
     */
    private static void validate(GlobalIdConfig config, WorkerIdAssigner<?> workerIdAssigner) {
        Preconditions.checkNotNull(config, "GlobalIdConfig 不能为 null");
        Preconditions.checkNotNull(workerIdAssigner, "WorkerIdAssigner 不能为 null");

        Integer timeBits = config.getTimeBits();
        Integer workerBits = config.getWorkerBits();
        Integer seqBits = config.getSeqBits();
        Preconditions.checkArgument(Objects.nonNull(timeBits) && timeBits > 0, "timeBits 必须为正整数，当前值: %s", timeBits);
        Preconditions.checkArgument(
                Objects.nonNull(workerBits) && workerBits > 0, "workerBits 必须为正整数，当前值: %s", workerBits);
        Preconditions.checkArgument(Objects.nonNull(seqBits) && seqBits > 0, "seqBits 必须为正整数，当前值: %s", seqBits);
        int totalBits = timeBits + workerBits + seqBits;
        Preconditions.checkArgument(
                totalBits <= BitsAllocator.TOTAL_BITS,
                "timeBits + workerBits + seqBits 之和不能超过 %s，当前为 %s",
                BitsAllocator.TOTAL_BITS,
                totalBits);

        String epochStr = config.getEpochStr();
        if (StringUtils.isNotBlank(config.getEpochStr())) {
            Date epoch;
            try {
                epoch = YeepayDateUtils.parseByDayPattern(epochStr);
            } catch (RuntimeException e) {
                throw new IllegalArgumentException("epochStr 必须是合法的 yyyy-MM-dd 日期，当前值: " + epochStr, e);
            }
            Preconditions.checkArgument(!epoch.after(new Date()), "epochStr 不能晚于今天，当前值: %s", epochStr);
        }

        Integer boostPower = config.getBoostPower();
        Preconditions.checkArgument(
                Objects.nonNull(boostPower) && boostPower >= 0, "boostPower 必须为非负整数，当前值: %s", boostPower);
        // RingBuffer 容量 = (maxSequence + 1) << boostPower = 1 << (seqBits + boostPower)，
        // 需保证不超出 int 正数范围（最高 1<<30）.
        Preconditions.checkArgument(
                seqBits + boostPower <= 30,
                "seqBits + boostPower 不能超过 30（否则 RingBuffer 容量溢出），seqBits=%s, boostPower=%s",
                seqBits,
                boostPower);

        Integer paddingFactor = config.getPaddingFactor();
        Preconditions.checkArgument(
                Objects.nonNull(paddingFactor) && paddingFactor > 0 && paddingFactor < 100,
                "paddingFactor 必须在 (0, 100) 区间，当前值: %s",
                paddingFactor);

        Integer scheduleInterval = config.getScheduleInterval();
        Preconditions.checkArgument(
                Objects.nonNull(scheduleInterval) && scheduleInterval >= 0,
                "scheduleInterval 必须为非负整数（0 表示不启用周期填充），当前值: %s",
                scheduleInterval);

        Preconditions.checkArgument(StringUtils.isNotBlank(config.getWorkerName()), "workerName 不能为空");
    }

    /**
     * 拒绝放入缓冲区处理器.
     */
    private static RejectedPutBufferHandler rejectedPutBufferHandler() {
        return (ringBuffer, uid) -> log.debug("拒绝放入缓冲区 UID:{}. {}", uid, ringBuffer);
    }

    /**
     * 拒绝获取缓冲区处理器.
     */
    private static RejectedTakeBufferHandler rejectedTakeBufferHandler() {
        return ringBuffer -> {
            log.warn("拒绝获取缓冲区. {}", ringBuffer);
            throw new RuntimeException("拒绝获取缓冲区. " + ringBuffer);
        };
    }
}
