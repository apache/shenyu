package com.yeepay.framework.global.id.core.buffer;

import com.google.common.base.Preconditions;
import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import lombok.extern.slf4j.Slf4j;

/**
 * 缓冲区填充执行器.
 * 负责异步填充RingBuffer以提高UID生成性能.
 */
@Slf4j
public class BufferPaddingExecutor {
    /**
     * Constants.
     */
    private static final String WORKER_NAME = "RingBuffer-Padding-Worker";

    private static final String SCHEDULE_NAME = "RingBuffer-Padding-Schedule";

    private static final long DEFAULT_SCHEDULE_INTERVAL = 5 * 60L;

    /**
     * Whether buffer padding is running.
     */
    private final AtomicBoolean running = new AtomicBoolean();

    /**
     * We can borrow UIDs from the future, here store the last second we have consumed.
     */
    private final PaddedAtomicLong lastSecond =
            new PaddedAtomicLong(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));

    /**
     * RingBuffer & BufferUidProvider.
     */
    private final RingBuffer ringBuffer;

    private final BufferedUidProvider uidProvider;

    /**
     * Padding immediately by the thread pool.
     */
    private final ExecutorService bufferPadExecutors;

    /**
     * Padding schedule thread.
     */
    private final ScheduledExecutorService bufferPadSchedule;

    /**
     * Schedule interval Unit as seconds.
     */
    private long scheduleInterval = DEFAULT_SCHEDULE_INTERVAL;

    /**
     * 调度任务.
     */
    private ScheduledFuture<?> scheduledFuture;

    /**
     * Constructor with {@link RingBuffer} and {@link BufferedUidProvider}, default use schedule.
     *
     * @param buffer   环形缓冲区
     * @param provider UID提供者
     */
    public BufferPaddingExecutor(RingBuffer buffer, BufferedUidProvider provider) {
        this(buffer, provider, true);
    }

    /**
     * Constructor with {@link RingBuffer}, {@link BufferedUidProvider}, and whether use schedule padding.
     *
     * @param buffer        环形缓冲区
     * @param provider      UID提供者
     * @param usingSchedule 是否使用调度
     */
    public BufferPaddingExecutor(RingBuffer buffer, BufferedUidProvider provider, boolean usingSchedule) {
        this.ringBuffer = buffer;
        this.uidProvider = provider;
        // initialize thread pool
        int cores = Runtime.getRuntime().availableProcessors();
        bufferPadExecutors = Executors.newFixedThreadPool(cores * 2, YeepayThreadFactory.create(WORKER_NAME));
        // initialize schedule thread
        if (usingSchedule) {
            bufferPadSchedule = Executors.newSingleThreadScheduledExecutor(YeepayThreadFactory.create(SCHEDULE_NAME));
        } else {
            bufferPadSchedule = null;
        }
    }

    /**
     * Start executors such as schedule.
     */
    public void start() {
        if (Objects.nonNull(bufferPadSchedule)) {
            bufferPadSchedule.scheduleWithFixedDelay(
                    this::paddingBuffer, scheduleInterval, scheduleInterval, TimeUnit.SECONDS);
        }
    }

    /**
     * Shutdown executors.
     */
    public void shutdown() {
        if (!bufferPadExecutors.isShutdown()) {
            bufferPadExecutors.shutdownNow();
        }
        if (Objects.nonNull(bufferPadSchedule) && !bufferPadSchedule.isShutdown()) {
            bufferPadSchedule.shutdownNow();
        }
    }

    /**
     * Whether is padding.
     *
     * @return 是否正在填充
     */
    public boolean isRunning() {
        return running.get();
    }

    /**
     * Padding buffer in the thread pool.
     */
    public void asyncPadding() {
        bufferPadExecutors.submit(this::paddingBuffer);
    }

    /**
     * Padding buffer fill the slots until to catch the cursor.
     */
    public void paddingBuffer() {
        log.debug("Ready to padding buffer lastSecond:{}. {}", lastSecond.get(), ringBuffer);
        // is still running
        if (!running.compareAndSet(false, true)) {
            log.info("Padding buffer is still running. {}", ringBuffer);
            return;
        }

        // fill the rest slots until to catch the cursor
        boolean isFullRingBuffer = false;
        while (!isFullRingBuffer) {
            List<Long> uidList = uidProvider.provide(lastSecond.incrementAndGet());
            for (Long uid : uidList) {
                if (Objects.nonNull(uid)) {
                    isFullRingBuffer = !ringBuffer.put(uid);
                    if (isFullRingBuffer) {
                        break;
                    }
                }
            }
        }
        // not running now
        running.compareAndSet(true, false);
        log.debug("End to padding buffer lastSecond:{}. {}", lastSecond.get(), ringBuffer);
    }

    /**
     * 设置调度间隔.
     *
     * @param scheduleInterval 调度间隔
     */
    public void setScheduleInterval(long scheduleInterval) {
        Preconditions.checkArgument(scheduleInterval > 0, "scheduleInterval must be greater than 0.");
        this.scheduleInterval = scheduleInterval;
    }
}
