package com.yeepay.framework.global.id.core.service;

import com.yeepay.framework.global.id.core.buffer.BufferPaddingExecutor;
import com.yeepay.framework.global.id.core.buffer.BufferedUidProvider;
import com.yeepay.framework.global.id.core.buffer.RejectedPutBufferHandler;
import com.yeepay.framework.global.id.core.buffer.RejectedTakeBufferHandler;
import com.yeepay.framework.global.id.core.buffer.RingBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 缓存型UID生成器.
 * 提供基于RingBuffer缓冲机制的高性能UID生成功能.
 */
@Setter
@Slf4j
public class CachedUidGenerator extends DefaultUidGenerator implements BufferedUidProvider {

    /**
     * 缓冲区大小，必须是2的幂次.
     */
    private int boostPower = 3;

    /**
     * 填充因子，当可用slot小于此百分比时触发缓冲区填充.
     */
    private int paddingFactor = 50;

    /**
     * 初始化缓冲区时立即填充.
     */
    private boolean scheduleInterval = true;

    /**
     * 拒绝的PUT缓冲区处理器.
     */
    private RejectedPutBufferHandler rejectedPutBufferHandler;

    /**
     * 拒绝的TAKE缓冲区处理器.
     */
    private RejectedTakeBufferHandler rejectedTakeBufferHandler;

    /**
     * 环形缓冲区.
     */
    private RingBuffer ringBuffer;

    /**
     * 缓冲区填充执行器.
     */
    private BufferPaddingExecutor bufferPaddingExecutor;

    /**
     * 调度间隔时间.
     */
    private long scheduleIntervalValue = 60L;

    /**
     * 初始化方法.
     * 在所有属性设置完成后调用此方法进行初始化.
     */
    @Override
    public void init() {
        super.init();
        this.initRingBuffer();
        log.info("Initialized RingBuffer successfully.");
    }

    /**
     * 获取UID.
     *
     * @return 生成的UID
     */
    @Override
    public long getUID() {
        try {
            return ringBuffer.take();
        } catch (Exception ex) {
            log.error("Generate unique id exception. ", ex);
            throw ex;
        }
    }

    /**
     * 解析UID.
     *
     * @param uid 待解析的UID
     * @return 解析结果字符串
     */
    @Override
    public String parseUID(long uid) {
        return super.parseUID(uid);
    }

    /**
     * 销毁方法.
     * 在Bean销毁时调用此方法进行资源清理.
     */
    public void destroy() {
        bufferPaddingExecutor.shutdown();
    }

    /**
     * 提供指定时间戳的UID列表.
     *
     * @param currentSecond 当前时间戳（秒）
     * @return UID列表
     */
    @Override
    public List<Long> provide(long currentSecond) {
        return nextIdsForOneSecond(currentSecond);
    }

    /**
     * 生成指定时间戳下一秒的所有UID.
     *
     * @param currentSecond 当前时间戳（秒）
     * @return UID列表
     */
    protected List<Long> nextIdsForOneSecond(long currentSecond) {
        // Initialize result list size of (max sequence + 1)
        int listSize = (int) getBitsAllocator().getMaxSequence() + 1;
        List<Long> uidList = new ArrayList<>(listSize);

        // Allocate the first sequence of the second, the others can be
        // calculated with the offset
        long firstSeqUid = getBitsAllocator().allocate(currentSecond - getEpochSeconds(), getWorkerId(), 0L);
        for (int offset = 0; offset < listSize; offset++) {
            uidList.add(firstSeqUid + offset);
        }
        return uidList;
    }

    /**
     * 初始化RingBuffer.
     */
    private void initRingBuffer() {
        // initialize RingBuffer
        int bufferSize = ((int) getBitsAllocator().getMaxSequence() + 1) << boostPower;
        this.ringBuffer = new RingBuffer(bufferSize, paddingFactor);
        log.info("Initialized ring buffer size:{}, paddingFactor:{}", bufferSize, paddingFactor);
        // initialize BufferPaddingExecutor
        boolean usingSchedule = scheduleIntervalValue > 0;
        this.bufferPaddingExecutor = new BufferPaddingExecutor(ringBuffer, this, usingSchedule);
        if (usingSchedule) {
            bufferPaddingExecutor.setScheduleInterval(scheduleIntervalValue);
        }
        // set rejected put/take handle policy
        this.ringBuffer.setBufferPaddingExecutor(bufferPaddingExecutor);
        if (Objects.nonNull(rejectedPutBufferHandler)) {
            this.ringBuffer.setRejectedPutHandler(rejectedPutBufferHandler);
        }
        if (Objects.nonNull(rejectedTakeBufferHandler)) {
            this.ringBuffer.setRejectedTakeHandler(rejectedTakeBufferHandler);
        }
        // fill in all slots of the RingBuffer
        bufferPaddingExecutor.paddingBuffer();
        bufferPaddingExecutor.start();
    }

    /**
     * 设置调度间隔时间.
     *
     * @param scheduleInterval 调度间隔时间
     */
    public void setScheduleInterval(long scheduleInterval) {
        this.scheduleIntervalValue = scheduleInterval;
    }
}
