package com.yeepay.framework.global.id.core.service;

import com.google.common.base.Preconditions;
import lombok.Getter;

/**
 * 位分配器.
 * 负责时间戳、工作节点ID和序列号的位分配与ID生成.
 */
@Getter
public class BitsAllocator {

    /**
     * 位分配的总位数（排除符号位）.
     */
    public static final int TOTAL_BITS = Long.SIZE - 1;

    /**
     * 时间戳位数.
     */
    private final int timestampBits;

    /**
     * 工作节点ID位数.
     */
    private final int workerIdBits;

    /**
     * 序列号位数.
     */
    private final int sequenceBits;

    /**
     * 最大增量时间戳.
     */
    private final long maxDeltaSeconds;

    /**
     * 最大工作节点ID.
     */
    private final long maxWorkerId;

    /**
     * 最大序列号.
     */
    private final long maxSequence;

    /**
     * 时间戳位移位数.
     */
    private final int timestampShift;

    /**
     * 工作节点ID位移位数.
     */
    private final int workerIdShift;

    /**
     * 构造函数.
     *
     * @param timeBits   时间戳位数
     * @param workerBits 工作节点ID位数
     * @param seqBits    序列号位数
     */
    public BitsAllocator(int timeBits, int workerBits, int seqBits) {
        // 验证位数之和
        int totalBits = timeBits + workerBits + seqBits;
        Preconditions.checkArgument(
                totalBits <= TOTAL_BITS,
                "Not support timestamp & workerId & sequence total bits over 63, current total bits: " + totalBits);

        // 初始化位数
        this.timestampBits = timeBits;
        this.workerIdBits = workerBits;
        this.sequenceBits = seqBits;

        // 计算最大值
        this.maxDeltaSeconds = ~(-1L << timeBits);
        this.maxWorkerId = ~(-1L << workerBits);
        this.maxSequence = ~(-1L << seqBits);

        // 计算位移位数
        this.timestampShift = workerBits + seqBits;
        this.workerIdShift = seqBits;
    }

    /**
     * 分配位到UID中.
     *
     * @param deltaSeconds 增量时间戳
     * @param workerId     工作节点ID
     * @param sequence     序列号
     * @return 生成的UID
     */
    public long allocate(long deltaSeconds, long workerId, long sequence) {
        return (deltaSeconds << timestampShift) | (workerId << workerIdShift) | sequence;
    }

    /**
     * 字符串表示.
     *
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return "BitsAllocator{"
                + "timestampBits=" + timestampBits
                + ", workerIdBits=" + workerIdBits
                + ", sequenceBits=" + sequenceBits
                + ", maxDeltaSeconds=" + maxDeltaSeconds
                + ", maxWorkerId=" + maxWorkerId
                + ", maxSequence=" + maxSequence
                + '}';
    }
}
