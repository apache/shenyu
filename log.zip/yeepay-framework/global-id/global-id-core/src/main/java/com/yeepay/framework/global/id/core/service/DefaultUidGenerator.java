package com.yeepay.framework.global.id.core.service;

import com.yeepay.framework.common.utils.YeepayDateUtils;
import com.yeepay.framework.global.id.api.UidGenerator;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.exception.UidGenerateException;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 默认UID生成器实现.
 * 基于Snowflake算法的UID生成器，提供基本的UID生成功能.
 */
public class DefaultUidGenerator implements UidGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultUidGenerator.class);

    /**
     * 时间位数.
     */
    private int timeBits = 28;

    /**
     * 工作节点位数.
     */
    private int workerBits = 22;

    /**
     * 序列号位数.
     */
    private int seqBits = 13;

    /**
     * 时间起点秒数，由 {@link #setEpochStr(String)} 解析 yyyy-MM-dd 后赋值.
     * 默认值对应 "2016-05-20"（JVM 默认时区下当日 0 点）.
     */
    @Getter
    private long epochSeconds = TimeUnit.MILLISECONDS.toSeconds(1463673600000L);

    /**
     * Stable fields after spring bean initializing.
     */
    @Getter
    private BitsAllocator bitsAllocator;

    /**
     * 工作节点ID.
     */
    @Getter
    private long workerId;

    /**
     * 工作节点名称.
     */
    @Setter
    private String workerName;

    /**
     * Volatile fields caused by nextId().
     */
    private long sequence;

    private long lastSecond = -1L;

    /**
     * Spring property.
     */
    @Setter
    private WorkerIdAssigner workerIdAssigner;

    /**
     * 设置 epoch 并同步刷新 epochSeconds.
     * 传入空（null / 空串 / 仅空白）视为不覆盖，保留默认 epochSeconds；
     * 传入非空时按 yyyy-MM-dd 校验格式与"不晚于今天"，非法值立即失败.
     *
     * @param epochStr 时间起点字符串，格式 yyyy-MM-dd，可为空
     */
    public void setEpochStr(String epochStr) {
        if (StringUtils.isBlank(epochStr)) {
            return;
        }
        this.epochSeconds = TimeUnit.MILLISECONDS.toSeconds(
                YeepayDateUtils.parseByDayPattern(epochStr).getTime());
    }

    /**
     * 初始化方法.
     */
    public void init() {
        // initialize bits allocator
        bitsAllocator = new BitsAllocator(timeBits, workerBits, seqBits);

        // initialize worker id
        workerId = workerIdAssigner.assignWorkerId(workerName);
        // workerId 超出 workerBits 容量会导致位溢出污染时间戳段，必须 fail-fast 而不是仅告警，
        // 否则会出现不同节点产出相同 UID 的严重正确性问题.
        if (workerId < 0 || workerId > bitsAllocator.getMaxWorkerId()) {
            throw new UidGenerateException(
                    "Worker id %d exceeds the max %d (workerBits=%d). " + "请清理过期 worker 记录或扩大 workerBits.",
                    workerId, bitsAllocator.getMaxWorkerId(), workerBits);
        }

        LOGGER.info(
                "Initialized bits(1, {}, {}, {}) for workerID:{}, epochSeconds:{}",
                timeBits,
                workerBits,
                seqBits,
                workerId,
                epochSeconds);
    }

    /**
     * 获取UID.
     *
     * @return 生成的UID
     * @throws UidGenerateException UID生成异常
     */
    @Override
    public long getUID() throws UidGenerateException {
        try {
            return nextId();
        } catch (Exception e) {
            LOGGER.error("Generate unique id exception. ", e);
            throw new UidGenerateException(e);
        }
    }

    /**
     * 解析UID.
     *
     * @param uid 待解析的UID
     * @return 解析结果字符串
     */
    @Override
    public String parseUID(long uid) {
        long totalBits = BitsAllocator.TOTAL_BITS;
        long signBits = 1L;
        long timestampBits = bitsAllocator.getTimestampBits();
        long workerIdBits = bitsAllocator.getWorkerIdBits();
        long sequenceBits = bitsAllocator.getSequenceBits();
        // parse UID
        long sequence = (uid << (totalBits - sequenceBits)) >>> (totalBits - sequenceBits);
        long workerId = (uid << (timestampBits + signBits)) >>> (totalBits - workerIdBits);
        long deltaSeconds = uid >>> (workerIdBits + sequenceBits);

        Date thatTime = new Date(TimeUnit.SECONDS.toMillis(epochSeconds + deltaSeconds));
        String thatTimeStr = YeepayDateUtils.formatByDateTimePattern(thatTime);
        // format as string
        return String.format(
                "{\"UID\":\"%d\",\"timestamp\":\"%s\",\"workerId\":\"%d\",\"sequence\":\"%d\"}",
                uid, thatTimeStr, workerId, sequence);
    }

    /**
     * 获取UID.
     *
     * @return UID
     * @throws UidGenerateException 如果时钟回拨或超过最大时间戳
     */
    protected synchronized long nextId() {
        long currentSecond = getCurrentSecond();

        // Clock moved backwards, refuse to generate uid
        if (currentSecond < lastSecond) {
            long refusedSeconds = lastSecond - currentSecond;
            throw new UidGenerateException("Clock moved backwards. Refusing for %d seconds", refusedSeconds);
        }

        // At the same second, increase sequence
        if (currentSecond == lastSecond) {
            sequence = (sequence + 1) & bitsAllocator.getMaxSequence();
            // Exceed the max sequence, we wait the next second to generate uid
            if (sequence == 0) {
                currentSecond = getNextSecond(lastSecond);
            }

            // At the different second, sequence restart from zero
        } else {
            sequence = 0L;
        }

        lastSecond = currentSecond;

        // Allocate bits for UID
        return bitsAllocator.allocate(currentSecond - epochSeconds, workerId, sequence);
    }

    /**
     * 获取下一毫秒.
     *
     * @param lastTimestamp 上次时间戳
     * @return 下一个时间戳
     */
    private long getNextSecond(long lastTimestamp) {
        long timestamp = getCurrentSecond();
        while (timestamp <= lastTimestamp) {
            timestamp = getCurrentSecond();
        }
        return timestamp;
    }

    /**
     * 获取当前秒数.
     *
     * @return 当前秒数
     */
    private long getCurrentSecond() {
        long currentSecond = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
        if (currentSecond - epochSeconds > bitsAllocator.getMaxDeltaSeconds()) {
            throw new UidGenerateException("Timestamp bits is exhausted. Refusing UID generate. Now: " + currentSecond);
        }

        return currentSecond;
    }

    /**
     * 设置时间位数.
     *
     * @param timeBits 时间位数
     */
    public void setTimeBits(int timeBits) {
        if (timeBits > 0) {
            this.timeBits = timeBits;
        }
    }

    /**
     * 设置工作节点位数.
     *
     * @param workerBits worker位数
     */
    public void setWorkerBits(int workerBits) {
        if (workerBits > 0) {
            this.workerBits = workerBits;
        }
    }

    /**
     * 设置序列号位数.
     *
     * @param seqBits 序列位数
     */
    public void setSeqBits(int seqBits) {
        if (seqBits > 0) {
            this.seqBits = seqBits;
        }
    }
}
