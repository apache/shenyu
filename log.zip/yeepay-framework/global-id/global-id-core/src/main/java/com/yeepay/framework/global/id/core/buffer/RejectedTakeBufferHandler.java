package com.yeepay.framework.global.id.core.buffer;

/**
 * 拒绝获取缓冲区处理器.
 */
@FunctionalInterface
public interface RejectedTakeBufferHandler {

    /**
     * Reject take buffer request.
     *
     * @param ringBuffer 环形缓冲区
     */
    void rejectTakeBuffer(RingBuffer ringBuffer);
}
