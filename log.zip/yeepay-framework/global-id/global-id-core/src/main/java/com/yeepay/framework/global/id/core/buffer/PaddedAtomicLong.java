package com.yeepay.framework.global.id.core.buffer;

import java.util.concurrent.atomic.AtomicLong;

/**
 * 填充的AtomicLong类，用于防止伪共享.
 */
public class PaddedAtomicLong extends AtomicLong {

    /**
     * Padded 6 long (48 bytes).
     */
    private volatile long p1 = 7L;

    private volatile long p2 = 7L;

    private volatile long p3 = 7L;

    private volatile long p4 = 7L;

    private volatile long p5 = 7L;

    private volatile long p6 = 7L;

    /**
     * Constructors from {@link AtomicLong}.
     */
    public PaddedAtomicLong() {
        super();
    }

    /**
     * Constructors from {@link AtomicLong}.
     *
     * @param initialValue 初始值
     */
    public PaddedAtomicLong(long initialValue) {
        super(initialValue);
    }

    /**
     * To prevent GC optimizations for cleaning unused padded references.
     *
     * @return 填充值的总和
     */
    public long sumPaddingToPreventOptimization() {
        return p1 + p2 + p3 + p4 + p5 + p6;
    }
}
