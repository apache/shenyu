package com.yeepay.framework.global.id.api.enums;

/**
 * 值枚举接口.
 *
 * @param <T> 值类型
 */
public interface ValuedEnum<T> {

    /**
     * 获取枚举值.
     *
     * @return 枚举值
     */
    T value();
}
