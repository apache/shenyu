package com.yeepay.framework.global.id.api.enums;

/**
 * WorkerNode类型枚举.
 */
public enum WorkerNodeType implements ValuedEnum<Integer> {

    /**
     * 容器类型.
     */
    CONTAINER(1),

    /**
     * 实际机器类型.
     */
    ACTUAL(2);

    /**
     * Lock type.
     */
    private final Integer type;

    /**
     * Constructor with field of type.
     *
     * @param type 类型值
     */
    WorkerNodeType(Integer type) {
        this.type = type;
    }

    @Override
    public Integer value() {
        return type;
    }
}
