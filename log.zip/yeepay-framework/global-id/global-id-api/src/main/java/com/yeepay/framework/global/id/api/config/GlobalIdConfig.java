package com.yeepay.framework.global.id.api.config;

import lombok.Data;

/**
 * The type Global id db properties.
 */
@Data
public class GlobalIdConfig {

    /**
     * 时间长度.
     * timeBits、workerBits、seqBits三个值相加为63，剩余一位为sign，固定1bit符号标识，使生成的UID为正数
     */
    private Integer timeBits = 30;

    /**
     * 机器id.
     */
    private Integer workerBits = 18;

    /**
     * 每秒下的并发序列.
     */
    private Integer seqBits = 15;

    /**
     * 格式：yyyy-MM-dd，这个值会转换成毫秒的时间戳.
     */
    private String epochStr = "2026-05-19";

    /**
     * RingBuffer size扩容参数, 可提高UID生成的吞吐量.
     */
    private Integer boostPower = 3;

    /**
     * 指定何时向RingBuffer中填充UID, 取值为百分比(0, 100).
     */
    private Integer paddingFactor = 65;

    /**
     * 另外一种RingBuffer填充时机, 在Schedule线程中, 周期性检查填充.
     * 一般不使用这个属性，除非使用ID的频次固定。
     */
    private Integer scheduleInterval = 60;

    /**
     * 工作节点名称.
     */
    private String workerName;
}
