package com.yeepay.framework.global.id.api;

/**
 * 表示为 {@link UidGenerator} 分配 worker id.
 *
 * @param <T> the type parameter
 */
public interface WorkerIdAssigner<T> {

    /**
     * Init.
     *
     * @param config the config
     */
    void init(T config);

    /**
     * Assign worker id with worker name.
     *
     * @param workerName worker名称
     * @return assigned worker id
     */
    long assignWorkerId(String workerName);

    /**
     * Close.
     */
    void close();
}
