package com.yeepay.framework.global.id.api.exception;

import org.apache.commons.lang3.StringUtils;

/**
 * UID生成异常.
 * 当UID生成过程中发生错误时抛出此异常.
 */
public class UidGenerateException extends RuntimeException {

    /**
     * 无参构造函数.
     */
    public UidGenerateException() {
        super();
    }

    /**
     * 构造函数.
     *
     * @param message 异常消息
     */
    public UidGenerateException(String message) {
        super(message);
    }

    /**
     * 构造函数.
     *
     * @param message 异常消息
     * @param cause   原因异常
     */
    public UidGenerateException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 格式化构造函数.
     *
     * @param msgFormat 消息格式
     * @param args      格式化参数
     */
    public UidGenerateException(String msgFormat, Object... args) {
        super(StringUtils.isNotBlank(msgFormat) ? String.format(msgFormat, args) : null);
    }

    /**
     * 构造函数.
     *
     * @param cause 原因异常
     */
    public UidGenerateException(Throwable cause) {
        super(cause);
    }
}
