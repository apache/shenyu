package com.yeepay.framework.global.id.api;

/**
 * UID生成器接口.
 * 提供生成和解析UID的基本功能.
 */
public interface UidGenerator {

    /**
     * 获取唯一ID.
     *
     * @return 生成的唯一ID
     */
    long getUID();

    /**
     * 解析UID.
     *
     * @param uid 待解析的UID
     * @return 解析结果字符串
     */
    String parseUID(long uid);
}
