# 全局唯一 ID 生成器（Global ID）

## 目录

1. [概述](#1-概述)
2. [快速开始](#2-快速开始)
3. [架构设计](#3-架构设计)
4. [配置详解](#4-配置详解)
   - [4.1 Snowflake 核心参数](#41-snowflake-核心参数)
   - [4.2 数据库模式（Database）](#42-数据库模式database)
   - [4.3 Redis 模式](#43-redis-模式)
   - [4.4 ZooKeeper 模式](#44-zookeeper-模式)
5. [使用方式](#5-使用方式)
   - [5.1 注入 UidGenerator](#51-注入-uidgenerator)
   - [5.2 生成单个 ID](#52-生成单个-id)
   - [5.3 批量生成 ID](#53-批量生成-id)
   - [5.4 解析 ID](#54-解析-id)
6. [原理详解](#6-原理详解)
   - [6.1 Snowflake 算法](#61-snowflake-算法)
   - [6.2 时钟回拨处理](#62-时钟回拨处理)
   - [6.3 CachedUidGenerator 与 RingBuffer](#63-cacheduidgenerator-与-ringbuffer)
   - [6.4 Worker ID 分配机制](#64-worker-id-分配机制)
   - [6.5 三种后端对比](#65-三种后端对比)
7. [性能测试](#7-性能测试)
8. [运维指南](#8-运维指南)
9. [常见问题](#9-常见问题)

---

## 1. 概述

全局唯一 ID 生成器（Global ID）是 yeepay-framework 提供的分布式唯一 ID 生成方案，基于 Twitter Snowflake 算法实现。它可以在分布式系统中生成**全局唯一、趋势递增**的 64 位长整型 ID，适用于订单号、流水号、分布式主键等场景。

### 核心特性

- **全局唯一**：通过 Worker ID 保证不同节点生成的 ID 不重复
- **高性能**：基于 RingBuffer 预生成机制，`getUID()` 无锁调用，单机可达**数百万 QPS**
- **高可用**：Worker ID 支持数据库/Redis/ZooKeeper 三种后端自动分配和故障恢复
- **可解析**：生成的 ID 可反解出时间戳、Worker ID 和序列号
- **灵活配置**：时间位、机器位、序列位均可自定义
- **Spring Boot 自动装配**：引入 starter 依赖即可使用，配置驱动

### 适用场景

| 场景 | 说明 |
|------|------|
| 数据库主键 | 替代自增 ID，适合分库分表 |
| 订单号/流水号 | 全局唯一，趋势递增 |
| 分布式消息 ID | Kafka/RocketMQ 消息幂等 |
| 链路追踪 TraceId | 全局唯一的请求标识 |

---

## 2. 快速开始

### 2.1 添加 Maven 依赖

根据你选择的 Worker ID 后端，引入对应的 starter 依赖（**三选一**）：

```xml
<!-- 方式一：数据库模式（推荐，无需额外中间件） -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-global-id-database</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>

<!-- 方式二：Redis 模式 -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-global-id-redis</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>

<!-- 方式三：ZooKeeper 模式 -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-global-id-zookeeper</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### 2.2 添加配置

以数据库模式为例，在 `application.yml` 中添加最少配置：

```yaml
yeepay:
  framework:
    global-id:
      database:
        config:
          driver-class-name: com.mysql.cj.jdbc.Driver
          jdbc-url: jdbc:mysql://127.0.0.1:3306/yeepay?useSSL=false&serverTimezone=Asia/Shanghai
          username: root
          password: root123
```

### 2.3 代码使用

```java
@RestController
public class OrderController {

    @Autowired
    private UidGenerator uidGenerator;

    @GetMapping("/order/create")
    public String createOrder() {
        long orderId = uidGenerator.getUID();
        return "Order created, ID: " + orderId;
    }
}
```

就这么简单！框架会自动完成 Worker ID 分配和 ID 生成器的初始化。

---

## 3. 架构设计

### 模块结构

```
global-id/
├── global-id-api/          # 接口定义（UidGenerator, WorkerIdAssigner, 配置类）
├── global-id-core/         # 核心实现（Snowflake算法, RingBuffer, BitsAllocator）
├── global-id-database/     # 数据库 Worker ID 分配器
├── global-id-redis/        # Redis Worker ID 分配器
└── global-id-zookeeper/    # ZooKeeper Worker ID 分配器

springboot-starter/springboot-starter-global-id/
├── springboot-starter-global-id-database/    # 数据库模式自动装配
├── springboot-starter-global-id-redis/       # Redis 模式自动装配
└── springboot-starter-global-id-zookeeper/   # ZooKeeper 模式自动装配

examples/examples-global-id/                   # 完整示例项目
```

### 分层架构

```
┌──────────────────────────────────────┐
│          UidGenerator (API)          │  ← 业务代码注入此接口
├──────────────────────────────────────┤
│     CachedUidGenerator (Core)        │  ← 带 RingBuffer 的高性能实现
├──────────────────────────────────────┤
│  BitsAllocator  │    RingBuffer      │  ← 位运算 + 无锁环形缓冲区
├──────────────────────────────────────┤
│      WorkerIdAssigner (SPI)          │  ← Worker ID 分配策略接口
├──────────┬──────────┬───────────────┤
│ Database │  Redis   │  ZooKeeper    │  ← 三种后端实现
└──────────┴──────────┴───────────────┘
```

### 激活机制

三个 starter 使用 Spring Boot 条件装配，**根据配置前缀自动激活**，互斥使用：

| 配置前缀 | 激活模式 |
|---------|---------|
| `yeepay.framework.global-id.database.*` | 数据库模式 |
| `yeepay.framework.global-id.redis.*` | Redis 模式 |
| `yeepay.framework.global-id.zookeeper.*` | ZooKeeper 模式 |

如果没有配置任何前缀，则不会激活任何自动装配。

---

## 4. 配置详解

### 4.1 Snowflake 核心参数

以下参数为三种模式共享，控制 Snowflake 算法的位分配和 RingBuffer 行为。

> **配置路径格式**：`yeepay.framework.global-id.{mode}.global.{property}`
>
> 其中 `{mode}` 为 `database`、`redis` 或 `zookeeper`。

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `time-bits` | Integer | `30` | 时间戳占用的位数。30 位可表示约 34 年的时间范围。与 `worker-bits`、`seq-bits` 之和必须 ≤ 63 |
| `worker-bits` | Integer | `18` | Worker ID 占用的位数。18 位可支持最多 **262143** 个 Worker 节点 |
| `seq-bits` | Integer | `15` | 每秒序列号占用的位数。15 位每秒可生成 **32768** 个 ID |
| `epoch-str` | String | `"2026-05-19"` | 起始纪元日期，格式 `yyyy-MM-dd`。ID 中的时间戳是从此日期开始的秒数偏移量 |
| `boost-power` | Integer | `3` | RingBuffer 容量扩展参数。`bufferSize = (maxSeq + 1) << boostPower`，即 `32768 << 3 = 262144` |
| `padding-factor` | Integer | `65` | RingBuffer 补位阈值百分比（0-100）。当剩余可用 ID 比例低于此值时触发异步填充 |
| `schedule-interval` | Integer | `60` | 定时补位检查间隔（秒）。设为 `0` 则禁用定时补位，仅在使用时异步补位 |
| `worker-name` | String | `spring.application.name` | Worker 节点名称。用于 Worker ID 分配时的分组标识。不配置则自动使用 Spring 应用名 |

#### 位分配约束

```
timeBits + workerBits + seqBits <= 63
```

等号右侧是 63 而非 64 —— 最高位（符号位）固定为 `0`，确保生成的 ID 始终为**正数**。

#### 默认位布局

```
Bit:  63      62 ─────────────── 33    32 ────────────── 15    14 ──────── 0
      sign    deltaSeconds (30 bits)    workerId (18 bits)    sequence (15 bits)
      0
```

#### 各参数影响分析

| 参数 | 增大影响 | 减小影响 |
|------|---------|---------|
| `time-bits` | 可用年限更长 | 支持更多 Worker 或更高 QPS |
| `worker-bits` | 支持更多节点 | 支持更长年限或更高 QPS |
| `seq-bits` | 单节点每秒 QPS 更高 | 支持更多节点或更长年限 |
| `boost-power` | 缓冲池更大，更不易耗尽 | 内存占用更小，启动填充更快 |
| `padding-factor` | 更早触发填充，更安全 | 填充频率降低，CPU 开销减小 |

#### YAML 完整配置示例

```yaml
yeepay:
  framework:
    global-id:
      database:                          # 以数据库模式为例，redis/zookeeper 同理
        global:
          # ====== Snowflake 位分配 ======
          time-bits: 30                  # 时间位（默认30，可用约34年）【必填，默认值30】
          worker-bits: 18                # Worker ID 位（默认18，支持262143个节点）【必填，默认值18】
          seq-bits: 15                   # 序列位（默认15，每节点每秒32768个ID）【必填，默认值15】

          # ====== 起始纪元 ======
          epoch-str: "2026-05-19"        # 纪元起点日期，格式yyyy-MM-dd【必填，默认值"2026-05-19"】
                                         # 修改此值会改变可用年限起点，设定后请勿再改

          # ====== RingBuffer 调优 ======
          boost-power: 3                 # 缓冲区容量 = 32768 << 3 = 262144 个槽位【可选，默认3】
          padding-factor: 65             # 剩余低于65%时异步填充RingBuffer【可选，默认65】
          schedule-interval: 60          # 每60秒定时检查并填充，0=禁用定时填充【可选，默认60】

          # ====== Worker 节点名称 ======
          # worker-name: my-service      # 不配置则自动使用 spring.application.name【可选】
```

---

### 4.2 数据库模式（Database）

**配置前缀**：`yeepay.framework.global-id.database`

使用 MySQL 表管理 Worker ID 的分配和心跳续期。通过 MyBatis + HikariCP 操作数据库，支持 `FOR UPDATE SKIP LOCKED` 无锁竞争槽位回收。

#### 数据库准备

首先需要在数据库中创建 Worker ID 管理表：

```sql
CREATE TABLE IF NOT EXISTS WORKER_NODE (
    ID BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键 = Worker ID',
    WORK_NAME VARCHAR(64) NOT NULL COMMENT '业务组名，对应 workerName',
    HOST_NAME VARCHAR(64) NOT NULL COMMENT '主机名或IP',
    TYPE INT NOT NULL DEFAULT 1 COMMENT '节点类型：1=容器部署, 2=物理机部署',
    LAUNCH_DATE DATE NOT NULL COMMENT '启动日期',
    LAST_ACTIVE_TIME DATETIME NOT NULL COMMENT '最后心跳时间',
    MODIFIED DATETIME NOT NULL COMMENT '修改时间',
    CREATED DATETIME NOT NULL COMMENT '创建时间',
    PRIMARY KEY (ID),
    INDEX IDX_WORK_NAME_ACTIVE (WORK_NAME, LAST_ACTIVE_TIME)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='全局ID-Worker节点表';
```

#### 完整配置属性

> **配置路径**：`yeepay.framework.global-id.database.config.{property}`

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `driver-class-name` | String | — | **必填**。JDBC 驱动类名，如 `com.mysql.cj.jdbc.Driver` |
| `jdbc-url` | String | — | **必填**。数据库连接 URL |
| `username` | String | — | **必填**。数据库用户名 |
| `password` | String | — | **必填**。数据库密码 |
| `logic-table` | String | — | 逻辑表名（当前版本预留字段，不使用） |
| `container` | boolean | `true` | 部署类型。`true`=CONTAINER(容器)，`false`=ACTUAL(物理机) |
| `heartbeat-interval-seconds` | long | `30` | 心跳间隔（秒）。**必须远小于** `zombie-expire-seconds` |
| `zombie-expire-seconds` | long | `300` | 僵尸槽位过期时间（秒）。超过此时间无心跳的槽位将被回收（默认 5 分钟） |
| `max-worker-id` | long | `262143` | 最大允许的 Worker ID。默认 `(1<<18)-1`，需与 `worker-bits` 匹配 |
| `minimum-idle` | int | `1` | HikariCP 连接池最小空闲连接数 |
| `maximum-pool-size` | int | `10` | HikariCP 连接池最大连接数 |
| `max-lifetime` | long | `28440000` | HikariCP 连接最大存活时间（毫秒），默认约 7.9 小时 |
| `validation-timeout` | long | `500` | HikariCP 连接验证超时（毫秒） |
| `connection-timeout` | long | `1000` | HikariCP 连接获取超时（毫秒） |

#### YAML 完整配置示例

```yaml
yeepay:
  framework:
    global-id:
      database:

        # ====== Snowflake 核心参数 ======
        global:
          time-bits: 30                        # 时间戳占用位数【必填，默认30】
          worker-bits: 18                      # Worker ID 占用位数【必填，默认18】
          seq-bits: 15                         # 序列号占用位数【必填，默认15】
          epoch-str: "2026-05-19"              # 纪元基准日期【必填，默认"2026-05-19"】
          boost-power: 3                       # RingBuffer 容量扩展参数【可选，默认3】
          padding-factor: 65                   # 填充阈值百分比(0-100)【可选，默认65】
          schedule-interval: 60                # 定时填充间隔秒数，0=禁用【可选，默认60】
          # worker-name: my-service            # Worker名称【可选，默认取 spring.application.name】

        # ====== 数据库连接及槽位管理 ======
        config:
          # --- JDBC 连接信息（以下4项必填） ---
          driver-class-name: com.mysql.cj.jdbc.Driver         # JDBC驱动类名
          jdbc-url: jdbc:mysql://127.0.0.1:3306/yeepay        # 数据库连接URL
            ? useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
          username: root                                      # 数据库用户名
          password: root123                                   # 数据库密码

          # --- 槽位管理 ---
          container: true                       # true=容器部署, false=物理机部署【可选，默认true】
          heartbeat-interval-seconds: 30        # 心跳间隔秒数【可选，默认30】
                                                # 建议设为 zombie-expire-seconds / 10
          zombie-expire-seconds: 300            # 僵尸槽位过期秒数(5分钟)【可选，默认300】
                                                # 超过此时间未心跳的槽位将被新节点回收
          max-worker-id: 262143                 # Worker ID上限【可选，默认(1<<18)-1=262143】
                                                # 必须与 worker-bits 位宽匹配

          # --- HikariCP 连接池 ---
          minimum-idle: 1                       # 最小空闲连接数【可选，默认1】
          maximum-pool-size: 10                 # 最大连接数【可选，默认10】
          max-lifetime: 28440000                # 连接最大存活ms(~7.9小时)【可选，默认28440000】
          validation-timeout: 500               # 连接验证超时ms【可选，默认500】
          connection-timeout: 1000              # 连接获取超时ms【可选，默认1000】
```

#### 数据库模式工作原理

1. **回收过期槽位**：启动时查询 `LAST_ACTIVE_TIME < now - zombieExpireSeconds` 的最早过期槽位，使用 `SELECT ... FOR UPDATE SKIP LOCKED` 行锁 + 跳过锁定，并发安全地认领最旧的过期槽位
2. **分配新槽位**：如无过期槽位可回收，INSERT 新行，通过 `@Options(useGeneratedKeys = true)` 获取自增主键作为 Worker ID
3. **溢出检查**：Worker ID 超过 `max-worker-id` 时抛出 `UidGenerateException`
4. **心跳续期**：通过 `ScheduledExecutorService` 单线程调度器定期更新 `LAST_ACTIVE_TIME`，带随机初始延迟避免惊群效应

#### 注意事项

- MySQL 需支持 `SKIP LOCKED`（MySQL 8.0+ 或 InnoDB）
- `heartbeat-interval-seconds` 建议设为 `zombie-expire-seconds / 10`，确保充足的重试窗口
- 进程意外崩溃不会立即释放槽位，需等待 `zombie-expire-seconds` 过期后才能被回收
- 每个 `worker-name`（即应用）独立管理槽位池，不同应用之间槽位不共享

---

### 4.3 Redis 模式

**配置前缀**：`yeepay.framework.global-id.redis`

使用 Redis 的 TTL 过期机制管理 Worker ID 槽位。依赖 Redisson 客户端（通过 `springboot-starter-infra-redisson` 提供 `RedissonClient` Bean）。

#### 前置条件

Redis 模式需要先配置 Redisson 连接（通过 infra-redisson starter）：

```yaml
yeepay:
  framework:
    infra:
      redisson:
        # 单机模式
        single:
          address: redis://127.0.0.1:6379

        # 或哨兵模式
        # sentinel:
        #   addresses:
        #     - redis://127.0.0.1:26379
        #     - redis://127.0.0.1:26380
        #   master-name: mymaster

        # 或集群模式
        # cluster:
        #   addresses:
        #     - redis://127.0.0.1:7001
        #     - redis://127.0.0.1:7002
```

#### 完整配置属性

> **配置路径**：`yeepay.framework.global-id.redis.config.{property}`

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `heartbeat-interval-seconds` | long | `30` | 心跳间隔（秒）。定期通过 Lua 脚本刷新槽位 key 的 TTL |
| `zombie-expire-seconds` | long | `300` | 槽位 TTL 过期时间（秒）。TTL 到期后 key 自动删除，槽位可被其他节点回收 |
| `key-prefix` | String | `"global-id"` | Redis key 命名空间前缀。建议同一 Redis 实例的不同应用使用不同前缀 |
| `max-worker-id` | long | `262143` | 最大允许的 Worker ID。默认 `(1<<18)-1`，需与全局 `worker-bits` 一致 |

#### YAML 完整配置示例

```yaml
yeepay:
  framework:
    # ====== Redisson 连接配置（必须） ======
    infra:
      redisson:
        single:
          address: redis://127.0.0.1:6379        # Redis 地址【必填】

    global-id:
      redis:
        # ====== Snowflake 核心参数 ======
        global:
          time-bits: 30                        # 时间戳占用位数【必填，默认30】
          worker-bits: 18                      # Worker ID 占用位数【必填，默认18】
          seq-bits: 15                         # 序列号占用位数【必填，默认15】
          epoch-str: "2026-05-19"              # 纪元基准日期【必填，默认"2026-05-19"】
          boost-power: 3                       # RingBuffer 容量扩展参数【可选，默认3】
          padding-factor: 65                   # 填充阈值百分比(0-100)【可选，默认65】
          schedule-interval: 60                # 定时填充间隔秒数，0=禁用【可选，默认60】
          # worker-name: my-service            # Worker名称【可选，默认取 spring.application.name】

        # ====== Redis 槽位管理 ======
        config:
          heartbeat-interval-seconds: 30        # 心跳间隔秒数【可选，默认30】
          zombie-expire-seconds: 300            # 槽位 TTL 秒数(5分钟)【可选，默认300】
          key-prefix: global-id                 # Redis key 前缀【可选，默认"global-id"】
          max-worker-id: 262143                 # Worker ID 上限【可选，默认262143】
```

#### Redis Key 结构

```
{keyPrefix}:counter              # RAtomicLong，全局自增计数器（跨所有应用共享）
{keyPrefix}:slot:{workerId}      # RBucket<String>，值为 "workerName:instanceId"，带 TTL
{keyPrefix}:{workerName}:ids     # RSet<String>，每个应用各自的已分配 Worker ID 集合
```

#### Redis 模式工作原理

1. **回收过期槽位**：SSCAN 遍历应用自身的 ID 集合，对每个槽位尝试 `SET NX`（如果 TTL 已过则 key 不存在，SET NX 成功即回收）。同时清理集合中属于其他应用的脏数据
2. **分配新槽位**：`INCR {prefix}:counter` 获取全局自增值，减 1 得到新的 Worker ID，然后 `SET NX` 原子认领槽位。最多重试 3 次处理并发竞争
3. **心跳续期**：通过 Lua 脚本实现原子操作——先 `GET` 检查值是否匹配（确认所有权仍在），匹配则 `EXPIRE` 刷新 TTL
4. **溢出检查**：Worker ID 超过 `max-worker-id` 时抛出异常

#### 注意事项

- 心跳使用 Lua 脚本实现 `check-and-renew` 原子操作，避免误刷他人槽位
- `RedissonClient` 由框架统一管理，**不会被此模块关闭**
- 槽位在 TTL 过期后由 Redis 自动删除，无需手动清理
- 相比数据库模式，故障恢复更快（TTL 过期即回收）
- 自动装配在 `InfraRedissonAutoConfiguration` 之后执行，确保 RedissonClient 先就绪

---

### 4.4 ZooKeeper 模式

**配置前缀**：`yeepay.framework.global-id.zookeeper`

使用 ZooKeeper 的**临时节点**（EPHEMERAL）机制管理 Worker ID。相比数据库和 Redis 模式，ZK 模式**无需心跳机制**——会话断开即自动删除临时节点、释放槽位。

#### 完整配置属性

> **配置路径**：`yeepay.framework.global-id.zookeeper.config.{property}`

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `connect-string` | String | — | **必填**。ZK 连接字符串，逗号分隔。如 `127.0.0.1:2181,127.0.0.1:2182` |
| `namespace` | String | — | ZK 命名空间（znode 前缀），用于多环境隔离。不配置则不使用命名空间 |
| `session-timeout` | Duration | `30s` | 会话超时时间。决定节点故障后槽位释放的速度（受 ZK 服务端 min/max 限制） |
| `connection-timeout` | Duration | `15s` | 连接建立超时时间 |
| `base-sleep-time` | Duration | `1s` | 重试策略初始等待时间（指数退避） |
| `max-retries` | int | `3` | 重试策略最大重试次数 |
| `digest-auth` | String | — | ZK digest 认证，格式 `username:password`。不配置则不使用认证 |
| `base-path` | String | `"/yeepay/global-id"` | ZK 中 Worker 节点的根路径 |
| `max-worker-id` | long | `262143` | 最大允许的 Worker ID |

#### YAML 完整配置示例

```yaml
yeepay:
  framework:
    global-id:
      zookeeper:
        # ====== Snowflake 核心参数 ======
        global:
          time-bits: 30                        # 时间戳占用位数【必填，默认30】
          worker-bits: 18                      # Worker ID 占用位数【必填，默认18】
          seq-bits: 15                         # 序列号占用位数【必填，默认15】
          epoch-str: "2026-05-19"              # 纪元基准日期【必填，默认"2026-05-19"】
          boost-power: 3                       # RingBuffer 容量扩展参数【可选，默认3】
          padding-factor: 65                   # 填充阈值百分比(0-100)【可选，默认65】
          schedule-interval: 60                # 定时填充间隔秒数，0=禁用【可选，默认60】
          # worker-name: my-service            # Worker名称【可选，默认取 spring.application.name】

        # ====== ZooKeeper 连接及槽位管理 ======
        config:
          # --- ZK 连接（connect-string 必填） ---
          connect-string: 127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183  # ZK集群地址

          # --- 命名空间（可选，用于多环境隔离） ---
          # namespace: production               # znode 前缀，不配置则无命名空间隔离

          # --- 会话与连接超时 ---
          session-timeout: 60s                  # 会话超时【可选，默认30s】
                                                # 越长越抗网络抖动，但故障恢复越慢
          connection-timeout: 15s               # 连接建立超时【可选，默认15s】

          # --- 重试策略（指数退避） ---
          base-sleep-time: 1s                   # 初始重试等待【可选，默认1s】
          max-retries: 3                        # 最大重试次数【可选，默认3】

          # --- 认证（可选） ---
          # digest-auth: admin:password123      # ZK digest 认证凭据

          # --- Worker 节点路径 ---
          base-path: /yeepay/global-id          # 在该路径下创建临时节点【可选，默认"/yeepay/global-id"】
          max-worker-id: 262143                 # Worker ID 上限【可选，默认262143】
```

#### ZK 路径结构

```
{basePath}/
└── pool/
    ├── worker-0000000001   # EPHEMERAL 临时节点，数据为 "workerName:hostName:uuid前8位"
    ├── worker-0000000003   # EPHEMERAL 临时节点
    ├── worker-0000000007   # EPHEMERAL 临时节点
    └── ...
```

节点名格式：`worker-{id:010d}`，即 Worker ID 零填充到 10 位。

#### ZooKeeper 模式工作原理

1. **确保路径存在**：`creatingParentsIfNeeded()` 创建 `{basePath}/pool` 路径
2. **扫描已占用槽位**：`getChildren()` 列出 pool 下所有 `worker-NNNNNNNNNN` 子节点，解析出已使用的 Worker ID
3. **选择空闲槽位**：从**随机起始位置**扫描 `[0, maxWorkerId]` 范围（避免所有节点争抢同一个槽位），找到第一个未占用的 ID
4. **创建临时节点**：`create().withMode(CreateMode.EPHEMERAL).forPath(nodePath, data)`。如果并发冲突（`NodeExistsException`），自动跳过，尝试下一个
5. **槽位耗尽**：所有槽位都被占满时抛出 `UidGenerateException`
6. **连接状态监听**：注册 `ConnectionStateListener` 监听 ZK 连接状态变化：
   - `LOST`：记录 ERROR 日志，临时节点已删除，应**立即重启**
   - `SUSPENDED`：记录 WARN 日志，连接挂起可能转为 LOST
   - `RECONNECTED`：记录 INFO 日志，会话恢复
   - `READ_ONLY`：记录 WARN 日志，可能已失去法定人数

#### 注意事项

- **不需要心跳机制**——ZK 会话断开后临时节点自动删除，槽位立即释放。这是 ZK 模式的核心优势
- `session-timeout` 的实际生效值由 ZK 服务端配置决定（在 `minSessionTimeout` 和 `maxSessionTimeout` 之间）
- **会话丢失（LOST）必须重启**：临时节点已删除，继续运行将产生 ID 冲突。框架会记录 ERROR 日志，运维需监控此日志
- 强烈建议设置合理的 `session-timeout`：过短容易因网络抖动误删节点；过长故障恢复慢
- 支持 `digest` 认证方式，生产环境建议配置

---

## 5. 使用方式

### 5.1 注入 UidGenerator

框架会自动向 Spring 容器注册 `UidGenerator` Bean（实际类型为 `CachedUidGenerator`），直接注入即可：

```java
@Service
public class OrderService {

    @Autowired
    private UidGenerator uidGenerator;

    // ...
}
```

### 5.2 生成单个 ID

```java
long orderId = uidGenerator.getUID();
// 返回示例: 693741758218240000
```

`getUID()` 方法从 RingBuffer 中直接取值，使用 CAS 无锁操作，并发调用性能极高（< 1 微秒）。

### 5.3 批量生成 ID

```java
List<Long> ids = IntStream.range(0, 100)
    .mapToObj(i -> uidGenerator.getUID())
    .collect(Collectors.toList());
```

### 5.4 解析 ID

`parseUID(long uid)` 可以反解 UID，返回 JSON 格式的结构化信息：

```java
String info = uidGenerator.parseUID(orderId);
// 返回:
// {
//   "UID": "693741758218240000",
//   "timestamp": "2026-06-04 15:30:22",
//   "workerId": "42",
//   "sequence": "0"
// }
```

| 返回字段 | 说明 |
|---------|------|
| `UID` | 原始 ID 值 |
| `timestamp` | ID 生成的实际时间（从 epoch 日期 + deltaSeconds 反算得出） |
| `workerId` | 生成该 ID 的 Worker 节点 ID |
| `sequence` | 该秒内的序列号（0 ~ 2^seqBits - 1） |

### 5.5 REST 接口示例

```java
@RestController
@RequestMapping("/global-id")
public class GlobalIdController {

    @Autowired
    private UidGenerator uidGenerator;

    /** 获取单个唯一ID */
    @GetMapping("/generate")
    public Long generate() {
        return uidGenerator.getUID();
    }

    /** 批量获取唯一ID */
    @GetMapping("/batch")
    public List<Long> batch(@RequestParam(defaultValue = "10") int count) {
        return IntStream.range(0, count)
            .mapToObj(i -> uidGenerator.getUID())
            .collect(Collectors.toList());
    }

    /** 解析ID结构 */
    @GetMapping("/parse/{uid}")
    public String parse(@PathVariable long uid) {
        return uidGenerator.parseUID(uid);
    }
}
```

---

## 6. 原理详解

### 6.1 Snowflake 算法

#### 位布局

默认配置下，63 位长整型布局（符号位固定为 0）：

```
Bit:  63       62 ················· 33    32 ·············· 15    14 ·········· 0
      ┌─┐     ┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────┐
      │0│     │   deltaSeconds       │  │     workerId          │  │  sequence    │
      │ │     │   (30 bits)          │  │     (18 bits)         │  │  (15 bits)   │
      └─┘     └──────────────────────┘  └──────────────────────┘  └──────────────┘
    符号位        时间戳偏移量               工作节点ID                 每秒序列号
```

#### BitsAllocator 核心计算

`BitsAllocator.allocate()` 将三个分量打包为 64 位长整型：

```java
public long allocate(long deltaSeconds, long workerId, long sequence) {
    return (deltaSeconds << timestampShift)   // 时间戳左移 workerBits + seqBits
         | (workerId << workerIdShift)        // Worker ID 左移 seqBits
         | sequence;                          // 序列号在最右侧
}
```

其中：
- `timestampShift = workerBits + seqBits`（默认 18 + 15 = 33）
- `workerIdShift = seqBits`（默认 15）

#### DefaultUidGenerator 生成流程

```
getUID()
  └── nextId()  (synchronized)
        ├── 计算 currentSecond = System.currentTimeMillis() / 1000
        ├── 检测时钟回拨: currentSecond < lastSecond → 抛异常拒绝
        ├── 序列号处理:
        │     ├── 同一秒内: sequence = (sequence + 1) & maxSequence
        │     │           若 sequence == 0（该秒耗尽）→ 忙等到下一秒
        │     └── 新的一秒: sequence = 0
        ├── 更新 lastSecond = currentSecond
        └── bitsAllocator.allocate(currentSecond - epochSeconds, workerId, sequence)
```

#### 为什么用秒而不是毫秒？

标准 Twitter Snowflake 使用毫秒级时间戳。本实现选择**秒级**的原因：

1. **更长的可用年限**：30 位秒级可覆盖约 34 年（`2^30 / 86400 / 365 ≈ 34`），而 30 位毫秒级仅约 12 天
2. **序列号空间充足**：每秒 32768 个 ID 对绝大多数业务足够，不够可通过增大 `seq-bits` 扩展
3. **RingBuffer 更高效**：CachedUidGenerator 预生成未来多秒的 ID，秒级粒度使缓冲区利用率更高

### 6.2 时钟回拨处理

#### 策略：严格拒绝

当检测到 `currentSecond < lastSecond` 时，**立即抛出 `UidGenerateException`**：

```java
if (currentSecond < lastSecond) {
    long refusedSeconds = lastSecond - currentSecond;
    throw new UidGenerateException(
        "Clock moved backwards. Refusing for %d seconds", refusedSeconds);
}
```

#### 影响范围

- **DefaultUidGenerator**：抛异常后当前及后续请求全部失败，直到时钟恢复正常
- **CachedUidGenerator**：RingBuffer 中已预生成缓存的 ID 仍可正常消费，直到缓冲耗尽。如果填充线程检测到回拨，新填充也会失败

#### 应对建议

1. **部署 NTP 服务**（如 `chronyd`），确保服务器时钟同步
2. **使用 slew mode**（渐进修正），避免 jump mode（跳变修正）
3. 如果发生回拨，**立即重启应用**——重启后会重新分配 Worker ID，避免 ID 重复

### 6.3 CachedUidGenerator 与 RingBuffer

这是框架的**核心性能优化**。`CachedUidGenerator` 继承自 `DefaultUidGenerator`，通过 RingBuffer 提前批量生成未来 ID 存入环形缓冲区，消费时直接内存读取。

#### RingBuffer 结构

```
        tail (写指针, AtomicLong, 生产者)
        │
        ▼
┌───┬───┬───┬───┬───┬───┬───┬───┐
│ ✓ │ ✓ │ ✓ │   │   │   │   │   │   ← 每个槽位有状态标记（PaddedAtomicLong）
└───┴───┴───┴───┴───┴───┴───┴───┘     ✓ = CAN_TAKE_FLAG (1L)，可消费
        ▲                               空 = CAN_PUT_FLAG (0L)，可写入
        │
        cursor (读指针, AtomicLong, 消费者)
```

#### 关键参数

- **容量**：`bufferSize = (maxSequence + 1) << boostPower`，默认 `32768 << 3 = 262144` 个槽位
- **容量约束**：必须为 2 的幂（使用 `sequence & indexMask` 位运算代替取模，性能更高）
- **填充阈值**：`paddingThreshold = bufferSize * paddingFactor / 100`，默认 `262144 * 65 / 100 ≈ 170393`
- **触发条件**：当 `tail - cursor < paddingThreshold`（即剩余可用 ID 不足 35%）时触发填充

#### 核心设计要点

**1. 生产者（put）——单线程同步**

由 `BufferPaddingExecutor` 的单一固定线程池调用：
```java
public synchronized boolean put(long uid) {
    // 1. 检查缓冲是否已满
    if (tail - cursor == bufferSize - 1) → 触发拒绝策略，返回 false
    // 2. 计算槽位索引: (tail + 1) & indexMask
    // 3. 检查槽位状态标记是否为 CAN_PUT_FLAG
    // 4. 写入 UID，设置标记为 CAN_TAKE_FLAG
    // 5. 递增 tail
}
```
单线程 + `synchronized` 保障生产者安全，无需 CAS。

**2. 消费者（take）——多线程无锁**

业务线程调用 `getUID()` → `ringBuffer.take()`：
```java
public long take() {
    // 1. CAS 推进 cursor（无锁并发）
    // 2. 检查是否需要触发异步填充
    // 3. 检查槽位状态是否为 CAN_TAKE_FLAG
    // 4. 读取 UID，设置标记为 CAN_PUT_FLAG
    // 5. 返回 UID
}
```
CAS 无锁并发是关键——多个业务线程可以同时消费，互不阻塞。

**3. PaddedAtomicLong ——防止伪共享**

每个槽位的状态标记使用 `PaddedAtomicLong`（继承 `AtomicLong`），额外填充 6 个 `volatile long` 字段（共 56 字节），确保每个槽位独占 CPU 缓存行（通常 64 字节），避免相邻槽位的状态修改导致彼此的缓存行失效。

**4. 双触发补位机制**

- **异步触发**：消费者 `take()` 时检测 `tail - cursor < paddingThreshold`，提交异步填充任务
- **定时触发**：`scheduleInterval` 秒定期执行填充，防止长时间无消费导致缓冲枯竭

#### 填充流程

```
BufferPaddingExecutor.paddingBuffer()
  ├── CAS running (false → true)，防止并发填充
  ├── 循环填充未来每秒的所有ID:
  │     ├── lastSecond.incrementAndGet()     ← 推进到下一秒
  │     ├── uidProvider.provide(currentSecond) ← 生成该秒所有序列号
  │     └── 逐个 ringBuffer.put(uid)
  │           └── put 返回 false（缓冲满） → 退出循环
  └── CAS running (true → false)
```

其中 `provide(currentSecond)` 会生成该秒内全部 `maxSequence + 1` 个 ID：

```java
List<Long> nextIdsForOneSecond(long currentSecond) {
    long firstSeqUid = bitsAllocator.allocate(
        currentSecond - epochSeconds, workerId, 0L);
    // 返回 firstSeqUid, firstSeqUid+1, ..., firstSeqUid+maxSequence
}
```

### 6.4 Worker ID 分配机制

#### WorkerIdAssigner 接口

```java
public interface WorkerIdAssigner<T> {
    void init(T config);                     // 初始化配置
    long assignWorkerId(String workerName);  // 分配Worker ID
    void close();                            // 释放资源
}
```

三种后端都实现了此接口。

#### 数据库模式分配流程

```
assignWorkerId(workerName)
  ├── Step 1: 尝试回收过期槽位
  │     └── claimExpiredSlot(workerName, hostName, type, expireBefore)
  │           ├── SELECT ID FROM WORKER_NODE
  │           │   WHERE WORK_NAME = workerName AND LAST_ACTIVE_TIME < expireBefore
  │           │   ORDER BY LAST_ACTIVE_TIME ASC LIMIT 1
  │           │   FOR UPDATE SKIP LOCKED        ← 行级锁 + 跳过已锁定行
  │           └── UPDATE WORKER_NODE SET HOST_NAME=..., LAST_ACTIVE_TIME=NOW()
  │
  ├── Step 2: 无过期槽位 → 分配新槽位
  │     └── INSERT INTO WORKER_NODE (WORK_NAME, HOST_NAME, ...)
  │          使用自增主键作为 Worker ID
  │
  ├── Step 3: 溢出检查
  │     └── workerId > maxWorkerId → 抛 UidGenerateException
  │
  └── Step 4: 启动心跳调度器
        └── WorkerHeartbeatScheduler (ScheduledExecutorService, 固定频率+随机初始延迟)
              └── UPDATE WORKER_NODE SET LAST_ACTIVE_TIME=NOW() WHERE ID=?
```

#### Redis 模式分配流程

```
assignWorkerId(workerName)
  ├── Step 1: 尝试回收过期槽位
  │     └── tryClaimExpiredSlot()
  │           ├── SSCAN {prefix}:{workerName}:ids          ← 遍历应用自身的ID集合
  │           ├── 对每个旧的slot执行 SET NX PX              ← 若key不存在(TTL已过期)→回收成功
  │           └── 清理集合中属于其他应用的ID
  │
  ├── Step 2: 无过期槽位 → 分配新槽位
  │     └── allocateNewSlot()  (最多重试3次)
  │           ├── INCR {prefix}:counter - 1 → 获取新Worker ID
  │           └── SET NX {prefix}:slot:{id} PX zombieExpire  ← 原子认领槽位
  │
  ├── Step 3: 溢出检查
  │     └── workerId > maxWorkerId → 抛 UidGenerateException
  │
  └── Step 4: 启动心跳调度器
        └── RedisWorkerHeartbeatScheduler (ScheduledExecutorService)
              └── Lua脚本原子操作: GET eq 本实例值 → EXPIRE 刷新TTL
```

Lua 心跳脚本：
```lua
if redis.call('GET', KEYS[1]) == ARGV[1] then
    redis.call('EXPIRE', KEYS[1], ARGV[2])
    return 1
end
return 0
```

#### ZooKeeper 模式分配流程

```
assignWorkerId(workerName)
  ├── Step 1: 确保路径存在
  │     └── creatingParentsIfNeeded({basePath}/pool)
  │
  ├── Step 2: 扫描已占用槽位
  │     └── getChildren({basePath}/pool)
  │          解析 "worker-NNNNNNNNNN" → workerId 集合
  │
  ├── Step 3: 从随机起始位置扫描空闲槽位
  │     └── for id in shuffledRange(0, maxWorkerId):
  │           ├── create().withMode(EPHEMERAL).forPath(nodePath, data)
  │           ├── 成功 → 返回 workerId
  │           └── NodeExistsException → 跳过，继续下一个
  │
  ├── Step 4: 槽位耗尽 → 抛 UidGenerateException
  │
  └── 注册 ConnectionStateListener 监听连接状态
```

### 6.5 三种后端对比

#### 综合对比

| 特性 | Database | Redis | ZooKeeper |
|------|----------|-------|-----------|
| **分配模型** | 按应用分组：先回收再 INSERT | 全局计数器 + 按应用 ID 集：先回收再 INCR | 全局共享池：扫描空闲 + 临时节点 |
| **并发保障** | 行锁 `FOR UPDATE SKIP LOCKED` | `SET NX` 原子操作 + 全局 INCR | ZK 临时节点创建原子性 |
| **心跳机制** | 显式 UPDATE（30s 间隔） | Lua 脚本原子 TTL 刷新（30s 间隔） | **无需心跳**（ZK 原生 session 机制） |
| **故障检测** | `LAST_ACTIVE_TIME < expireBefore` | Key TTL 过期自动删除 | Session 超时 → EPHEMERAL 节点自动删除 |
| **故障恢复速度** | 慢（需等 `zombieExpireSeconds`） | 中（需等 TTL 过期） | 快（Session 断开即删除） |
| **外部依赖** | MySQL（HikariCP 连接池） | Redis（Redisson 客户端） | ZooKeeper（Curator 客户端） |
| **连接管理** | 自行管理 HikariCP（close 时关闭） | 共享 `RedissonClient`（不关闭） | 自行管理 Curator（close 时关闭） |
| **重启后 Worker ID** | 不保证相同（不影响正确性） | 不保证相同 | 不保证相同 |
| **运维复杂度** | 需建表 | 无需建表 | 无需建表 |
| **推荐场景** | 已有 MySQL 基础设施 | 已有 Redis 基础设施，追求更快恢复 | 已有 ZK 基础设施，追求最快恢复 |

#### 选型建议

| 条件 | 推荐 |
|------|------|
| 只有 MySQL，无 Redis/ZK | **Database** |
| 已有 Redis，对故障恢复速度有要求 | **Redis** |
| 已有 ZooKeeper，追求最快故障恢复 | **ZooKeeper** |
| 生产环境通用推荐 | **Database** 或 **Redis**（运维最简单） |

---

## 7. 性能测试

`examples/examples-global-id/` 目录附带了两个测试脚本：

| 脚本 | 用途 |
|------|------|
| `test-global-id.sh` | 功能正确性验证 |
| `perf-test-global-id.sh` | 性能基准测试 |

### 快速运行

```bash
# 1. 启动示例应用
mvn spring-boot:run -pl examples/examples-global-id

# 2. 运行功能测试
bash examples/examples-global-id/test-global-id.sh

# 3. 运行性能测试
bash examples/examples-global-id/perf-test-global-id.sh
```

### 功能测试覆盖

| 测试项 | 验证内容 |
|--------|---------|
| 单 ID 生成（3 项） | 返回正数、连续两次不重复、单调递增 |
| 批量生成（5 项） | 默认 10 个、指定 50 个、全部唯一、全部递增、批次 1 个 |
| ID 解析（4 项） | 返回字段完整性、解析值匹配、时间戳格式正确、Worker ID 非负 |
| 并发唯一性（2 项） | 100 并发有效、零重复 |
| 大批量唯一性（2 项） | 1000 个无重复 |
| 跨批次唯一性（1 项） | 200 个分两批无碰撞 |

### 性能测试覆盖

| 测试项 | 验证内容 |
|--------|---------|
| 串行延迟 | 200 次顺序请求，avg/min/max/p50/p95/p99 微秒级延迟 |
| 批量吞吐 | batch=100/500/1000/5000 的 IDs/s 吞吐 |
| 并发吞吐 | 50 并发 × 100 次 = 5000 IDs，全局唯一性 |
| 大规模唯一性 | 10 万 ID 零重复 |
| 并发批次 | 10 并发 × batch(1000) = 10000 IDs 全局唯一 |

### 性能基准参考

基于 CachedUidGenerator + RingBuffer 的典型指标：

| 指标 | 参考值 |
|------|--------|
| 单线程 `getUID()` QPS | 500 万 ~ 1000 万 / 秒 |
| HTTP 接口吞吐 | 1 万 ~ 5 万 IDs / 秒 |
| `getUID()` 延迟 | < 1 微秒（纯内存操作） |
| RingBuffer 初始填充时间 | < 100 毫秒 |

---

## 8. 运维指南

### 8.1 启动检查清单

- [ ] 确认依赖中间件可用（MySQL/Redis/ZK）
- [ ] 数据库模式：确认 `WORKER_NODE` 表已创建
- [ ] Redis 模式：确认 Redisson 连接配置正确，Redis 服务可连通
- [ ] ZooKeeper 模式：确认 ZK 连接字符串正确，ZK 集群可连通
- [ ] `worker-name`（或 `spring.application.name`）在 Worker 组内唯一
- [ ] 各节点系统时钟已 NTP 同步（`chronyd -v` 或 `ntpd -q`）
- [ ] 检查启动日志确认 `WorkerIdAssigner` 分配成功

### 8.2 关键日志

| 日志内容 | 含义 | 处理 |
|---------|------|------|
| `Assign worker id: X` | Worker ID 分配成功 | 正常 |
| `RingBuffer initialized` | RingBuffer 初始化完成 | 正常 |
| `Heartbeat failed` | 心跳失败（DB/Redis） | **高危**——槽位可能已被回收，需重启 |
| `ConnectionStateListener - LOST` | ZK 会话丢失 | **立即重启**——临时节点已删除 |
| `Clock moved backwards` | 时钟回拨 | **立即重启**——检查 NTP |
| `No expired slot found, allocating new` | 无过期槽位，分配新槽位 | 正常 |
| `Slot exhausted` | Worker ID 达到上限 | 需扩容或清理僵尸节点 |

### 8.3 监控指标建议

| 监控项 | 重要性 | 告警阈值建议 |
|--------|:---:|------|
| Worker ID 分配成功率 | 高 | 失败 = 应用无法启动 |
| 心跳成功率（DB/Redis） | 高 | < 100% 持续 3 个周期告警 |
| 时钟偏差 | 高 | NTP offset > 1s |
| RingBuffer 填充失败 | 中 | 持续失败告警 |
| 僵尸槽位数量（DB） | 低 | > 预期节点数 2 倍 |

### 8.4 故障处理

#### 场景一：应用无法启动，Worker ID 分配失败

| 后端 | 排查步骤 |
|------|---------|
| Database | 检查 DB 连接；确认表中 WORK_NAME 对应槽位是否全部被占用且未过期；检查 `max-worker-id` 是否已达上限 |
| Redis | 检查 Redis 连接；`KEYS {prefix}:*` 确认槽位和计数器状态；检查 `max-worker-id` |
| ZooKeeper | 检查 ZK 连接；`ls {basePath}/pool` 确认槽位数量；检查 `session-timeout` 是否过短 |

#### 场景二：运行时心跳失败

**数据库/Redis 模式**——日志显示 `Heartbeat failed`：

- 立即检查中间件连接是否正常
- 槽位可能已被其他节点回收，**需立即重启应用**避免 ID 冲突
- 排查 `zombie-expire-seconds` 是否设置过短或网络是否有抖动

#### 场景三：ZooKeeper 会话丢失

日志显示 `ConnectionStateListener - LOST`：

- **立即重启应用！** 临时节点已删除，继续运行会产生 ID 冲突
- 检查 ZK 集群健康状况
- 检查网络是否有分区
- 考虑增加 `session-timeout` 以提高容忍度

#### 场景四：时钟回拨

日志显示 `Clock moved backwards. Refusing for X seconds`：

- 检查 NTP 服务状态（`chronyc tracking` 或 `ntpq -p`）
- **立即重启应用**（重启后重新分配 Worker ID，避免 ID 重复）
- 如果持续发生，排查 NTP 服务配置和使用 slew mode

### 8.5 扩容指南

当 Worker ID 接近上限时：

1. **调整位分配**：增大 `worker-bits`，同步减小 `time-bits` 或 `seq-bits`
2. **修改 max-worker-id**：与新的 `worker-bits` 保持一致
3. **统一更新配置**：所有节点必须使用相同的位分配参数
4. **滚动重启**：逐台重启应用节点

> **警告**：修改 `worker-bits`、`time-bits`、`seq-bits` 或 `epoch-str` 会改变 ID 结构，新旧 ID 的 `parseUID()` 结果不兼容。建议在系统初期确定参数，避免运行中修改。

---

## 9. 常见问题

### Q1：生成的 ID 是否严格全局有序？

**不是严格全局有序的。** ID 在同一节点内严格递增，但跨节点时，由于各节点时钟的微小差异和 Worker ID 不同，总体趋势递增但有局部乱序。

如果业务需要严格全局有序，建议在应用层排序或使用数据库自增序列。

### Q2：Worker ID 分配后可以固定不变吗？

**不保证。** 框架设计上重启不保证获取相同的 Worker ID（三种后端都是先尝试回收过期槽位），但这不影响正确性——Snowflake 算法只需保证**同一时刻**Worker ID 唯一即可。

### Q3：修改 epoch-str 有什么影响？

修改 epoch 会改变所有 ID 的时间戳基准。建议：
- 新系统：一开始就设定好合适的 epoch，避免后续修改
- 老系统：**绝对不要修改**，否则新旧 ID 的时间戳语义不一致，`parseUID()` 结果错误

### Q4：RingBuffer 缓冲池太大吃内存吗？

默认 262144 个槽位 × 8 字节 = **约 2MB**（加上标记数组约 4MB），内存占用极小。`boost-power=3` 已经足够大多数场景，无需调大。

### Q5：与 MySQL 自增 ID 相比有什么优势？

| | MySQL 自增 ID | Global ID |
|---|---|---|
| 分布式支持 | 需额外序列服务或分段 | 天然支持，各节点独立生成 |
| 性能 | 受 DB 限制（~几千 QPS） | 内存操作，~百万 QPS |
| 单点故障 | 依赖 DB | 各节点独立，无单点 |
| ID 含义 | 纯数字，无意义 | 可解析出时间戳和节点信息 |
| 分库分表 | 需额外处理冲突 | 天然全局唯一 |

### Q6：如何选择合适的 seq-bits？

计算公式：`单节点峰值 QPS ≈ 2^seqBits`

| seqBits | 单节点每秒 ID 数 | 适用场景 |
|---------|:---:|------|
| 14 | 16384 | 常规业务 |
| 15（默认） | 32768 | 高并发业务 |
| 16 | 65536 | 超高并发 |
| 17 | 131072 | 极限场景 |

### Q7：可以同时使用多种后端吗？

**不支持且不应该。** 三个 starter 通过条件装配互斥激活。如果在同一应用配置了多个前缀，需要手动排除不需要的自动装配类。同时使用多种后端也无法保证 Worker ID 不冲突。

### Q8：CachedUidGenerator 启动时的初始填充需要多久？

以默认配置（每秒 32768 个 ID，RingBuffer 262144 槽位），初始填充填充一个 RingBuffer 需要处理约 8 秒的未来 ID，耗时通常 < 100 毫秒。

### Q9：应用异常退出后 Worker ID 多久可回收？

| 后端 | 回收时间 |
|------|---------|
| Database | 最多 `zombie-expire-seconds`（默认 300 秒 = 5 分钟） |
| Redis | 最多 `zombie-expire-seconds`（默认 300 秒 = 5 分钟，即 key TTL） |
| ZooKeeper | 最多 `session-timeout`（默认 30 秒，取决于服务端配置） |
