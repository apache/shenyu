package com.yeepay.framework.global.id.database.heartbeat;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.global.id.database.service.WorkNodeService;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;

/**
 * worker 心跳调度器：容器场景下周期性更新 LAST_ACTIVE_TIME，使本节点不会被其他节点
 * 当成僵尸槽位回收掉. 单例式启动，JVM 退出时通过 shutdown hook 优雅关闭.
 */
@Slf4j
public class WorkerHeartbeatScheduler {

    /**
     * worker 槽位 DB 服务.
     */
    private final WorkNodeService workerNodeService;

    /**
     * 本节点的 worker ID.
     */
    private final long workerId;

    /**
     * 心跳间隔（秒）.
     */
    private final long intervalSeconds;

    /**
     * 心跳调度线程池.
     */
    private ScheduledExecutorService executor;

    /**
     * 构造心跳调度器.
     *
     * @param workerNodeService DB 服务
     * @param workerId          本节点的 worker ID
     * @param intervalSeconds   心跳间隔（秒），建议远小于僵尸过期阈值（如 30s vs 300s）
     */
    public WorkerHeartbeatScheduler(WorkNodeService workerNodeService, long workerId, long intervalSeconds) {
        this.workerNodeService = workerNodeService;
        this.workerId = workerId;
        this.intervalSeconds = intervalSeconds;
    }

    /**
     * 启动心跳线程. 多次调用幂等. 关闭由调用方（DatabaseWorkerIdAssigner）统一负责.
     */
    public synchronized void start() {
        if (Objects.nonNull(executor)) {
            return;
        }
        executor = Executors.newSingleThreadScheduledExecutor(
                YeepayThreadFactory.create("database-global-id-worker-heartbeat", true));
        long jitter = ThreadLocalRandom.current().nextLong(intervalSeconds);
        executor.scheduleAtFixedRate(this::beat, jitter, intervalSeconds, TimeUnit.SECONDS);
        log.info("Worker heartbeat scheduler started: workerId={}, intervalSeconds={}", workerId, intervalSeconds);
    }

    /**
     * 关闭心跳线程. 多次调用幂等.
     */
    public synchronized void shutdown() {
        if (Objects.isNull(executor) || executor.isShutdown()) {
            return;
        }
        executor.shutdownNow();
        log.info("Worker heartbeat scheduler stopped: workerId={}", workerId);
    }

    private void beat() {
        try {
            boolean ok = workerNodeService.heartbeat(workerId);
            if (!ok) {
                // 没匹配上：通常意味着记录被别人当成僵尸抢走了 —— 这里只告警，
                // 因为继续产出 UID 会与抢占方撞车。运维介入是更稳妥的处理.
                log.error(
                        "Heartbeat lost for workerId={}, the slot may have been reclaimed by another node. "
                                + "请立即检查心跳间隔与僵尸过期阈值的差距，并重启本实例.",
                        workerId);
            }
        } catch (RuntimeException e) {
            // 网络抖动 / 短暂连接失败 -> 仅 warn，由下一次 tick 继续
            log.warn("Heartbeat failed for workerId={}, will retry next tick", workerId, e);
        }
    }
}
