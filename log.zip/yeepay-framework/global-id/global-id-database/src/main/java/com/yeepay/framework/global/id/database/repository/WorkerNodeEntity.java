package com.yeepay.framework.global.id.database.repository;

import com.yeepay.framework.global.id.api.enums.WorkerNodeType;
import java.util.Date;
import lombok.Data;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * WorkerNode实体类.
 */
@Data
public class WorkerNodeEntity {

    /**
     * Entity unique id (table unique).
     */
    private long id;

    /**
     * Type of CONTAINER: HostName, ACTUAL : IP.
     */
    private String hostName;

    /**
     * Type of workName.
     */
    private String workName;

    /**
     * type of {@link WorkerNodeType}.
     */
    private int type;

    /**
     * Worker launch date, default now.
     */
    private Date launchDate = new Date();

    /**
     * 最后活跃时间，容器场景下由 worker 周期心跳更新；非容器场景写入即为启动时间.
     */
    private Date lastActiveTime = new Date();

    /**
     * Created time.
     */
    private Date created = new Date();

    /**
     * Last modified.
     */
    private Date modified = new Date();

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
