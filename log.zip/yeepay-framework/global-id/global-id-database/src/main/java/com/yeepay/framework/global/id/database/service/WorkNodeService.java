package com.yeepay.framework.global.id.database.service;

import com.yeepay.framework.global.id.database.repository.WorkerNodeEntity;
import java.util.Date;

/**
 * WorkNode 服务接口.
 *
 * <p>分配模型：每个 workName 是一个槽位池，本接口提供"抢过期槽位 / 新增槽位 / 心跳"三个原子动作.</p>
 */
public interface WorkNodeService {

    /**
     * 关闭服务，释放自管的资源（如自创建的连接池）. 多次调用应幂等.
     */
    void close();

    /**
     * 尝试抢占 workName 池中一个心跳过期的槽位.
     * 内部以"找候选 → CAS UPDATE → 失败重试"的语义实现，调用方拿到的是直接可用的 workerId.
     *
     * @param workName     业务组标识
     * @param hostName     本实例主机名/IP（仅作记录）
     * @param type         节点类型
     * @param expireBefore 心跳过期阈值
     * @return 抢占成功返回槽位 ID（= workerId）；无可抢槽位或重试仍失败时返回 null
     */
    Long claimExpiredSlot(String workName, String hostName, int type, Date expireBefore);

    /**
     * 池中没有可抢槽位时，插入一条新槽位.
     *
     * @param workerNodeEntity 槽位实体，回填自增 ID
     */
    void addWorkerNode(WorkerNodeEntity workerNodeEntity);

    /**
     * 心跳：更新指定槽位的 LAST_ACTIVE_TIME.
     *
     * @param id 槽位 ID
     * @return false 通常意味着记录已被别的实例抢占
     */
    boolean heartbeat(long id);
}
