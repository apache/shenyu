package com.yeepay.framework.global.id.database.repository;

import java.util.Date;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * WorkerNode 数据库映射器.
 *
 * <p>分配模型：每个 workName 是一个槽位池，每条记录代表池内的一个槽位（ID = workerId）.
 * 实例启动时优先抢一个心跳过期的旧槽位；抢不到再 INSERT 扩容；并周期心跳维持占用.</p>
 */
@Mapper
public interface WorkerNodeMapper {

    /**
     * 查找并锁定指定 workName 下最旧的一条过期槽位 ID.
     * FOR UPDATE SKIP LOCKED 避免并发抢占同一行.
     *
     * @param workName     业务组标识
     * @param expireBefore 心跳过期阈值
     * @return 候选 ID；无可抢槽位时返回 null
     */
    @Select("SELECT ID FROM WORKER_NODE "
            + "WHERE WORK_NAME = #{workName} AND LAST_ACTIVE_TIME < #{expireBefore} "
            + "ORDER BY LAST_ACTIVE_TIME ASC LIMIT 1 "
            + "FOR UPDATE SKIP LOCKED")
    Long findExpiredCandidateForUpdate(@Param("workName") String workName, @Param("expireBefore") Date expireBefore);

    /**
     * 抢占指定 ID 的槽位（已被 FOR UPDATE 锁定，无需二次校验 LAST_ACTIVE_TIME）.
     *
     * @param id       候选槽位 ID
     * @param hostName 新占用者主机名/IP
     * @param type     节点类型
     * @return 影响行数
     */
    @Update("UPDATE WORKER_NODE "
            + "SET HOST_NAME = #{hostName}, TYPE = #{type}, "
            + "    LAUNCH_DATE = CURRENT_DATE, LAST_ACTIVE_TIME = NOW(), MODIFIED = NOW() "
            + "WHERE ID = #{id}")
    int claimById(@Param("id") long id, @Param("hostName") String hostName, @Param("type") int type);

    /**
     * 插入新槽位（自增 ID 即为 workerId）. 池子里没有可抢的过期槽位时使用.
     *
     * @param workerNodeEntity 工作节点实体
     */
    @Insert("INSERT INTO WORKER_NODE "
            + "(WORK_NAME, HOST_NAME, TYPE, LAUNCH_DATE, LAST_ACTIVE_TIME, MODIFIED, CREATED) "
            + "VALUES "
            + "(#{workName}, #{hostName}, #{type}, #{launchDate}, NOW(), NOW(), NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "ID")
    void addWorkerNode(WorkerNodeEntity workerNodeEntity);

    /**
     * 心跳：更新指定槽位的 LAST_ACTIVE_TIME 为当前时间.
     *
     * @param id 槽位 ID
     * @return 影响行数
     */
    @Update("UPDATE WORKER_NODE SET LAST_ACTIVE_TIME = NOW(), MODIFIED = NOW() WHERE ID = #{id}")
    int heartbeat(@Param("id") long id);
}
