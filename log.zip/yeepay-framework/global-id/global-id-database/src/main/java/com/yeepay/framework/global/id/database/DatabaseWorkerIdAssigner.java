package com.yeepay.framework.global.id.database;

import com.yeepay.framework.common.utils.NetUtils;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.enums.WorkerNodeType;
import com.yeepay.framework.global.id.api.exception.UidGenerateException;
import com.yeepay.framework.global.id.database.config.DatabaseConfig;
import com.yeepay.framework.global.id.database.heartbeat.WorkerHeartbeatScheduler;
import com.yeepay.framework.global.id.database.repository.WorkerNodeEntity;
import com.yeepay.framework.global.id.database.service.WorkNodeService;
import com.yeepay.framework.global.id.database.service.WorkNodeServiceImpl;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import lombok.extern.slf4j.Slf4j;

/**
 * 基于 DB 的 workerId 分配器（动态槽位池模型）.
 *
 * <p>workName 是业务组标识，组内所有实例共享同一槽位池. 启动流程：
 * <ol>
 *   <li>抢一个池内心跳过期的旧槽位</li>
 *   <li>没抢到则 INSERT 新槽位扩容</li>
 *   <li>启动周期心跳维持本槽位占用</li>
 * </ol>
 *
 * <p>整套机制不依赖 hostName 稳定性，因此对 K8s Deployment / StatefulSet / 物理机一视同仁.
 * 节点重启不保证拿回原 workerId，但雪花算法仅要求"任一时刻全局唯一"，绑定语义无意义.</p>
 *
 * <p>资源管理：实现 close，统一关闭 heartbeatScheduler 与 workerNodeService.
 * Spring 环境通过 {@code @Bean(destroyMethod = "close")} 触发关闭.</p>
 */
@Slf4j
public class DatabaseWorkerIdAssigner implements WorkerIdAssigner<DatabaseConfig> {

    /**
     * worker 槽位 DB 服务.
     */
    private WorkNodeService workerNodeService;

    /**
     * 是否运行在容器中，决定 TYPE 字段标记.
     */
    private boolean container;

    /**
     * 心跳间隔（秒）.
     */
    private long heartbeatIntervalSeconds;

    /**
     * 心跳过期阈值（秒）.
     */
    private long zombieExpireSeconds;

    /**
     * 允许的最大 workerId.
     */
    private long maxWorkerId;

    /**
     * 心跳调度器.
     */
    private WorkerHeartbeatScheduler heartbeatScheduler;

    /**
     * 关闭幂等标志.
     */
    private final AtomicBoolean closed = new AtomicBoolean(false);

    @Override
    public void init(final DatabaseConfig config) {
        this.workerNodeService = new WorkNodeServiceImpl(config);
        this.container = config.isContainer();
        this.heartbeatIntervalSeconds = config.getHeartbeatIntervalSeconds();
        this.zombieExpireSeconds = config.getZombieExpireSeconds();
        this.maxWorkerId = config.getMaxWorkerId();
    }

    @Override
    public long assignWorkerId(final String workerName) {
        String hostName = NetUtils.getLocalAddress();
        int type = container ? WorkerNodeType.CONTAINER.value() : WorkerNodeType.ACTUAL.value();
        // ① 优先抢一个心跳过期的旧槽位
        Date expireBefore = new Date(System.currentTimeMillis() - zombieExpireSeconds * 1000L);
        Long workerId = workerNodeService.claimExpiredSlot(workerName, hostName, type, expireBefore);
        if (Objects.nonNull(workerId)) {
            log.info(
                    "Claimed expired slot: workerId={}, workName={}, host={}, expireBefore={}",
                    workerId,
                    workerName,
                    hostName,
                    expireBefore);
        } else {
            // ② 池子里没有过期槽位，INSERT 扩容
            WorkerNodeEntity entity = buildWorkerNode(workerName, hostName, type);
            workerNodeService.addWorkerNode(entity);
            workerId = entity.getId();
            log.info("Inserted new slot: workerId={}, workName={}, host={}", workerId, workerName, hostName);
        }

        // ③ 溢出保护
        if (workerId > maxWorkerId) {
            throw new UidGenerateException(
                    "workerId %d 超过最大允许值 %d. workerName=%s. 请清理过期槽位或调大 workerBits.", workerId, maxWorkerId, workerName);
        }

        // ④ 启动心跳维持本槽位占用
        heartbeatScheduler = new WorkerHeartbeatScheduler(workerNodeService, workerId, heartbeatIntervalSeconds);
        heartbeatScheduler.start();

        return workerId;
    }

    /**
     * 统一关闭资源：先停心跳，再关 DB 连接池. 多次调用幂等.
     */
    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        if (Objects.nonNull(heartbeatScheduler)) {
            try {
                heartbeatScheduler.shutdown();
            } catch (RuntimeException e) {
                log.warn("Failed to shutdown heartbeat scheduler", e);
            }
        }
        if (Objects.nonNull(workerNodeService)) {
            try {
                workerNodeService.close();
            } catch (RuntimeException e) {
                log.warn("Failed to close workerNodeService", e);
            }
        }
        log.info("DatabaseWorkerIdAssigner closed.");
    }

    private WorkerNodeEntity buildWorkerNode(String workerName, String hostName, int type) {
        WorkerNodeEntity entity = new WorkerNodeEntity();
        entity.setWorkName(workerName);
        entity.setHostName(hostName);
        entity.setType(type);
        return entity;
    }
}
