package com.yeepay.framework.global.id.database.config;

import lombok.Data;

/**
 * 全局 ID 模块使用的数据库连接 & 槽位池配置.
 */
@Data
public class DatabaseConfig {

    /**
     * 数据库驱动类名.
     */
    private String driverClassName;

    /**
     * JDBC URL.
     */
    private String jdbcUrl;

    /**
     * 数据库用户名.
     */
    private String username;

    /**
     * 数据库密码.
     */
    private String password;

    /**
     * 逻辑表名.
     */
    private String logicTable;

    /**
     * 是否运行在容器中，默认为true.
     */
    private boolean container = true;

    /**
     * 心跳间隔（秒），周期性更新 LAST_ACTIVE_TIME 维持本节点的槽位占用.
     * 必须远小于 {@link #zombieExpireSeconds}，避免活节点被误判为僵尸.
     */
    private long heartbeatIntervalSeconds = 30L;

    /**
     * 心跳过期阈值（秒）. 超过该时间未心跳的槽位可被其他实例抢占.
     * 留出网络抖动 / GC 停顿 / DB 故障的容错窗口，默认 5 分钟.
     */
    private long zombieExpireSeconds = 300L;

    /**
     * 允许的最大 workerId（与雪花算法的 workerBits 对齐）.
     * AUTO_INCREMENT 超过该上限时直接抛 {@code UidGenerateException}，避免 Snowflake ID 碰撞.
     * 默认对应 workerBits=18 的上限.
     */
    private long maxWorkerId = (1L << 18) - 1;

    /**
     * Hikari 连接池最小空闲连接数.
     */
    private int minimumIdle = 1;

    /**
     * Hikari 连接池最大连接数.
     */
    private int maximumPoolSize = 10;

    /**
     * 连接最大存活时间（毫秒），超过会被回收重建.
     */
    private long maxLifetime = 28440000L;

    /**
     * 连接有效性校验超时（毫秒）.
     */
    private long validationTimeout = 500L;

    /**
     * 获取连接的超时时间（毫秒）.
     */
    private long connectionTimeout = 1000L;
}
