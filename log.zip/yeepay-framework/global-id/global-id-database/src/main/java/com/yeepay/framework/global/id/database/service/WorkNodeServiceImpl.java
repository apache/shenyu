package com.yeepay.framework.global.id.database.service;

import com.yeepay.framework.global.id.database.config.DatabaseConfig;
import com.yeepay.framework.global.id.database.repository.WorkerNodeEntity;
import com.yeepay.framework.global.id.database.repository.WorkerNodeMapper;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

/**
 * WorkNode 服务实现.
 */
@Slf4j
public class WorkNodeServiceImpl implements WorkNodeService {

    private SqlSessionFactory sqlSessionFactory;

    /**
     * 持有自管的 DataSource，用于 close 时释放. 外部传入的 dataSource 不归本类管理.
     */
    private DataSource ownedDataSource;

    private final AtomicBoolean closed = new AtomicBoolean(false);

    /**
     * Instantiates a new Work node service.
     *
     * @param dataSource the data source
     */
    public WorkNodeServiceImpl(DataSource dataSource) {
        setSqlSessionFactory(dataSource);
    }

    /**
     * Instantiates a new Work node service.
     *
     * @param config the config
     */
    public WorkNodeServiceImpl(DatabaseConfig config) {
        this.ownedDataSource = buildDataSource(config);
        setSqlSessionFactory(this.ownedDataSource);
    }

    @Override
    public Long claimExpiredSlot(String workName, String hostName, int type, Date expireBefore) {
        try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
            WorkerNodeMapper mapper = sqlSession.getMapper(WorkerNodeMapper.class);
            Long candidate = mapper.findExpiredCandidateForUpdate(workName, expireBefore);
            if (Objects.isNull(candidate)) {
                return null;
            }
            mapper.claimById(candidate, hostName, type);
            sqlSession.commit();
            return candidate;
        }
    }

    @Override
    public void addWorkerNode(WorkerNodeEntity workerNodeEntity) {
        try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
            WorkerNodeMapper mapper = sqlSession.getMapper(WorkerNodeMapper.class);
            mapper.addWorkerNode(workerNodeEntity);
            sqlSession.commit();
        }
    }

    @Override
    public boolean heartbeat(long id) {
        try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
            WorkerNodeMapper mapper = sqlSession.getMapper(WorkerNodeMapper.class);
            int rows = mapper.heartbeat(id);
            sqlSession.commit();
            return rows == 1;
        }
    }

    /**
     * 关闭服务. 仅关闭自创建的 HikariDataSource，外部传入的 dataSource 不动.
     */
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        if (ownedDataSource instanceof HikariDataSource) {
            try {
                ((HikariDataSource) ownedDataSource).close();
                log.info("WorkNodeService DataSource closed.");
            } catch (RuntimeException e) {
                log.warn("Failed to close WorkNodeService DataSource", e);
            }
        }
    }

    private DataSource buildDataSource(DatabaseConfig config) {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(config.getDriverClassName());
        hikariConfig.setJdbcUrl(config.getJdbcUrl());
        hikariConfig.setUsername(config.getUsername());
        hikariConfig.setPassword(config.getPassword());
        hikariConfig.setMinimumIdle(config.getMinimumIdle());
        hikariConfig.setMaximumPoolSize(config.getMaximumPoolSize());
        hikariConfig.setMaxLifetime(config.getMaxLifetime());
        hikariConfig.setValidationTimeout(config.getValidationTimeout());
        hikariConfig.setConnectionTimeout(config.getConnectionTimeout());
        return new HikariDataSource(hikariConfig);
    }

    private void setSqlSessionFactory(DataSource dataSource) {
        TransactionFactory transactionFactory = new JdbcTransactionFactory();
        Environment environment = new Environment("development", transactionFactory, dataSource);
        Configuration configuration = new Configuration(environment);
        configuration.addMapper(WorkerNodeMapper.class);
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(configuration);
    }
}
