CREATE TABLE WORKER_NODE
(
    ID               BIGINT      NOT NULL AUTO_INCREMENT COMMENT 'auto increment id, used as snowflake workerId',
    WORK_NAME        VARCHAR(64) NOT NULL COMMENT '业务组标识，一组应用共用同一 workName，每条记录代表组内一个槽位',
    HOST_NAME        VARCHAR(64) NOT NULL COMMENT '当前占用者主机名/IP，仅供运维定位，不参与分配匹配',
    TYPE             INT         NOT NULL COMMENT 'node type: ACTUAL or CONTAINER, 仅作标识',
    LAUNCH_DATE      DATE        NOT NULL COMMENT '本次抢占时间',
    LAST_ACTIVE_TIME DATETIME    NOT NULL COMMENT '心跳时间，超过阈值的记录可被其他实例抢占',
    MODIFIED         TIMESTAMP   NOT NULL COMMENT 'modified time',
    CREATED          TIMESTAMP   NOT NULL COMMENT 'created time',
    PRIMARY KEY (ID),
    KEY IDX_WORK_ACTIVE (WORK_NAME, LAST_ACTIVE_TIME)
)
