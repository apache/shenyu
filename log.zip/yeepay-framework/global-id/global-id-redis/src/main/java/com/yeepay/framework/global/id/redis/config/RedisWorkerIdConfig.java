package com.yeepay.framework.global.id.redis.config;

import lombok.Data;

/**
 * Redis 方式 workerId 分配器的配置.
 */
@Data
public class RedisWorkerIdConfig {

    /**
     * 心跳间隔（秒），周期性刷新槽位 TTL 维持占用.
     * 必须远小于 {@link #zombieExpireSeconds}，避免活节点被误判为僵尸.
     */
    private long heartbeatIntervalSeconds = 30L;

    /**
     * 槽位过期阈值（秒）. 超过该时间未续期的槽位可被其他实例抢占.
     */
    private long zombieExpireSeconds = 300L;

    /**
     * Redis key 前缀.
     */
    private String keyPrefix = "global-id";

    /**
     * 允许的最大 workerId（与雪花算法的 workerBits 对齐）.
     * 分配超过该上限时直接抛 {@code UidGenerateException}，避免 Snowflake ID 碰撞.
     * 默认对应 workerBits=18 的上限.
     */
    private long maxWorkerId = (1L << 18) - 1;
}
