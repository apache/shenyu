package com.yeepay.framework.global.id.redis.heartbeat;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import com.yeepay.framework.global.id.redis.RedisWorkerIdAssigner;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;

/**
 * Redis worker 心跳调度器：周期性刷新槽位 TTL，使本节点不会被其他节点抢占.
 */
@Slf4j
public class RedisWorkerHeartbeatScheduler {

    /**
     * workerId 分配器，提供心跳执行逻辑.
     */
    private final RedisWorkerIdAssigner assigner;

    /**
     * 槽位 Redis key.
     */
    private final String slotKey;

    /**
     * 槽位值（workerName:instanceId），心跳时校验归属.
     */
    private final String slotValue;

    /**
     * 心跳间隔（秒）.
     */
    private final long intervalSeconds;

    /**
     * 心跳线程池.
     */
    private ScheduledExecutorService executor;

    /**
     * 构造心跳调度器.
     *
     * @param assigner        分配器实例，提供 heartbeat 方法
     * @param slotKey         槽位 Redis key
     * @param slotValue       槽位值（workerName:instanceId）
     * @param intervalSeconds 心跳间隔（秒）
     */
    public RedisWorkerHeartbeatScheduler(
            RedisWorkerIdAssigner assigner, String slotKey, String slotValue, long intervalSeconds) {
        this.assigner = assigner;
        this.slotKey = slotKey;
        this.slotValue = slotValue;
        this.intervalSeconds = intervalSeconds;
    }

    /**
     * 启动心跳线程. 多次调用幂等.
     */
    public synchronized void start() {
        if (Objects.nonNull(executor)) {
            return;
        }
        executor = Executors.newSingleThreadScheduledExecutor(
                YeepayThreadFactory.create("redis-global-id-worker-heartbeat", true));
        long jitter = ThreadLocalRandom.current().nextLong(intervalSeconds);
        executor.scheduleAtFixedRate(this::beat, jitter, intervalSeconds, TimeUnit.SECONDS);
        log.info("Redis worker heartbeat scheduler started: slotKey={}, intervalSeconds={}", slotKey, intervalSeconds);
    }

    /**
     * 关闭心跳线程. 多次调用幂等.
     */
    public synchronized void shutdown() {
        if (Objects.isNull(executor) || executor.isShutdown()) {
            return;
        }
        executor.shutdownNow();
        log.info("Redis worker heartbeat scheduler stopped: slotKey={}", slotKey);
    }

    private void beat() {
        try {
            boolean ok = assigner.heartbeat(slotKey, slotValue);
            if (!ok) {
                log.error(
                        "Heartbeat lost for slotKey={}, the slot may have been reclaimed by another node. "
                                + "请立即检查心跳间隔与僵尸过期阈值的差距，并重启本实例.",
                        slotKey);
            }
        } catch (RuntimeException e) {
            log.warn("Heartbeat failed for slotKey={}, will retry next tick", slotKey, e);
        }
    }
}
