package com.yeepay.framework.global.id.redis;

import com.yeepay.framework.common.utils.NetUtils;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.exception.UidGenerateException;
import com.yeepay.framework.global.id.redis.config.RedisWorkerIdConfig;
import com.yeepay.framework.global.id.redis.heartbeat.RedisWorkerHeartbeatScheduler;
import java.time.Duration;
import java.util.Collections;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RBucket;
import org.redisson.api.RScript;
import org.redisson.api.RSet;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.StringCodec;

/**
 * 基于 Redis 的 workerId 分配器（全局唯一 + 按应用回收）.
 * <b>推荐方案</b>：相比 Database 和 ZooKeeper，Redis 方案在万级节点规模下综合表现最优——
 * 分配与心跳均为微秒级操作，无全量扫描开销，且大多数基础设施已具备 Redis 集群.
 *
 * <h3>分配原理</h3>
 * <ol>
 *   <li><b>回收优先</b>：扫描本应用历史 ID 集合（SSCAN），对每个 ID 尝试 {@code SET NX}
 *       抢占全局槽位——若该槽位 TTL 已过期（key 不存在），则抢占成功，复用旧 ID</li>
 *   <li><b>新分配兜底</b>：若无可回收 ID，{@code INCR} 全局原子计数器获取新 ID，
 *       再 {@code SET NX} 占位，并将新 ID 加入本应用的历史集合</li>
 *   <li><b>心跳续期</b>：启动后台线程，每 {@code heartbeatIntervalSeconds} 秒执行 Lua 脚本，
 *       原子校验槽位归属后刷新 TTL，保证活节点不被误回收</li>
 * </ol>
 *
 * <h3>Key 结构</h3>
 * <ul>
 *   <li>{@code {keyPrefix}:counter} — 全局原子计数器，所有应用共享，保证 ID 跨应用唯一</li>
 *   <li>{@code {keyPrefix}:slot:{id}} — 全局槽位，值为 {@code workerName:ip:uuid}，带 TTL</li>
 *   <li>{@code {keyPrefix}:{workerName}:ids} — 按应用记录已分配的 ID 集合（SET），用于回收扫描</li>
 * </ul>
 *
 * <h3>核心保证</h3>
 * <ul>
 *   <li><b>全局唯一</b>：全局计数器 + {@code SET NX} 原子占位，任一时刻每个 ID 只有一个持有者</li>
 *   <li><b>自动回收</b>：槽位 TTL 过期后自动释放，无需人工清理</li>
 *   <li><b>ID 紧凑</b>：优先回收旧 ID，避免计数器无限增长突破 maxWorkerId 上限</li>
 * </ul>
 *
 * <p>资源管理：实现 {@link AutoCloseable}，统一关闭 heartbeatScheduler.
 * 不关闭 RedissonClient（共享资源，不归本类管理）.
 * Spring 环境通过 {@code @Bean(destroyMethod = "close")} 触发关闭.</p>
 */
@Slf4j
@RequiredArgsConstructor
public class RedisWorkerIdAssigner implements WorkerIdAssigner<RedisWorkerIdConfig>, AutoCloseable {

    /**
     * 分配新槽位时的最大重试次数.
     */
    private static final int ALLOCATE_RETRY_LIMIT = 3;

    /**
     * 心跳 Lua 脚本：原子校验 instanceId 并刷新 TTL.
     */
    private static final String LUA_HEARTBEAT = "if redis.call('GET', KEYS[1]) == ARGV[1] then "
            + "redis.call('EXPIRE', KEYS[1], ARGV[2]) "
            + "return 1 "
            + "end "
            + "return 0";

    /**
     * Redisson 客户端.
     */
    private final RedissonClient redissonClient;

    /**
     * 心跳间隔（秒）.
     */
    private long heartbeatIntervalSeconds;

    /**
     * 槽位过期阈值（秒）.
     */
    private long zombieExpireSeconds;

    /**
     * Redis key 前缀.
     */
    private String keyPrefix;

    /**
     * 允许的最大 workerId.
     */
    private long maxWorkerId;

    /**
     * 本实例唯一标识，用于心跳时校验槽位归属.
     */
    private String instanceId;

    /**
     * 心跳 Lua 脚本 SHA 缓存，避免每次心跳传输完整脚本.
     */
    private volatile String heartbeatScriptSha;

    /**
     * 心跳调度器.
     */
    private RedisWorkerHeartbeatScheduler heartbeatScheduler;

    /**
     * 关闭标记，保证 close 幂等.
     */
    private final AtomicBoolean closed = new AtomicBoolean(false);

    @Override
    public void init(final RedisWorkerIdConfig config) {
        this.heartbeatIntervalSeconds = config.getHeartbeatIntervalSeconds();
        this.zombieExpireSeconds = config.getZombieExpireSeconds();
        this.keyPrefix = config.getKeyPrefix();
        this.maxWorkerId = config.getMaxWorkerId();
        this.instanceId = NetUtils.getLocalAddress() + ":" + UUID.randomUUID();
    }

    @Override
    public long assignWorkerId(final String workerName) {
        String globalCounterKey = keyPrefix + ":counter";
        String globalSlotPrefix = keyPrefix + ":slot:";
        String appIdsKey = keyPrefix + ":" + workerName + ":ids";
        String slotValue = workerName + ":" + instanceId;

        // ① 从本应用已分配的 ID 中，尝试抢一个过期的全局槽位
        RSet<String> appIdsSet = redissonClient.getSet(appIdsKey, StringCodec.INSTANCE);
        Long workerId = tryClaimExpiredSlot(globalSlotPrefix, appIdsSet, slotValue, workerName);

        if (Objects.nonNull(workerId)) {
            log.info(
                    "Claimed expired Redis slot: workerId={}, workName={}, instanceId={}",
                    workerId,
                    workerName,
                    instanceId);
        } else {
            // ② 没有可抢槽位，通过全局计数器分配新 ID
            RAtomicLong globalCounter = redissonClient.getAtomicLong(globalCounterKey);
            workerId = allocateNewSlot(globalCounter, globalSlotPrefix, slotValue);
            appIdsSet.add(String.valueOf(workerId));
            log.info(
                    "Allocated new Redis slot: workerId={}, workName={}, instanceId={}",
                    workerId,
                    workerName,
                    instanceId);
        }

        // ③ 溢出保护
        if (workerId > maxWorkerId) {
            throw new UidGenerateException(
                    "workerId %d 超过最大允许值 %d. workerName=%s. " + "请检查 RedisWorkerIdConfig.maxWorkerId 配置或清理过期槽位.",
                    workerId, maxWorkerId, workerName);
        }

        // ④ 启动心跳维持本槽位占用
        String slotKey = globalSlotPrefix + workerId;
        heartbeatScheduler = new RedisWorkerHeartbeatScheduler(this, slotKey, slotValue, heartbeatIntervalSeconds);
        heartbeatScheduler.start();

        return workerId;
    }

    /**
     * 统一关闭资源：停心跳. 多次调用幂等.
     */
    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        if (Objects.nonNull(heartbeatScheduler)) {
            try {
                heartbeatScheduler.shutdown();
            } catch (RuntimeException e) {
                log.warn("Failed to shutdown Redis heartbeat scheduler", e);
            }
        }
        log.info("RedisWorkerIdAssigner closed.");
    }

    /**
     * 执行心跳：原子校验 slotValue 并刷新 TTL.
     *
     * @param slotKey   槽位 key
     * @param slotValue 槽位值（workerName:instanceId），用于校验归属
     * @return true 续期成功，false 槽位已被他人抢占
     */
    public boolean heartbeat(String slotKey, String slotValue) {
        RScript script = redissonClient.getScript(StringCodec.INSTANCE);
        if (Objects.isNull(heartbeatScriptSha)) {
            heartbeatScriptSha = script.scriptLoad(LUA_HEARTBEAT);
        }
        try {
            Long result = script.evalSha(
                    RScript.Mode.READ_WRITE,
                    heartbeatScriptSha,
                    RScript.ReturnType.INTEGER,
                    Collections.singletonList(slotKey),
                    slotValue,
                    String.valueOf(zombieExpireSeconds));
            return result == 1L;
        } catch (Exception e) {
            heartbeatScriptSha = null;
            Long result = script.eval(
                    RScript.Mode.READ_WRITE,
                    LUA_HEARTBEAT,
                    RScript.ReturnType.INTEGER,
                    Collections.singletonList(slotKey),
                    slotValue,
                    String.valueOf(zombieExpireSeconds));
            return result == 1L;
        }
    }

    private Long tryClaimExpiredSlot(
            String globalSlotPrefix, RSet<String> appIdsSet, String slotValue, String workerName) {
        Iterator<String> it = appIdsSet.iterator();
        while (it.hasNext()) {
            String idStr = it.next();
            long id = Long.parseLong(idStr);
            RBucket<String> bucket = redissonClient.getBucket(globalSlotPrefix + id, StringCodec.INSTANCE);
            if (bucket.setIfAbsent(slotValue, Duration.ofSeconds(zombieExpireSeconds))) {
                return id;
            }
            String currentOwner = bucket.get();
            if (Objects.nonNull(currentOwner) && !currentOwner.startsWith(workerName + ":")) {
                appIdsSet.remove(idStr);
            }
        }
        return null;
    }

    private long allocateNewSlot(RAtomicLong globalCounter, String globalSlotPrefix, String slotValue) {
        for (int attempt = 0; attempt < ALLOCATE_RETRY_LIMIT; attempt++) {
            long newId = globalCounter.incrementAndGet() - 1;
            if (newId > maxWorkerId) {
                throw new UidGenerateException("Redis global counter 已超过 maxWorkerId %d, 请检查槽位回收是否正常.", maxWorkerId);
            }
            RBucket<String> bucket = redissonClient.getBucket(globalSlotPrefix + newId, StringCodec.INSTANCE);
            if (bucket.setIfAbsent(slotValue, Duration.ofSeconds(zombieExpireSeconds))) {
                return newId;
            }
            log.warn(
                    "Freshly allocated slot {} was claimed by another node, retrying (attempt {})", newId, attempt + 1);
        }
        throw new IllegalStateException(
                "Failed to allocate new Redis slot after " + ALLOCATE_RETRY_LIMIT + " attempts");
    }
}
