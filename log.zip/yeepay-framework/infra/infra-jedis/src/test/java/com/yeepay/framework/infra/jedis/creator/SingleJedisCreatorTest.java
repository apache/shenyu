package com.yeepay.framework.infra.jedis.creator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import org.junit.jupiter.api.Test;

class SingleJedisCreatorTest {

    @Test
    void constructor_nullSingleConfig_throwsNPE() {
        JedisConfig config = new JedisConfig();
        assertThatThrownBy(() -> new SingleJedisCreator(config, null, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("singleConfig");
    }

    @Test
    void create_singleMode_returnsClient() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        single.setHost("127.0.0.1");
        single.setPort(6379);
        SingleJedisCreator creator = new SingleJedisCreator(config, single, null);
        assertThat(creator.create()).isNotNull();
    }

    @Test
    void create_withCustomizer_customizerCalled() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        boolean[] called = {false};
        SingleJedisCreator creator = new SingleJedisCreator(config, single, jedis -> called[0] = true);
        creator.create();
        assertThat(called[0]).isTrue();
    }
}
