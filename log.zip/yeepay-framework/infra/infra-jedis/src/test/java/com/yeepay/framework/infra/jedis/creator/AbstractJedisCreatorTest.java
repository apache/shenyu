package com.yeepay.framework.infra.jedis.creator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.Connection;
import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.UnifiedJedis;

@ExtendWith(MockitoExtension.class)
class AbstractJedisCreatorTest {

    @Mock
    private UnifiedJedis mockJedis;

    @Mock
    private JedisConfigCustomizer customizer;

    private static class TestCreator extends AbstractJedisCreator {
        private final UnifiedJedis result;

        TestCreator(JedisConfig config, JedisConfigCustomizer customizer, UnifiedJedis result) {
            super(config, customizer);
            this.result = result;
        }

        @Override
        protected UnifiedJedis doCreate() {
            return result;
        }
    }

    // ── constructor ────────────────────────────────────────────────────────

    @Test
    void constructor_nullConfig_throwsNPE() {
        assertThatThrownBy(() -> new TestCreator(null, null, mockJedis)).isInstanceOf(NullPointerException.class);
    }

    // ── create ─────────────────────────────────────────────────────────────

    @Test
    void create_withoutCustomizer_returnsJedis() {
        TestCreator creator = new TestCreator(new JedisConfig(), null, mockJedis);
        assertThat(creator.create()).isSameAs(mockJedis);
        verifyNoInteractions(customizer);
    }

    @Test
    void create_withCustomizer_callsCustomize() {
        TestCreator creator = new TestCreator(new JedisConfig(), customizer, mockJedis);
        creator.create();
        verify(customizer).customize(mockJedis);
    }

    // ── buildClientConfig ──────────────────────────────────────────────────

    @Test
    void buildClientConfig_setsAllFieldsFromConfig() {
        JedisConfig cfg = new JedisConfig();
        cfg.setUsername("user1");
        cfg.setPassword("pass1");
        cfg.setDatabase(3);
        cfg.setTimeout(5000);
        TestCreator creator = new TestCreator(cfg, null, mockJedis);

        DefaultJedisClientConfig cc = creator.buildClientConfig();
        assertThat(cc.getUser()).isEqualTo("user1");
        assertThat(cc.getPassword()).isEqualTo("pass1");
        assertThat(cc.getDatabase()).isEqualTo(3);
        assertThat(cc.getSocketTimeoutMillis()).isEqualTo(5000);
        assertThat(cc.getConnectionTimeoutMillis()).isEqualTo(5000);
    }

    @Test
    void buildClientConfig_defaultValues() {
        TestCreator creator = new TestCreator(new JedisConfig(), null, mockJedis);
        DefaultJedisClientConfig cc = creator.buildClientConfig();
        assertThat(cc.getDatabase()).isEqualTo(0);
        assertThat(cc.getSocketTimeoutMillis()).isEqualTo(2000);
    }

    @Test
    void buildClientConfig_blankUsernameAndPassword_setsNull() {
        JedisConfig cfg = new JedisConfig();
        cfg.setUsername("   ");
        cfg.setPassword("");
        TestCreator creator = new TestCreator(cfg, null, mockJedis);
        DefaultJedisClientConfig cc = creator.buildClientConfig();
        assertThat(cc.getUser()).isNull();
        assertThat(cc.getPassword()).isNull();
    }

    // ── buildPoolConfig ────────────────────────────────────────────────────

    @Test
    void buildPoolConfig_setsAllFieldsFromConfig() {
        JedisConfig cfg = new JedisConfig();
        cfg.getPool().setMaxTotal(20);
        cfg.getPool().setMaxIdle(10);
        cfg.getPool().setMinIdle(2);
        cfg.getPool().setMaxWait(500L);
        TestCreator creator = new TestCreator(cfg, null, mockJedis);

        GenericObjectPoolConfig<Connection> pool = creator.buildPoolConfig();
        assertThat(pool.getMaxTotal()).isEqualTo(20);
        assertThat(pool.getMaxIdle()).isEqualTo(10);
        assertThat(pool.getMinIdle()).isEqualTo(2);
        assertThat(pool.getMaxWaitDuration().toMillis()).isEqualTo(500L);
    }

    @Test
    void buildPoolConfig_defaultValues() {
        TestCreator creator = new TestCreator(new JedisConfig(), null, mockJedis);
        GenericObjectPoolConfig<Connection> pool = creator.buildPoolConfig();
        assertThat(pool.getMaxTotal()).isEqualTo(8);
        assertThat(pool.getMaxIdle()).isEqualTo(8);
        assertThat(pool.getMinIdle()).isEqualTo(0);
        assertThat(pool.getMaxWaitDuration().toMillis()).isEqualTo(2000L);
    }

    // ── parseNodes ─────────────────────────────────────────────────────────

    @Test
    void parseNodes_validList_returnsCorrectSet() {
        List<String> nodes = Arrays.asList("127.0.0.1:6379", "127.0.0.2:6380");
        Set<HostAndPort> result = AbstractJedisCreator.parseNodes(nodes);
        assertThat(result).hasSize(2);
        assertThat(result).anyMatch(h -> h.getHost().equals("127.0.0.1") && h.getPort() == 6379);
        assertThat(result).anyMatch(h -> h.getHost().equals("127.0.0.2") && h.getPort() == 6380);
    }

    @Test
    void parseNodes_withWhitespace_trimsCorrectly() {
        List<String> nodes = Arrays.asList(" 10.0.0.1 : 7000 ");
        Set<HostAndPort> result = AbstractJedisCreator.parseNodes(nodes);
        assertThat(result).hasSize(1);
        HostAndPort hp = result.iterator().next();
        assertThat(hp.getHost()).isEqualTo("10.0.0.1");
        assertThat(hp.getPort()).isEqualTo(7000);
    }

    @Test
    void parseNodes_emptyList_returnsEmptySet() {
        Set<HostAndPort> result = AbstractJedisCreator.parseNodes(List.of());
        assertThat(result).isEmpty();
    }

    // ── getConfig ──────────────────────────────────────────────────────────

    @Test
    void getConfig_returnsSameConfig() {
        JedisConfig cfg = new JedisConfig();
        cfg.setDatabase(5);
        TestCreator creator = new TestCreator(cfg, null, mockJedis);
        assertThat(creator.getConfig().getDatabase()).isEqualTo(5);
    }
}
