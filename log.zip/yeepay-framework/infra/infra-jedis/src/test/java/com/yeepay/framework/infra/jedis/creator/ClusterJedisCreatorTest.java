package com.yeepay.framework.infra.jedis.creator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import org.junit.jupiter.api.Test;

class ClusterJedisCreatorTest {

    @Test
    void constructor_nullClusterConfig_throwsNPE() {
        JedisConfig config = new JedisConfig();
        assertThatThrownBy(() -> new ClusterJedisCreator(config, null, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("clusterConfig");
    }

    @Test
    void constructor_validConfig_succeeds() {
        JedisConfig config = new JedisConfig();
        JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
        cluster.setNodes(java.util.List.of("127.0.0.1:6379", "127.0.0.1:6380"));
        ClusterJedisCreator creator = new ClusterJedisCreator(config, cluster, null);
        assertThat(creator).isNotNull();
    }

    @Test
    void doCreate_throwsOnConnect() {
        JedisConfig config = new JedisConfig();
        config.setTimeout(100);
        JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
        cluster.setNodes(java.util.List.of("127.0.0.1:6399"));
        cluster.setMaxAttempts(1);
        ClusterJedisCreator creator = new ClusterJedisCreator(config, cluster, null);
        assertThatThrownBy(creator::create).isInstanceOf(Exception.class);
    }
}
