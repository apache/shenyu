package com.yeepay.framework.infra.jedis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import redis.clients.jedis.UnifiedJedis;

class JedisClientFactoryTest {

    @Test
    void create_noModeConfigured_throwsIllegalArgument() {
        JedisConfig config = new JedisConfig();
        assertThatThrownBy(() -> JedisClientFactory.create(config))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("single / sentinel / cluster");
    }

    @Test
    void create_noModeWithCustomizer_throwsIllegalArgument() {
        JedisConfig config = new JedisConfig();
        assertThatThrownBy(() -> JedisClientFactory.create(config, jedis -> {}))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void create_singleMode_returnsNonNullClient() {
        JedisConfig config = new JedisConfig();
        config.setTimeout(100);
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        single.setHost("127.0.0.1");
        single.setPort(6379);
        config.setSingle(single);

        // JedisPooled is lazily connected — construction succeeds even without a real Redis.
        UnifiedJedis client = JedisClientFactory.create(config);
        assertThat(client).isNotNull();
        client.close();
    }

    @Test
    void create_singleMode_withCustomizer_callsCustomizer() {
        JedisConfig config = new JedisConfig();
        config.setTimeout(100);
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        config.setSingle(single);

        boolean[] customized = {false};
        UnifiedJedis client = JedisClientFactory.create(config, jedis -> customized[0] = true);
        assertThat(customized[0]).isTrue();
        client.close();
    }

    @Test
    void create_sentinelMode_throwsOnNoSentinelAvailable() {
        JedisConfig config = new JedisConfig();
        config.setTimeout(200);
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.setNodes(Collections.singletonList("127.0.0.1:26399"));
        config.setSentinel(sentinel);

        // JedisSentineled connects to sentinels eagerly — expect a connection failure.
        assertThatThrownBy(() -> JedisClientFactory.create(config)).isInstanceOf(Exception.class);
    }

    @Test
    void create_clusterMode_throwsOnNoClusterAvailable() {
        JedisConfig config = new JedisConfig();
        config.setTimeout(200);
        JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
        cluster.getNodes().add("127.0.0.1:7399");
        config.setCluster(cluster);

        // JedisCluster connects to cluster nodes eagerly — expect a connection failure.
        assertThatThrownBy(() -> JedisClientFactory.create(config)).isInstanceOf(Exception.class);
    }

    // ==================== loadConfig tests ====================

    @Test
    void loadConfig_singleMode_parsesAllProperties() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-single.properties");

        assertThat(config.getPassword()).isEqualTo("testpass");
        assertThat(config.getUsername()).isEqualTo("testuser");
        assertThat(config.getDatabase()).isEqualTo(2);
        assertThat(config.getTimeout()).isEqualTo(3000);

        JedisConfig.PoolConfig pool = config.getPool();
        assertThat(pool.getMaxTotal()).isEqualTo(16);
        assertThat(pool.getMaxIdle()).isEqualTo(8);
        assertThat(pool.getMinIdle()).isEqualTo(2);
        assertThat(pool.getMaxWait()).isEqualTo(3000L);
        assertThat(pool.isTestOnBorrow()).isTrue();
        assertThat(pool.isTestOnReturn()).isTrue();
        assertThat(pool.isTestWhileIdle()).isTrue();
        assertThat(pool.getNumTestsPerEvictionRun()).isEqualTo(5);
        assertThat(pool.getTimeBetweenEvictionRunsMillis()).isEqualTo(60000L);
        assertThat(pool.getSoftMinEvictableIdleTimeMillis()).isEqualTo(30000L);
        assertThat(pool.getMinEvictableIdleTimeMillis()).isEqualTo(120000L);
        assertThat(pool.isBlockWhenExhausted()).isTrue();

        assertThat(config.getSingle()).isNotNull();
        assertThat(config.getSingle().getHost()).isEqualTo("10.0.0.1");
        assertThat(config.getSingle().getPort()).isEqualTo(6380);
        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_sentinelMode_parsesAllProperties() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-sentinel.properties");

        assertThat(config.getPassword()).isEqualTo("sentinelpass");
        assertThat(config.getDatabase()).isEqualTo(1);

        assertThat(config.getSentinel()).isNotNull();
        assertThat(config.getSentinel().getMasterName()).isEqualTo("mymaster");
        assertThat(config.getSentinel().getNodes())
                .containsExactly("10.0.0.1:26379", "10.0.0.2:26379", "10.0.0.3:26379");
        assertThat(config.getSentinel().getSentinelPassword()).isEqualTo("sentpass");
        assertThat(config.getSingle()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_clusterMode_parsesAllProperties() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-cluster.properties");

        assertThat(config.getPassword()).isEqualTo("clusterpass");

        assertThat(config.getCluster()).isNotNull();
        assertThat(config.getCluster().getNodes()).containsExactly("10.0.0.1:7000", "10.0.0.2:7001", "10.0.0.3:7002");
        assertThat(config.getCluster().getMaxAttempts()).isEqualTo(3);
        assertThat(config.getSingle()).isNull();
        assertThat(config.getSentinel()).isNull();
    }

    @Test
    void loadConfig_legacySentinelMode_parsesCorrectly() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-legacy-sentinel.properties");

        assertThat(config.getPassword()).isEqualTo("legacypass");
        assertThat(config.getDatabase()).isEqualTo(1);

        JedisConfig.PoolConfig pool = config.getPool();
        assertThat(pool.getMaxTotal()).isEqualTo(20);
        assertThat(pool.getMaxIdle()).isEqualTo(10);
        assertThat(pool.getMinIdle()).isEqualTo(2);
        assertThat(pool.getMaxWait()).isEqualTo(5000L);
        assertThat(pool.isTestOnBorrow()).isTrue();
        assertThat(pool.isTestWhileIdle()).isTrue();
        assertThat(pool.getTimeBetweenEvictionRunsMillis()).isEqualTo(30000L);
        assertThat(pool.getMinEvictableIdleTimeMillis()).isEqualTo(60000L);
        assertThat(pool.isBlockWhenExhausted()).isTrue();

        assertThat(config.getSentinel()).isNotNull();
        assertThat(config.getSentinel().getMasterName()).isEqualTo("mymaster");
        assertThat(config.getSentinel().getNodes())
                .containsExactly("10.0.0.1:26379", "10.0.0.2:26379", "10.0.0.3:26379");
        assertThat(config.getSingle()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_legacyClusterMode_parsesCorrectly() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-legacy-cluster.properties");

        assertThat(config.getPassword()).isEqualTo("legacypass");
        assertThat(config.getPool().getMaxTotal()).isEqualTo(16);

        assertThat(config.getCluster()).isNotNull();
        assertThat(config.getCluster().getNodes()).containsExactly("10.0.0.1:7000", "10.0.0.2:7001", "10.0.0.3:7002");
        assertThat(config.getSingle()).isNull();
        assertThat(config.getSentinel()).isNull();
    }

    @Test
    void loadConfig_legacyAutoDetectSingle_parsesCorrectly() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-legacy-auto-single.properties");

        assertThat(config.getPassword()).isEqualTo("legacypass");
        assertThat(config.getDatabase()).isEqualTo(0);
        assertThat(config.getPool().getMaxTotal()).isEqualTo(8);

        assertThat(config.getSingle()).isNotNull();
        assertThat(config.getSingle().getHost()).isEqualTo("10.0.0.1");
        assertThat(config.getSingle().getPort()).isEqualTo(6379);
        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_legacyAutoDetectSentinel_parsesCorrectly() {
        JedisConfig config = JedisClientFactory.loadConfig("testcfg", "jedis-legacy-auto-sentinel.properties");

        assertThat(config.getPassword()).isEqualTo("legacypass");
        assertThat(config.getDatabase()).isEqualTo(1);

        assertThat(config.getSentinel()).isNotNull();
        assertThat(config.getSentinel().getMasterName()).isEqualTo("mymaster");
        assertThat(config.getSentinel().getNodes()).containsExactly("10.0.0.1:26379", "10.0.0.2:26379");
        assertThat(config.getSingle()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_fileNotFound_throwsIllegalArgument() {
        assertThatThrownBy(() -> JedisClientFactory.loadConfig("testcfg", "nonexistent.properties"))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
