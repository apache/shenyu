package com.yeepay.framework.infra.jedis.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class JedisConfigTest {

    @Test
    void defaults_topLevel() {
        JedisConfig config = new JedisConfig();
        assertThat(config.getUsername()).isNull();
        assertThat(config.getPassword()).isNull();
        assertThat(config.getDatabase()).isZero();
        assertThat(config.getTimeout()).isEqualTo(2000);
        assertThat(config.getPool()).isNotNull();
        assertThat(config.getSingle()).isNull();
        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void defaults_poolConfig() {
        JedisConfig.PoolConfig pool = new JedisConfig.PoolConfig();
        assertThat(pool.getMaxTotal()).isEqualTo(8);
        assertThat(pool.getMaxIdle()).isEqualTo(8);
        assertThat(pool.getMinIdle()).isZero();
        assertThat(pool.getMaxWait()).isEqualTo(2000L);
        assertThat(pool.isTestOnBorrow()).isFalse();
        assertThat(pool.isTestOnReturn()).isFalse();
        assertThat(pool.isTestWhileIdle()).isFalse();
        assertThat(pool.getNumTestsPerEvictionRun()).isEqualTo(3);
        assertThat(pool.getTimeBetweenEvictionRunsMillis()).isEqualTo(-1L);
        assertThat(pool.getSoftMinEvictableIdleTimeMillis()).isEqualTo(-1L);
        assertThat(pool.getMinEvictableIdleTimeMillis()).isEqualTo(1800000L);
        assertThat(pool.isBlockWhenExhausted()).isTrue();
    }

    @Test
    void defaults_singleConfig() {
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        assertThat(single.getHost()).isEqualTo("localhost");
        assertThat(single.getPort()).isEqualTo(6379);
    }

    @Test
    void defaults_sentinelConfig() {
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        assertThat(sentinel.getMasterName()).isNull();
        assertThat(sentinel.getNodes()).isEmpty();
        assertThat(sentinel.getSentinelPassword()).isNull();
    }

    @Test
    void defaults_clusterConfig() {
        JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
        assertThat(cluster.getNodes()).isEmpty();
        assertThat(cluster.getMaxAttempts()).isEqualTo(5);
    }

    @Test
    void setters_topLevel() {
        JedisConfig config = new JedisConfig();
        config.setUsername("user");
        config.setPassword("pass");
        config.setDatabase(3);
        config.setTimeout(5000);
        assertThat(config.getUsername()).isEqualTo("user");
        assertThat(config.getPassword()).isEqualTo("pass");
        assertThat(config.getDatabase()).isEqualTo(3);
        assertThat(config.getTimeout()).isEqualTo(5000);
    }

    @Test
    void setters_poolConfig() {
        JedisConfig.PoolConfig pool = new JedisConfig.PoolConfig();
        pool.setMaxTotal(16);
        pool.setMaxIdle(16);
        pool.setMinIdle(4);
        pool.setMaxWait(5000L);
        pool.setTestOnBorrow(true);
        pool.setTestOnReturn(true);
        pool.setTestWhileIdle(true);
        pool.setNumTestsPerEvictionRun(5);
        pool.setTimeBetweenEvictionRunsMillis(30000L);
        pool.setSoftMinEvictableIdleTimeMillis(60000L);
        pool.setMinEvictableIdleTimeMillis(120000L);
        pool.setBlockWhenExhausted(false);
        assertThat(pool.getMaxTotal()).isEqualTo(16);
        assertThat(pool.getMaxIdle()).isEqualTo(16);
        assertThat(pool.getMinIdle()).isEqualTo(4);
        assertThat(pool.getMaxWait()).isEqualTo(5000L);
        assertThat(pool.isTestOnBorrow()).isTrue();
        assertThat(pool.isTestOnReturn()).isTrue();
        assertThat(pool.isTestWhileIdle()).isTrue();
        assertThat(pool.getNumTestsPerEvictionRun()).isEqualTo(5);
        assertThat(pool.getTimeBetweenEvictionRunsMillis()).isEqualTo(30000L);
        assertThat(pool.getSoftMinEvictableIdleTimeMillis()).isEqualTo(60000L);
        assertThat(pool.getMinEvictableIdleTimeMillis()).isEqualTo(120000L);
        assertThat(pool.isBlockWhenExhausted()).isFalse();
    }

    @Test
    void setters_singleConfig() {
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        single.setHost("10.0.0.1");
        single.setPort(6380);
        assertThat(single.getHost()).isEqualTo("10.0.0.1");
        assertThat(single.getPort()).isEqualTo(6380);
    }

    @Test
    void setters_sentinelConfig() {
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.setNodes(java.util.List.of("host1:26379", "host2:26379"));
        sentinel.setSentinelPassword("spass");
        assertThat(sentinel.getMasterName()).isEqualTo("mymaster");
        assertThat(sentinel.getNodes()).hasSize(2);
        assertThat(sentinel.getSentinelPassword()).isEqualTo("spass");
    }

    @Test
    void setters_clusterConfig() {
        JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
        cluster.setNodes(java.util.List.of("host1:6379", "host2:6379"));
        cluster.setMaxAttempts(10);
        assertThat(cluster.getNodes()).hasSize(2);
        assertThat(cluster.getMaxAttempts()).isEqualTo(10);
    }

    @Test
    void modeConfigs_mutuallyExclusive() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        config.setSingle(single);
        assertThat(config.getSingle()).isSameAs(single);
        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }
}
