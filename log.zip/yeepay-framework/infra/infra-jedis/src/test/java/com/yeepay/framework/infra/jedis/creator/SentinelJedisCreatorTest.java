package com.yeepay.framework.infra.jedis.creator;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import org.junit.jupiter.api.Test;

class SentinelJedisCreatorTest {

    @Test
    void constructor_nullSentinelConfig_throwsNPE() {
        JedisConfig config = new JedisConfig();
        assertThatThrownBy(() -> new SentinelJedisCreator(config, null, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("sentinelConfig");
    }

    @Test
    void constructor_nullMasterName_throwsNPE() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        assertThatThrownBy(() -> new SentinelJedisCreator(config, sentinel, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("masterName");
    }

    @Test
    void constructor_validConfig_succeeds() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.setNodes(java.util.List.of("127.0.0.1:26379"));
        SentinelJedisCreator creator = new SentinelJedisCreator(config, sentinel, null);
        org.assertj.core.api.Assertions.assertThat(creator).isNotNull();
    }

    @Test
    void doCreate_withSentinelPassword_throwsOnConnect() {
        JedisConfig config = new JedisConfig();
        config.setPassword("mainpass");
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.setNodes(java.util.List.of("127.0.0.1:26379"));
        sentinel.setSentinelPassword("sentinelpass");
        SentinelJedisCreator creator = new SentinelJedisCreator(config, sentinel, null);
        assertThatThrownBy(creator::create).isInstanceOf(Exception.class);
    }

    @Test
    void doCreate_withBlankSentinelPassword_throwsOnConnect() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.setNodes(java.util.List.of("127.0.0.1:26379"));
        sentinel.setSentinelPassword("   ");
        SentinelJedisCreator creator = new SentinelJedisCreator(config, sentinel, null);
        assertThatThrownBy(creator::create).isInstanceOf(Exception.class);
    }

    @Test
    void doCreate_withNullSentinelPassword_throwsOnConnect() {
        JedisConfig config = new JedisConfig();
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.setNodes(java.util.List.of("127.0.0.1:26379"));
        SentinelJedisCreator creator = new SentinelJedisCreator(config, sentinel, null);
        assertThatThrownBy(creator::create).isInstanceOf(Exception.class);
    }
}
