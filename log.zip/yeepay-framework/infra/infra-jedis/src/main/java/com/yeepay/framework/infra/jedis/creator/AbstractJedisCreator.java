package com.yeepay.framework.infra.jedis.creator;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.UnifiedJedis;

/**
 * Jedis 客户端创建器抽象基类（模板方法模式）.
 *
 * <p>提供公共配置构建逻辑（连接池、客户端配置），子类只需实现 {@link #doCreate()}。
 */
@Slf4j
public abstract class AbstractJedisCreator {

    private final JedisConfig config;

    private final JedisConfigCustomizer customizer;

    /**
     * 构造创建器.
     *
     * @param config     Jedis 配置
     * @param customizer 可选的客户端定制器
     */
    protected AbstractJedisCreator(final JedisConfig config, final JedisConfigCustomizer customizer) {
        Objects.requireNonNull(config, "jedisConfig must not be null");
        this.config = config;
        this.customizer = customizer;
    }

    /**
     * 创建 {@link UnifiedJedis} 并应用定制器.
     *
     * @return 创建完成的客户端
     */
    public final UnifiedJedis create() {
        UnifiedJedis jedis = doCreate();
        if (Objects.nonNull(customizer)) {
            customizer.customize(jedis);
        }
        return jedis;
    }

    /**
     * 子类实现具体的创建逻辑.
     *
     * @return 创建完成的客户端
     */
    protected abstract UnifiedJedis doCreate();

    /**
     * 构建主节点客户端配置（连接超时、认证、数据库索引）.
     *
     * @return Jedis 客户端配置
     */
    protected DefaultJedisClientConfig buildClientConfig() {
        String user = config.getUsername();
        String password = config.getPassword();
        return DefaultJedisClientConfig.builder()
                .user(hasText(user) ? user : null)
                .password(hasText(password) ? password : null)
                .database(config.getDatabase())
                .socketTimeoutMillis(config.getTimeout())
                .connectionTimeoutMillis(config.getTimeout())
                .build();
    }

    private static boolean hasText(String s) {
        return Objects.nonNull(s) && !s.trim().isEmpty();
    }

    /**
     * 构建连接池配置，类型参数由调用方指定.
     *
     * @param <T> 连接类型
     * @return 连接池配置
     */
    protected <T> GenericObjectPoolConfig<T> buildPoolConfig() {
        GenericObjectPoolConfig<T> poolConfig = new GenericObjectPoolConfig<>();
        JedisConfig.PoolConfig pc = config.getPool();
        poolConfig.setMaxTotal(pc.getMaxTotal());
        poolConfig.setMaxIdle(pc.getMaxIdle());
        poolConfig.setMinIdle(pc.getMinIdle());
        poolConfig.setMaxWait(Duration.ofMillis(pc.getMaxWait()));
        poolConfig.setTestOnBorrow(pc.isTestOnBorrow());
        poolConfig.setTestOnReturn(pc.isTestOnReturn());
        poolConfig.setTestWhileIdle(pc.isTestWhileIdle());
        poolConfig.setNumTestsPerEvictionRun(pc.getNumTestsPerEvictionRun());
        poolConfig.setTimeBetweenEvictionRuns(Duration.ofMillis(pc.getTimeBetweenEvictionRunsMillis()));
        poolConfig.setSoftMinEvictableIdleDuration(Duration.ofMillis(pc.getSoftMinEvictableIdleTimeMillis()));
        poolConfig.setMinEvictableIdleDuration(Duration.ofMillis(pc.getMinEvictableIdleTimeMillis()));
        poolConfig.setBlockWhenExhausted(pc.isBlockWhenExhausted());
        return poolConfig;
    }

    /**
     * 将 "host:port" 字符串列表解析为 {@link HostAndPort} 集合.
     *
     * @param nodes 节点字符串列表
     * @return {@link HostAndPort} 集合
     */
    protected static Set<HostAndPort> parseNodes(final List<String> nodes) {
        Set<HostAndPort> result = new HashSet<>();
        for (String node : nodes) {
            String[] parts = node.split(":");
            result.add(new HostAndPort(parts[0].trim(), Integer.parseInt(parts[1].trim())));
        }
        return result;
    }

    /**
     * 获取 Jedis 配置.
     *
     * @return Jedis 配置
     */
    protected JedisConfig getConfig() {
        return config;
    }
}
