package com.yeepay.framework.infra.jedis.creator;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisPooled;
import redis.clients.jedis.UnifiedJedis;

/**
 * 单机模式 Jedis 客户端创建器.
 *
 * <p>创建 {@link JedisPooled}（{@link UnifiedJedis} 子类，内置连接池）。
 */
@Slf4j
public class SingleJedisCreator extends AbstractJedisCreator {

    private final JedisConfig.SingleConfig singleConfig;

    public SingleJedisCreator(
            final JedisConfig config,
            final JedisConfig.SingleConfig singleConfig,
            final JedisConfigCustomizer customizer) {
        super(config, customizer);
        Objects.requireNonNull(singleConfig, "singleConfig must not be null");
        this.singleConfig = singleConfig;
    }

    @Override
    protected UnifiedJedis doCreate() {
        HostAndPort hostAndPort = new HostAndPort(singleConfig.getHost(), singleConfig.getPort());
        UnifiedJedis jedis = new JedisPooled(hostAndPort, buildClientConfig(), this.buildPoolConfig());
        log.info("Jedis single pool created: {}:{}", singleConfig.getHost(), singleConfig.getPort());
        return jedis;
    }
}
