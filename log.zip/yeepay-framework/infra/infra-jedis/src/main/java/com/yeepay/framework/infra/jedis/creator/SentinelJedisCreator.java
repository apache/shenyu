package com.yeepay.framework.infra.jedis.creator;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisSentineled;
import redis.clients.jedis.UnifiedJedis;

/**
 * 哨兵模式 Jedis 客户端创建器.
 *
 * <p>创建 {@link JedisSentineled}（{@link UnifiedJedis} 子类，自动跟随主节点切换）。
 * 主节点密码与哨兵节点密码分开配置。
 */
@Slf4j
public class SentinelJedisCreator extends AbstractJedisCreator {

    private final JedisConfig.SentinelConfig sentinelConfig;

    public SentinelJedisCreator(
            final JedisConfig config,
            final JedisConfig.SentinelConfig sentinelConfig,
            final JedisConfigCustomizer customizer) {
        super(config, customizer);
        Objects.requireNonNull(sentinelConfig, "sentinelConfig must not be null");
        Objects.requireNonNull(sentinelConfig.getMasterName(), "sentinel masterName must not be null");
        this.sentinelConfig = sentinelConfig;
    }

    @Override
    protected UnifiedJedis doCreate() {
        Set<HostAndPort> sentinels = parseNodes(sentinelConfig.getNodes());
        DefaultJedisClientConfig masterClientConfig = buildClientConfig();
        String sentinelPassword = sentinelConfig.getSentinelPassword();
        DefaultJedisClientConfig sentinelClientConfig = DefaultJedisClientConfig.builder()
                .password(
                        Objects.nonNull(sentinelPassword)
                                        && !sentinelPassword.trim().isEmpty()
                                ? sentinelPassword
                                : null)
                .socketTimeoutMillis(getConfig().getTimeout())
                .connectionTimeoutMillis(getConfig().getTimeout())
                .build();

        UnifiedJedis jedis = new JedisSentineled(
                sentinelConfig.getMasterName(),
                masterClientConfig,
                this.buildPoolConfig(),
                sentinels,
                sentinelClientConfig);

        log.info(
                "Jedis sentinel pool created, master={}, sentinels={}",
                sentinelConfig.getMasterName(),
                sentinelConfig.getNodes());
        return jedis;
    }
}
