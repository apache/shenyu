package com.yeepay.framework.infra.jedis.creator;

import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.UnifiedJedis;

/**
 * 集群模式 Jedis 客户端创建器.
 *
 * <p>创建 {@link JedisCluster}（{@link UnifiedJedis} 子类，自动路由到对应槽节点）。
 */
@Slf4j
public class ClusterJedisCreator extends AbstractJedisCreator {

    private final JedisConfig.ClusterConfig clusterConfig;

    public ClusterJedisCreator(
            final JedisConfig config,
            final JedisConfig.ClusterConfig clusterConfig,
            final JedisConfigCustomizer customizer) {
        super(config, customizer);
        Objects.requireNonNull(clusterConfig, "clusterConfig must not be null");
        this.clusterConfig = clusterConfig;
    }

    @Override
    protected UnifiedJedis doCreate() {
        Set<HostAndPort> nodes = parseNodes(clusterConfig.getNodes());
        UnifiedJedis jedis =
                new JedisCluster(nodes, buildClientConfig(), clusterConfig.getMaxAttempts(), this.buildPoolConfig());
        log.info("Jedis cluster client created, nodes={}", clusterConfig.getNodes());
        return jedis;
    }
}
