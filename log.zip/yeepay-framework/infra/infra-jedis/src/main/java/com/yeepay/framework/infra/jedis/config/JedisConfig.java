package com.yeepay.framework.infra.jedis.config;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

/**
 * Jedis 客户端配置.
 *
 * <p>三种模式互斥，仅需配置其中一个：
 * <ul>
 *   <li>{@link SingleConfig single}  — 单机模式</li>
 *   <li>{@link SentinelConfig sentinel} — 哨兵模式</li>
 *   <li>{@link ClusterConfig cluster}  — 集群模式</li>
 * </ul>
 *
 * <p>示例（application.yml，单机模式）：
 * <pre>
 * yeepay:
 *   framework:
 *    infra:
 *     jedis:
 *       password: secret
 *       timeout: 2000
 *       pool:
 *         max-total: 16
 *       single:
 *         host: 127.0.0.1
 *         port: 6379
 * </pre>
 */
@Data
public class JedisConfig {

    private Model model = new Model();

    /** Redis 认证用户名（ACL，可选）. */
    private String username;

    /** Redis 认证密码. */
    private String password;

    /** 使用的 Redis 数据库索引，默认 0. */
    private int database;

    /** 连接 / Socket 超时（毫秒），默认 2000. */
    private int timeout = 2000;

    /** 连接池通用配置. */
    private PoolConfig pool = new PoolConfig();

    /** 单机模式配置（与 sentinel / cluster 互斥）. */
    private SingleConfig single;

    /** 哨兵模式配置（与 single / cluster 互斥）. */
    private SentinelConfig sentinel;

    /** 集群模式配置（与 single / sentinel 互斥）. */
    private ClusterConfig cluster;

    /**
     * 连接池通用配置.
     */
    @Data
    public static class PoolConfig {

        /** 最大连接数，默认 8. */
        private int maxTotal = 8;

        /** 最大空闲连接数，默认 8. */
        private int maxIdle = 8;

        /** 最小空闲连接数，默认 0. */
        private int minIdle;

        /** 获取连接最长等待时间（毫秒），默认 2000. */
        private long maxWait = 2000L;

        /** 借出前是否测试连接可用性. */
        private boolean testOnBorrow;

        /** 归还时是否测试连接可用性. */
        private boolean testOnReturn;

        /** 空闲时是否测试连接可用性. */
        private boolean testWhileIdle;

        /** 每次驱逐检查的对象数，默认 3. */
        private int numTestsPerEvictionRun = 3;

        /** 驱逐线程运行间隔（毫秒），-1 表示不启用，默认 -1. */
        private long timeBetweenEvictionRunsMillis = -1L;

        /** 对象在池中保持空闲而不被驱逐的最短时间（毫秒），默认 -1. */
        private long softMinEvictableIdleTimeMillis = -1L;

        /** 对象在池中的最小空闲时间（毫秒），超过后可被驱逐，默认 1800000（30 分钟）. */
        private long minEvictableIdleTimeMillis = 1800000L;

        /** 池耗尽时是否阻塞等待，默认 true. */
        private boolean blockWhenExhausted = true;
    }

    /**
     * 单机模式连接配置.
     */
    @Data
    public static class SingleConfig {

        /** Redis 主机地址，默认 localhost. */
        private String host = "localhost";

        /** Redis 端口，默认 6379. */
        private int port = 6379;
    }

    /**
     * 哨兵模式连接配置.
     */
    @Data
    public static class SentinelConfig {

        /** Sentinel 监控的主节点名称. */
        private String masterName;

        /** Sentinel 节点列表，格式 "host:port". */
        private List<String> nodes = new ArrayList<>();

        /** Sentinel 节点密码（与主节点密码分开）. */
        private String sentinelPassword;
    }

    /**
     * Jedis configuration model.
     */
    @Data
    public static class Model {

        /**
         * 配置文件类型，默认为 yaml，不为这个，那么就从路径下的文件加载.
         */
        private String type = "yaml";

        private String path;

        private String fileName;
    }

    /**
     * 集群模式连接配置.
     */
    @Data
    public static class ClusterConfig {

        /** 集群节点列表，格式 "host:port". */
        private List<String> nodes = new ArrayList<>();

        /** 命令最大重试次数，默认 5. */
        private int maxAttempts = 5;
    }
}
