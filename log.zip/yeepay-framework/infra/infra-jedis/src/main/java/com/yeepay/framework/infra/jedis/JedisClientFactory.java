package com.yeepay.framework.infra.jedis;

import static com.yeepay.framework.common.utils.PropertiesLoader.hasKey;
import static com.yeepay.framework.common.utils.PropertiesLoader.ifPresent;
import static com.yeepay.framework.common.utils.PropertiesLoader.ifPresentAny;
import static com.yeepay.framework.common.utils.PropertiesLoader.splitAndTrim;

import com.yeepay.framework.common.utils.PropertiesLoader;
import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import com.yeepay.framework.infra.jedis.creator.ClusterJedisCreator;
import com.yeepay.framework.infra.jedis.creator.SentinelJedisCreator;
import com.yeepay.framework.infra.jedis.creator.SingleJedisCreator;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import redis.clients.jedis.UnifiedJedis;

/**
 * Jedis 客户端工厂.
 *
 * <p>根据 {@link JedisConfig} 中配置的模式（single / sentinel / cluster）
 * 自动选择对应的创建器，统一返回 {@link UnifiedJedis}。
 *
 * <p>使用示例：
 * <pre>
 * UnifiedJedis client = JedisClientFactory.create(config);
 * // or with customizer
 * UnifiedJedis client = JedisClientFactory.create(config, jedis -&gt; preWarm(jedis));
 * </pre>
 */
public final class JedisClientFactory {

    private JedisClientFactory() {}

    /**
     * 根据配置自动选择模式创建客户端.
     *
     * @param config Jedis 配置
     * @return 创建完成的客户端
     */
    public static UnifiedJedis create(final JedisConfig config) {
        return create(config, null);
    }

    /**
     * 根据配置自动选择模式创建客户端，并应用定制器.
     *
     * @param config     Jedis 配置
     * @param customizer 可选的客户端定制器
     * @return 创建完成的客户端
     */
    public static UnifiedJedis create(final JedisConfig config, final JedisConfigCustomizer customizer) {
        if (Objects.nonNull(config.getSingle())) {
            return new SingleJedisCreator(config, config.getSingle(), customizer).create();
        } else if (Objects.nonNull(config.getSentinel())) {
            return new SentinelJedisCreator(config, config.getSentinel(), customizer).create();
        } else if (Objects.nonNull(config.getCluster())) {
            return new ClusterJedisCreator(config, config.getCluster(), customizer).create();
        } else {
            throw new IllegalArgumentException("JedisConfig 未配置任何模式，请配置 single / sentinel / cluster 之一");
        }
    }

    /**
     * 从 classpath 配置文件创建客户端.
     *
     * <p>配置文件格式（properties）：
     * <pre>
     * # 公共配置
     * password=secret
     * timeout=2000
     * database=0
     *
     * # 连接池
     * pool.maxTotal=8
     * pool.maxIdle=8
     * pool.minIdle=0
     * pool.maxWait=2000
     *
     * # 单机模式（三种模式配其一）
     * single.host=127.0.0.1
     * single.port=6379
     *
     * # 哨兵模式
     * #sentinel.masterName=mymaster
     * #sentinel.nodes=host1:port1,host2:port2
     * #sentinel.sentinelPassword=
     *
     * # 集群模式
     * #cluster.nodes=host1:port1,host2:port2
     * #cluster.maxAttempts=5
     * </pre>
     *
     * @param path     classpath 下的目录路径，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @return 创建完成的客户端
     */
    public static UnifiedJedis createFromClasspath(final String path, final String filename) {
        return createFromClasspath(path, filename, null);
    }

    /**
     * 使用默认路径和文件名从 classpath 创建 Jedis 客户端.
     *
     * @return 创建完成的客户端
     */
    public static UnifiedJedis createFromClasspath() {
        return createFromClasspath("runtimecfg", "yeepay-redis.properties", null);
    }

    /**
     * 使用默认路径和文件名从 classpath 创建 Jedis 客户端，并应用定制器.
     *
     * @param customizer 可选的客户端定制器
     * @return 创建完成的客户端
     */
    public static UnifiedJedis createFromClasspath(final JedisConfigCustomizer customizer) {
        return createFromClasspath("runtimecfg", "yeepay-redis.properties", customizer);
    }

    /**
     * 从 classpath 配置文件创建客户端，并应用定制器.
     *
     * @param path       classpath 下的目录路径，{@code null} 或空串时从 classpath 根加载
     * @param filename   属性文件名称
     * @param customizer 可选的客户端定制器
     * @return 创建完成的客户端
     */
    public static UnifiedJedis createFromClasspath(
            final String path, final String filename, final JedisConfigCustomizer customizer) {
        JedisConfig config = loadConfig(path, filename);
        return create(config, customizer);
    }

    /**
     * 从 classpath 配置文件加载 {@link JedisConfig}.
     *
     * @param path     classpath 下的目录路径，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @return 解析后的 Jedis 配置
     */
    public static JedisConfig loadConfig(final String path, final String filename) {
        Properties props = PropertiesLoader.load(path, filename);
        return buildConfig(props);
    }

    private static JedisConfig buildConfig(final Properties props) {
        JedisConfig config = new JedisConfig();

        ifPresent(props, "password", config::setPassword);
        ifPresent(props, "username", config::setUsername);
        ifPresent(props, "database", v -> config.setDatabase(Integer.parseInt(v)));
        ifPresent(props, "timeout", v -> config.setTimeout(Integer.parseInt(v)));

        JedisConfig.PoolConfig pool = config.getPool();
        ifPresentAny(props, v -> pool.setMaxTotal(Integer.parseInt(v)), "pool.maxTotal", "maxTotal");
        ifPresentAny(props, v -> pool.setMaxIdle(Integer.parseInt(v)), "pool.maxIdle", "maxIdle");
        ifPresentAny(props, v -> pool.setMinIdle(Integer.parseInt(v)), "pool.minIdle", "minIdle");
        ifPresentAny(props, v -> pool.setMaxWait(Long.parseLong(v)), "pool.maxWait", "maxWaitMillis");
        ifPresentAny(props, v -> pool.setTestOnBorrow(Boolean.parseBoolean(v)), "pool.testOnBorrow", "testOnBorrow");
        ifPresentAny(props, v -> pool.setTestOnReturn(Boolean.parseBoolean(v)), "pool.testOnReturn", "testOnReturn");
        ifPresentAny(props, v -> pool.setTestWhileIdle(Boolean.parseBoolean(v)), "pool.testWhileIdle", "testWhileIdle");
        ifPresentAny(
                props,
                v -> pool.setNumTestsPerEvictionRun(Integer.parseInt(v)),
                "pool.numTestsPerEvictionRun",
                "numTestsPerEvictionRun");
        ifPresentAny(
                props,
                v -> pool.setTimeBetweenEvictionRunsMillis(Long.parseLong(v)),
                "pool.timeBetweenEvictionRunsMillis",
                "timeBetweenEvictionRunsMillis");
        ifPresentAny(
                props,
                v -> pool.setSoftMinEvictableIdleTimeMillis(Long.parseLong(v)),
                "pool.softMinEvictableIdleTimeMillis",
                "softMinEvictableIdleTimeMillis");
        ifPresentAny(
                props,
                v -> pool.setMinEvictableIdleTimeMillis(Long.parseLong(v)),
                "pool.minEvictableIdleTimeMillis",
                "minEvictableIdleTimeMillis");
        ifPresentAny(
                props,
                v -> pool.setBlockWhenExhausted(Boolean.parseBoolean(v)),
                "pool.blockWhenExhausted",
                "blockWhenExhausted");

        if (hasKey(props, "single.host") || hasKey(props, "single.port")) {
            JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
            ifPresent(props, "single.host", single::setHost);
            ifPresent(props, "single.port", v -> single.setPort(Integer.parseInt(v)));
            config.setSingle(single);
        } else if (hasKey(props, "sentinel.masterName")) {
            JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
            ifPresent(props, "sentinel.masterName", sentinel::setMasterName);
            ifPresent(props, "sentinel.nodes", v -> sentinel.setNodes(splitAndTrim(v)));
            ifPresent(props, "sentinel.sentinelPassword", sentinel::setSentinelPassword);
            config.setSentinel(sentinel);
        } else if (hasKey(props, "cluster.nodes")) {
            JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
            ifPresent(props, "cluster.nodes", v -> cluster.setNodes(splitAndTrim(v)));
            ifPresent(props, "cluster.maxAttempts", v -> cluster.setMaxAttempts(Integer.parseInt(v)));
            config.setCluster(cluster);
        } else {
            autoDetect(props, config);
        }

        return config;
    }

    /**
     * 兼容 RedisClientUtils 老配置格式的自动检测逻辑.
     *
     * <ul>
     *   <li>{@code mode=sentinel} → 哨兵模式</li>
     *   <li>{@code mode=cluster}  → 集群模式</li>
     *   <li>无 mode 或其他值 → 根据 {@code sentinels} 地址数量自动判断：多个为哨兵，单个为单机</li>
     * </ul>
     */
    private static void autoDetect(final Properties props, final JedisConfig config) {
        String mode = props.getProperty("mode", "").trim();

        if ("sentinel".equals(mode)) {
            buildLegacySentinel(props, config);
            return;
        }
        if ("cluster".equals(mode)) {
            buildLegacyCluster(props, config);
            return;
        }
        if (!hasKey(props, "sentinels")) {
            return;
        }
        List<String> nodes = splitAndTrim(props.getProperty("sentinels"));
        if (nodes.size() > 1) {
            buildLegacySentinel(props, config);
        } else {
            buildLegacySingle(nodes.get(0), config);
        }
    }

    private static void buildLegacySentinel(final Properties props, final JedisConfig config) {
        JedisConfig.SentinelConfig sentinel = new JedisConfig.SentinelConfig();
        ifPresent(props, "masterName", sentinel::setMasterName);
        ifPresent(props, "sentinels", v -> sentinel.setNodes(splitAndTrim(v)));
        config.setSentinel(sentinel);
    }

    private static void buildLegacyCluster(final Properties props, final JedisConfig config) {
        JedisConfig.ClusterConfig cluster = new JedisConfig.ClusterConfig();
        ifPresent(props, "sentinels", v -> cluster.setNodes(splitAndTrim(v)));
        config.setCluster(cluster);
    }

    private static void buildLegacySingle(final String hostPort, final JedisConfig config) {
        String[] parts = hostPort.split(":");
        JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
        single.setHost(parts[0].trim());
        if (parts.length > 1) {
            single.setPort(Integer.parseInt(parts[1].trim()));
        }
        config.setSingle(single);
    }
}
