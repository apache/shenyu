package com.yeepay.framework.infra.jedis.config;

import redis.clients.jedis.UnifiedJedis;

/**
 * Jedis 客户端定制器.
 *
 * <p>在 Spring 容器中声明此接口的 Bean，可在 {@link UnifiedJedis} 创建完成后
 * 进行额外操作（如预热连接、注册监控等）。
 */
@FunctionalInterface
public interface JedisConfigCustomizer {

    /**
     * 对已创建的 Jedis 客户端进行定制.
     *
     * @param jedis 已创建的 Jedis 客户端
     */
    void customize(UnifiedJedis jedis);
}
