# Infra Jedis 模块文档

## 概述

`infra-jedis` 模块为下游服务提供 **Jedis（Redis 客户端）的工厂模式封装**，屏蔽底层连接细节，支持三种部署拓扑（单机、哨兵、集群）。模块分为两层：

- **核心层 (`infra/infra-jedis/`)**：纯 Java 库，不依赖 Spring，提供 `JedisClientFactory` 和 `JedisConfig`
- **Starter 层 (`springboot-starter/springboot-starter-infra/springboot-starter-infra-jedis/`)**：Spring Boot 自动配置，通过 `@ConfigurationProperties` 将 YAML/Properties 配置绑定到客户端

---

## 模块结构

```
infra/infra-jedis/
├── pom.xml
├── JedisClientFactory.java           # 客户端工厂
├── JedisConfig.java                  # 配置 POJO
├── JedisConfigCustomizer.java        # 客户端自定义回调（@FunctionalInterface）
└── creator/
    ├── AbstractJedisCreator.java     # 模板方法基类
    ├── SingleJedisCreator.java       # 单机模式
    ├── SentinelJedisCreator.java     # 哨兵模式
    └── ClusterJedisCreator.java      # 集群模式

springboot-starter/springboot-starter-infra/springboot-starter-infra-jedis/
├── pom.xml
├── InfraJedisAutoConfiguration.java  # 自动配置类
└── InfraJedisConfigured.java         # 条件匹配类
```

---

## 一、功能

- **统一 API**：所有模式（单机/哨兵/集群）均返回 `UnifiedJedis` 实例，调用方无需关心底层拓扑
- **三种部署模式**：`single`（单机）、`sentinel`（哨兵）、`cluster`（集群）
- **连接池管理**：内置 Apache Commons Pool2，完整配置最大连接数、空闲连接、驱逐策略等
- **双模式配置加载**：支持 Spring Boot YAML 绑定和独立 Properties 文件加载
- **旧格式兼容**：自动识别旧版配置属性并转换为新格式
- **客户端自定义**：通过 `JedisConfigCustomizer` 回调在客户端创建后注入自定义逻辑

---

## 二、集成方式

### Maven 依赖

```xml
<!-- 核心库 -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>infra-jedis</artifactId>
    <version>${yeepay-framework.version}</version>
</dependency>

<!-- Spring Boot Starter（推荐） -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-infra-jedis</artifactId>
    <version>${yeepay-framework.version}</version>
</dependency>
```

引入 `springboot-starter-infra-jedis` 后，会自动注册 `InfraJedisAutoConfiguration`，根据配置自动创建 `UnifiedJedis` Bean。

### 激活条件

自动配置仅在 classpath 存在 Jedis 且配置前缀 `yeepay.framework.infra.jedis.*` 下有任意属性时激活。换句话说，**如果不配置任何 Jedis 属性，不会创建 Bean**。

---

## 三、配置方式

### 方式一：Spring Boot YAML 配置（推荐）

Jedis 支持三种部署模式。YAML 配置模式下，`model.type` 默认为 `yaml`，所有配置通过 Spring Boot 的 `@ConfigurationProperties` 绑定到 `JedisConfig` 对象。

配置根路径为 `yeepay.framework.infra.jedis`。顶层属性 `username`、`password`、`database`、`timeout` 和 `pool` 在所有模式下通用；具体连接拓扑通过 `single`、`sentinel` 或 `cluster` 三个互斥的子节点指定——**只能启用其中一个**，即配置中只能出现 `single`、`sentinel`、`cluster` 三者之一。

---

#### 全局配置（三种模式通用）

以下属性在所有模式下行为一致，定义在 `yeepay.framework.infra.jedis` 下即可，无需在具体模式内重复。

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `username` | String | null | Redis 用户名（Redis 6.0+ ACL），不配置则不发送 AUTH 用户名 |
| `password` | String | null | Redis 密码，不配置则不进行认证 |
| `database` | int | 0 | 数据库编号，0-15 |
| `timeout` | int | 2000 | Redis 命令执行超时/连接超时（毫秒） |
| `pool.max-total` | int | 8 | 连接池最大连接数，超过此数阻塞等待 |
| `pool.max-idle` | int | 8 | 最大空闲连接数，超过的空闲连接会被回收 |
| `pool.min-idle` | int | 0 | 最小空闲连接数，连接池会保持此数量的就绪连接 |
| `pool.max-wait` | long | -1 | 获取连接最大等待时间（毫秒），-1 表示无限等待 |
| `pool.test-on-borrow` | boolean | false | 从池中借出连接时是否做 PING 验证，开启增加延迟 |
| `pool.test-on-return` | boolean | false | 归还连接时是否做 PING 验证 |
| `pool.test-while-idle` | boolean | false | 对空闲连接是否做 PING 验证，配合驱逐策略使用 |
| `pool.min-evictable-idle-time` | long | 1800000 | 连接空闲超过此时间（毫秒）才可被驱逐，默认 30 分钟 |
| `pool.time-between-eviction-runs` | long | -1 | 驱逐检查线程运行间隔（毫秒），-1 表示不启用驱逐线程 |
| `pool.num-tests-per-eviction-run` | int | 3 | 每次驱逐检查时最多检查的连接数 |
| `model.type` | String | yaml | 配置加载模式：`yaml`（Spring 绑定）或 `properties`（文件加载） |
| `model.path` | String | runtimecfg | 仅 `type=properties` 时生效，classpath 下的配置文件目录 |
| `model.file-name` | String | yeepay-redis.properties | 仅 `type=properties` 时生效，配置文件名 |

---

#### 模式一：单机模式 `single`

**适用场景**：开发环境、独立 Redis 节点。

单机模式连接到一个固定的 Redis 地址。仅需配置 `host` 和 `port`。

```yaml
yeepay:
  framework:
    infra:
      jedis:
        # === 全局配置 ===
        username: myuser              # 默认 null，不配置则不认证
        password: mypassword          # 默认 null
        database: 0                   # 默认 0
        timeout: 2000                 # 默认 2000ms

        # === 连接池 ===
        pool:
          max-total: 50               # 默认 8，最大连接数
          max-idle: 10                # 默认 8，最大空闲连接
          min-idle: 5                 # 默认 0，最小空闲连接
          max-wait: 3000              # 默认 -1（无限等待），获取连接最大等待（毫秒）
          test-on-borrow: true        # 默认 false，借出时 PING 验证
          test-on-return: false       # 默认 false，归还时 PING 验证
          test-while-idle: true       # 默认 false，对空闲连接 PING 验证
          min-evictable-idle-time: 60000     # 默认 1800000（30分钟），可驱逐前最小空闲时间
          time-between-eviction-runs: 30000  # 默认 -1（不启用），驱逐检查间隔
          num-tests-per-eviction-run: 3      # 默认 3，每次驱逐检查的连接数

        # === 单机模式 ===
        single:
          host: 127.0.0.1             # 默认 localhost
          port: 6379                  # 默认 6379
```

**单机模式关键点**：
- `host` 和 `port` 都有默认值（localhost:6379），开发环境可最小化配置
- `test-while-idle` 配合 `time-between-eviction-runs` 和 `min-evictable-idle-time` 使用，生产环境建议开启，避免拿到已被服务端关闭的连接
- `max-total` 和 `max-idle` 默认仅 8，生产环境需根据并发量调大

---

#### 模式二：哨兵模式 `sentinel`

**适用场景**：生产环境 Redis 主从 + Sentinel 架构，需要自动故障转移。

哨兵模式通过 Sentinel 节点自动发现当前主节点。仅需配置 `sentinel`，**不能**配置 `single`。

```yaml
yeepay:
  framework:
    infra:
      jedis:
        # === 全局配置 ===
        password: redispass           # Redis 数据节点的密码
        database: 0                   # 默认 0
        timeout: 2000                 # 默认 2000ms

        # === 连接池 ===
        pool:
          max-total: 100              # 默认 8，哨兵模式建议调大
          max-idle: 20                # 默认 8
          min-idle: 10                # 默认 0，生产环境建议预创建连接
          max-wait: 3000              # 默认 -1
          test-while-idle: true       # 建议开启，避免拿到断连接

        # === 哨兵模式 ===
        sentinel:
          master-name: mymaster       # 必填，Sentinel 监控的主节点名称
          nodes:                      # 必填，哨兵节点地址列表（host:port）
            - 10.0.0.1:26379
            - 10.0.0.2:26379
            - 10.0.0.3:26379
          sentinel-password: sentinelpass  # 默认 null，哨兵密码（可与数据密码不同）
```

**哨兵模式关键点**：
- `master-name` 和 `nodes` 是必填项，缺一不可
- `sentinel-password` 和 `password` 是独立的——前者用于连接哨兵节点，后者用于连接 Redis 数据节点
- `nodes` 格式为 `host:port`（不带协议前缀），与 Redisson 的 `redis://host:port` 不同
- Jedis 哨兵模式不区分主/从连接池，所有操作共用一个连接池
- 建议配置 `min-idle` 预创建连接，避免流量突发时的连接建立延迟

---

#### 模式三：集群模式 `cluster`

**适用场景**：Redis Cluster 部署，数据按槽位分片存储。

集群模式连接 Redis Cluster 的多个节点，客户端自动处理槽位重定向（MOVED/ASK）。仅需配置 `cluster`。

```yaml
yeepay:
  framework:
    infra:
      jedis:
        # === 全局配置 ===
        password: redispass           # 所有集群节点共用此密码
        timeout: 2000                 # 默认 2000ms

        # === 连接池 ===
        pool:
          max-total: 200              # 默认 8，集群模式下每个节点独立维护连接池，需根据节点数调整
          max-idle: 50                # 默认 8
          min-idle: 10                # 默认 0

        # === 集群模式 ===
        cluster:
          nodes:                      # 必填，集群节点地址列表（host:port）
            - 10.0.0.1:6379
            - 10.0.0.2:6379
            - 10.0.0.3:6379
          max-attempts: 5             # 默认 5，命令执行最大重试次数（含重定向）
```

**集群模式关键点**：
- Jedis 的集群模式对**每个节点**独立维护一个连接池，即 `max-total` 是每个节点的上限，而非全局上限
- `max-attempts` 包括首次尝试和 MOVED/ASK 重定向后的重试，设为 5 表示最多尝试 5 个节点
- `nodes` 至少配置一个即可发现整个集群拓扑，但建议配置所有主节点防止单点发现失败
- 集群模式**不支持** `database` 参数（Redis Cluster 仅支持 db 0）
- 与哨兵模式一样，集群模式不区分主/从连接池

---

#### 三种模式对比

| 维度 | 单机 `single` | 哨兵 `sentinel` | 集群 `cluster` |
|------|------|------|------|
| 节点配置 | `host` + `port` | `nodes` + `master-name` | `nodes` |
| 自动故障转移 | 不支持 | Sentinel 自动切换 | 集群内置选举 + 重定向 |
| 读写分离 | 不支持 | 不支持（Jedis 哨兵模式只连主节点） | 不支持（默认只连主节点） |
| 数据分片 | 不支持 | 不支持 | 支持（16384 槽位） |
| 连接池 | 单连接池 | 单连接池 | 每节点独立连接池 |
| database 支持 | 支持 db 0-15 | 支持 db 0-15 | 不支持，仅 db 0 |
| 适用环境 | 开发/测试 | 生产（主从+哨兵） | 生产（大规模/高吞吐） |
| 必填项 | 无（都有默认值） | `master-name`, `nodes` | `nodes` |

---

### 方式二：Properties 文件加载

设置 `yeepay.framework.infra.jedis.model.type = properties`，然后指定文件路径：

```yaml
yeepay:
  framework:
    infra:
      jedis:
        model:
          type: properties
          path: runtimecfg           # classpath 下的目录路径
          file-name: yeepay-redis.properties  # 文件名
```

默认路径为 `runtimecfg/yeepay-redis.properties`。Properties 文件的键名格式为点号分隔的扁平键：

```properties
# 单机模式（新格式）
single.host=10.0.0.1
single.port=6380
password=redispass
username=redisuser
database=1
timeout=3000
pool.maxTotal=100
pool.maxIdle=20
pool.minIdle=10
pool.maxWait=5000

# 哨兵模式（新格式）
sentinel.masterName=mymaster
sentinel.nodes=10.0.0.1:26379,10.0.0.2:26379,10.0.0.3:26379
sentinel.sentinelPassword=sentinelpass
password=redispass

# 集群模式（新格式）
cluster.nodes=10.0.0.1:6379,10.0.0.2:6379,10.0.0.3:6379
cluster.maxAttempts=5
password=redispass

# 旧格式兼容（自动检测模式）
mode=sentinel                    # single / sentinel / cluster
masterName=mymaster
sentinels=10.0.0.1:26379,10.0.0.2:26379,10.0.0.3:26379
pool.maxTotal=50
```

**旧格式自动检测规则**：
- 有 `mode` 键 → 按 `mode` 值选择
- 无 `mode` 键且 `sentinels` 数量 > 1 → 哨兵模式
- 无 `mode` 键且 `sentinels` 数量 = 1 → 单机模式

---

## 四、JedisConfig 完整配置参考

### 顶层属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `username` | String | null | Redis 用户名（Redis 6.0+ ACL） |
| `password` | String | null | Redis 密码 |
| `database` | int | 0 | 数据库索引 |
| `timeout` | int | 2000 | 连接/命令超时（毫秒） |

### PoolConfig - 连接池配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `max-total` | int | 8 | 最大连接数 |
| `max-idle` | int | 8 | 最大空闲连接数 |
| `min-idle` | int | 0 | 最小空闲连接数 |
| `max-wait` | long | -1 | 获取连接最大等待时间（毫秒），-1 无限 |
| `test-on-borrow` | boolean | false | 借出时是否测试 |
| `test-on-return` | boolean | false | 归还时是否测试 |
| `test-while-idle` | boolean | false | 空闲时是否测试 |
| `min-evictable-idle-time` | long | 1800000 | 最小空闲驱逐时间（毫秒） |
| `time-between-eviction-runs` | long | -1 | 驱逐检查间隔（毫秒），-1 不启用 |
| `num-tests-per-eviction-run` | int | 3 | 每次驱逐检查数量 |

### SingleConfig - 单机模式

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `host` | String | localhost | Redis 主机地址 |
| `port` | int | 6379 | Redis 端口 |

### SentinelConfig - 哨兵模式

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `master-name` | String | **必填** | 主节点名称 |
| `nodes` | List\<String\> | **必填** | 哨兵节点列表，格式 `host:port` |
| `sentinel-password` | String | null | 哨兵密码 |

### ClusterConfig - 集群模式

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `nodes` | List\<String\> | **必填** | 集群节点列表，格式 `host:port` |
| `max-attempts` | int | 5 | 命令执行最大重试次数 |

### Model - 配置模式

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `type` | String | yaml | 配置类型：`yaml`（Spring 绑定）或 `properties`（文件加载） |
| `path` | String | runtimecfg | Properties 文件所在 classpath 目录 |
| `file-name` | String | yeepay-redis.properties | Properties 文件名 |

---

## 五、客户端自定义

可以通过注册 `JedisConfigCustomizer` Bean 在客户端创建后注入自定义逻辑：

```java
@Bean
public JedisConfigCustomizer jedisCustomizer() {
    return jedis -> {
        // 自定义配置，如设置客户端名称
        // jedis 是 UnifiedJedis 实例
    };
}
```

`JedisConfigCustomizer` 是一个 `@FunctionalInterface`，签名为 `void customize(UnifiedJedis jedis)`。

---

## 六、直接使用工厂（非 Spring 环境）

```java
// 通过配置对象创建
JedisConfig config = new JedisConfig();
config.setPassword("redispass");
JedisConfig.SingleConfig single = new JedisConfig.SingleConfig();
single.setHost("127.0.0.1");
single.setPort(6379);
config.setSingle(single);

UnifiedJedis jedis = JedisClientFactory.create(config);

// 通过 classpath 文件创建
UnifiedJedis jedis = JedisClientFactory.createFromClasspath(
    "runtimecfg", "yeepay-redis.properties"
);

// 带自定义回调
UnifiedJedis jedis = JedisClientFactory.create(config, jedis -> {
    // 自定义逻辑
});
```

---

## 七、Spring Boot 自动配置详解

### 自动配置注册

项目使用 Spring Boot 3.x 的 `AutoConfiguration.imports` 机制（**非** `spring.factories`）。

注册文件位于 `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`：

```
com.yeepay.framework.springboot.starter.infra.jedis.InfraJedisAutoConfiguration
```

### InfraJedisAutoConfiguration 工作流程

1. **条件检查**：`InfraJedisConfigured` 实现 `Condition` 接口，使用 `Binder` 检查 `yeepay.framework.infra.jedis` 前缀下是否有绑定属性
2. **配置 Bean**：创建 `@ConfigurationProperties` 绑定的 `JedisConfig` Bean
3. **客户端 Bean**：
   - 如果 `Model.type = "yaml"`（默认）：直接使用 Spring 绑定的 `JedisConfig` 调用 `JedisClientFactory.create()`
   - 如果 `Model.type = "properties"`：从 `Model.path` / `Model.fileName` 指定的 classpath 文件加载
   - 注入所有 `JedisConfigCustomizer` Bean（通过 `ObjectProvider`）

### @ConditionalOnMissingBean 覆盖

客户端 Bean 标注了 `@ConditionalOnMissingBean`，允许用户完全覆盖：

```java
@Bean
public UnifiedJedis myJedisClient() {
    // 自定义创建逻辑，会替代自动配置的 Bean
}
```

---

## 八、完整 YAML 配置模板

### 单机模式

```yaml
yeepay:
  framework:
    infra:
      jedis:
        model:
          type: yaml
        username: myuser
        password: mypassword
        database: 0
        timeout: 2000
        pool:
          max-total: 50
          max-idle: 10
          min-idle: 5
          max-wait: 3000
          test-on-borrow: true
          test-on-return: false
          test-while-idle: true
          min-evictable-idle-time: 60000
          time-between-eviction-runs: 30000
          num-tests-per-eviction-run: 3
        single:
          host: 127.0.0.1
          port: 6379
```

### 哨兵模式

```yaml
yeepay:
  framework:
    infra:
      jedis:
        model:
          type: yaml
        password: mypassword
        database: 0
        timeout: 2000
        pool:
          max-total: 100
          max-idle: 20
          min-idle: 10
          max-wait: 3000
        sentinel:
          master-name: mymaster
          nodes:
            - 10.0.0.1:26379
            - 10.0.0.2:26379
            - 10.0.0.3:26379
          sentinel-password: sentinelpass
```

### 集群模式

```yaml
yeepay:
  framework:
    infra:
      jedis:
        model:
          type: yaml
        password: mypassword
        timeout: 2000
        pool:
          max-total: 200
          max-idle: 50
          min-idle: 10
        cluster:
          nodes:
            - 10.0.0.1:6379
            - 10.0.0.2:6379
            - 10.0.0.3:6379
          max-attempts: 5
```

---

## 九、注意事项

1. **配置模式互斥**：单机/哨兵/集群三种模式只能选择其一，同时配置多个模式行为未定义
2. **配置激活条件**：starter 必须配置至少一个属性才会激活，空配置不会创建客户端 Bean
3. **Model.type 默认值**：默认 `yaml` 即 Spring 绑定模式，切换到 `properties` 需同时配置 `path` 和 `file-name`
4. **Properties 文件位置**：`path` 为 classpath 下的目录路径，默认从 `runtimecfg/` 加载
5. **旧格式兼容**：旧版 `mode` + `sentinels` + `masterName` 配置格式仍受支持，会自动检测并转换
6. **客户端自定义**：`JedisConfigCustomizer` 回调在客户端完全创建后、返回前调用，适用于添加监听器或修改配置
7. **集群连接池**：Jedis 集群模式对每个节点独立维护连接池，`max-total` 是每个节点的上限，配置时需考虑节点数量
