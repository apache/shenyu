# Infra ZooKeeper 模块文档

## 概述

`infra-zookeeper` 模块为下游服务提供 **Apache Curator Framework 的工厂模式封装**，简化 ZooKeeper 客户端的创建和配置。模块仅包含核心层（纯 Java 库，不依赖 Spring），**目前没有对应的 Spring Boot Starter**，需手动创建 `CuratorFramework` Bean。

---

## 模块结构

```
infra/infra-zookeeper/
├── pom.xml
├── CuratorClientFactory.java         # 客户端工厂
└── config/
    └── ZkConfig.java                 # 配置 POJO（含 RetryConfig、AuthInfo、RetryPolicyType）
```

---

## 一、功能

- **Curator 封装**：对 Apache Curator Framework 的工厂模式封装，简化客户端创建流程
- **六种重试策略**：指数退避、有界指数退避、N 次重试、单次重试、无限重试、限时重试
- **多认证支持**：支持 digest 快捷认证和自定义多认证方案（最多 32 个认证条目）
- **灵活超时配置**：会话超时、连接超时、关闭等待超时等，统一使用 `java.time.Duration`
- **命名空间隔离**：支持 Curator 命名空间，所有 znode 路径自动添加前缀
- **只读模式**：支持 Curator 的只读模式，在集群失去法定人数时仍可提供读服务
- **默认数据**：支持设置创建 znode 时的默认数据

---

## 二、集成方式

### Maven 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>infra-zookeeper</artifactId>
    <version>${yeepay-framework.version}</version>
</dependency>
```

> **注意**：ZooKeeper 模块目前**没有**对应的 Spring Boot Starter，需要手动创建 `CuratorFramework` Bean。

---

## 三、配置方式

### Properties 文件配置

ZooKeeper 模块通过 classpath 下的 `.properties` 文件加载配置。所有时间值以**毫秒**为单位。

#### 完整 Properties 示例

```properties
# === 连接配置 ===
connectString=10.0.0.1:2181,10.0.0.2:2181,10.0.0.3:2181  # 必填，ZK 集群地址，逗号分隔 host:port
namespace=myapp                                            # 默认 null，Curator 命名空间（所有路径自动加前缀）

# === 超时配置（单位：毫秒）===
sessionTimeoutMs=60000                                     # 默认 60000，会话超时，决定临时节点存活时间
connectionTimeoutMs=15000                                  # 默认 15000，连接建立超时
waitForShutdownTimeoutMs=0                                 # 默认 0，关闭时等待操作完成的最大时间
maxCloseWaitMs=1000                                        # 默认 1000，close() 内部最大等待时间

# === 行为配置 ===
canBeReadOnly=false                                        # 默认 false，集群失联时是否允许只读会话
simulatedSessionExpirationPercent=100                      # 默认 100，模拟会话过期百分比（0-100），用于测试
defaultData=hello-zk                                       # 默认 null，创建 znode 时的默认数据（UTF-8 编码）

# === 认证配置 ===
digestAuth=admin:admin123                                  # 默认 null，快捷 digest 认证，格式 username:password

# 多认证方案（可选，最多 32 个）
auth.0.scheme=digest                                       # 认证方案类型（digest / ip / sasl）
auth.0.auth=user1:pass1                                    # 认证凭据
auth.1.scheme=ip
auth.1.auth=10.0.0.0/8

# === 重试策略 ===
retry.type=EXPONENTIAL_BACKOFF                             # 默认 EXPONENTIAL_BACKOFF，重试策略类型
retry.baseSleepTimeMs=1000                                 # 默认 1000，基础退避时间（毫秒）
retry.maxSleepTimeMs=60000                                 # 默认 60000，最大退避时间（毫秒）
retry.maxElapsedTimeMs=300000                              # 默认 300000，总最大耗时（毫秒）
retry.maxRetries=3                                         # 默认 3，最大重试次数
```

#### 最小配置

`connectString` 是唯一必填项，其余属性都有默认值，最小配置仅需一行：

```properties
connectString=127.0.0.1:2181
```

---

## 四、ZkConfig 完整配置参考

### 顶层属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `connectString` | String | **必填** | ZK 连接字符串，格式 `host1:port1,host2:port2` |
| `namespace` | String | null | Curator 命名空间，所有 znode 路径自动添加此前缀 |
| `sessionTimeout` | Duration | 60s | 会话超时时间，决定临时节点在客户端断开后存活多久 |
| `connectionTimeout` | Duration | 15s | 连接建立超时时间 |
| `waitForShutdownTimeout` | Duration | 0s | 关闭时等待正在进行的操作完成的最大时间 |
| `maxCloseWait` | Duration | 1s | `close()` 方法内部的最大等待时间 |
| `canBeReadOnly` | boolean | false | 集群失去法定人数时是否允许只读会话 |
| `defaultData` | byte[] | null | 创建 znode 时未指定数据时使用的默认数据 |
| `simulatedSessionExpirationPercent` | int | 100 | 模拟会话过期百分比（0-100），仅用于测试 |
| `digestAuth` | String | null | 快捷 digest 认证，格式 `username:password` |
| `authInfos` | List\<AuthInfo\> | [] | 多认证方案列表，支持 scheme 和 auth |

### RetryConfig - 重试策略

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `type` | RetryPolicyType | EXPONENTIAL_BACKOFF | 重试策略类型 |
| `baseSleepTime` | Duration | 1s | 基础退避时间 |
| `maxSleepTime` | Duration | 60s | 最大退避时间（仅 `BOUNDED_EXPONENTIAL_BACKOFF` 使用） |
| `maxElapsedTime` | Duration | 300s | 总最大耗时（仅 `UNTIL_ELAPSED` 使用） |
| `maxRetries` | int | 3 | 最大重试次数（`EXPONENTIAL_BACKOFF`、`BOUNDED_EXPONENTIAL_BACKOFF`、`N_TIMES` 使用） |

### RetryPolicyType 枚举

六种重试策略，对应 Curator 的不同 `RetryPolicy` 实现：

| 枚举值 | Curator 实现类 | 关键参数 | 行为描述 |
|------|------|------|------|
| `EXPONENTIAL_BACKOFF` | `ExponentialBackoffRetry` | `baseSleepTime`, `maxRetries` | 每次重试等待时间指数增长（翻倍），最多重试 maxRetries 次 |
| `BOUNDED_EXPONENTIAL_BACKOFF` | `BoundedExponentialBackoffRetry` | `baseSleepTime`, `maxSleepTime`, `maxRetries` | 指数退避但有上限，等待时间不超过 maxSleepTime |
| `N_TIMES` | `RetryNTimes` | `maxRetries`, `baseSleepTime` | 固定间隔重试 maxRetries 次，每次等待 baseSleepTime |
| `ONE_TIME` | `RetryOneTime` | `baseSleepTime` | 只重试一次，等待 baseSleepTime 后执行 |
| `FOREVER` | `RetryForever` | `baseSleepTime` | 无限重试，每次等待 baseSleepTime |
| `UNTIL_ELAPSED` | `RetryUntilElapsed` | `maxElapsedTime`, `baseSleepTime` | 在 maxElapsedTime 时间内持续重试，每次等待 baseSleepTime |

#### 重试策略选择建议

| 场景 | 推荐策略 | 理由 |
|------|------|------|
| 生产环境通用 | `EXPONENTIAL_BACKOFF` | 指数退避避免在故障时对 ZK 集群造成持续压力 |
| 网络不稳定环境 | `BOUNDED_EXPONENTIAL_BACKOFF` | 限制最大退避时间，避免等待过长 |
| 快速失败场景 | `N_TIMES` 或 `ONE_TIME` | 快速返回失败，由上层业务处理 |
| 关键路径（不能失败） | `FOREVER` | 持续重试直到成功，适合核心服务 |
| 有 SLA 要求 | `UNTIL_ELAPSED` | 在指定时间窗口内持续尝试 |

### AuthInfo - 认证信息

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `scheme` | String | null | 认证方案，如 `digest`、`ip`、`sasl` |
| `auth` | String | null | 认证凭据，格式由 scheme 决定 |

`digestAuth` 是快捷方式，等价于配置一个 scheme 为 `digest` 的 `AuthInfo`。两者可以同时使用，工厂方法会将它们合并。

---

## 五、使用方式

### 5.1 通过配置对象创建

```java
// 创建配置
ZkConfig config = new ZkConfig();
config.setConnectString("127.0.0.1:2181");
config.setNamespace("myapp");
config.setSessionTimeout(Duration.ofSeconds(30));
config.setDigestAuth("admin:secret");

// 自定义重试策略
ZkConfig.RetryConfig retry = new ZkConfig.RetryConfig();
retry.setType(ZkConfig.RetryPolicyType.BOUNDED_EXPONENTIAL_BACKOFF);
retry.setBaseSleepTime(Duration.ofMillis(500));
retry.setMaxSleepTime(Duration.ofSeconds(10));
retry.setMaxRetries(5);
config.setRetry(retry);

// 创建并启动客户端
CuratorFramework client = CuratorClientFactory.create(config);

// 使用客户端
client.create().forPath("/test", "data".getBytes());
byte[] data = client.getData().forPath("/test");

// 关闭客户端
client.close();
```

### 5.2 从 classpath 文件加载

```java
// 从 classpath 下的 properties 文件加载配置并创建客户端
CuratorFramework client = CuratorClientFactory.createFromClasspath(
    "runtimecfg",           // classpath 下的目录路径
    "zookeeper.properties"  // 文件名
);
```

`createFromClasspath` 方法等价于先调用 `loadConfig(path, filename)` 获取 `ZkConfig`，再调用 `create(config)`。

### 5.3 只加载配置（不创建客户端）

```java
ZkConfig config = CuratorClientFactory.loadConfig(
    "runtimecfg",
    "zookeeper.properties"
);
// 可以在创建客户端前修改配置
config.setNamespace("custom-ns");
CuratorFramework client = CuratorClientFactory.create(config);
```

### 5.4 Spring Boot 手动配置

```java
@Configuration
public class ZookeeperConfiguration {

    @Bean
    public CuratorFramework curatorFramework() {
        return CuratorClientFactory.createFromClasspath(
            "runtimecfg", "zookeeper.properties"
        );
    }

    // Bean 销毁时关闭客户端
    @PreDestroy
    public void destroy() {
        curatorFramework().close();
    }
}
```

或者通过配置对象创建：

```java
@Configuration
public class ZookeeperConfiguration {

    @Bean
    public CuratorFramework curatorFramework() {
        ZkConfig config = CuratorClientFactory.loadConfig(
            "runtimecfg", "zookeeper.properties"
        );
        // 可在此处覆盖特定配置
        return CuratorClientFactory.create(config);
    }
}
```

### 5.5 多认证方案

```java
ZkConfig config = new ZkConfig();
config.setConnectString("127.0.0.1:2181");

// 快捷 digest 认证
config.setDigestAuth("admin:secret");

// 额外的认证方案
List<ZkConfig.AuthInfo> authInfos = new ArrayList<>();
ZkConfig.AuthInfo ipAuth = new ZkConfig.AuthInfo();
ipAuth.setScheme("ip");
ipAuth.setAuth("10.0.0.0/8");
authInfos.add(ipAuth);

ZkConfig.AuthInfo saslAuth = new ZkConfig.AuthInfo();
saslAuth.setScheme("sasl");
saslAuth.setAuth("user@REALM");
authInfos.add(saslAuth);

config.setAuthInfos(authInfos);

CuratorFramework client = CuratorClientFactory.create(config);
```

对应的 Properties 配置：

```properties
connectString=127.0.0.1:2181
digestAuth=admin:secret
auth.0.scheme=ip
auth.0.auth=10.0.0.0/8
auth.1.scheme=sasl
auth.1.auth=user@REALM
```

认证条目索引从 0 开始，最多支持 32 个（索引 0-31）。`auth.N.scheme` 和 `auth.N.auth` 只要有一个存在就会创建该条认证信息。

---

## 六、配置验证

`CuratorClientFactory.create()` 会在创建客户端前进行以下验证，不满足条件时抛出 `IllegalArgumentException`：

| 验证项 | 规则 |
|------|------|
| `connectString` | 不能为 null 或空白 |
| `sessionTimeout` | 不能为 null，必须 >= 0 |
| `connectionTimeout` | 不能为 null，必须 >= 0 |
| `waitForShutdownTimeout` | 不能为 null，必须 >= 0 |
| `maxCloseWait` | 不能为 null，必须 >= 0 |
| `simulatedSessionExpirationPercent` | 必须在 0-100 之间（含） |
| `retry` 和 `retry.type` | 不能为 null |
| `retry.baseSleepTime` | 必须 >= 0 |
| `retry.maxSleepTime` | 必须 >= 0 |
| `retry.maxElapsedTime` | 必须 >= 0 |

验证通过后，工厂方法会自动调用 `client.start()`，返回的客户端已处于 `STARTED` 状态，可以直接使用。

---

## 七、注意事项

1. **无 Spring Boot Starter**：与 Jedis/Redisson 不同，ZooKeeper 模块没有对应的 Starter，需手动创建 `CuratorFramework` Bean
2. **命名空间前导斜杠**：`namespace` 如果以 `/` 开头，工厂方法会自动去除，无需手动处理
3. **defaultData 克隆**：工厂方法内部会对 `defaultData` 进行 `.clone()` 操作，避免外部修改影响客户端行为
4. **客户端生命周期**：工厂方法返回的客户端已经 `start()`，调用方负责在不使用时调用 `close()` 释放资源
5. **Properties 键名**：时间值在 Properties 文件中以毫秒为单位（如 `sessionTimeoutMs=60000`），而 Java 配置对象使用 `java.time.Duration`
6. **认证合并**：`digestAuth` 和 `authInfos` 可以同时配置，工厂方法会将它们合并为一个认证列表
7. **Curator 原生 API**：创建后的 `CuratorFramework` 就是标准的 Curator 客户端，可以使用 Curator 的全部功能（节点操作、Leader 选举、分布式锁、分布式队列等）
