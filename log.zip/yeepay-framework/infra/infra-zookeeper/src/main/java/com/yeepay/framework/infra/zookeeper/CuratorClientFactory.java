package com.yeepay.framework.infra.zookeeper;

import static com.yeepay.framework.common.utils.PropertiesLoader.ifPresent;

import com.yeepay.framework.common.utils.PropertiesLoader;
import com.yeepay.framework.infra.zookeeper.config.ZkConfig;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.AuthInfo;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.BoundedExponentialBackoffRetry;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.retry.RetryForever;
import org.apache.curator.retry.RetryNTimes;
import org.apache.curator.retry.RetryOneTime;
import org.apache.curator.retry.RetryUntilElapsed;

/**
 * Curator 客户端工厂.
 *
 * <p>统一封装 {@link CuratorFramework} 的构建与启动，返回已 {@code start()} 的实例.
 * 调用方负责在生命周期结束时 {@code close()} 客户端.
 *
 * <p>使用示例：
 * <pre>
 * CuratorFramework client = CuratorClientFactory.create(zkConfig);
 * // ... 业务使用 ...
 * client.close();
 * </pre>
 */
public final class CuratorClientFactory {

    private CuratorClientFactory() {}

    /**
     * 根据配置创建并启动一个 Curator 客户端.
     *
     * @param config zk 配置
     * @return 已启动的 {@link CuratorFramework}
     */
    public static CuratorFramework create(final ZkConfig config) {
        validate(config);

        CuratorFrameworkFactory.Builder builder = CuratorFrameworkFactory.builder()
                .connectString(config.getConnectString())
                .sessionTimeoutMs(toMillisInt(config.getSessionTimeout()))
                .connectionTimeoutMs(toMillisInt(config.getConnectionTimeout()))
                .waitForShutdownTimeoutMs(toMillisInt(config.getWaitForShutdownTimeout()))
                .maxCloseWaitMs(toMillisInt(config.getMaxCloseWait()))
                .canBeReadOnly(config.isCanBeReadOnly())
                .simulatedSessionExpirationPercent(config.getSimulatedSessionExpirationPercent())
                .retryPolicy(buildRetryPolicy(config.getRetry()));

        if (Objects.nonNull(config.getNamespace())
                && !config.getNamespace().trim().isEmpty()) {
            builder.namespace(stripLeadingSlash(config.getNamespace().trim()));
        }
        if (Objects.nonNull(config.getDefaultData()) && config.getDefaultData().length > 0) {
            builder.defaultData(config.getDefaultData().clone());
        }
        List<AuthInfo> auths = collectAuthInfos(config);
        if (!auths.isEmpty()) {
            builder.authorization(auths);
        }

        CuratorFramework client = builder.build();
        client.start();
        return client;
    }

    /**
     * 从 classpath 配置文件创建客户端.
     *
     * <p>配置文件格式（properties）：
     * <pre>
     * connectString=10.0.0.1:2181,10.0.0.2:2181
     * namespace=yeepay
     *
     * # 时间相关参数均以毫秒为单位
     * sessionTimeoutMs=60000
     * connectionTimeoutMs=15000
     * waitForShutdownTimeoutMs=0
     * maxCloseWaitMs=1000
     *
     * # 行为
     * canBeReadOnly=false
     * simulatedSessionExpirationPercent=100
     * defaultData=hello                 # UTF-8 字符串
     *
     * # 认证
     * digestAuth=user:pass
     * # 可选：多 auth（auth.0.scheme / auth.0.auth / auth.1.scheme ...）
     * # auth.0.scheme=digest
     * # auth.0.auth=user:pass
     * # auth.1.scheme=ip
     * # auth.1.auth=10.0.0.0/8
     *
     * # 重试策略：EXPONENTIAL_BACKOFF | BOUNDED_EXPONENTIAL_BACKOFF | N_TIMES | ONE_TIME | FOREVER | UNTIL_ELAPSED
     * retry.type=EXPONENTIAL_BACKOFF
     * retry.baseSleepTimeMs=1000
     * retry.maxSleepTimeMs=60000
     * retry.maxElapsedTimeMs=300000
     * retry.maxRetries=3
     * </pre>
     *
     * @param path     classpath 目录，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名
     * @return 已启动的 {@link CuratorFramework}
     */
    public static CuratorFramework createFromClasspath(final String path, final String filename) {
        return create(loadConfig(path, filename));
    }

    /**
     * 从 classpath 配置文件加载 {@link ZkConfig}.
     *
     * @param path     classpath 目录，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名
     * @return 解析后的 {@link ZkConfig}
     */
    public static ZkConfig loadConfig(final String path, final String filename) {
        Properties props = PropertiesLoader.load(path, filename);
        return buildConfig(props);
    }

    private static ZkConfig buildConfig(final Properties props) {
        ZkConfig config = new ZkConfig();

        ifPresent(props, "connectString", config::setConnectString);
        ifPresent(props, "namespace", config::setNamespace);

        ifPresent(props, "sessionTimeoutMs", v -> config.setSessionTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, "connectionTimeoutMs", v -> config.setConnectionTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(
                props,
                "waitForShutdownTimeoutMs",
                v -> config.setWaitForShutdownTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, "maxCloseWaitMs", v -> config.setMaxCloseWait(Duration.ofMillis(Long.parseLong(v))));

        ifPresent(props, "canBeReadOnly", v -> config.setCanBeReadOnly(Boolean.parseBoolean(v)));
        ifPresent(
                props,
                "simulatedSessionExpirationPercent",
                v -> config.setSimulatedSessionExpirationPercent(Integer.parseInt(v)));
        ifPresent(props, "defaultData", v -> config.setDefaultData(v.getBytes(StandardCharsets.UTF_8)));

        ifPresent(props, "digestAuth", config::setDigestAuth);
        config.setAuthInfos(parseAuthInfos(props));

        applyRetryConfig(props, config.getRetry());

        return config;
    }

    private static void applyRetryConfig(final Properties props, final ZkConfig.RetryConfig retry) {
        ifPresent(props, "retry.type", v -> retry.setType(ZkConfig.RetryPolicyType.valueOf(v.trim())));
        ifPresent(props, "retry.baseSleepTimeMs", v -> retry.setBaseSleepTime(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, "retry.maxSleepTimeMs", v -> retry.setMaxSleepTime(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, "retry.maxElapsedTimeMs", v -> retry.setMaxElapsedTime(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, "retry.maxRetries", v -> retry.setMaxRetries(Integer.parseInt(v)));
    }

    private static List<ZkConfig.AuthInfo> parseAuthInfos(final Properties props) {
        List<ZkConfig.AuthInfo> out = new ArrayList<>();
        for (int i = 0; i < 32; i++) {
            String schemeKey = "auth." + i + ".scheme";
            String authKey = "auth." + i + ".auth";
            if (!props.containsKey(schemeKey) && !props.containsKey(authKey)) {
                continue;
            }
            ZkConfig.AuthInfo info = new ZkConfig.AuthInfo();
            ifPresent(props, schemeKey, info::setScheme);
            ifPresent(props, authKey, info::setAuth);
            out.add(info);
        }
        return out;
    }

    private static RetryPolicy buildRetryPolicy(final ZkConfig.RetryConfig retry) {
        int base = toMillisInt(retry.getBaseSleepTime());
        int maxSleep = toMillisInt(retry.getMaxSleepTime());
        int maxElapsed = toMillisInt(retry.getMaxElapsedTime());
        int n = retry.getMaxRetries();
        return switch (retry.getType()) {
            case EXPONENTIAL_BACKOFF -> new ExponentialBackoffRetry(base, n);
            case BOUNDED_EXPONENTIAL_BACKOFF -> new BoundedExponentialBackoffRetry(base, maxSleep, n);
            case N_TIMES -> new RetryNTimes(n, base);
            case ONE_TIME -> new RetryOneTime(base);
            case FOREVER -> new RetryForever(base);
            case UNTIL_ELAPSED -> new RetryUntilElapsed(maxElapsed, base);
        };
    }

    private static List<AuthInfo> collectAuthInfos(final ZkConfig config) {
        List<AuthInfo> out = new ArrayList<>();
        if (Objects.nonNull(config.getDigestAuth())
                && !config.getDigestAuth().trim().isEmpty()) {
            out.add(new AuthInfo("digest", config.getDigestAuth().trim().getBytes(StandardCharsets.UTF_8)));
        }
        if (Objects.nonNull(config.getAuthInfos())) {
            for (ZkConfig.AuthInfo info : config.getAuthInfos()) {
                if (Objects.isNull(info)
                        || Objects.isNull(info.getScheme())
                        || info.getScheme().trim().isEmpty()) {
                    continue;
                }
                byte[] bytes = Objects.isNull(info.getAuth())
                        ? new byte[0]
                        : info.getAuth().getBytes(StandardCharsets.UTF_8);
                out.add(new AuthInfo(info.getScheme().trim(), bytes));
            }
        }
        return out;
    }

    private static void validate(final ZkConfig config) {
        if (Objects.isNull(config)
                || Objects.isNull(config.getConnectString())
                || config.getConnectString().trim().isEmpty()) {
            throw new IllegalArgumentException("ZkConfig.connectString 不能为空");
        }
        requireNonNegative(config.getSessionTimeout(), "sessionTimeout");
        requireNonNegative(config.getConnectionTimeout(), "connectionTimeout");
        requireNonNegative(config.getWaitForShutdownTimeout(), "waitForShutdownTimeout");
        requireNonNegative(config.getMaxCloseWait(), "maxCloseWait");
        int percent = config.getSimulatedSessionExpirationPercent();
        if (percent < 0 || percent > 100) {
            throw new IllegalArgumentException("simulatedSessionExpirationPercent 必须在 [0,100]，当前=" + percent);
        }
        ZkConfig.RetryConfig retry = config.getRetry();
        if (Objects.isNull(retry) || Objects.isNull(retry.getType())) {
            throw new IllegalArgumentException("ZkConfig.retry / retry.type 不能为 null");
        }
        requireNonNegative(retry.getBaseSleepTime(), "retry.baseSleepTime");
        requireNonNegative(retry.getMaxSleepTime(), "retry.maxSleepTime");
        requireNonNegative(retry.getMaxElapsedTime(), "retry.maxElapsedTime");
    }

    private static void requireNonNegative(final Duration d, final String field) {
        if (Objects.isNull(d) || d.isNegative()) {
            throw new IllegalArgumentException("ZkConfig." + field + " 不能为 null 或负数: " + d);
        }
    }

    private static int toMillisInt(final Duration d) {
        long ms = d.toMillis();
        if (ms > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("Duration 转毫秒超过 int 上限: " + d);
        }
        return (int) ms;
    }

    private static String stripLeadingSlash(final String ns) {
        return ns.startsWith("/") ? ns.substring(1) : ns;
    }
}
