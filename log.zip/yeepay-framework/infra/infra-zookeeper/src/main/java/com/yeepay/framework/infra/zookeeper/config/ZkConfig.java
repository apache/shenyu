package com.yeepay.framework.infra.zookeeper.config;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

/**
 * ZooKeeper 客户端配置（基于 Apache Curator）.
 *
 * <p>覆盖 {@link org.apache.curator.framework.CuratorFrameworkFactory.Builder} 上的主要可调参数，
 * 时间类型统一使用 {@link Duration}. 业务路径（namespace 下具体子路径）由调用方在拿到
 * {@link org.apache.curator.framework.CuratorFramework} 后自行管理.
 */
@Data
public class ZkConfig {

    /**
     * 连接串，多个节点逗号分隔，如 {@code 10.0.0.1:2181,10.0.0.2:2181/yeepay}.
     */
    private String connectString;

    /**
     * 命名空间，所有 znode 路径会自动加上 {@code /namespace} 前缀；
     * 留空则不启用 namespace，调用方需自己写完整路径.
     */
    private String namespace;

    /**
     * 会话超时. 决定 EPHEMERAL 节点存活时长. 与 ZK 服务端 tickTime*2~20 兼容.
     */
    private Duration sessionTimeout = Duration.ofSeconds(60);

    /**
     * 连接建立超时.
     */
    private Duration connectionTimeout = Duration.ofSeconds(15);

    /**
     * 关闭客户端时等待 in-flight 操作完成的时间. 0 表示不等待.
     */
    private Duration waitForShutdownTimeout = Duration.ZERO;

    /**
     * close() 调用时 Curator 内部释放资源的最长等待. 默认 1s 与 Curator 默认值一致.
     */
    private Duration maxCloseWait = Duration.ofSeconds(1);

    /**
     * 是否允许 read-only 会话（仅在 ZK 集群丢失多数派但仍允许读时有效）.
     */
    private boolean canBeReadOnly;

    /**
     * 创建 znode 时使用的默认数据，留空（null）等价于空字节数组.
     */
    private byte[] defaultData;

    /**
     * 模拟 session 过期百分比（0-100），仅用于测试. 默认 100 表示正常会话.
     */
    private int simulatedSessionExpirationPercent = 100;

    /**
     * 单个 digest 认证（{@code username:password}），便利字段；
     * 与 {@link #authInfos} 合并后下发到 Curator，留空则不启用.
     */
    private String digestAuth;

    /**
     * 完整认证列表，支持多 scheme（digest / ip / sasl / world）.
     */
    private List<AuthInfo> authInfos = new ArrayList<>();

    /**
     * 重试策略配置.
     */
    private RetryConfig retry = new RetryConfig();

    /**
     * 重试策略子配置.
     */
    @Data
    public static class RetryConfig {

        /**
         * 重试策略类型，默认指数退避. 不同类型只读取自己关心的字段，其它字段忽略.
         */
        private RetryPolicyType type = RetryPolicyType.EXPONENTIAL_BACKOFF;

        /**
         * 初始退避时间. EXPONENTIAL_BACKOFF / BOUNDED_EXPONENTIAL_BACKOFF / N_TIMES / ONE_TIME /
         * FOREVER / UNTIL_ELAPSED 都会读取此字段.
         */
        private Duration baseSleepTime = Duration.ofSeconds(1);

        /**
         * 单次最大退避. 仅 BOUNDED_EXPONENTIAL_BACKOFF 使用.
         */
        private Duration maxSleepTime = Duration.ofMinutes(1);

        /**
         * 总重试时长上限. 仅 UNTIL_ELAPSED 使用.
         */
        private Duration maxElapsedTime = Duration.ofMinutes(5);

        /**
         * 最大重试次数. EXPONENTIAL_BACKOFF / BOUNDED_EXPONENTIAL_BACKOFF / N_TIMES 使用.
         */
        private int maxRetries = 3;
    }

    /**
     * 认证条目.
     */
    @Data
    public static class AuthInfo {

        /**
         * 认证 scheme（如 {@code digest}、{@code ip}、{@code sasl}）.
         */
        private String scheme;

        /**
         * 认证字符串. 对于 digest scheme 形如 {@code username:password}.
         */
        private String auth;
    }

    /**
     * 重试策略类型枚举，对应 Curator 内置 {@code org.apache.curator.retry.*} 策略.
     */
    public enum RetryPolicyType {

        /**
         * 指数退避，受 {@link RetryConfig#getMaxRetries()} 限制.
         */
        EXPONENTIAL_BACKOFF,

        /**
         * 指数退避，单次退避封顶到 {@link RetryConfig#getMaxSleepTime()}.
         */
        BOUNDED_EXPONENTIAL_BACKOFF,

        /**
         * 固定重试 N 次，每次间隔固定 {@link RetryConfig#getBaseSleepTime()}.
         */
        N_TIMES,

        /**
         * 仅重试一次.
         */
        ONE_TIME,

        /**
         * 永久重试，每次间隔固定 {@link RetryConfig#getBaseSleepTime()}.
         */
        FOREVER,

        /**
         * 直到累计耗时超过 {@link RetryConfig#getMaxElapsedTime()}.
         */
        UNTIL_ELAPSED
    }
}
