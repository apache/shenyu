package com.yeepay.framework.infra.zookeeper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.zookeeper.config.ZkConfig;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.imps.CuratorFrameworkState;
import org.apache.curator.test.TestingServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CuratorClientFactoryTest {

    private static TestingServer server;

    @BeforeAll
    static void startZk() throws Exception {
        server = new TestingServer();
    }

    @AfterAll
    static void stopZk() throws Exception {
        if (server != null) {
            server.close();
        }
    }

    private ZkConfig baseConfig() {
        ZkConfig c = new ZkConfig();
        c.setConnectString(server.getConnectString());
        c.setSessionTimeout(Duration.ofSeconds(10));
        c.setConnectionTimeout(Duration.ofSeconds(5));
        c.getRetry().setBaseSleepTime(Duration.ofMillis(200));
        c.getRetry().setMaxRetries(2);
        return c;
    }

    @Test
    @DisplayName("默认配置可连接 TestingServer")
    void create_with_minimal_config() throws Exception {
        ZkConfig c = baseConfig();
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            assertThat(client.blockUntilConnected(5, TimeUnit.SECONDS)).isTrue();
            assertThat(client.getState()).isEqualTo(CuratorFrameworkState.STARTED);
        }
    }

    @Test
    @DisplayName("connectString 为空应快速失败")
    void blank_connect_string_rejected() {
        ZkConfig c = new ZkConfig();
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("connectString");
    }

    @Test
    @DisplayName("负数 Duration 应被校验拒绝")
    void negative_duration_rejected() {
        ZkConfig c = baseConfig();
        c.setSessionTimeout(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("sessionTimeout");
    }

    @Test
    @DisplayName("simulatedSessionExpirationPercent 越界应被拒绝")
    void simulated_percent_out_of_range_rejected() {
        ZkConfig c = baseConfig();
        c.setSimulatedSessionExpirationPercent(200);
        assertThatThrownBy(() -> CuratorClientFactory.create(c)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("覆盖全部重试策略类型都能成功构建客户端")
    void all_retry_policy_types_work() throws Exception {
        for (ZkConfig.RetryPolicyType type : ZkConfig.RetryPolicyType.values()) {
            ZkConfig c = baseConfig();
            c.getRetry().setType(type);
            c.getRetry().setMaxSleepTime(Duration.ofSeconds(2));
            c.getRetry().setMaxElapsedTime(Duration.ofSeconds(5));
            try (CuratorFramework client = CuratorClientFactory.create(c)) {
                assertThat(client.blockUntilConnected(5, TimeUnit.SECONDS))
                        .as("retry type=%s 应能连接", type)
                        .isTrue();
            }
        }
    }

    @Test
    @DisplayName("namespace 前导斜杠应被裁掉，连接后写入路径正确")
    void namespace_strips_leading_slash() throws Exception {
        ZkConfig c = baseConfig();
        c.setNamespace("/yeepay/test-" + System.nanoTime());
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            client.blockUntilConnected(5, TimeUnit.SECONDS);
            client.create().creatingParentsIfNeeded().forPath("/hello", "world".getBytes());
            byte[] data = client.getData().forPath("/hello");
            assertThat(new String(data)).isEqualTo("world");
        }
    }

    @Test
    @DisplayName("null config 应快速失败")
    void null_config_rejected() {
        assertThatThrownBy(() -> CuratorClientFactory.create(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("connectionTimeout 为负数应被拒绝")
    void negative_connectionTimeout_rejected() {
        ZkConfig c = baseConfig();
        c.setConnectionTimeout(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("connectionTimeout");
    }

    @Test
    @DisplayName("waitForShutdownTimeout 为负数应被拒绝")
    void negative_waitForShutdownTimeout_rejected() {
        ZkConfig c = baseConfig();
        c.setWaitForShutdownTimeout(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("waitForShutdownTimeout");
    }

    @Test
    @DisplayName("maxCloseWait 为负数应被拒绝")
    void negative_maxCloseWait_rejected() {
        ZkConfig c = baseConfig();
        c.setMaxCloseWait(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("maxCloseWait");
    }

    @Test
    @DisplayName("simulatedSessionExpirationPercent 为负数应被拒绝")
    void negative_simulated_percent_rejected() {
        ZkConfig c = baseConfig();
        c.setSimulatedSessionExpirationPercent(-1);
        assertThatThrownBy(() -> CuratorClientFactory.create(c)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("retry.baseSleepTime 为负数应被拒绝")
    void negative_retryBaseSleepTime_rejected() {
        ZkConfig c = baseConfig();
        c.getRetry().setBaseSleepTime(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("baseSleepTime");
    }

    @Test
    @DisplayName("retry.maxSleepTime 为负数应被拒绝")
    void negative_retryMaxSleepTime_rejected() {
        ZkConfig c = baseConfig();
        c.getRetry().setMaxSleepTime(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("maxSleepTime");
    }

    @Test
    @DisplayName("retry.maxElapsedTime 为负数应被拒绝")
    void negative_retryMaxElapsedTime_rejected() {
        ZkConfig c = baseConfig();
        c.getRetry().setMaxElapsedTime(Duration.ofMillis(-1));
        assertThatThrownBy(() -> CuratorClientFactory.create(c))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("maxElapsedTime");
    }

    @Test
    @DisplayName("digestAuth 认证信息可传入并成功创建客户端")
    void digestAuth_creates_client() throws Exception {
        ZkConfig c = baseConfig();
        c.setDigestAuth("admin:secret");
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            assertThat(client.blockUntilConnected(5, TimeUnit.SECONDS)).isTrue();
        }
    }

    @Test
    @DisplayName("defaultData 应正确传入")
    void defaultData_used() throws Exception {
        ZkConfig c = baseConfig();
        c.setDefaultData("test-data".getBytes());
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            client.blockUntilConnected(5, TimeUnit.SECONDS);
            String path = "/dd-test-" + System.nanoTime();
            client.create().creatingParentsIfNeeded().forPath(path);
            byte[] data = client.getData().forPath(path);
            assertThat(new String(data)).isEqualTo("test-data");
        }
    }

    @Test
    @DisplayName("canBeReadOnly 设为 true 可成功创建客户端")
    void canBeReadOnly_creates_client() throws Exception {
        ZkConfig c = baseConfig();
        c.setCanBeReadOnly(true);
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            assertThat(client.blockUntilConnected(5, TimeUnit.SECONDS)).isTrue();
        }
    }

    @Test
    @DisplayName("空白 namespace 不设置 namespace")
    void blank_namespace_not_set() throws Exception {
        ZkConfig c = baseConfig();
        c.setNamespace("  ");
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            assertThat(client.blockUntilConnected(5, TimeUnit.SECONDS)).isTrue();
            assertThat(client.getNamespace()).isEmpty();
        }
    }

    @Test
    @DisplayName("配置文件不存在应抛异常")
    void loadConfig_fileNotFound_throws() {
        assertThatThrownBy(() -> CuratorClientFactory.loadConfig("testcfg", "nonexistent.properties"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("createFromClasspath 正确创建客户端")
    void createFromClasspath_creates_client() throws Exception {
        ZkConfig c = CuratorClientFactory.loadConfig("testcfg", "zookeeper-full.properties");
        c.setConnectString(server.getConnectString());
        try (CuratorFramework client = CuratorClientFactory.create(c)) {
            assertThat(client.blockUntilConnected(5, TimeUnit.SECONDS)).isTrue();
        }
    }

    @Test
    @DisplayName("properties 文件加载应覆盖所有字段")
    void load_config_from_classpath_covers_all_fields() {
        ZkConfig c = CuratorClientFactory.loadConfig("testcfg", "zookeeper-full.properties");

        assertThat(c.getConnectString()).isEqualTo("10.0.0.1:2181,10.0.0.2:2181");
        assertThat(c.getNamespace()).isEqualTo("yeepay");
        assertThat(c.getSessionTimeout()).isEqualTo(Duration.ofMillis(45000));
        assertThat(c.getConnectionTimeout()).isEqualTo(Duration.ofMillis(8000));
        assertThat(c.getWaitForShutdownTimeout()).isEqualTo(Duration.ofMillis(2000));
        assertThat(c.getMaxCloseWait()).isEqualTo(Duration.ofMillis(3000));
        assertThat(c.isCanBeReadOnly()).isTrue();
        assertThat(c.getSimulatedSessionExpirationPercent()).isEqualTo(80);
        assertThat(new String(c.getDefaultData())).isEqualTo("hello-zk");
        assertThat(c.getDigestAuth()).isEqualTo("admin:s3cret");

        List<ZkConfig.AuthInfo> auths = c.getAuthInfos();
        assertThat(auths).hasSize(2);
        assertThat(auths.get(0).getScheme()).isEqualTo("digest");
        assertThat(auths.get(0).getAuth()).isEqualTo("user1:pass1");
        assertThat(auths.get(1).getScheme()).isEqualTo("ip");
        assertThat(auths.get(1).getAuth()).isEqualTo("10.0.0.0/8");

        ZkConfig.RetryConfig retry = c.getRetry();
        assertThat(retry.getType()).isEqualTo(ZkConfig.RetryPolicyType.BOUNDED_EXPONENTIAL_BACKOFF);
        assertThat(retry.getBaseSleepTime()).isEqualTo(Duration.ofMillis(500));
        assertThat(retry.getMaxSleepTime()).isEqualTo(Duration.ofMillis(30000));
        assertThat(retry.getMaxElapsedTime()).isEqualTo(Duration.ofMillis(120000));
        assertThat(retry.getMaxRetries()).isEqualTo(5);
    }
}
