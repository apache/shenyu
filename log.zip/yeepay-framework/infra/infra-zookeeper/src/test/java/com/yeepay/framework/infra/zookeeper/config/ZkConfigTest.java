package com.yeepay.framework.infra.zookeeper.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class ZkConfigTest {

    @Test
    void defaults_topLevel() {
        ZkConfig config = new ZkConfig();
        assertThat(config.getConnectString()).isNull();
        assertThat(config.getNamespace()).isNull();
        assertThat(config.getSessionTimeout()).isEqualTo(Duration.ofSeconds(60));
        assertThat(config.getConnectionTimeout()).isEqualTo(Duration.ofSeconds(15));
        assertThat(config.getWaitForShutdownTimeout()).isEqualTo(Duration.ZERO);
        assertThat(config.getMaxCloseWait()).isEqualTo(Duration.ofSeconds(1));
        assertThat(config.isCanBeReadOnly()).isFalse();
        assertThat(config.getDefaultData()).isNull();
        assertThat(config.getSimulatedSessionExpirationPercent()).isEqualTo(100);
        assertThat(config.getDigestAuth()).isNull();
        assertThat(config.getAuthInfos()).isEmpty();
        assertThat(config.getRetry()).isNotNull();
    }

    @Test
    void defaults_retryConfig() {
        ZkConfig.RetryConfig retry = new ZkConfig.RetryConfig();
        assertThat(retry.getType()).isEqualTo(ZkConfig.RetryPolicyType.EXPONENTIAL_BACKOFF);
        assertThat(retry.getBaseSleepTime()).isEqualTo(Duration.ofSeconds(1));
        assertThat(retry.getMaxSleepTime()).isEqualTo(Duration.ofMinutes(1));
        assertThat(retry.getMaxElapsedTime()).isEqualTo(Duration.ofMinutes(5));
        assertThat(retry.getMaxRetries()).isEqualTo(3);
    }

    @Test
    void defaults_authInfo() {
        ZkConfig.AuthInfo authInfo = new ZkConfig.AuthInfo();
        assertThat(authInfo.getScheme()).isNull();
        assertThat(authInfo.getAuth()).isNull();
    }

    @Test
    void setters_topLevel() {
        ZkConfig config = new ZkConfig();
        config.setConnectString("localhost:2181");
        config.setNamespace("test");
        config.setSessionTimeout(Duration.ofSeconds(30));
        config.setConnectionTimeout(Duration.ofSeconds(10));
        config.setWaitForShutdownTimeout(Duration.ofSeconds(5));
        config.setMaxCloseWait(Duration.ofSeconds(2));
        config.setCanBeReadOnly(true);
        config.setDefaultData("data".getBytes());
        config.setSimulatedSessionExpirationPercent(50);
        config.setDigestAuth("user:pass");

        assertThat(config.getConnectString()).isEqualTo("localhost:2181");
        assertThat(config.getNamespace()).isEqualTo("test");
        assertThat(config.getSessionTimeout()).isEqualTo(Duration.ofSeconds(30));
        assertThat(config.getConnectionTimeout()).isEqualTo(Duration.ofSeconds(10));
        assertThat(config.getWaitForShutdownTimeout()).isEqualTo(Duration.ofSeconds(5));
        assertThat(config.getMaxCloseWait()).isEqualTo(Duration.ofSeconds(2));
        assertThat(config.isCanBeReadOnly()).isTrue();
        assertThat(new String(config.getDefaultData())).isEqualTo("data");
        assertThat(config.getSimulatedSessionExpirationPercent()).isEqualTo(50);
        assertThat(config.getDigestAuth()).isEqualTo("user:pass");
    }

    @Test
    void setters_retryConfig() {
        ZkConfig.RetryConfig retry = new ZkConfig.RetryConfig();
        retry.setType(ZkConfig.RetryPolicyType.N_TIMES);
        retry.setBaseSleepTime(Duration.ofMillis(500));
        retry.setMaxSleepTime(Duration.ofSeconds(30));
        retry.setMaxElapsedTime(Duration.ofMinutes(2));
        retry.setMaxRetries(5);

        assertThat(retry.getType()).isEqualTo(ZkConfig.RetryPolicyType.N_TIMES);
        assertThat(retry.getBaseSleepTime()).isEqualTo(Duration.ofMillis(500));
        assertThat(retry.getMaxSleepTime()).isEqualTo(Duration.ofSeconds(30));
        assertThat(retry.getMaxElapsedTime()).isEqualTo(Duration.ofMinutes(2));
        assertThat(retry.getMaxRetries()).isEqualTo(5);
    }

    @Test
    void setters_authInfo() {
        ZkConfig.AuthInfo authInfo = new ZkConfig.AuthInfo();
        authInfo.setScheme("digest");
        authInfo.setAuth("user:pass");
        assertThat(authInfo.getScheme()).isEqualTo("digest");
        assertThat(authInfo.getAuth()).isEqualTo("user:pass");
    }

    @Test
    void setters_authInfosList() {
        ZkConfig config = new ZkConfig();
        List<ZkConfig.AuthInfo> infos = new ArrayList<>();
        ZkConfig.AuthInfo ai = new ZkConfig.AuthInfo();
        ai.setScheme("ip");
        ai.setAuth("10.0.0.0/8");
        infos.add(ai);
        config.setAuthInfos(infos);
        assertThat(config.getAuthInfos()).hasSize(1);
        assertThat(config.getAuthInfos().get(0).getScheme()).isEqualTo("ip");
    }

    @Test
    void retryPolicyType_values() {
        ZkConfig.RetryPolicyType[] values = ZkConfig.RetryPolicyType.values();
        assertThat(values).hasSize(6);
        assertThat(values)
                .containsExactly(
                        ZkConfig.RetryPolicyType.EXPONENTIAL_BACKOFF,
                        ZkConfig.RetryPolicyType.BOUNDED_EXPONENTIAL_BACKOFF,
                        ZkConfig.RetryPolicyType.N_TIMES,
                        ZkConfig.RetryPolicyType.ONE_TIME,
                        ZkConfig.RetryPolicyType.FOREVER,
                        ZkConfig.RetryPolicyType.UNTIL_ELAPSED);
    }

    @Test
    void retryPolicyType_valueOf() {
        assertThat(ZkConfig.RetryPolicyType.valueOf("EXPONENTIAL_BACKOFF"))
                .isEqualTo(ZkConfig.RetryPolicyType.EXPONENTIAL_BACKOFF);
        assertThat(ZkConfig.RetryPolicyType.valueOf("FOREVER")).isEqualTo(ZkConfig.RetryPolicyType.FOREVER);
        assertThatThrownBy(() -> ZkConfig.RetryPolicyType.valueOf("INVALID"))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
