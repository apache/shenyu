package com.yeepay.framework.infra.redisson.cilent;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import org.junit.jupiter.api.Test;

class ClusterRedissonClientCreatorTest {

    @Test
    void constructor_nullClusterConfig_throwsNPE() {
        RedissonConfig config = new RedissonConfig();
        assertThatThrownBy(() -> new ClusterRedissonClientCreator(config, null, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("clusterConfig");
    }

    @Test
    void constructor_nullRedissonConfig_throwsNPE() {
        RedissonConfig.ClusterConfig clusterConfig = new RedissonConfig.ClusterConfig();
        assertThatThrownBy(() -> new ClusterRedissonClientCreator(null, clusterConfig, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("redissonConfig");
    }

    @Test
    void constructor_validConfig_succeeds() {
        RedissonConfig config = new RedissonConfig();
        RedissonConfig.ClusterConfig clusterConfig = new RedissonConfig.ClusterConfig();
        ClusterRedissonClientCreator creator = new ClusterRedissonClientCreator(config, clusterConfig, null);
        org.assertj.core.api.Assertions.assertThat(creator).isNotNull();
    }
}
