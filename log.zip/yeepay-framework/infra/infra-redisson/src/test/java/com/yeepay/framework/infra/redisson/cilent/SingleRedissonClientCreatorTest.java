package com.yeepay.framework.infra.redisson.cilent;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.redisson.Redisson;
import org.redisson.config.Config;

class SingleRedissonClientCreatorTest {

    @Test
    void constructor_nullSingleConfig_throwsNPE() {
        RedissonConfig config = new RedissonConfig();
        assertThatThrownBy(() -> new SingleRedissonClientCreator(config, null, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("singleConfig");
    }

    @Test
    void constructor_nullRedissonConfig_throwsNPE() {
        RedissonConfig.SingleConfig singleConfig = new RedissonConfig.SingleConfig();
        singleConfig.setAddress("redis://127.0.0.1:6379");
        assertThatThrownBy(() -> new SingleRedissonClientCreator(null, singleConfig, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("redissonConfig");
    }

    @Test
    void creator_withCustomizer_customizerCalled() {
        try (MockedStatic<Redisson> redissonMock = mockStatic(Redisson.class)) {
            redissonMock
                    .when(() -> Redisson.create(any(Config.class)))
                    .thenThrow(new RuntimeException("mocked - no real Redis connection"));

            RedissonConfig redissonConfig = new RedissonConfig();
            RedissonConfig.SingleConfig singleConfig = new RedissonConfig.SingleConfig();
            singleConfig.setAddress("redis://127.0.0.1:6399");
            boolean[] called = {false};
            SingleRedissonClientCreator creator =
                    new SingleRedissonClientCreator(redissonConfig, singleConfig, cfg -> called[0] = true);
            try {
                creator.creator();
            } catch (Exception ignored) {
            }
            assertThat(called[0]).isTrue();
        }
    }
}
