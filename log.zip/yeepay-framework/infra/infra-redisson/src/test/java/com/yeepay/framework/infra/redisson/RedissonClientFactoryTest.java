package com.yeepay.framework.infra.redisson;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import java.time.Duration;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.redisson.Redisson;
import org.redisson.config.Config;
import org.redisson.config.ReadMode;
import org.redisson.config.ShardedSubscriptionMode;
import org.redisson.config.SubscriptionMode;

class RedissonClientFactoryTest {

    private MockedStatic<Redisson> redissonMock;

    @BeforeEach
    void setUp() {
        redissonMock = mockStatic(Redisson.class);
        redissonMock
                .when(() -> Redisson.create(any(Config.class)))
                .thenThrow(new RuntimeException("mocked - no real Redis connection"));
    }

    @AfterEach
    void tearDown() {
        redissonMock.close();
    }

    @Test
    void create_noModeConfigured_throwsIllegalArgument() {
        RedissonConfig config = new RedissonConfig();
        assertThatThrownBy(() -> RedissonClientFactory.create(config))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Invalid RedissonConfig");
    }

    @Test
    void create_noModeWithCustomizer_throwsIllegalArgument() {
        RedissonConfig config = new RedissonConfig();
        assertThatThrownBy(() -> RedissonClientFactory.create(config, c -> {}))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void create_singleMode_throwsOnNoServerAvailable() {
        RedissonConfig config = buildFastFailSingleConfig();
        assertThatThrownBy(() -> RedissonClientFactory.create(config)).isInstanceOf(Throwable.class);
    }

    @Test
    void createSingle_directCall_throwsOnNoServerAvailable() {
        RedissonConfig config = buildFastFailSingleConfig();
        assertThatThrownBy(() -> RedissonClientFactory.createSingle(config, config.getSingle()))
                .isInstanceOf(Throwable.class);
    }

    @Test
    void createSingle_withCustomizer_customizerCalledBeforeException() {
        RedissonConfig config = buildFastFailSingleConfig();
        boolean[] called = {false};
        assertThatThrownBy(
                        () -> RedissonClientFactory.createSingle(config, config.getSingle(), cfg -> called[0] = true))
                .isInstanceOf(Throwable.class);
    }

    @Test
    void createSentinel_throwsOnNoSentinelAvailable() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.SentinelConfig sentinel = new RedissonConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.getSentinelAddresses().add("redis://127.0.0.1:26399");
        config.setSentinel(sentinel);
        assertThatThrownBy(() -> RedissonClientFactory.createSentinel(config, config.getSentinel()))
                .isInstanceOf(Throwable.class);
    }

    @Test
    void createCluster_throwsOnNoClusterAvailable() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.ClusterConfig cluster = new RedissonConfig.ClusterConfig();
        cluster.getNodeAddresses().add("redis://127.0.0.1:7399");
        config.setCluster(cluster);
        assertThatThrownBy(() -> RedissonClientFactory.createCluster(config, config.getCluster()))
                .isInstanceOf(Throwable.class);
    }

    // ==================== loadConfig — new format ====================

    @Test
    void loadConfig_singleMode_parsesAllProperties() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-single.properties");

        assertThat(config.getThreads()).isEqualTo(16);
        assertThat(config.getNettyThreads()).isEqualTo(32);

        RedissonConfig.SingleConfig single = config.getSingle();
        assertThat(single).isNotNull();
        assertThat(single.getAddress()).isEqualTo("redis://10.0.0.1:6379");
        assertThat(single.getPassword()).isEqualTo("testpass");
        assertThat(single.getUsername()).isEqualTo("testuser");
        assertThat(single.getDatabase()).isEqualTo(2);
        assertThat(single.getClientName()).isEqualTo("myClient");

        // Connection
        RedissonConfig.ConnectionConfig conn = single.getConnection();
        assertThat(conn.getConnectTimeout()).isEqualTo(Duration.ofMillis(500));
        assertThat(conn.getTimeout()).isEqualTo(Duration.ofMillis(200));
        assertThat(conn.getIdleTimeout()).isEqualTo(Duration.ofMillis(10000));
        assertThat(conn.getRetryAttempts()).isEqualTo(5);
        assertThat(conn.getPingInterval()).isEqualTo(Duration.ofMillis(3000));

        // Subscription
        RedissonConfig.SubscriptionConfig sub = single.getSubscription();
        assertThat(sub.getTimeout()).isEqualTo(Duration.ofMillis(5000));
        assertThat(sub.getPerConnection()).isEqualTo(10);

        // TCP
        RedissonConfig.TcpConfig tcp = single.getTcp();
        assertThat(tcp.isNoDelay()).isTrue();
        assertThat(tcp.isKeepAlive()).isTrue();
        assertThat(tcp.getKeepAliveCount()).isEqualTo(5);
        assertThat(tcp.getKeepAliveIdle()).isEqualTo(Duration.ofMillis(15000));
        assertThat(tcp.getKeepAliveInterval()).isEqualTo(Duration.ofMillis(10000));
        assertThat(tcp.getUserTimeout()).isEqualTo(Duration.ofMillis(2000));

        // Pool
        assertThat(single.getPool().getPoolSize()).isEqualTo(64);
        assertThat(single.getPool().getMinimumIdleSize()).isEqualTo(24);
        assertThat(single.getPool().getReconnectionInterval()).isEqualTo(Duration.ofMillis(5000));

        // Subscription Pool
        assertThat(single.getSubscriptionPool().getPoolSize()).isEqualTo(50);
        assertThat(single.getSubscriptionPool().getMinimumIdleSize()).isEqualTo(10);
        assertThat(single.getSubscriptionPool().getReconnectionInterval()).isEqualTo(Duration.ofMillis(3000));

        // DNS Monitoring
        assertThat(single.getDnsMonitoring().getInterval()).isEqualTo(Duration.ofMillis(8000));

        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_sentinelMode_parsesAllProperties() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-sentinel.properties");

        assertThat(config.getThreads()).isEqualTo(8);
        assertThat(config.getNettyThreads()).isEqualTo(16);

        RedissonConfig.SentinelConfig sentinel = config.getSentinel();
        assertThat(sentinel).isNotNull();
        assertThat(sentinel.getMasterName()).isEqualTo("mymaster");
        assertThat(sentinel.getSentinelAddresses()).containsExactly("redis://10.0.0.1:26379", "redis://10.0.0.2:26379");
        assertThat(sentinel.getPassword()).isEqualTo("sentinelpass");
        assertThat(sentinel.getUsername()).isEqualTo("sentuser");
        assertThat(sentinel.getDatabase()).isEqualTo(1);
        assertThat(sentinel.getSentinelPassword()).isEqualTo("sentpass");
        assertThat(sentinel.getSentinelUsername()).isEqualTo("sentadmin");
        assertThat(sentinel.getClientName()).isEqualTo("sentClient");

        // Sentinel-specific
        assertThat(sentinel.isCheckSentinelsList()).isFalse();
        assertThat(sentinel.isCheckSlaveStatusWithSyncing()).isFalse();
        assertThat(sentinel.isSentinelsDiscovery()).isFalse();

        // Connection
        RedissonConfig.ConnectionConfig conn = sentinel.getConnection();
        assertThat(conn.getConnectTimeout()).isEqualTo(Duration.ofMillis(600));
        assertThat(conn.getTimeout()).isEqualTo(Duration.ofMillis(300));
        assertThat(conn.getIdleTimeout()).isEqualTo(Duration.ofMillis(15000));
        assertThat(conn.getRetryAttempts()).isEqualTo(4);
        assertThat(conn.getPingInterval()).isEqualTo(Duration.ofMillis(4000));

        // Subscription
        assertThat(sentinel.getSubscription().getTimeout()).isEqualTo(Duration.ofMillis(6000));
        assertThat(sentinel.getSubscription().getPerConnection()).isEqualTo(8);

        // TCP
        assertThat(sentinel.getTcp().isNoDelay()).isTrue();
        assertThat(sentinel.getTcp().isKeepAlive()).isTrue();
        assertThat(sentinel.getTcp().getKeepAliveCount()).isEqualTo(8);

        // Master Pool
        assertThat(sentinel.getMasterPool().getPoolSize()).isEqualTo(32);
        assertThat(sentinel.getMasterPool().getMinimumIdleSize()).isEqualTo(16);
        assertThat(sentinel.getMasterPool().getReconnectionInterval()).isEqualTo(Duration.ofMillis(4000));

        // Slave Pool
        assertThat(sentinel.getSlavePool().getPoolSize()).isEqualTo(64);
        assertThat(sentinel.getSlavePool().getMinimumIdleSize()).isEqualTo(24);
        assertThat(sentinel.getSlavePool().getReconnectionInterval()).isEqualTo(Duration.ofMillis(5000));

        // Subscription Pool
        assertThat(sentinel.getSubscriptionPool().getPoolSize()).isEqualTo(50);
        assertThat(sentinel.getSubscriptionPool().getMinimumIdleSize()).isEqualTo(12);
        assertThat(sentinel.getSubscriptionPool().getReconnectionInterval()).isEqualTo(Duration.ofMillis(3000));

        // Read/Write Mode
        assertThat(sentinel.getReadWriteMode().getReadMode()).isEqualTo(ReadMode.MASTER_SLAVE);
        assertThat(sentinel.getReadWriteMode().getSubscriptionMode()).isEqualTo(SubscriptionMode.SLAVE);

        // DNS & Scan
        assertThat(sentinel.getDnsMonitoring().getInterval()).isEqualTo(Duration.ofMillis(10000));
        assertThat(sentinel.getScanInterval()).isEqualTo(Duration.ofMillis(2000));

        assertThat(config.getSingle()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_clusterMode_parsesAllProperties() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-cluster.properties");

        assertThat(config.getThreads()).isEqualTo(16);
        assertThat(config.getNettyThreads()).isEqualTo(32);

        RedissonConfig.ClusterConfig cluster = config.getCluster();
        assertThat(cluster).isNotNull();
        assertThat(cluster.getNodeAddresses())
                .containsExactly("redis://10.0.0.1:7000", "redis://10.0.0.2:7001", "redis://10.0.0.3:7002");
        assertThat(cluster.getPassword()).isEqualTo("clusterpass");
        assertThat(cluster.getUsername()).isEqualTo("clusteruser");
        assertThat(cluster.getDatabase()).isEqualTo(0);
        assertThat(cluster.getClientName()).isEqualTo("clusterClient");

        // Cluster-specific
        assertThat(cluster.isCheckSlotsCoverage()).isFalse();
        assertThat(cluster.isCheckMasterLinkStatus()).isTrue();
        assertThat(cluster.getShardedSubscriptionMode()).isEqualTo(ShardedSubscriptionMode.AUTO);

        // Connection
        RedissonConfig.ConnectionConfig conn = cluster.getConnection();
        assertThat(conn.getConnectTimeout()).isEqualTo(Duration.ofMillis(700));
        assertThat(conn.getTimeout()).isEqualTo(Duration.ofMillis(150));
        assertThat(conn.getIdleTimeout()).isEqualTo(Duration.ofMillis(12000));
        assertThat(conn.getRetryAttempts()).isEqualTo(3);
        assertThat(conn.getPingInterval()).isEqualTo(Duration.ofMillis(6000));

        // Subscription
        assertThat(cluster.getSubscription().getTimeout()).isEqualTo(Duration.ofMillis(8000));
        assertThat(cluster.getSubscription().getPerConnection()).isEqualTo(6);

        // TCP
        assertThat(cluster.getTcp().isNoDelay()).isFalse();
        assertThat(cluster.getTcp().isKeepAlive()).isTrue();

        // Master Pool
        assertThat(cluster.getMasterPool().getPoolSize()).isEqualTo(48);
        assertThat(cluster.getMasterPool().getMinimumIdleSize()).isEqualTo(20);

        // Slave Pool
        assertThat(cluster.getSlavePool().getPoolSize()).isEqualTo(64);
        assertThat(cluster.getSlavePool().getMinimumIdleSize()).isEqualTo(32);

        // Subscription Pool
        assertThat(cluster.getSubscriptionPool().getPoolSize()).isEqualTo(32);
        assertThat(cluster.getSubscriptionPool().getMinimumIdleSize()).isEqualTo(8);

        // Read/Write Mode
        assertThat(cluster.getReadWriteMode().getReadMode()).isEqualTo(ReadMode.MASTER);
        assertThat(cluster.getReadWriteMode().getSubscriptionMode()).isEqualTo(SubscriptionMode.MASTER);

        // DNS & Scan
        assertThat(cluster.getDnsMonitoring().getInterval()).isEqualTo(Duration.ofMillis(7000));
        assertThat(cluster.getScanInterval()).isEqualTo(Duration.ofMillis(3000));

        assertThat(config.getSingle()).isNull();
        assertThat(config.getSentinel()).isNull();
    }

    // ==================== loadConfig — legacy format ====================

    @Test
    void loadConfig_legacySentinelMode_parsesCorrectly() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-legacy-sentinel.properties");

        assertThat(config.getSentinel()).isNotNull();
        assertThat(config.getSentinel().getMasterName()).isEqualTo("mymaster");
        assertThat(config.getSentinel().getSentinelAddresses())
                .containsExactly("redis://10.0.0.1:26379", "redis://10.0.0.2:26379", "redis://10.0.0.3:26379");
        assertThat(config.getSentinel().getPassword()).isEqualTo("legacypass");
        assertThat(config.getSentinel().getUsername()).isEqualTo("legacyuser");
        assertThat(config.getSentinel().getDatabase()).isEqualTo(1);
        assertThat(config.getSingle()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_legacyClusterMode_parsesCorrectly() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-legacy-cluster.properties");

        assertThat(config.getCluster()).isNotNull();
        assertThat(config.getCluster().getNodeAddresses())
                .containsExactly("redis://10.0.0.1:7000", "redis://10.0.0.2:7001", "redis://10.0.0.3:7002");
        assertThat(config.getCluster().getPassword()).isEqualTo("legacypass");
        assertThat(config.getCluster().getDatabase()).isEqualTo(0);
        assertThat(config.getSingle()).isNull();
        assertThat(config.getSentinel()).isNull();
    }

    @Test
    void loadConfig_legacyAutoDetectSingle_parsesCorrectly() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-legacy-auto-single.properties");

        assertThat(config.getSingle()).isNotNull();
        assertThat(config.getSingle().getAddress()).isEqualTo("redis://10.0.0.1:6379");
        assertThat(config.getSingle().getPassword()).isEqualTo("legacypass");
        assertThat(config.getSingle().getDatabase()).isEqualTo(0);
        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_legacyAutoDetectSentinel_parsesCorrectly() {
        RedissonConfig config = RedissonClientFactory.loadConfig("testcfg", "redisson-legacy-auto-sentinel.properties");

        assertThat(config.getSentinel()).isNotNull();
        assertThat(config.getSentinel().getMasterName()).isEqualTo("mymaster");
        assertThat(config.getSentinel().getSentinelAddresses())
                .containsExactly("redis://10.0.0.1:26379", "redis://10.0.0.2:26379");
        assertThat(config.getSentinel().getPassword()).isEqualTo("legacypass");
        assertThat(config.getSentinel().getDatabase()).isEqualTo(1);
        assertThat(config.getSingle()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void loadConfig_fileNotFound_throwsIllegalArgument() {
        assertThatThrownBy(() -> RedissonClientFactory.loadConfig("testcfg", "nonexistent.properties"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void create_sentinelMode_dispatchesToSentinelCreator() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.SentinelConfig sentinel = new RedissonConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.getSentinelAddresses().add("redis://127.0.0.1:26399");
        config.setSentinel(sentinel);
        assertThatThrownBy(() -> RedissonClientFactory.create(config)).isInstanceOf(Throwable.class);
    }

    @Test
    void create_clusterMode_dispatchesToClusterCreator() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.ClusterConfig cluster = new RedissonConfig.ClusterConfig();
        cluster.getNodeAddresses().add("redis://127.0.0.1:7399");
        config.setCluster(cluster);
        assertThatThrownBy(() -> RedissonClientFactory.create(config)).isInstanceOf(Throwable.class);
    }

    @Test
    void createSentinel_withCustomizer_throwsOnNoServer() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.SentinelConfig sentinel = new RedissonConfig.SentinelConfig();
        sentinel.setMasterName("mymaster");
        sentinel.getSentinelAddresses().add("redis://127.0.0.1:26399");
        assertThatThrownBy(() -> RedissonClientFactory.createSentinel(config, sentinel, c -> {}))
                .isInstanceOf(Throwable.class);
    }

    @Test
    void createCluster_withCustomizer_throwsOnNoServer() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.ClusterConfig cluster = new RedissonConfig.ClusterConfig();
        cluster.getNodeAddresses().add("redis://127.0.0.1:7399");
        assertThatThrownBy(() -> RedissonClientFactory.createCluster(config, cluster, c -> {}))
                .isInstanceOf(Throwable.class);
    }

    // ==================== helpers ====================

    private RedissonConfig buildFastFailConfig() {
        return new RedissonConfig();
    }

    private RedissonConfig buildFastFailSingleConfig() {
        RedissonConfig config = buildFastFailConfig();
        RedissonConfig.SingleConfig single = new RedissonConfig.SingleConfig();
        single.setAddress("redis://127.0.0.1:6399");
        single.getConnection().setConnectTimeout(Duration.ofMillis(100));
        single.getConnection().setRetryAttempts(0);
        config.setSingle(single);
        return config;
    }
}
