package com.yeepay.framework.infra.redisson.cilent;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import com.yeepay.framework.infra.redisson.enums.CodecType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.redisson.Redisson;
import org.redisson.config.Config;

@ExtendWith(MockitoExtension.class)
class AbstractRedissonClientCreatorTest {

    @Mock
    private RedissonConfigCustomizer customizer;

    private MockedStatic<Redisson> redissonMock;

    @BeforeEach
    void setUp() {
        redissonMock = mockStatic(Redisson.class);
        redissonMock
                .when(() -> Redisson.create(any(Config.class)))
                .thenThrow(new RuntimeException("mocked - no real Redis connection"));
    }

    @AfterEach
    void tearDown() {
        redissonMock.close();
    }

    private static class TestCreator extends AbstractRedissonClientCreator {
        private Config capturedConfig;

        TestCreator(RedissonConfig config, RedissonConfigCustomizer customizer) {
            super(config, customizer);
        }

        @Override
        protected void setConfig(Config config) {
            this.capturedConfig = config;
            config.useSingleServer().setAddress("redis://127.0.0.1:6399");
        }

        Config getCapturedConfig() {
            return capturedConfig;
        }
    }

    @Test
    void constructor_nullConfig_throwsNPE() {
        assertThatThrownBy(() -> new TestCreator(null, null)).isInstanceOf(NullPointerException.class);
    }

    @Test
    void creator_withCustomizer_customizerCalledBeforeConnect() {
        RedissonConfig config = buildFastFailConfig();
        TestCreator creator = new TestCreator(config, customizer);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
        verify(customizer).customize(any(Config.class));
    }

    @Test
    void creator_buildsCommonConfig_threadsSet() {
        RedissonConfig config = buildFastFailConfig();
        config.setThreads(8);
        config.setNettyThreads(16);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
        assertThat(creator.getCapturedConfig()).isNotNull();
    }

    @Test
    void creator_codecString_setsStringCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.STRING);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecJsonJackson_setsJsonCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.JSON_JACKSON);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecKryo5_setsKryoCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.KRYO5);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecMsgpack_setsMsgpackCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.MSGPACK_JACKSON);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecCbor_setsCborCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.CBOR_JACKSON);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecSmile_setsSmileCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.SMILE_JACKSON);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecJavaSerialization_setsSerializationCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.JAVA_SERIALIZATION);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecLz4_setsLz4Codec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.LZ4);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecByteArray_setsByteArrayCodec() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.BYTE_ARRAY);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_nullCodec_noCodecSet() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(null);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    @Test
    void creator_codecFst_fallsThroughToDefault() {
        RedissonConfig config = buildFastFailConfig();
        config.setCodec(CodecType.FST);
        TestCreator creator = new TestCreator(config, null);
        assertThatThrownBy(creator::creator).isInstanceOf(Throwable.class);
    }

    private RedissonConfig buildFastFailConfig() {
        return new RedissonConfig();
    }
}
