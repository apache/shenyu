package com.yeepay.framework.infra.redisson.enums;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class CodecTypeTest {

    @Test
    void values_containsAllTypes() {
        CodecType[] values = CodecType.values();
        assertThat(values).hasSize(10);
        assertThat(values)
                .containsExactly(
                        CodecType.STRING,
                        CodecType.JSON_JACKSON,
                        CodecType.MSGPACK_JACKSON,
                        CodecType.CBOR_JACKSON,
                        CodecType.SMILE_JACKSON,
                        CodecType.KRYO5,
                        CodecType.FST,
                        CodecType.JAVA_SERIALIZATION,
                        CodecType.LZ4,
                        CodecType.BYTE_ARRAY);
    }

    @Test
    void valueOf_validNames() {
        assertThat(CodecType.valueOf("STRING")).isEqualTo(CodecType.STRING);
        assertThat(CodecType.valueOf("JSON_JACKSON")).isEqualTo(CodecType.JSON_JACKSON);
        assertThat(CodecType.valueOf("MSGPACK_JACKSON")).isEqualTo(CodecType.MSGPACK_JACKSON);
        assertThat(CodecType.valueOf("CBOR_JACKSON")).isEqualTo(CodecType.CBOR_JACKSON);
        assertThat(CodecType.valueOf("SMILE_JACKSON")).isEqualTo(CodecType.SMILE_JACKSON);
        assertThat(CodecType.valueOf("KRYO5")).isEqualTo(CodecType.KRYO5);
        assertThat(CodecType.valueOf("FST")).isEqualTo(CodecType.FST);
        assertThat(CodecType.valueOf("JAVA_SERIALIZATION")).isEqualTo(CodecType.JAVA_SERIALIZATION);
        assertThat(CodecType.valueOf("LZ4")).isEqualTo(CodecType.LZ4);
        assertThat(CodecType.valueOf("BYTE_ARRAY")).isEqualTo(CodecType.BYTE_ARRAY);
    }

    @Test
    void valueOf_invalidName_throwsIllegalArgument() {
        assertThatThrownBy(() -> CodecType.valueOf("INVALID")).isInstanceOf(IllegalArgumentException.class);
    }
}
