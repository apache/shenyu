package com.yeepay.framework.infra.redisson.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.infra.redisson.enums.CodecType;
import java.time.Duration;
import org.junit.jupiter.api.Test;
import org.redisson.config.Protocol;
import org.redisson.config.ReadMode;
import org.redisson.config.ShardedSubscriptionMode;
import org.redisson.config.SubscriptionMode;
import org.redisson.config.TransportMode;

class RedissonConfigTest {

    @Test
    void defaults_topLevel() {
        RedissonConfig config = new RedissonConfig();
        assertThat(config.getThreads()).isEqualTo(16);
        assertThat(config.getNettyThreads()).isEqualTo(32);
        assertThat(config.getTransportMode()).isEqualTo(TransportMode.NIO);
        assertThat(config.getCodec()).isEqualTo(CodecType.KRYO5);
        assertThat(config.getProtocol()).isEqualTo(Protocol.RESP2);
        assertThat(config.getLock()).isNotNull();
        assertThat(config.getPubSub()).isNotNull();
        assertThat(config.getCleanup()).isNotNull();
        assertThat(config.getMisc()).isNotNull();
        assertThat(config.getSingle()).isNull();
        assertThat(config.getSentinel()).isNull();
        assertThat(config.getCluster()).isNull();
    }

    @Test
    void defaults_lockConfig() {
        RedissonConfig.LockConfig lock = new RedissonConfig.LockConfig();
        assertThat(lock.getWatchdogTimeout()).isEqualTo(Duration.ofSeconds(30));
        assertThat(lock.getWatchdogBatchSize()).isEqualTo(100);
        assertThat(lock.getFairWaitTimeout()).isEqualTo(Duration.ofMinutes(5));
        assertThat(lock.isCheckSyncedSlaves()).isTrue();
        assertThat(lock.getSlavesSyncTimeout()).isEqualTo(Duration.ofMinutes(1));
    }

    @Test
    void defaults_pubSubConfig() {
        RedissonConfig.PubSubConfig pubSub = new RedissonConfig.PubSubConfig();
        assertThat(pubSub.isKeepOrder()).isTrue();
        assertThat(pubSub.getReliableTopicWatchdogTimeout()).isEqualTo(Duration.ofMillis(10));
    }

    @Test
    void defaults_cleanupConfig() {
        RedissonConfig.CleanupConfig cleanup = new RedissonConfig.CleanupConfig();
        assertThat(cleanup.getMinDelay()).isEqualTo(Duration.ofSeconds(5));
        assertThat(cleanup.getMaxDelay()).isEqualTo(Duration.ofMinutes(30));
        assertThat(cleanup.getKeysAmount()).isEqualTo(100);
    }

    @Test
    void defaults_miscConfig() {
        RedissonConfig.MiscConfig misc = new RedissonConfig.MiscConfig();
        assertThat(misc.isReferenceEnabled()).isTrue();
        assertThat(misc.isUseScriptCache()).isTrue();
        assertThat(misc.isLazyInitialization()).isFalse();
    }

    @Test
    void defaults_connectionConfig() {
        RedissonConfig.ConnectionConfig conn = new RedissonConfig.ConnectionConfig();
        assertThat(conn.getIdleTimeout()).isEqualTo(Duration.ofSeconds(10));
        assertThat(conn.getConnectTimeout()).isEqualTo(Duration.ofMillis(500));
        assertThat(conn.getTimeout()).isEqualTo(Duration.ofMillis(100));
        assertThat(conn.getRetryAttempts()).isEqualTo(3);
        assertThat(conn.getPingInterval()).isEqualTo(Duration.ofSeconds(5));
    }

    @Test
    void defaults_subscriptionConfig() {
        RedissonConfig.SubscriptionConfig sub = new RedissonConfig.SubscriptionConfig();
        assertThat(sub.getTimeout()).isEqualTo(Duration.ofMillis(7500));
        assertThat(sub.getPerConnection()).isEqualTo(5);
    }

    @Test
    void defaults_tcpConfig() {
        RedissonConfig.TcpConfig tcp = new RedissonConfig.TcpConfig();
        assertThat(tcp.isNoDelay()).isTrue();
        assertThat(tcp.isKeepAlive()).isFalse();
        assertThat(tcp.getKeepAliveCount()).isEqualTo(10);
        assertThat(tcp.getKeepAliveIdle()).isEqualTo(Duration.ofSeconds(30));
        assertThat(tcp.getKeepAliveInterval()).isEqualTo(Duration.ofSeconds(30));
        assertThat(tcp.getUserTimeout()).isEqualTo(Duration.ofSeconds(1));
    }

    @Test
    void defaults_connectionPoolConfig() {
        RedissonConfig.ConnectionPoolConfig pool = new RedissonConfig.ConnectionPoolConfig();
        assertThat(pool.getMinimumIdleSize()).isEqualTo(24);
        assertThat(pool.getPoolSize()).isEqualTo(64);
        assertThat(pool.getReconnectionInterval()).isEqualTo(Duration.ofSeconds(3));
    }

    @Test
    void defaults_readWriteModeConfig() {
        RedissonConfig.ReadWriteModeConfig rwm = new RedissonConfig.ReadWriteModeConfig();
        assertThat(rwm.getReadMode()).isEqualTo(ReadMode.SLAVE);
        assertThat(rwm.getSubscriptionMode()).isEqualTo(SubscriptionMode.MASTER);
    }

    @Test
    void defaults_dnsMonitoringConfig() {
        RedissonConfig.DnsMonitoringConfig dns = new RedissonConfig.DnsMonitoringConfig();
        assertThat(dns.getInterval()).isEqualTo(Duration.ofSeconds(5));
    }

    @Test
    void defaults_baseConfig() {
        RedissonConfig.BaseConfig base = new RedissonConfig.BaseConfig();
        assertThat(base.getConnection()).isNotNull();
        assertThat(base.getSubscription()).isNotNull();
        assertThat(base.getTcp()).isNotNull();
        assertThat(base.getClientName()).isNull();
        assertThat(base.getUsername()).isNull();
        assertThat(base.getPassword()).isNull();
        assertThat(base.getDatabase()).isZero();
        assertThat(base.getClientBeanName()).isNull();
        assertThat(base.getDataManagerBeanName()).isNull();
        assertThat(base.getLockBeanName()).isNull();
    }

    @Test
    void defaults_singleConfig() {
        RedissonConfig.SingleConfig single = new RedissonConfig.SingleConfig();
        assertThat(single.getAddress()).isNull();
        assertThat(single.getPool()).isNotNull();
        assertThat(single.getSubscriptionPool()).isNotNull();
        assertThat(single.getDnsMonitoring()).isNotNull();
    }

    @Test
    void defaults_sentinelConfig() {
        RedissonConfig.SentinelConfig sentinel = new RedissonConfig.SentinelConfig();
        assertThat(sentinel.getSentinelAddresses()).isEmpty();
        assertThat(sentinel.getMasterName()).isNull();
        assertThat(sentinel.getSentinelUsername()).isNull();
        assertThat(sentinel.getSentinelPassword()).isNull();
        assertThat(sentinel.isCheckSentinelsList()).isTrue();
        assertThat(sentinel.isCheckSlaveStatusWithSyncing()).isTrue();
        assertThat(sentinel.isSentinelsDiscovery()).isTrue();
    }

    @Test
    void defaults_clusterConfig() {
        RedissonConfig.ClusterConfig cluster = new RedissonConfig.ClusterConfig();
        assertThat(cluster.getNodeAddresses()).isEmpty();
        assertThat(cluster.isCheckSlotsCoverage()).isTrue();
        assertThat(cluster.isCheckMasterLinkStatus()).isFalse();
        assertThat(cluster.getShardedSubscriptionMode()).isEqualTo(ShardedSubscriptionMode.AUTO);
    }

    @Test
    void defaults_baseMasterSlaveConfig() {
        RedissonConfig.BaseMasterSlaveConfig bms = new RedissonConfig.BaseMasterSlaveConfig();
        assertThat(bms.getMasterPool()).isNotNull();
        assertThat(bms.getSlavePool()).isNotNull();
        assertThat(bms.getSubscriptionPool()).isNotNull();
        assertThat(bms.getReadWriteMode()).isNotNull();
        assertThat(bms.getDnsMonitoring()).isNotNull();
        assertThat(bms.getScanInterval()).isEqualTo(Duration.ofSeconds(1));
    }

    @Test
    void setters_topLevel() {
        RedissonConfig config = new RedissonConfig();
        config.setThreads(8);
        config.setNettyThreads(16);
        assertThat(config.getThreads()).isEqualTo(8);
        assertThat(config.getNettyThreads()).isEqualTo(16);
    }
}
