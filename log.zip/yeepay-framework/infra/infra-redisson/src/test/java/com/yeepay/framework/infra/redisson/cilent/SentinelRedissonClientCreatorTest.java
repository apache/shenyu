package com.yeepay.framework.infra.redisson.cilent;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import org.junit.jupiter.api.Test;

class SentinelRedissonClientCreatorTest {

    @Test
    void constructor_nullSentinelConfig_throwsNPE() {
        RedissonConfig config = new RedissonConfig();
        assertThatThrownBy(() -> new SentinelRedissonClientCreator(config, null, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("sentinelConfig");
    }

    @Test
    void constructor_nullRedissonConfig_throwsNPE() {
        RedissonConfig.SentinelConfig sentinelConfig = new RedissonConfig.SentinelConfig();
        assertThatThrownBy(() -> new SentinelRedissonClientCreator(null, sentinelConfig, null))
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("redissonConfig");
    }

    @Test
    void constructor_validConfig_succeeds() {
        RedissonConfig config = new RedissonConfig();
        RedissonConfig.SentinelConfig sentinelConfig = new RedissonConfig.SentinelConfig();
        sentinelConfig.setMasterName("mymaster");
        SentinelRedissonClientCreator creator = new SentinelRedissonClientCreator(config, sentinelConfig, null);
        org.assertj.core.api.Assertions.assertThat(creator).isNotNull();
    }
}
