package com.yeepay.framework.infra.redisson.cilent;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.ClusterConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import java.util.Objects;
import org.redisson.config.ClusterServersConfig;
import org.redisson.config.Config;

/**
 * The type Cluster redisson client creator.
 */
public class ClusterRedissonClientCreator extends AbstractRedissonClientCreator {

    private final ClusterConfig clusterConfig;

    /**
     * Instantiates a new Cluster redisson client creator.
     *
     * @param redissonConfig the redisson config
     * @param clusterConfig the cluster config
     * @param customizer the customizer
     */
    public ClusterRedissonClientCreator(
            final RedissonConfig redissonConfig,
            ClusterConfig clusterConfig,
            final RedissonConfigCustomizer customizer) {
        super(redissonConfig, customizer);
        this.clusterConfig = clusterConfig;
        Objects.requireNonNull(clusterConfig, "clusterConfig is null");
    }

    @Override
    protected void setConfig(final Config config) {
        ClusterServersConfig clusterServersConfig = config.useClusterServers();
        clusterServersConfig
                .setScanInterval((int) clusterConfig.getScanInterval().toMillis())
                .setCheckSlotsCoverage(clusterConfig.isCheckSlotsCoverage())
                .setCheckMasterLinkStatus(clusterConfig.isCheckMasterLinkStatus())
                .setShardedSubscriptionMode(clusterConfig.getShardedSubscriptionMode());

        // 主节点连接池配置
        clusterServersConfig
                .setMasterConnectionMinimumIdleSize(
                        clusterConfig.getMasterPool().getMinimumIdleSize())
                .setMasterConnectionPoolSize(clusterConfig.getMasterPool().getPoolSize());

        // 从节点连接池配置
        clusterServersConfig
                .setSlaveConnectionMinimumIdleSize(clusterConfig.getSlavePool().getMinimumIdleSize())
                .setSlaveConnectionPoolSize(clusterConfig.getSlavePool().getPoolSize())
                .setFailedSlaveReconnectionInterval((int)
                        clusterConfig.getSlavePool().getReconnectionInterval().toMillis());

        // 读写模式配置
        clusterServersConfig
                .setReadMode(clusterConfig.getReadWriteMode().getReadMode())
                .setSubscriptionMode(clusterConfig.getReadWriteMode().getSubscriptionMode());

        // 订阅连接池配置
        clusterServersConfig
                .setSubscriptionConnectionMinimumIdleSize(
                        clusterConfig.getSubscriptionPool().getMinimumIdleSize())
                .setSubscriptionConnectionPoolSize(
                        clusterConfig.getSubscriptionPool().getPoolSize());

        // DNS 监控配置
        clusterServersConfig.setDnsMonitoringInterval(
                clusterConfig.getDnsMonitoring().getInterval().toMillis());

        // 设置节点地址（此方法返回void）
        clusterServersConfig.setNodeAddresses(clusterConfig.getNodeAddresses());

        // 认证配置
        clusterServersConfig.setUsername(clusterConfig.getUsername()).setPassword(clusterConfig.getPassword());

        // 连接配置
        clusterServersConfig
                .setConnectTimeout(
                        (int) clusterConfig.getConnection().getConnectTimeout().toMillis())
                .setTimeout((int) clusterConfig.getConnection().getTimeout().toMillis())
                .setIdleConnectionTimeout(
                        (int) clusterConfig.getConnection().getIdleTimeout().toMillis())
                .setRetryAttempts(clusterConfig.getConnection().getRetryAttempts())
                .setPingConnectionInterval(
                        (int) clusterConfig.getConnection().getPingInterval().toMillis());

        // TCP配置
        clusterServersConfig
                .setKeepAlive(clusterConfig.getTcp().isKeepAlive())
                .setTcpNoDelay(clusterConfig.getTcp().isNoDelay())
                .setTcpKeepAliveCount(clusterConfig.getTcp().getKeepAliveCount())
                .setTcpKeepAliveIdle(
                        (int) clusterConfig.getTcp().getKeepAliveIdle().toSeconds())
                .setTcpKeepAliveInterval(
                        (int) clusterConfig.getTcp().getKeepAliveInterval().toSeconds())
                .setTcpUserTimeout((int) clusterConfig.getTcp().getUserTimeout().toSeconds());

        // 订阅配置
        clusterServersConfig
                .setSubscriptionTimeout(
                        (int) clusterConfig.getSubscription().getTimeout().toMillis())
                .setSubscriptionsPerConnection(clusterConfig.getSubscription().getPerConnection());

        // 客户端配置
        clusterServersConfig.setClientName(clusterConfig.getClientName());
    }
}
