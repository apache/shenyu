package com.yeepay.framework.infra.redisson.cilent;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SingleConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import java.util.Objects;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;

/**
 * The type Single redisson client creator.
 */
public class SingleRedissonClientCreator extends AbstractRedissonClientCreator {

    private final SingleConfig singleConfig;

    /**
     * Instantiates a new Single redisson client creator.
     *
     * @param redissonConfig the redisson config
     * @param singleConfig the single config
     * @param customizer the customizer
     */
    public SingleRedissonClientCreator(
            final RedissonConfig redissonConfig,
            final SingleConfig singleConfig,
            final RedissonConfigCustomizer customizer) {
        super(redissonConfig, customizer);
        this.singleConfig = singleConfig;
        Objects.requireNonNull(singleConfig, "singleConfig is null");
    }

    @Override
    protected void setConfig(final Config config) {
        SingleServerConfig singleServerConfig = config.useSingleServer();
        singleServerConfig.setAddress(singleConfig.getAddress()).setDatabase(singleConfig.getDatabase());

        // 普通连接池配置
        singleServerConfig
                .setConnectionMinimumIdleSize(singleConfig.getPool().getMinimumIdleSize())
                .setConnectionPoolSize(singleConfig.getPool().getPoolSize());

        // 订阅连接池配置
        singleServerConfig
                .setSubscriptionConnectionMinimumIdleSize(
                        singleConfig.getSubscriptionPool().getMinimumIdleSize())
                .setSubscriptionConnectionPoolSize(
                        singleConfig.getSubscriptionPool().getPoolSize());

        // DNS 监控配置
        singleServerConfig
                .setDnsMonitoringInterval(
                        singleConfig.getDnsMonitoring().getInterval().toMillis())
                // 认证配置
                .setUsername(singleConfig.getUsername())
                .setPassword(singleConfig.getPassword())
                // 连接配置
                .setConnectTimeout(
                        (int) singleConfig.getConnection().getConnectTimeout().toMillis())
                .setTimeout((int) singleConfig.getConnection().getTimeout().toMillis())
                .setIdleConnectionTimeout(
                        (int) singleConfig.getConnection().getIdleTimeout().toMillis())
                .setRetryAttempts(singleConfig.getConnection().getRetryAttempts())
                .setPingConnectionInterval(
                        (int) singleConfig.getConnection().getPingInterval().toMillis())
                // TCP配置
                .setKeepAlive(singleConfig.getTcp().isKeepAlive())
                .setTcpNoDelay(singleConfig.getTcp().isNoDelay())
                .setTcpKeepAliveCount(singleConfig.getTcp().getKeepAliveCount())
                .setTcpKeepAliveIdle(
                        (int) singleConfig.getTcp().getKeepAliveIdle().toSeconds())
                .setTcpKeepAliveInterval(
                        (int) singleConfig.getTcp().getKeepAliveInterval().toSeconds())
                .setTcpUserTimeout((int) singleConfig.getTcp().getUserTimeout().toSeconds())
                // 订阅配置
                .setSubscriptionTimeout(
                        (int) singleConfig.getSubscription().getTimeout().toMillis())
                .setSubscriptionsPerConnection(singleConfig.getSubscription().getPerConnection())
                // 客户端配置
                .setClientName(singleConfig.getClientName());
    }
}
