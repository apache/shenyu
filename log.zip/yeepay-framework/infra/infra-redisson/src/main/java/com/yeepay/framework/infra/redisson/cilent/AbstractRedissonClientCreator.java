package com.yeepay.framework.infra.redisson.cilent;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import com.yeepay.framework.infra.redisson.enums.CodecType;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.ByteArrayCodec;
import org.redisson.client.codec.StringCodec;
import org.redisson.codec.CborJacksonCodec;
import org.redisson.codec.JsonJacksonCodec;
import org.redisson.codec.Kryo5Codec;
import org.redisson.codec.LZ4Codec;
import org.redisson.codec.MsgPackJacksonCodec;
import org.redisson.codec.SerializationCodec;
import org.redisson.codec.SmileJacksonCodec;
import org.redisson.config.Config;

/**
 * The type Abstract redisson client creator.
 */
@Slf4j
public abstract class AbstractRedissonClientCreator {

    private final RedissonConfig redissonConfig;

    private final RedissonConfigCustomizer customizer;

    public AbstractRedissonClientCreator(
            final RedissonConfig redissonConfig, final RedissonConfigCustomizer customizer) {
        Objects.requireNonNull(redissonConfig, "redissonConfig is null");
        this.redissonConfig = redissonConfig;
        this.customizer = customizer;
    }

    /**
     * Creator redisson client.
     *
     * @return the Redisson client
     */
    public RedissonClient creator() {
        Config config = buildByCommon();
        setConfig(config);
        if (Objects.nonNull(customizer)) {
            customizer.customize(config);
        }
        try {
            return Redisson.create(config);
        } catch (Exception e) {
            log.error("RedissonClient creat error", e);
            throw e;
        }
    }

    /**
     * Sets config.
     *
     * @param config the config
     */
    protected abstract void setConfig(Config config);

    private Config buildByCommon() {
        Config config = new Config();
        // 线程配置
        config.setNettyThreads(redissonConfig.getNettyThreads());
        config.setThreads(redissonConfig.getThreads());
        // 传输配置
        config.setTransportMode(redissonConfig.getTransportMode());
        // 分布式锁配置
        config.setLockWatchdogTimeout(
                redissonConfig.getLock().getWatchdogTimeout().toMillis());
        config.setLockWatchdogBatchSize(redissonConfig.getLock().getWatchdogBatchSize());
        config.setFairLockWaitTimeout(
                redissonConfig.getLock().getFairWaitTimeout().toMillis());
        config.setCheckLockSyncedSlaves(redissonConfig.getLock().isCheckSyncedSlaves());
        config.setSlavesSyncTimeout(
                redissonConfig.getLock().getSlavesSyncTimeout().toMillis());

        // 发布订阅配置
        config.setReliableTopicWatchdogTimeout(
                redissonConfig.getPubSub().getReliableTopicWatchdogTimeout().toMillis());
        config.setKeepPubSubOrder(redissonConfig.getPubSub().isKeepOrder());

        // 内存清理配置
        config.setMinCleanUpDelay(
                (int) redissonConfig.getCleanup().getMinDelay().toSeconds());
        config.setMaxCleanUpDelay(
                (int) redissonConfig.getCleanup().getMaxDelay().toSeconds());
        config.setCleanUpKeysAmount(redissonConfig.getCleanup().getKeysAmount());

        // 其他配置
        config.setReferenceEnabled(redissonConfig.getMisc().isReferenceEnabled());
        config.setUseScriptCache(redissonConfig.getMisc().isUseScriptCache());
        config.setLazyInitialization(redissonConfig.getMisc().isLazyInitialization());
        // 序列化配置
        config.setProtocol(redissonConfig.getProtocol());
        CodecType codecType = redissonConfig.getCodec();
        if (Objects.nonNull(codecType)) {
            switch (codecType) {
                case STRING:
                    config.setCodec(new StringCodec());
                    break;
                case JSON_JACKSON:
                    config.setCodec(new JsonJacksonCodec());
                    break;
                case MSGPACK_JACKSON:
                    config.setCodec(new MsgPackJacksonCodec());
                    break;
                case CBOR_JACKSON:
                    config.setCodec(new CborJacksonCodec());
                    break;
                case SMILE_JACKSON:
                    config.setCodec(new SmileJacksonCodec());
                    break;
                case KRYO5:
                    config.setCodec(new Kryo5Codec());
                    break;
                case JAVA_SERIALIZATION:
                    config.setCodec(new SerializationCodec());
                    break;
                case LZ4:
                    config.setCodec(new LZ4Codec());
                    break;
                case BYTE_ARRAY:
                    config.setCodec(new ByteArrayCodec());
                    break;
                default:
                    break;
            }
        }
        return config;
    }
}
