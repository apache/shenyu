package com.yeepay.framework.infra.redisson.config;

import org.redisson.config.Config;

/**
 * The interface redisson config customizer.
 */
public interface RedissonConfigCustomizer {

    /**
     * Customize redisson config.
     *
     * @param config the config
     */
    void customize(Config config);
}
