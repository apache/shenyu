package com.yeepay.framework.infra.redisson.cilent;

import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SentinelConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import java.util.Objects;
import org.redisson.config.Config;
import org.redisson.config.SentinelServersConfig;

/**
 * The type Sentinel redisson client creator.
 */
public class SentinelRedissonClientCreator extends AbstractRedissonClientCreator {

    private final SentinelConfig sentinelConfig;

    /**
     * Instantiates a new Sentinel redisson client creator.
     *
     * @param redissonConfig the redisson config
     * @param sentinelConfig the sentinel config
     * @param customizer the customizer
     */
    public SentinelRedissonClientCreator(
            final RedissonConfig redissonConfig,
            final SentinelConfig sentinelConfig,
            final RedissonConfigCustomizer customizer) {
        super(redissonConfig, customizer);
        Objects.requireNonNull(sentinelConfig, "sentinelConfig is null");
        this.sentinelConfig = sentinelConfig;
    }

    @Override
    protected void setConfig(final Config config) {
        SentinelServersConfig sentinelServersConfig = config.useSentinelServers();
        // 设置哨兵地址（此方法返回void）
        sentinelServersConfig.setSentinelAddresses(sentinelConfig.getSentinelAddresses());
        sentinelServersConfig
                .setUsername(sentinelConfig.getUsername())
                .setPassword(sentinelConfig.getPassword())
                .setScanInterval((int) sentinelConfig.getScanInterval().toMillis())
                .setMasterName(sentinelConfig.getMasterName())
                .setSentinelUsername(sentinelConfig.getSentinelUsername())
                .setSentinelPassword(sentinelConfig.getSentinelPassword())
                .setCheckSentinelsList(sentinelConfig.isCheckSentinelsList())
                .setCheckSlaveStatusWithSyncing(sentinelConfig.isCheckSlaveStatusWithSyncing())
                .setSentinelsDiscovery(sentinelConfig.isSentinelsDiscovery())
                .setDatabase(sentinelConfig.getDatabase());
        // 主节点连接池配置
        sentinelServersConfig
                .setMasterConnectionMinimumIdleSize(
                        sentinelConfig.getMasterPool().getMinimumIdleSize())
                .setMasterConnectionPoolSize(sentinelConfig.getMasterPool().getPoolSize());
        // 从节点连接池配置
        sentinelServersConfig
                .setSlaveConnectionMinimumIdleSize(sentinelConfig.getSlavePool().getMinimumIdleSize())
                .setSlaveConnectionPoolSize(sentinelConfig.getSlavePool().getPoolSize())
                .setFailedSlaveReconnectionInterval((int)
                        sentinelConfig.getSlavePool().getReconnectionInterval().toMillis())
                .setReadMode(sentinelConfig.getReadWriteMode().getReadMode());
        // 读写模式配置
        sentinelServersConfig.setSubscriptionMode(
                sentinelConfig.getReadWriteMode().getSubscriptionMode());
        // 订阅连接池配置
        sentinelServersConfig
                .setSubscriptionConnectionMinimumIdleSize(
                        sentinelConfig.getSubscriptionPool().getMinimumIdleSize())
                .setSubscriptionConnectionPoolSize(
                        sentinelConfig.getSubscriptionPool().getPoolSize());
        // DNS 监控配置
        sentinelServersConfig.setDnsMonitoringInterval(
                sentinelConfig.getDnsMonitoring().getInterval().toMillis());
        // 连接配置
        sentinelServersConfig
                .setConnectTimeout(
                        (int) sentinelConfig.getConnection().getConnectTimeout().toMillis())
                .setTimeout((int) sentinelConfig.getConnection().getTimeout().toMillis())
                .setIdleConnectionTimeout(
                        (int) sentinelConfig.getConnection().getIdleTimeout().toMillis())
                .setRetryAttempts(sentinelConfig.getConnection().getRetryAttempts())
                .setPingConnectionInterval(
                        (int) sentinelConfig.getConnection().getPingInterval().toMillis());
        // TCP配置
        sentinelServersConfig
                .setKeepAlive(sentinelConfig.getTcp().isKeepAlive())
                .setTcpNoDelay(sentinelConfig.getTcp().isNoDelay())
                .setTcpKeepAliveCount(sentinelConfig.getTcp().getKeepAliveCount())
                .setTcpKeepAliveIdle(
                        (int) sentinelConfig.getTcp().getKeepAliveIdle().toSeconds())
                .setTcpKeepAliveInterval(
                        (int) sentinelConfig.getTcp().getKeepAliveInterval().toSeconds())
                .setTcpUserTimeout(
                        (int) sentinelConfig.getTcp().getUserTimeout().toSeconds());
        // 订阅配置
        sentinelServersConfig
                .setSubscriptionTimeout(
                        (int) sentinelConfig.getSubscription().getTimeout().toMillis())
                .setSubscriptionsPerConnection(sentinelConfig.getSubscription().getPerConnection());
    }
}
