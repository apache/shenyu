package com.yeepay.framework.infra.redisson;

import static com.yeepay.framework.common.utils.PropertiesLoader.hasKey;
import static com.yeepay.framework.common.utils.PropertiesLoader.ifPresent;
import static com.yeepay.framework.common.utils.PropertiesLoader.splitAndTrim;

import com.yeepay.framework.common.utils.PropertiesLoader;
import com.yeepay.framework.infra.redisson.cilent.ClusterRedissonClientCreator;
import com.yeepay.framework.infra.redisson.cilent.SentinelRedissonClientCreator;
import com.yeepay.framework.infra.redisson.cilent.SingleRedissonClientCreator;
import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.ClusterConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SentinelConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SingleConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import org.redisson.api.RedissonClient;
import org.redisson.config.ReadMode;
import org.redisson.config.ShardedSubscriptionMode;
import org.redisson.config.SubscriptionMode;

/**
 * The type Redisson client factory.
 */
public class RedissonClientFactory {

    /**
     * Create redisson client.
     *
     * @param config the config
     * @return the Redisson client
     */
    public static RedissonClient create(RedissonConfig config) {
        return create(config, null);
    }

    /**
     * Create redisson client.
     *
     * @param config the config
     * @param customizer the customizer
     * @return the Redisson client
     */
    public static RedissonClient create(RedissonConfig config, RedissonConfigCustomizer customizer) {
        if (Objects.nonNull(config.getSingle())) {
            return createSingle(config, config.getSingle(), customizer);
        } else if (Objects.nonNull(config.getSentinel())) {
            return createSentinel(config, config.getSentinel(), customizer);
        } else if (Objects.nonNull(config.getCluster())) {
            return createCluster(config, config.getCluster(), customizer);
        } else {
            throw new IllegalArgumentException("Invalid RedissonConfig: no valid configuration found");
        }
    }

    /**
     * Create single redisson client.
     *
     * @param config the config
     * @param singleConfig the single config
     * @return the Redisson client
     */
    public static RedissonClient createSingle(RedissonConfig config, SingleConfig singleConfig) {
        return createSingle(config, singleConfig, null);
    }

    /**
     * Create single redisson client.
     *
     * @param config the config
     * @param singleConfig the single config
     * @param customizer the customizer
     * @return the Redisson client
     */
    public static RedissonClient createSingle(
            RedissonConfig config, SingleConfig singleConfig, RedissonConfigCustomizer customizer) {
        return new SingleRedissonClientCreator(config, singleConfig, customizer).creator();
    }

    /**
     * Create sentinel redisson client.
     *
     * @param config the config
     * @param sentinelConfig the sentinel config
     * @return the redisson client
     */
    public static RedissonClient createSentinel(RedissonConfig config, SentinelConfig sentinelConfig) {
        return createSentinel(config, sentinelConfig, null);
    }

    /**
     * Create sentinel redisson client.
     *
     * @param config the config
     * @param sentinelConfig the sentinel config
     * @param customizer the customizer
     * @return the Redisson client
     */
    public static RedissonClient createSentinel(
            RedissonConfig config, SentinelConfig sentinelConfig, RedissonConfigCustomizer customizer) {
        return new SentinelRedissonClientCreator(config, sentinelConfig, customizer).creator();
    }

    /**
     * Create cluster redisson client.
     *
     * @param config the config
     * @param clusterConfig the cluster config
     * @return the Redisson client
     */
    public static RedissonClient createCluster(RedissonConfig config, ClusterConfig clusterConfig) {
        return createCluster(config, clusterConfig, null);
    }

    /**
     * Create cluster redisson client.
     *
     * @param config the config
     * @param clusterConfig the cluster config
     * @param customizer the customizer
     * @return the Redisson client
     */
    public static RedissonClient createCluster(
            RedissonConfig config, ClusterConfig clusterConfig, RedissonConfigCustomizer customizer) {
        return new ClusterRedissonClientCreator(config, clusterConfig, customizer).creator();
    }

    /**
     * 从 classpath 配置文件创建客户端.
     *
     * <p>配置文件格式（properties）：
     * <pre>
     * # 全局配置
     * threads=16
     * nettyThreads=32
     *
     * # 单机模式（三种模式配其一）
     * single.address=redis://127.0.0.1:6379
     * single.password=secret
     * single.database=0
     * single.pool.poolSize=64
     * single.pool.minimumIdleSize=24
     *
     * # 哨兵模式
     * #sentinel.masterName=mymaster
     * #sentinel.sentinelAddresses=redis://host1:port1,redis://host2:port2
     * #sentinel.password=secret
     * #sentinel.database=0
     * #sentinel.sentinelPassword=
     *
     * # 集群模式
     * #cluster.nodeAddresses=redis://host1:port1,redis://host2:port2
     * #cluster.password=secret
     * </pre>
     *
     * @param path classpath 下的目录路径，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @return the Redisson client
     */
    public static RedissonClient createFromClasspath(final String path, final String filename) {
        return createFromClasspath(path, filename, null);
    }

    /**
     * 使用默认路径和文件名从 classpath 创建 Redisson 客户端.
     *
     * @return the Redisson client
     */
    public static RedissonClient createFromClasspath() {
        return createFromClasspath("runtimecfg", "yeepay-redis.properties", null);
    }

    /**
     * Create from classpath redisson client.
     *
     * @param customizer the customizer
     * @return the redisson client
     */
    public static RedissonClient createFromClasspath(final RedissonConfigCustomizer customizer) {
        return createFromClasspath("runtimecfg", "yeepay-redisson.properties", customizer);
    }

    /**
     * 从 classpath 配置文件创建客户端，并应用定制器.
     *
     * @param path classpath 下的目录路径，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @param customizer 可选的配置定制器
     * @return the Redisson client
     */
    public static RedissonClient createFromClasspath(
            final String path, final String filename, final RedissonConfigCustomizer customizer) {
        RedissonConfig config = loadConfig(path, filename);
        return create(config, customizer);
    }

    /**
     * 从 classpath 配置文件加载 {@link RedissonConfig}.
     *
     * @param path classpath 下的目录路径，{@code null} 或空串时从 classpath 根加载
     * @param filename 属性文件名称
     * @return 解析后的 Redisson 配置
     */
    public static RedissonConfig loadConfig(final String path, final String filename) {
        Properties props = PropertiesLoader.load(path, filename);
        return buildConfig(props);
    }

    private static RedissonConfig buildConfig(final Properties props) {
        RedissonConfig config = new RedissonConfig();

        ifPresent(props, "threads", v -> config.setThreads(Integer.parseInt(v)));
        ifPresent(props, "nettyThreads", v -> config.setNettyThreads(Integer.parseInt(v)));

        if (hasKey(props, "single.address")) {
            SingleConfig single = new SingleConfig();
            ifPresent(props, "single.address", single::setAddress);
            applyBaseConfig(props, "single.", single);
            applyPoolConfig(props, "single.pool.", single.getPool());
            applyPoolConfig(props, "single.subscriptionPool.", single.getSubscriptionPool());
            ifPresent(props, "single.dnsMonitoring.interval", v -> single.getDnsMonitoring()
                    .setInterval(Duration.ofMillis(Long.parseLong(v))));
            config.setSingle(single);
        } else if (hasKey(props, "sentinel.masterName")) {
            SentinelConfig sentinel = new SentinelConfig();
            ifPresent(props, "sentinel.masterName", sentinel::setMasterName);
            ifPresent(props, "sentinel.sentinelAddresses", v -> sentinel.setSentinelAddresses(splitAndTrim(v)));
            ifPresent(props, "sentinel.sentinelPassword", sentinel::setSentinelPassword);
            ifPresent(props, "sentinel.sentinelUsername", sentinel::setSentinelUsername);
            ifPresent(
                    props, "sentinel.checkSentinelsList", v -> sentinel.setCheckSentinelsList(Boolean.parseBoolean(v)));
            ifPresent(
                    props,
                    "sentinel.checkSlaveStatusWithSyncing",
                    v -> sentinel.setCheckSlaveStatusWithSyncing(Boolean.parseBoolean(v)));
            ifPresent(
                    props, "sentinel.sentinelsDiscovery", v -> sentinel.setSentinelsDiscovery(Boolean.parseBoolean(v)));
            applyBaseConfig(props, "sentinel.", sentinel);
            applyMasterSlaveConfig(props, "sentinel.", sentinel);
            config.setSentinel(sentinel);
        } else if (hasKey(props, "cluster.nodeAddresses")) {
            ClusterConfig cluster = new ClusterConfig();
            ifPresent(props, "cluster.nodeAddresses", v -> cluster.setNodeAddresses(splitAndTrim(v)));
            ifPresent(props, "cluster.checkSlotsCoverage", v -> cluster.setCheckSlotsCoverage(Boolean.parseBoolean(v)));
            ifPresent(
                    props,
                    "cluster.checkMasterLinkStatus",
                    v -> cluster.setCheckMasterLinkStatus(Boolean.parseBoolean(v)));
            ifPresent(
                    props,
                    "cluster.shardedSubscriptionMode",
                    v -> cluster.setShardedSubscriptionMode(ShardedSubscriptionMode.valueOf(v)));
            applyBaseConfig(props, "cluster.", cluster);
            applyMasterSlaveConfig(props, "cluster.", cluster);
            config.setCluster(cluster);
        } else {
            autoDetect(props, config);
        }

        return config;
    }

    private static void applyBaseConfig(
            final Properties props, final String prefix, final RedissonConfig.BaseConfig base) {
        ifPresent(props, prefix + "password", base::setPassword);
        ifPresent(props, prefix + "username", base::setUsername);
        ifPresent(props, prefix + "database", v -> base.setDatabase(Integer.parseInt(v)));
        ifPresent(props, prefix + "clientName", base::setClientName);

        RedissonConfig.ConnectionConfig conn = base.getConnection();
        ifPresent(
                props,
                prefix + "connection.connectTimeout",
                v -> conn.setConnectTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, prefix + "connection.timeout", v -> conn.setTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(
                props,
                prefix + "connection.idleTimeout",
                v -> conn.setIdleTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, prefix + "connection.retryAttempts", v -> conn.setRetryAttempts(Integer.parseInt(v)));
        ifPresent(
                props,
                prefix + "connection.pingInterval",
                v -> conn.setPingInterval(Duration.ofMillis(Long.parseLong(v))));

        RedissonConfig.SubscriptionConfig sub = base.getSubscription();
        ifPresent(props, prefix + "subscription.timeout", v -> sub.setTimeout(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, prefix + "subscription.perConnection", v -> sub.setPerConnection(Integer.parseInt(v)));

        RedissonConfig.TcpConfig tcp = base.getTcp();
        ifPresent(props, prefix + "tcp.noDelay", v -> tcp.setNoDelay(Boolean.parseBoolean(v)));
        ifPresent(props, prefix + "tcp.keepAlive", v -> tcp.setKeepAlive(Boolean.parseBoolean(v)));
        ifPresent(props, prefix + "tcp.keepAliveCount", v -> tcp.setKeepAliveCount(Integer.parseInt(v)));
        ifPresent(props, prefix + "tcp.keepAliveIdle", v -> tcp.setKeepAliveIdle(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(
                props,
                prefix + "tcp.keepAliveInterval",
                v -> tcp.setKeepAliveInterval(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(props, prefix + "tcp.userTimeout", v -> tcp.setUserTimeout(Duration.ofMillis(Long.parseLong(v))));
    }

    private static void applyPoolConfig(
            final Properties props, final String prefix, final RedissonConfig.ConnectionPoolConfig pool) {
        ifPresent(props, prefix + "poolSize", v -> pool.setPoolSize(Integer.parseInt(v)));
        ifPresent(props, prefix + "minimumIdleSize", v -> pool.setMinimumIdleSize(Integer.parseInt(v)));
        ifPresent(
                props,
                prefix + "reconnectionInterval",
                v -> pool.setReconnectionInterval(Duration.ofMillis(Long.parseLong(v))));
    }

    private static void applyMasterSlaveConfig(
            final Properties props, final String prefix, final RedissonConfig.BaseMasterSlaveConfig masterSlave) {
        applyPoolConfig(props, prefix + "masterPool.", masterSlave.getMasterPool());
        applyPoolConfig(props, prefix + "slavePool.", masterSlave.getSlavePool());
        applyPoolConfig(props, prefix + "subscriptionPool.", masterSlave.getSubscriptionPool());

        RedissonConfig.ReadWriteModeConfig rwm = masterSlave.getReadWriteMode();
        ifPresent(props, prefix + "readWriteMode.readMode", v -> rwm.setReadMode(ReadMode.valueOf(v)));
        ifPresent(
                props,
                prefix + "readWriteMode.subscriptionMode",
                v -> rwm.setSubscriptionMode(SubscriptionMode.valueOf(v)));

        ifPresent(props, prefix + "dnsMonitoring.interval", v -> masterSlave
                .getDnsMonitoring()
                .setInterval(Duration.ofMillis(Long.parseLong(v))));
        ifPresent(
                props, prefix + "scanInterval", v -> masterSlave.setScanInterval(Duration.ofMillis(Long.parseLong(v))));
    }

    /**
     * 兼容 RedisClientUtils 老配置格式的自动检测逻辑.
     *
     * <ul>
     *   <li>{@code mode=sentinel} → 哨兵模式</li>
     *   <li>{@code mode=cluster}  → 集群模式</li>
     *   <li>无 mode 或其他值 → 根据 {@code sentinels} 地址数量自动判断：多个为哨兵，单个为单机</li>
     * </ul>
     */
    private static void autoDetect(final Properties props, final RedissonConfig config) {
        String mode = props.getProperty("mode", "").trim();

        if ("sentinel".equals(mode)) {
            buildLegacySentinel(props, config);
            return;
        }
        if ("cluster".equals(mode)) {
            buildLegacyCluster(props, config);
            return;
        }
        if (!hasKey(props, "sentinels")) {
            return;
        }
        List<String> nodes = splitAndTrim(props.getProperty("sentinels"));
        if (nodes.size() > 1) {
            buildLegacySentinel(props, config);
        } else {
            buildLegacySingle(props, nodes.get(0), config);
        }
    }

    private static void buildLegacySentinel(final Properties props, final RedissonConfig config) {
        SentinelConfig sentinel = new SentinelConfig();
        ifPresent(props, "masterName", sentinel::setMasterName);
        ifPresent(props, "sentinels", v -> sentinel.setSentinelAddresses(toRedisUris(splitAndTrim(v))));
        applyLegacyBaseConfig(props, sentinel);
        config.setSentinel(sentinel);
    }

    private static void buildLegacyCluster(final Properties props, final RedissonConfig config) {
        ClusterConfig cluster = new ClusterConfig();
        ifPresent(props, "sentinels", v -> cluster.setNodeAddresses(toRedisUris(splitAndTrim(v))));
        applyLegacyBaseConfig(props, cluster);
        config.setCluster(cluster);
    }

    private static void buildLegacySingle(final Properties props, final String hostPort, final RedissonConfig config) {
        SingleConfig single = new SingleConfig();
        single.setAddress(toRedisUri(hostPort));
        applyLegacyBaseConfig(props, single);
        config.setSingle(single);
    }

    private static void applyLegacyBaseConfig(final Properties props, final RedissonConfig.BaseConfig base) {
        ifPresent(props, "password", base::setPassword);
        ifPresent(props, "username", base::setUsername);
        ifPresent(props, "database", v -> base.setDatabase(Integer.parseInt(v)));
    }

    private static List<String> toRedisUris(final List<String> nodes) {
        List<String> uris = new ArrayList<>();
        for (String node : nodes) {
            uris.add(toRedisUri(node));
        }
        return uris;
    }

    private static String toRedisUri(final String hostPort) {
        String trimmed = hostPort.trim();
        if (trimmed.startsWith("redis://") || trimmed.startsWith("rediss://")) {
            return trimmed;
        }
        return "redis://" + trimmed;
    }
}
