package com.yeepay.framework.infra.redisson.enums;

/**
 * Supported Redisson Codec types for configuration binding.
 */
public enum CodecType {

    /**
     * String codec type.
     */
    STRING,
    /**
     * Json jackson codec type.
     */
    JSON_JACKSON,
    /**
     * Msgpack jackson codec type.
     */
    MSGPACK_JACKSON,
    /**
     * Cbor jackson codec type.
     */
    CBOR_JACKSON,
    /**
     * Smile jackson codec type.
     */
    SMILE_JACKSON,
    /**
     * Kryo 5 codec type.
     */
    KRYO5,
    /**
     * Fst codec type.
     */
    FST,
    /**
     * Java serialization codec type.
     */
    JAVA_SERIALIZATION,
    /**
     * Lz 4 codec type.
     */
    LZ4,
    /**
     * Byte array codec type.
     */
    BYTE_ARRAY
}
