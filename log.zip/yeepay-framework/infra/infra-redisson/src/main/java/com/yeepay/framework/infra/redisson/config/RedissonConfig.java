package com.yeepay.framework.infra.redisson.config;

import com.yeepay.framework.infra.redisson.enums.CodecType;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.redisson.config.Protocol;
import org.redisson.config.ReadMode;
import org.redisson.config.ShardedSubscriptionMode;
import org.redisson.config.SubscriptionMode;
import org.redisson.config.TransportMode;

/**
 * The type Htx redisson config.
 */
@Data
public class RedissonConfig {

    private Model model = new Model();

    /**
     * Redisson executor thread count.
     * Redisson 执行器线程数。
     */
    private int threads = 16;

    /**
     * Netty worker thread count.
     * Netty 工作线程数。
     */
    private int nettyThreads = 32;

    /**
     * Transport mode (NIO/EPOLL/KQUEUE etc.).
     * 传输模式（NIO/EPOLL/KQUEUE 等）。
     * 默认 NIO（跨平台兼容）。如需使用 EPOLL/KQUEUE 需额外引入对应的 netty native transport 依赖。
     */
    private TransportMode transportMode = TransportMode.NIO;

    /**
     * Codec type for value serialization.
     * 编解码器类型（序列化方式）。
     */
    private CodecType codec = CodecType.KRYO5;

    /**
     * Redis protocol version.
     * Redis 协议版本。
     */
    private Protocol protocol = Protocol.RESP2;

    /**
     * 分布式锁配置.
     * Distributed lock configurations.
     */
    private LockConfig lock = new LockConfig();

    /**
     * 发布订阅配置.
     * Pub/Sub configurations.
     */
    private PubSubConfig pubSub = new PubSubConfig();

    /**
     * 内存清理配置.
     * Memory cleanup configurations.
     */
    private CleanupConfig cleanup = new CleanupConfig();

    /**
     * 其他配置.
     * Other configurations.
     */
    private MiscConfig misc = new MiscConfig();

    /**
     * Single server mode configurations map. Key is the client name.
     * 单机模式配置，键为客户端名称。
     */
    private SingleConfig single;

    /**
     * Sentinel mode configurations map. Key is the client name.
     * 哨兵模式配置，键为客户端名称。
     */
    private SentinelConfig sentinel;

    /**
     * Cluster mode configurations map. Key is the client name.
     * 集群模式配置，键为客户端名称。
     */
    private ClusterConfig cluster;

    /**
     * Redisson configuration model.
     */
    @Data
    public static class Model {

        /**
         * 配置文件类型，默认为 yaml，不为这个，那么就从路径下的文件加载.
         */
        private String type = "yaml";

        private String path;

        private String fileName;
    }

    /**
     * The type Cluster config.
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class ClusterConfig extends BaseMasterSlaveConfig {

        /**
         * Redis cluster node urls list.
         * Redis 集群节点地址列表。
         */
        private List<String> nodeAddresses = new ArrayList<>();

        /**
         * Check cluster slots coverage on startup.
         * 是否在启动时检查集群 slot 覆盖情况。
         */
        private boolean checkSlotsCoverage = true;

        /**
         * Check master link status before using it.
         * 使用主节点前是否检查主节点链接状态。
         */
        private boolean checkMasterLinkStatus;

        /**
         * Sharded subscription mode for pub/sub.
         * 分片订阅模式（用于发布订阅）。
         */
        private ShardedSubscriptionMode shardedSubscriptionMode = ShardedSubscriptionMode.AUTO;
    }

    /**
     * The type Sentinel config.
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class SentinelConfig extends BaseMasterSlaveConfig {

        /**
         * Redis sentinel node urls list.
         * 哨兵节点地址列表。
         */
        private List<String> sentinelAddresses = new ArrayList<>();

        /**
         * Master name monitored by Sentinel.
         * 哨兵监控的主节点名称。
         */
        private String masterName;

        /**
         * Sentinel username.
         * 哨兵用户名。
         */
        private String sentinelUsername;

        /**
         * Sentinel password.
         * 哨兵密码。
         */
        private String sentinelPassword;

        /**
         * Verify Sentinel list consistency.
         * 是否校验哨兵节点列表一致性。
         */
        private boolean checkSentinelsList = true;

        /**
         * Check slave status with syncing state.
         * 是否检查从节点状态（包括同步中状态）。
         */
        private boolean checkSlaveStatusWithSyncing = true;

        /**
         * Enable Sentinel auto discovery.
         * 是否启用哨兵自动发现。
         */
        private boolean sentinelsDiscovery = true;
    }

    /**
     * The type Base master slave config.
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class BaseMasterSlaveConfig extends BaseConfig {

        /**
         * 主节点连接池配置
         * Master node connection pool configurations.
         */
        private ConnectionPoolConfig masterPool = new ConnectionPoolConfig();

        /**
         * 从节点连接池配置
         * Slave node connection pool configurations.
         */
        private ConnectionPoolConfig slavePool = new ConnectionPoolConfig();

        /**
         * 订阅连接池配置
         * Subscription connection pool configurations.
         */
        private ConnectionPoolConfig subscriptionPool = new ConnectionPoolConfig();

        /**
         * 读写模式配置
         * Read/Write mode configurations.
         */
        private ReadWriteModeConfig readWriteMode = new ReadWriteModeConfig();

        /**
         * DNS 监控配置
         * DNS monitoring configurations.
         */
        private DnsMonitoringConfig dnsMonitoring = new DnsMonitoringConfig();

        /**
         * Redis cluster scan interval in milliseconds.
         * 集群拓扑扫描间隔（毫秒）。
         */
        private Duration scanInterval = Duration.ofSeconds(1);
    }

    /**
     * 读写模式配置
     * Read/Write mode configurations.
     */
    @Data
    public static class ReadWriteModeConfig {

        /**
         * Read mode for data reading from master/slave.
         * 读模式：SLAVE（仅从节点）、MASTER（仅主节点）、MASTER_SLAVE（主从都读）。
         */
        private ReadMode readMode = ReadMode.SLAVE;

        /**
         * Subscription mode for pub/sub from master/slave.
         * 订阅模式：MASTER（主节点订阅）、SLAVE（从节点订阅）。
         */
        private SubscriptionMode subscriptionMode = SubscriptionMode.MASTER;
    }

    /**
     * DNS 监控配置
     * DNS monitoring configurations.
     */
    @Data
    public static class DnsMonitoringConfig {

        /**
         * interval in milliseconds to check DNS for nodes.
         * 节点 DNS 检查间隔（毫秒）。
         */
        private Duration interval = Duration.ofSeconds(5);
    }

    /**
     * The type Single config.
     */
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class SingleConfig extends BaseConfig {

        /**
         * Redis server address.
         * Redis 服务器地址。
         */
        private String address;

        /**
         * 普通连接池配置.
         * Normal connection pool configurations.
         */
        private ConnectionPoolConfig pool = new ConnectionPoolConfig();

        /**
         * 订阅连接池配置.
         * Subscription connection pool configurations.
         */
        private ConnectionPoolConfig subscriptionPool = new ConnectionPoolConfig();

        /**
         * interval in milliseconds to check DNS for nodes.
         * 节点 DNS 检查间隔（毫秒）。
         */
        private DnsMonitoringConfig dnsMonitoring = new DnsMonitoringConfig();
    }

    /**
     * 普通连接池配置
     * Normal connection pool configurations.
     */
    @Data
    public static class ConnectionPoolConfig {

        /**
         * Minimum idle connection amount.
         * 普通连接最小空闲数。
         */
        private int minimumIdleSize = 24;

        /**
         * Maximum connection pool size.
         * 普通连接最大连接池大小。
         */
        private int poolSize = 64;

        /**
         * Reconnection interval in milliseconds for failed connections.
         * 失败连接重连间隔（毫秒）。
         */
        private Duration reconnectionInterval = Duration.ofSeconds(3);
    }

    /**
     * The type Base config.
     */
    @Data
    public static class BaseConfig {

        /**
         * 连接配置.
         * Connection related configurations.
         */
        private ConnectionConfig connection = new ConnectionConfig();

        /**
         * 订阅配置.
         * Subscription configurations.
         */
        private SubscriptionConfig subscription = new SubscriptionConfig();

        /**
         * TCP 配置.
         * TCP related configurations.
         */
        private TcpConfig tcp = new TcpConfig();

        /**
         * Name of client connection.
         * 客户端连接名称.
         */
        private String clientName;

        /**
         * Username for Redis ACL authentication.
         * Redis ACL 认证用户名。
         */
        private String username;

        /**
         * Password for Redis authentication.
         * Redis 认证密码，无需认证时为 null。
         */
        private String password;

        /**
         * Database index used for Redis connection.
         * 使用的 Redis 数据库索引。
         */
        private int database;

        /**
         * RedissonClient 的 bean name, 默认值为 ${key}RedissonClient.
         */
        private String clientBeanName;

        /**
         * DataManager 的 bean name, 默认值为 ${key}RedissonDataManager.
         */
        private String dataManagerBeanName;

        /**
         * LockManager 的 bean name, 默认值为 ${key}RedissonLockManager.
         */
        private String lockBeanName;
    }

    /**
     * 连接配置
     * Connection configurations.
     */
    @Data
    public static class ConnectionConfig {

        /**
         * Idle connection timeout in milliseconds.
         * 当连接在指定超时时间内未被使用且当前连接数大于最小空闲连接数时，
         * 连接将被关闭并从连接池移除。单位：毫秒。
         */
        private Duration idleTimeout = Duration.ofSeconds(10);

        /**
         * Timeout during connecting to any Redis server (milliseconds).
         * 连接 Redis 服务器的超时时间，单位：毫秒。
         */
        private Duration connectTimeout = Duration.ofMillis(500);

        /**
         * Redis server response timeout in milliseconds.
         * Redis 命令发送成功后开始计时的响应超时时间，单位：毫秒。
         */
        private Duration timeout = Duration.ofMillis(100);

        /**
         * Retry attempts of command execution.
         * 命令执行的重试次数。
         */
        private int retryAttempts = 3;

        /**
         * Heartbeat ping interval in milliseconds.
         * 连接心跳 ping 间隔（毫秒）。
         */
        private Duration pingInterval = Duration.ofSeconds(5);
    }

    /**
     * 订阅配置
     * Subscription (Pub/Sub) configurations.
     */
    @Data
    public static class SubscriptionConfig {

        /**
         * Subscription handshake timeout in milliseconds.
         * 订阅（pub/sub）握手超时时间（毫秒）。
         */
        private Duration timeout = Duration.ofMillis(7500);

        /**
         * Subscriptions per Redis connection limit.
         * 每个连接允许的订阅数量上限。
         */
        private int perConnection = 5;
    }

    /**
     * TCP 配置
     * TCP protocol configurations.
     */
    @Data
    public static class TcpConfig {

        /**
         * Enable TCP no-delay (Nagle algorithm off).
         * 是否开启 TCP 无延迟（关闭 Nagle 算法）。
         */
        private boolean noDelay = true;

        /**
         * Enable TCP keepalive.
         * 是否启用 TCP keepalive。
         */
        private boolean keepAlive;

        /**
         * TCP keepalive probe count.
         * TCP keepalive 探测次数。
         */
        private int keepAliveCount = 10;

        /**
         * Defines the time in seconds the connection needs to remain idle before TCP starts sending keepalive probes.
         * TCP keepalive 空闲时间。
         */
        private Duration keepAliveIdle = Duration.ofSeconds(30);

        /**
         * TCP keepalive probe interval.
         * TCP keepalive 探测间隔。
         */
        private Duration keepAliveInterval = Duration.ofSeconds(30);

        /**
         * TCP user timeout.
         * TCP 用户超时时间。
         */
        private Duration userTimeout = Duration.ofSeconds(1);
    }

    /**
     * 分布式锁配置.
     * Distributed lock configurations.
     */
    @Data
    public static class LockConfig {

        /**
         * Lock watchdog timeout in milliseconds.
         * 分布式锁看门狗超时时间（毫秒）。
         */
        private Duration watchdogTimeout = Duration.ofSeconds(30);

        /**
         * Batch size for lock watchdog renewal.
         * 锁看门狗续约批次大小。
         */
        private int watchdogBatchSize = 100;

        /**
         * Default fair lock wait time in milliseconds.
         * 公平锁默认等待超时时间（毫秒）。
         */
        private Duration fairWaitTimeout = Duration.ofMinutes(5);

        /**
         * Check if lock needs synced slaves confirmation.
         * 获取锁是否校验从节点同步完成。
         */
        private boolean checkSyncedSlaves = true;

        /**
         * Timeout to wait for slaves sync in milliseconds.
         * 等待从节点同步超时时间（毫秒）。
         */
        private Duration slavesSyncTimeout = Duration.ofMinutes(1);
    }

    /**
     * 发布订阅配置.
     * Pub/Sub (Publish/Subscribe) configurations.
     */
    @Data
    public static class PubSubConfig {

        /**
         * Keep pub/sub message order.
         * 是否保持发布订阅消息的顺序。
         */
        private boolean keepOrder = true;

        /**
         * Reliable topic watchdog timeout in milliseconds.
         * 可靠主题（ReliableTopic）看门狗超时时间（毫秒）。
         */
        private Duration reliableTopicWatchdogTimeout = Duration.ofMillis(10);
    }

    /**
     * 内存清理配置.
     * Memory cleanup configurations.
     */
    @Data
    public static class CleanupConfig {

        /**
         * Minimum cleanup delay in seconds.
         * 最小清理延迟（秒）。
         */
        private Duration minDelay = Duration.ofSeconds(5);

        /**
         * Maximum cleanup delay in seconds.
         * 最大清理延迟（秒）。
         */
        private Duration maxDelay = Duration.ofMinutes(30);

        /**
         * Keys amount to cleanup per cycle.
         * 每次清理的键数量。
         */
        private int keysAmount = 100;
    }

    /**
     * 其他配置.
     * Miscellaneous configurations.
     */
    @Data
    public static class MiscConfig {

        /**
         * Enable reference objects for Redisson.
         * 是否启用 Redisson 引用功能。
         */
        private boolean referenceEnabled = true;

        /**
         * Use script cache to speed up Lua execution.
         * 是否启用脚本缓存以加速 Lua 执行。
         */
        private boolean useScriptCache = true;

        /**
         * Lazy initialization for Redisson client.
         * 是否启用延迟初始化。
         */
        private boolean lazyInitialization;
    }
}
