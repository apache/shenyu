# Infra Redisson 模块文档

## 概述

`infra-redisson` 模块为下游服务提供 **Redisson（Redis 高级客户端）的工厂模式封装**，屏蔽底层连接细节，支持三种部署拓扑（单机、哨兵、集群）。模块分为两层：

- **核心层 (`infra/infra-redisson/`)**：纯 Java 库，不依赖 Spring，提供 `RedissonClientFactory` 和 `RedissonConfig`
- **Starter 层 (`springboot-starter/springboot-starter-infra/springboot-starter-infra-redisson/`)**：Spring Boot 自动配置，通过 `@ConfigurationProperties` 将 YAML/Properties 配置绑定到客户端

---

## 模块结构

```
infra/infra-redisson/
├── pom.xml
├── RedissonClientFactory.java            # 客户端工厂
├── RedissonConfig.java                   # 配置 POJO（含大量子配置类）
├── RedissonConfigCustomizer.java         # 客户端自定义回调
├── CodecType.java                        # 编解码器枚举（10种）
└── cilent/
    ├── AbstractRedissonClientCreator.java      # 模板方法基类
    ├── SingleRedissonClientCreator.java        # 单机模式
    ├── SentinelRedissonClientCreator.java      # 哨兵模式
    └── ClusterRedissonClientCreator.java       # 集群模式

springboot-starter/springboot-starter-infra/springboot-starter-infra-redisson/
├── pom.xml
├── InfraRedissonAutoConfiguration.java   # 自动配置类
└── InfraRedissonConfigured.java          # 条件匹配类
```

---

## 一、功能

- **高级 Redis 客户端**：基于 Redisson，提供分布式锁、分布式集合、发布订阅等高级功能
- **三种部署模式**：`single`（单机）、`sentinel`（哨兵）、`cluster`（集群）
- **丰富的编解码器支持**：10 种编解码器（String、JSON Jackson、MsgPack、CBOR、Smile、Kryo5、FST、Java Serialization、LZ4、Byte Array）
- **细粒度配置**：连接池（主/从/订阅分离）、TCP 参数、DNS 监控、读写模式、锁行为、发布订阅、资源清理等
- **双模式配置加载**：YAML 绑定和 Properties 文件加载
- **旧格式兼容**：自动识别旧版配置属性

---

## 二、集成方式

### Maven 依赖

```xml
<!-- 核心库 -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>infra-redisson</artifactId>
    <version>${yeepay-framework.version}</version>
</dependency>

<!-- Spring Boot Starter（推荐） -->
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-infra-redisson</artifactId>
    <version>${yeepay-framework.version}</version>
</dependency>
```

引入 starter 后自动注册 `InfraRedissonAutoConfiguration`，创建 `RedissonClient` Bean。

### 激活条件

同时满足两个条件：
1. classpath 存在 `org.redisson.Redisson` 类
2. 配置前缀 `yeepay.framework.infra.redisson.*` 下有任意属性

---

## 三、配置方式

### 方式一：Spring Boot YAML 配置（推荐）

Redisson 支持三种部署模式。YAML 配置模式下，`model.type` 默认为 `yaml`，所有配置通过 Spring Boot 的 `@ConfigurationProperties` 绑定到 `RedissonConfig` 对象。

配置根路径为 `yeepay.framework.infra.redisson`。全局属性（如 `threads`、`codec`、`lock` 等）在所有模式下通用；具体连接拓扑通过 `single`、`sentinel` 或 `cluster` 三个互斥的子节点指定——**只能启用其中一个**，即配置中只能出现 `single`、`sentinel`、`cluster` 三者之一。

---

#### 全局配置（三种模式通用）

在配置任何具体模式之前，先设置全局参数。这些参数决定 Redisson 客户端的行为，与 Redis 拓扑无关：

```yaml
yeepay:
  framework:
    infra:
      redisson:
        model:
          type: yaml              # 使用 YAML 绑定模式（默认）
        threads: 16               # 默认 16，事件循环线程数，影响 Netty 处理 Redis 响应的并发能力
        netty-threads: 32         # 默认 32，Netty I/O 线程数
        codec: KRYO5              # 默认 KRYO5，编解码器类型，决定 Java 对象与 Redis 数据如何互相转换
        protocol: RESP2           # 默认 RESP2，Redis 协议版本，RESP2 兼容性最好，RESP3 支持新特性
        transport-mode: NIO       # 默认 NIO，Netty 传输模式，一般保持 NIO 即可

        # 分布式锁行为
        lock:
          watchdog-timeout: 30000       # 默认 30000ms，看门狗续期超时，锁持有超过此时间自动续期
          watchdog-batch-size: 100      # 默认 100，看门狗每次批量处理的锁数量
          fair-wait-timeout: 300000     # 默认 300000ms，公平锁等待超时
          check-synced-slaves: true     # 默认 true，是否检查从节点同步后才视为加锁成功
          slaves-sync-timeout: 60000    # 默认 60000ms，从节点同步超时

        # 发布订阅
        pub-sub:
          keep-order: true              # 默认 true，是否保持消息顺序
          reliable-topic-watchdog-timeout: 10  # 默认 10ms，可靠主题看门狗超时

        # 资源清理
        cleanup:
          min-delay: 5000               # 默认 5000ms，最小清理延迟
          max-delay: 1800000            # 默认 1800000ms（30分钟），最大清理延迟
          keys-amount: 100              # 默认 100，每次清理的 key 数量

        # 杂项
        misc:
          reference-enabled: true       # 默认 true，是否启用引用计数
          use-script-cache: true        # 默认 true，是否缓存 Lua 脚本
          lazy-initialization: false    # 默认 false，是否延迟初始化连接

        # === 以下三种模式任选其一 ===
```

---

#### 模式一：单机模式 `single`

**适用场景**：开发环境、Redis 单实例部署。

单机模式连接到一个独立的 Redis 节点。配置集中在 `single` 下，核心是 `address`（Redis 地址）、认证信息（`username`/`password`）和连接池。

```yaml
        single:
          # --- 连接地址与认证 ---
          address: redis://127.0.0.1:6379   # 必填，Redis 地址，格式 redis://host:port
          username: myuser                   # 默认 null，Redis 6.0+ ACL 用户名（可选）
          password: mypassword               # 默认 null，Redis 密码
          database: 0                        # 默认 0，数据库编号
          client-name: myapp                 # 默认 null，客户端标识名，便于在 CLIENT LIST 中识别

          # --- 连接参数 ---
          connection:
            idle-timeout: 10000              # 默认 10000ms，连接空闲超时，超时后关闭连接
            connect-timeout: 500             # 默认 500ms，TCP 连接建立超时
            timeout: 100                     # 默认 100ms，Redis 命令响应超时
            retry-attempts: 3                # 默认 3，命令失败后的重试次数
            ping-interval: 5000              # 默认 5000ms，PING 心跳间隔，确保连接存活

          # --- 订阅参数 ---
          subscription:
            timeout: 7500                    # 默认 7500ms，订阅操作超时
            per-connection: 5                # 默认 5，每个连接的最大订阅数

          # --- TCP 参数 ---
          tcp:
            no-delay: true                   # 默认 true，启用 TCP_NODELAY，禁用 Nagle 算法，降低延迟
            keep-alive: false                # 默认 false，是否启用 TCP KeepAlive
            keep-alive-count: 10             # 默认 10，KeepAlive 探测次数
            keep-alive-idle: 30000           # 默认 30000ms，KeepAlive 空闲多久开始探测
            keep-alive-interval: 30000       # 默认 30000ms，KeepAlive 探测间隔
            user-timeout: 1000               # 默认 1000ms，TCP 用户超时

          # --- 连接池（命令执行用） ---
          pool:
            minimum-idle-size: 24            # 默认 24，最小空闲连接数，低于此值会新建连接
            pool-size: 64                    # 默认 64，连接池最大连接数
            reconnection-interval: 3000      # 默认 3000ms，断线重连间隔

          # --- 订阅连接池（发布订阅专用） ---
          subscription-pool:
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64

          # --- DNS 监控（动态域名场景） ---
          dns-monitoring:
            interval: 5000                   # 默认 5000ms，DNS 变更检测间隔，-1 禁用
```

**单机模式关键点**：
- `address` 必须使用 `redis://` 或 `rediss://`（SSL）协议前缀
- `pool` 和 `subscription-pool` 分别管理普通命令和发布订阅的连接，避免订阅阻塞命令执行
- `connection.retry-attempts` 控制命令级重试，与连接池级别的 `reconnection-interval` 配合工作

---

#### 模式二：哨兵模式 `sentinel`

**适用场景**：生产环境 Redis 主从架构，需要通过哨兵自动故障转移。

哨兵模式通过 Redis Sentinel 自动发现当前主节点，并在主节点故障时自动切换到新的主节点。配置在 `sentinel` 下。

```yaml
        sentinel:
          # --- 哨兵节点 ---
          sentinel-addresses:                # 必填，哨兵节点地址列表
            - redis://10.0.0.1:26379
            - redis://10.0.0.2:26379
            - redis://10.0.0.3:26379
          master-name: mymaster              # 必填，要监控的主节点名称（与 sentinel.conf 中一致）

          # --- 哨兵认证 ---
          sentinel-username: sentineluser    # 默认 null，哨兵 ACL 用户名（Redis 6.0+）
          sentinel-password: sentinelpass    # 默认 null，哨兵密码

          # --- 哨兵行为 ---
          check-sentinels-list: true         # 默认 true，启动时检查配置的哨兵列表是否在线
          check-slave-status-with-syncing: false  # 默认 false，检查从节点时是否包含 syncing 状态
          sentinels-discovery: true          # 默认 true，是否从哨兵自动发现其他哨兵节点

          # --- Redis 认证 ---
          username: redisuser                # 默认 null，Redis 主/从节点的用户名
          password: redispass                # 默认 null，Redis 主/从节点的密码
          database: 0                        # 默认 0，数据库编号

          # --- 读写分离 ---
          read-write-mode:
            read-mode: SLAVE                 # 默认 SLAVE，读操作路由：MASTER（仅主）/ SLAVE（仅从）/ MASTER_SLAVE（两者）
            subscription-mode: MASTER        # 默认 MASTER，订阅路由：MASTER / SLAVE / MASTER_SLAVE

          # --- 拓扑扫描 ---
          scan-interval: 5000                # 默认 5000ms，扫描主/从节点变更的间隔

          # --- 连接池（按主/从/订阅分离） ---
          master-pool:                       # 主节点连接池（写操作）
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64
          slave-pool:                        # 从节点连接池（读操作）
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64
          subscription-pool:                 # 订阅连接池（发布订阅）
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64

          # --- DNS 监控 ---
          dns-monitoring:
            interval: 5000                   # 默认 5000ms

          # --- 连接/订阅/TCP 参数与单机模式相同 ---
          connection:
            idle-timeout: 10000              # 默认 10000ms
            connect-timeout: 500             # 默认 500ms
            timeout: 100                     # 默认 100ms
            retry-attempts: 3                # 默认 3
            ping-interval: 5000              # 默认 5000ms
          subscription:
            timeout: 7500                    # 默认 7500ms
            per-connection: 5                # 默认 5
          tcp:
            no-delay: true                   # 默认 true
```

**哨兵模式关键点**：
- `sentinel-addresses` 和 `master-name` 是必填项，缺一不可
- 连接池分为三层：`master-pool`（写）、`slave-pool`（读）、`subscription-pool`（订阅），这对于读写分离场景至关重要
- `read-mode: SLAVE` + `subscription-mode: MASTER` 是常见组合：读走从库减轻主库压力，订阅走主库保证消息可靠性
- `sentinel-password` 和 `password` 是独立的：前者用于连接哨兵节点，后者用于连接 Redis 数据节点
- `scan-interval` 决定故障转移后多快能发现新拓扑，默认 5 秒

---

#### 模式三：集群模式 `cluster`

**适用场景**：Redis Cluster 部署，数据分片存储，需要水平扩展。

集群模式连接 Redis Cluster 的多个节点，自动发现集群拓扑并处理槽位重定向（MOVED/ASK）。配置在 `cluster` 下。

```yaml
        cluster:
          # --- 集群节点 ---
          node-addresses:                    # 必填，集群节点地址列表（至少一个，建议多个）
            - redis://10.0.0.1:6379
            - redis://10.0.0.2:6379
            - redis://10.0.0.3:6379
            - redis://10.0.0.4:6379
            - redis://10.0.0.5:6379
            - redis://10.0.0.6:6379

          # --- 集群行为 ---
          check-slots-coverage: true         # 默认 true，检查所有 16384 个槽位是否都有节点负责，false 允许部分槽未覆盖
          check-master-link-status: true     # 默认 true，检查主节点间链路状态
          sharded-subscription-mode: false   # 默认 false，是否启用分片订阅（Redis 7.0+ 新特性）

          # --- 认证 ---
          username: redisuser                # 默认 null
          password: redispass                # 默认 null

          # --- 读写分离 ---
          read-write-mode:
            read-mode: MASTER                # 默认 MASTER，集群模式建议 MASTER，因为从节点不保证强一致性
            subscription-mode: MASTER        # 默认 MASTER

          # --- 拓扑扫描 ---
          scan-interval: 5000                # 默认 5000ms

          # --- 连接池（主/从/订阅分离） ---
          master-pool:
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64
          slave-pool:
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64
          subscription-pool:
            minimum-idle-size: 24            # 默认 24
            pool-size: 64                    # 默认 64

          # --- DNS 监控 ---
          dns-monitoring:
            interval: 5000                   # 默认 5000ms

          # --- 连接/订阅/TCP 参数 ---
          connection:
            idle-timeout: 10000              # 默认 10000ms
            connect-timeout: 500             # 默认 500ms
            timeout: 100                     # 默认 100ms
            retry-attempts: 3                # 默认 3
            ping-interval: 5000              # 默认 5000ms
          subscription:
            timeout: 7500                    # 默认 7500ms
            per-connection: 5                # 默认 5
          tcp:
            no-delay: true                   # 默认 true
```

**集群模式关键点**：
- `node-addresses` 至少配置一个节点，Redisson 会通过 `CLUSTER NODES` 自动发现所有节点；但建议配置多个节点防止单点发现失败
- `check-slots-coverage: true`（默认）确保所有 16384 个槽位都有节点负责，避免部分 key 不可用
- `read-mode` 默认 `MASTER`，因为 Redis Cluster 的从节点复制是异步的，读从节点可能拿到脏数据
- `sharded-subscription-mode` 对应 Redis 7.0+ 的 Sharded Pub/Sub，可大幅降低集群广播开销
- 与哨兵模式类似，主/从/订阅三套连接池相互隔离

---

#### 三种模式对比

| 维度 | 单机 `single` | 哨兵 `sentinel` | 集群 `cluster` |
|------|------|------|------|
| 节点配置 | `address` 单个地址 | `sentinel-addresses` + `master-name` | `node-addresses` 多个地址 |
| 自动故障转移 | 不支持 | Sentinel 自动切换 | 集群内置选举 |
| 读写分离 | 不支持 | 支持（`master-pool` + `slave-pool`） | 支持 |
| 数据分片 | 不支持 | 不支持 | 支持（16384 槽位） |
| 适用环境 | 开发/测试 | 生产（主从架构） | 生产（大规模/高吞吐） |
| 必填项 | `address` | `sentinel-addresses`, `master-name` | `node-addresses` |

---

### 方式二：Properties 文件加载

设置 `yeepay.framework.infra.redisson.model.type = properties`，默认路径为 `runtimecfg/yeepay-redisson.properties`。

```properties
# 单机模式（新格式）
threads=16
nettyThreads=32
single.address=redis://127.0.0.1:6379
single.password=mypassword
single.username=myuser
single.database=0
single.clientName=myapp
single.connection.idleTimeout=10000
single.connection.connectTimeout=500
single.connection.timeout=100
single.connection.retryAttempts=3
single.connection.pingInterval=5000
single.pool.minimumIdleSize=24
single.pool.poolSize=64
single.pool.reconnectionInterval=3000
single.subscriptionPool.minimumIdleSize=24
single.subscriptionPool.poolSize=64
single.dnsMonitoring.interval=5000

# 哨兵模式（新格式）
sentinel.masterName=mymaster
sentinel.sentinelAddresses=redis://10.0.0.1:26379,redis://10.0.0.2:26379
sentinel.sentinelUsername=sentineluser
sentinel.sentinelPassword=sentinelpass

# 集群模式（新格式）
cluster.nodeAddresses=redis://10.0.0.1:6379,redis://10.0.0.2:6379

# 旧格式兼容
mode=sentinel
masterName=mymaster
sentinels=10.0.0.1:26379,10.0.0.2:26379
```

---

## 四、RedissonConfig 完整配置参考

### 顶层全局属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `threads` | int | 16 | 事件循环线程数 |
| `netty-threads` | int | 32 | Netty 线程数 |
| `transport-mode` | String | NIO | 传输模式 |
| `codec` | CodecType | KRYO5 | 编解码器类型 |
| `protocol` | String | RESP2 | Redis 协议版本（RESP2 / RESP3） |

### CodecType 枚举值

| 值 | 说明 |
|------|------|
| `STRING` | 字符串编解码 |
| `JSON_JACKSON` | Jackson JSON 编解码 |
| `MSGPACK_JACKSON` | MessagePack 编解码 |
| `CBOR_JACKSON` | CBOR 编解码 |
| `SMILE_JACKSON` | Smile 编解码 |
| `KRYO5` | Kryo 5 编解码（默认） |
| `FST` | FST 编解码 |
| `JAVA_SERIALIZATION` | Java 原生序列化 |
| `LZ4` | LZ4 压缩 |
| `BYTE_ARRAY` | 字节数组 |

### LockConfig - 分布式锁配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `watchdog-timeout` | long | 30000 | 看门狗超时时间（毫秒） |
| `watchdog-batch-size` | int | 100 | 看门狗批量大小 |
| `fair-wait-timeout` | long | 300000 | 公平锁等待超时（毫秒） |
| `check-synced-slaves` | boolean | true | 是否检查从节点同步 |
| `slaves-sync-timeout` | long | 60000 | 从节点同步超时（毫秒） |

### PubSubConfig - 发布订阅配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `keep-order` | boolean | true | 是否保持消息顺序 |
| `reliable-topic-watchdog-timeout` | long | 10 | 可靠主题看门狗超时（毫秒） |

### CleanupConfig - 资源清理配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `min-delay` | long | 5000 | 最小清理延迟（毫秒） |
| `max-delay` | long | 1800000 | 最大清理延迟（毫秒） |
| `keys-amount` | int | 100 | 每次清理 key 数量 |

### MiscConfig - 杂项配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `reference-enabled` | boolean | true | 是否启用引用 |
| `use-script-cache` | boolean | true | 是否使用脚本缓存 |
| `lazy-initialization` | boolean | false | 是否延迟初始化 |

### SingleConfig - 单机模式

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `address` | String | **必填** | Redis 地址，格式 `redis://host:port` |
| `username` | String | null | 用户名 |
| `password` | String | null | 密码 |
| `database` | int | 0 | 数据库索引 |
| `client-name` | String | null | 客户端名称 |
| `pool` | ConnectionPoolConfig | - | 连接池配置 |
| `subscription-pool` | ConnectionPoolConfig | - | 订阅连接池配置 |
| `dns-monitoring` | DnsMonitoringConfig | - | DNS 监控配置 |
| `connection` | ConnectionConfig | - | 连接参数配置 |
| `subscription` | SubscriptionConfig | - | 订阅参数配置 |
| `tcp` | TcpConfig | - | TCP 参数配置 |

### SentinelConfig - 哨兵模式（继承 BaseMasterSlaveConfig）

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `sentinel-addresses` | List\<String\> | **必填** | 哨兵地址列表 |
| `master-name` | String | **必填** | 主节点名称 |
| `sentinel-username` | String | null | 哨兵用户名 |
| `sentinel-password` | String | null | 哨兵密码 |
| `check-sentinels-list` | boolean | true | 是否检查哨兵列表 |
| `check-slave-status-with-syncing` | boolean | false | 是否检查从节点同步状态 |
| `sentinels-discovery` | boolean | true | 是否启用哨兵发现 |
| `scan-interval` | int | 5000 | 扫描间隔（毫秒） |
| `read-write-mode` | ReadWriteModeConfig | - | 读写模式 |
| `master-pool` | ConnectionPoolConfig | - | 主节点连接池 |
| `slave-pool` | ConnectionPoolConfig | - | 从节点连接池 |
| `subscription-pool` | ConnectionPoolConfig | - | 订阅连接池 |
| `dns-monitoring` | DnsMonitoringConfig | - | DNS 监控 |

**ReadWriteModeConfig**：

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `read-mode` | String | SLAVE | 读模式：`MASTER` / `SLAVE` / `MASTER_SLAVE` |
| `subscription-mode` | String | MASTER | 订阅模式：`MASTER` / `SLAVE` / `MASTER_SLAVE` |

### ClusterConfig - 集群模式（继承 BaseMasterSlaveConfig）

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `node-addresses` | List\<String\> | **必填** | 集群节点地址列表 |
| `check-slots-coverage` | boolean | true | 是否检查槽位覆盖 |
| `check-master-link-status` | boolean | true | 是否检查主节点链接状态 |
| `sharded-subscription-mode` | boolean | false | 是否启用分片订阅模式 |

（其余从/主/订阅池、读写模式、DNS 监控、扫描间隔等属性与 SentinelConfig 相同）

### ConnectionPoolConfig - 连接池配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `minimum-idle-size` | int | 24 | 最小空闲连接数 |
| `pool-size` | int | 64 | 连接池大小 |
| `reconnection-interval` | long | 3000 | 重连间隔（毫秒） |

### ConnectionConfig - 连接参数配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `idle-timeout` | long | 10000 | 空闲超时（毫秒） |
| `connect-timeout` | long | 500 | 连接超时（毫秒） |
| `timeout` | long | 100 | 命令超时（毫秒） |
| `retry-attempts` | int | 3 | 重试次数 |
| `ping-interval` | long | 5000 | Ping 间隔（毫秒） |

### SubscriptionConfig - 订阅参数配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `timeout` | long | 7500 | 订阅超时（毫秒） |
| `per-connection` | int | 5 | 每个连接订阅数 |

### TcpConfig - TCP 参数配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `no-delay` | boolean | true | 是否启用 TCP_NODELAY |
| `keep-alive` | boolean | false | 是否启用 TCP KeepAlive |
| `keep-alive-count` | int | 10 | KeepAlive 探测次数 |
| `keep-alive-idle` | long | 30000 | KeepAlive 空闲时间（毫秒） |
| `keep-alive-interval` | long | 30000 | KeepAlive 探测间隔（毫秒） |
| `user-timeout` | long | 1000 | 用户超时（毫秒） |

### DnsMonitoringConfig - DNS 监控配置

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `interval` | long | 5000 | DNS 变更检测间隔（毫秒） |

---

## 五、客户端自定义

```java
@Bean
public RedissonConfigCustomizer redissonCustomizer() {
    return config -> {
        // config 是 org.redisson.config.Config 实例
        // 可以在此添加 Redisson 原生配置
    };
}
```

---

## 六、直接使用工厂（非 Spring 环境）

```java
RedissonConfig config = new RedissonConfig();
RedissonConfig.SingleConfig single = new RedissonConfig.SingleConfig();
single.setAddress("redis://127.0.0.1:6379");
single.setPassword("mypassword");
config.setSingle(single);

RedissonClient client = RedissonClientFactory.create(config);

// 通过 classpath 文件创建
RedissonClient client = RedissonClientFactory.createFromClasspath(
    "runtimecfg", "yeepay-redisson.properties"
);
```

---

## 七、Spring Boot 自动配置详解

### 自动配置注册

项目使用 Spring Boot 3.x 的 `AutoConfiguration.imports` 机制（**非** `spring.factories`）。

注册文件位于 `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`：

```
com.yeepay.framework.springboot.starter.infra.redisson.InfraRedissonAutoConfiguration
```

### InfraRedissonAutoConfiguration 工作流程

1. **条件检查**：`InfraRedissonConfigured` 检查 `yeepay.framework.infra.redisson` 前缀下是否有绑定属性
2. **配置 Bean**：`@ConfigurationProperties` 绑定 `RedissonConfig`
3. **客户端 Bean**：
   - 如果 `Model.type = "yaml"`（默认）：直接使用 Spring 绑定的 `RedissonConfig` 调用 `RedissonClientFactory.create()`
   - 如果 `Model.type = "properties"`：从 `Model.path` / `Model.fileName` 指定的 classpath 文件加载
   - 注入所有 `RedissonConfigCustomizer` Bean（通过 `ObjectProvider`）

### @ConditionalOnMissingBean 覆盖

客户端 Bean 标注了 `@ConditionalOnMissingBean`，允许用户完全覆盖：

```java
@Bean
public RedissonClient myRedissonClient() {
    // 自定义创建逻辑，会替代自动配置的 Bean
}
```

---

## 八、完整 YAML 配置模板

### 单机模式

```yaml
yeepay:
  framework:
    infra:
      redisson:
        model:
          type: yaml
        threads: 16
        netty-threads: 32
        codec: KRYO5
        protocol: RESP2
        lock:
          watchdog-timeout: 30000
          watchdog-batch-size: 100
          fair-wait-timeout: 300000
          check-synced-slaves: true
          slaves-sync-timeout: 60000
        single:
          address: redis://127.0.0.1:6379
          password: mypassword
          database: 0
          client-name: myapp
          connection:
            idle-timeout: 10000
            connect-timeout: 500
            timeout: 100
            retry-attempts: 3
            ping-interval: 5000
          pool:
            minimum-idle-size: 24
            pool-size: 64
            reconnection-interval: 3000
          subscription-pool:
            minimum-idle-size: 24
            pool-size: 64
```

### 哨兵模式

```yaml
yeepay:
  framework:
    infra:
      redisson:
        model:
          type: yaml
        threads: 8
        netty-threads: 16
        codec: KRYO5
        sentinel:
          sentinel-addresses:
            - redis://10.0.0.1:26379
            - redis://10.0.0.2:26379
            - redis://10.0.0.3:26379
          master-name: mymaster
          sentinel-password: sentinelpass
          password: redispass
          database: 0
          read-write-mode:
            read-mode: SLAVE
            subscription-mode: MASTER
          master-pool:
            minimum-idle-size: 24
            pool-size: 64
          slave-pool:
            minimum-idle-size: 24
            pool-size: 64
          subscription-pool:
            minimum-idle-size: 24
            pool-size: 64
```

### 集群模式

```yaml
yeepay:
  framework:
    infra:
      redisson:
        model:
          type: yaml
        threads: 20
        netty-threads: 40
        codec: STRING
        cluster:
          node-addresses:
            - redis://10.0.0.1:6379
            - redis://10.0.0.2:6379
            - redis://10.0.0.3:6379
            - redis://10.0.0.4:6379
            - redis://10.0.0.5:6379
            - redis://10.0.0.6:6379
          check-slots-coverage: true
          check-master-link-status: true
          sharded-subscription-mode: false
          scan-interval: 5000
          read-write-mode:
            read-mode: MASTER
            subscription-mode: MASTER
          password: redispass
```

---

## 九、注意事项

1. **配置模式互斥**：单机/哨兵/集群三种模式只能选择其一，同时配置多个模式行为未定义
2. **配置激活条件**：starter 必须配置至少一个属性才会激活，空配置不会创建客户端 Bean
3. **Model.type 默认值**：默认 `yaml` 即 Spring 绑定模式，切换到 `properties` 需同时配置 `path` 和 `file-name`
4. **Properties 文件位置**：`path` 为 classpath 下的目录路径，默认从 `runtimecfg/` 加载
5. **旧格式兼容**：旧版 `mode` + `sentinels` + `masterName` 配置格式仍受支持，会自动检测并转换
6. **客户端自定义**：`RedissonConfigCustomizer` 回调在客户端完全创建后、返回前调用
7. **地址格式**：Redisson 所有节点地址使用 `redis://host:port` 格式（带协议前缀），与 Jedis 的 `host:port` 格式不同
8. **连接池分离**：哨兵和集群模式下，主/从/订阅三套连接池各自独立，合理配置可避免资源争抢
