package com.yeepay.framework.logging.filter;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.turbo.TurboFilter;
import ch.qos.logback.core.spi.FilterReply;
import java.util.Objects;
import java.util.concurrent.Callable;
import org.slf4j.Marker;

/**
 * 强制改变日志级别的过滤器，继承自TurboFilter.
 */
public class ForceChangeLevelFilter extends TurboFilter {

    private static final ThreadLocal<Level> LEVEL_HOLDER = new ThreadLocal<>();

    @Override
    public FilterReply decide(Marker marker, Logger logger, Level level, String format, Object[] params, Throwable t) {
        Level target = getLevel();
        if (Objects.nonNull(target) && target.levelInt <= level.levelInt) {
            return FilterReply.ACCEPT;
        }
        return FilterReply.NEUTRAL;
    }

    /**
     * 设置当前线程的日志级别.
     *
     * @param level 日志级别
     */
    public static void setLevel(Level level) {
        LEVEL_HOLDER.set(level);
    }

    /**
     * 获取当前线程的日志级别.
     *
     * @return 日志级别
     */
    public static Level getLevel() {
        return LEVEL_HOLDER.get();
    }

    /**
     * 清除当前线程的日志级别.
     */
    public static void clear() {
        LEVEL_HOLDER.remove();
    }

    /**
     * 在指定日志级别下执行操作.
     *
     * @param level    日志级别
     * @param runnable 要执行的操作
     */
    public static void changeLevel(Level level, Runnable runnable) {
        try {
            LEVEL_HOLDER.set(level);
            runnable.run();
        } finally {
            LEVEL_HOLDER.remove();
        }
    }

    /**
     * 在指定日志级别下执行可调用操作.
     *
     * @param <T>      返回类型
     * @param level    日志级别
     * @param callable 要执行的可调用操作
     * @return 操作结果
     */
    public static <T> T changeLevel(Level level, Callable<T> callable) {
        try {
            LEVEL_HOLDER.set(level);
            return callable.call();
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } finally {
            LEVEL_HOLDER.remove();
        }
    }
}
