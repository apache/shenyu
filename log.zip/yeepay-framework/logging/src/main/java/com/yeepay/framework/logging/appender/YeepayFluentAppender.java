package com.yeepay.framework.logging.appender;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Layout;
import ch.qos.logback.core.UnsynchronizedAppenderBase;
import com.yeepay.framework.common.theadcontext.ThreadContextType;
import com.yeepay.framework.common.theadcontext.ThreadContextUtils;
import com.yeepay.infra.stream.Constants;
import com.yeepay.infra.stream.StreamLogger;
import com.yeepay.infra.stream.StreamLoggerFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * The type Logback appender.
 */
@Slf4j
public class YeepayFluentAppender extends UnsynchronizedAppenderBase<ILoggingEvent> {

    private StreamLogger streamLogger;

    private String tag = "java";

    @Setter
    private String remoteAddress = "app.logsync.yp:24224";

    @Setter
    private String appName;

    @Setter
    private String deployEnv;

    private String label = "java.label";

    @Getter
    @Setter
    private Layout<ILoggingEvent> layout;

    /**
     * Sets tag.
     *
     * @param tag the tag
     */
    public void setTag(String tag) {
        this.tag = tag.toLowerCase();
    }

    /**
     * Sets label.
     *
     * @param label the label
     */
    public void setLabel(String label) {
        this.label = label.toLowerCase().replaceAll("\\.", "_");
    }

    @Override
    public void start() {
        try {
            log.info("init fluent-logback");
            String hostname = InetAddress.getLocalHost().getHostName();
            log.info("hostname is: {}", hostname);
            if (StringUtils.isEmpty(appName)) {
                appName = System.getProperty(Constants.YEEPAY_APP_NAME);
            }
            if (StringUtils.isEmpty(appName)) {
                throw new IllegalArgumentException("app name must not be null or empty");
            }
            if (StringUtils.isEmpty(deployEnv)) {
                deployEnv = System.getProperty(Constants.DEPLOY_ENV);
            }
            log.info("deploy_env:{}", deployEnv);
            final String host = remoteAddress.split(":")[0].trim();
            final int port = Integer.parseInt(remoteAddress.split(":")[1].trim());
            log.info("remoteAddress is: {}", remoteAddress);
            if (StringUtils.isNotEmpty(appName)) {
                label = appName.toLowerCase().replace("-", "_");
            }
            if (label.contains("nc_pay")) {
                label = "nc-pay";
            }
            log.info("app name is: {}", appName);
            log.info("label is {}", label);
            log.info("deploy_env is {}", deployEnv);
            String tagLabel = tag + "." + label;
            log.info("tag_label is: {}", tagLabel);
            streamLogger = StreamLoggerFactory.getLogger("queue", tagLabel, host, port);
            Runtime.getRuntime().addShutdownHook(new Thread(() -> streamLogger.close()));
        } catch (UnknownHostException e) {
            log.info("UnknownHost{}", String.valueOf(e));
        }
        super.start();
    }

    @Override
    protected void append(ILoggingEvent iLoggingEvent) {
        if (!isStarted()) {
            return;
        }
        Map<String, Object> message = new HashMap<>();
        message.put("level", iLoggingEvent.getLevel().toString());
        message.put("loggerName", iLoggingEvent.getLoggerName());
        message.put("thread", iLoggingEvent.getThreadName());
        sendAsAppLog(iLoggingEvent, message);
    }

    private void sendAsAppLog(ILoggingEvent event, Map<String, Object> message) {
        if (Objects.nonNull(layout)) {
            message.put("message", buildMessage(event) + layout.doLayout(event).trim());
        } else {
            message.put("message", buildMessage(event) + event.toString().trim());
        }
        streamLogger.log(message, event.getTimeStamp());
    }

    /**
     * Build message string.
     *
     * @param event the event
     * @return the string
     */
    protected String buildMessage(ILoggingEvent event) {
        StringBuilder builder = new StringBuilder();
        if (!ThreadContextUtils.contextInitialized()) {
            ThreadContextUtils.initContext(null, null, ThreadContextType.MANUAL);
        }
        builder.append("APP[");
        builder.append(ThreadContextUtils.getContext().getAppName());
        builder.append("] - GUID[");
        builder.append(ThreadContextUtils.getContext().getThreadUID());
        builder.append("] - TYPE[");
        builder.append(ThreadContextUtils.getContext().getType());
        builder.append("] ");
        if (Objects.nonNull(event)
                && Objects.nonNull(event.getMDCPropertyMap())
                && event.getMDCPropertyMap().containsKey("trace_id")) {
            builder.append(" - TRACE_ID[")
                    .append(event.getMDCPropertyMap().get("trace_id"))
                    .append("] ");
        }
        if (Objects.nonNull(event)
                && Objects.nonNull(event.getMDCPropertyMap())
                && event.getMDCPropertyMap().containsKey("trace_flags")) {
            builder.append(" - TRACE_FLAGS[")
                    .append(event.getMDCPropertyMap().get("trace_flags"))
                    .append("] ");
        }
        return builder.toString();
    }

    @Override
    public void stop() {
        streamLogger.close();
    }
}
