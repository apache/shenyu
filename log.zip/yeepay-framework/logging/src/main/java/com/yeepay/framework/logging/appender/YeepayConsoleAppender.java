package com.yeepay.framework.logging.appender;

import com.yeepay.framework.common.concurrent.YeepayThreadFactory;
import java.io.BufferedOutputStream;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 控制台追加器，支持缓冲输出以提高性能.
 * <a href="https://www.oracle.com/technical-resources/articles/javase/perftuning.html">...</a>
 * By default, System.out (a PrintStream) is line buffered, meaning that the output buffer is flushed when a newline character is encountered.
 *
 * @param <E> 事件类型
 */
@Slf4j
public class YeepayConsoleAppender<E> extends ch.qos.logback.core.ConsoleAppender<E> {

    @Setter
    private int bufferSize;

    @Setter
    private int flushInterval = 30 * 1000;

    private ScheduledThreadPoolExecutor flushExecutor;

    public YeepayConsoleAppender() {
        super();
    }

    @Override
    public void start() {
        if (!this.isImmediateFlush() && this.bufferSize > 128) {
            FileOutputStream fdout = new FileOutputStream(FileDescriptor.out);
            BufferedOutputStream bos = new BufferedOutputStream(fdout, this.bufferSize);
            PrintStream ps = new PrintStream(bos, false, StandardCharsets.UTF_8);

            this.flush();
            System.setOut(ps);
            if (Objects.nonNull(flushExecutor)) {
                flushExecutor.shutdownNow();
            }
            flushExecutor = new ScheduledThreadPoolExecutor(1, YeepayThreadFactory.create("system.out.flusher"));
            if (flushInterval < 1000) {
                flushInterval = 1000;
            }
            flushExecutor.scheduleWithFixedDelay(this::flush, 10 * 1000, flushInterval, TimeUnit.MILLISECONDS);
        }
        super.start();
    }

    @Override
    public void stop() {
        if (Objects.nonNull(flushExecutor)) {
            flushExecutor.shutdown();
        }
        flush();
    }

    private void flush() {
        try {
            System.out.flush();
        } catch (Throwable e) {
            log.warn("Failed to flush System.out", e);
        }
    }
}
