package com.yeepay.framework.logging.appender;

import static org.assertj.core.api.Assertions.assertThat;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;

class YeepayConsoleAppenderTest {

    private final LoggerContext loggerContext = new LoggerContext();

    @AfterEach
    void tearDown() {
        loggerContext.stop();
    }

    private void loadConfig(String resourcePath) throws Exception {
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(loggerContext);
        loggerContext.reset();
        configurator.doConfigure(getClass().getClassLoader().getResource(resourcePath));
    }

    @Test
    void customVariablesShouldBeApplied() throws Exception {
        loadConfig("logback-console-test.xml");

        Appender<ILoggingEvent> appender =
                loggerContext.getLogger(Logger.ROOT_LOGGER_NAME).getAppender("CONSOLE");

        assertThat(appender).isInstanceOf(YeepayConsoleAppender.class);
        assertThat(appender.isStarted()).isTrue();

        YeepayConsoleAppender<ILoggingEvent> consoleAppender = (YeepayConsoleAppender<ILoggingEvent>) appender;
        assertThat(consoleAppender.isImmediateFlush()).isTrue();
    }

    @Test
    void defaultVariablesShouldWork() throws Exception {
        loadConfig("logback-console-default-test.xml");

        Appender<ILoggingEvent> appender =
                loggerContext.getLogger(Logger.ROOT_LOGGER_NAME).getAppender("CONSOLE");

        assertThat(appender).isInstanceOf(YeepayConsoleAppender.class);
        assertThat(appender.isStarted()).isTrue();

        YeepayConsoleAppender<ILoggingEvent> consoleAppender = (YeepayConsoleAppender<ILoggingEvent>) appender;
        assertThat(consoleAppender.isImmediateFlush()).isFalse();
    }

    @Test
    void shouldStartWithoutError() throws Exception {
        loadConfig("logback-console-test.xml");

        assertThat(loggerContext.getStatusManager().getCopyOfStatusList()).noneMatch(s -> s.getLevel() > 1);
    }
}
