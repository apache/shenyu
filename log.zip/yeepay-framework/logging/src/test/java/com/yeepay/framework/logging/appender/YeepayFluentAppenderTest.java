package com.yeepay.framework.logging.appender;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import com.yeepay.framework.common.theadcontext.ThreadContextType;
import com.yeepay.framework.common.theadcontext.ThreadContextUtils;
import com.yeepay.infra.stream.StreamLogger;
import com.yeepay.infra.stream.StreamLoggerFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class YeepayFluentAppenderTest {

    private LoggerContext loggerContext;
    private MockedStatic<StreamLoggerFactory> streamLoggerFactoryMock;
    private StreamLogger mockStreamLogger;

    @BeforeEach
    void setUp() {
        ThreadContextUtils.initContext("test-app", null, ThreadContextType.MANUAL);
        mockStreamLogger = mock(StreamLogger.class);
        when(mockStreamLogger.log(anyMap(), anyLong())).thenReturn(true);
        streamLoggerFactoryMock = mockStatic(StreamLoggerFactory.class);
        streamLoggerFactoryMock
                .when(() -> StreamLoggerFactory.getLogger(anyString(), anyString(), anyString(), anyInt()))
                .thenReturn(mockStreamLogger);
        loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
    }

    @AfterEach
    void tearDown() {
        loggerContext.stop();
        streamLoggerFactoryMock.close();
    }

    private void loadConfig(String resourcePath) throws Exception {
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(loggerContext);
        loggerContext.reset();
        configurator.doConfigure(getClass().getClassLoader().getResource(resourcePath));
    }

    @Test
    void customVariablesShouldBeApplied() throws Exception {
        loadConfig("logback-fluent-test.xml");

        Appender<ILoggingEvent> appender =
                loggerContext.getLogger(Logger.ROOT_LOGGER_NAME).getAppender("fluentd-app");

        assertThat(appender)
                .as("fluentd-app appender should be present")
                .isNotNull()
                .isInstanceOf(YeepayFluentAppender.class);
        assertThat(appender.isStarted()).as("appender should be started").isTrue();

        streamLoggerFactoryMock.verify(
                () -> StreamLoggerFactory.getLogger(eq("queue"), eq("custom_tag.test_app"), eq("10.0.0.1"), eq(24324)));
    }

    @Test
    void shouldLogAndSendToStreamLogger() throws Exception {
        loadConfig("logback-fluent-test.xml");

        Appender<ILoggingEvent> appender =
                loggerContext.getLogger(Logger.ROOT_LOGGER_NAME).getAppender("fluentd-app");
        assertThat(appender.isStarted()).isTrue();

        ch.qos.logback.classic.Logger logger = loggerContext.getLogger("test.fluent");
        logger.info("hello from fluent appender test");

        verify(mockStreamLogger, atLeastOnce())
                .log(
                        argThat(map -> {
                            assertThat(map).containsKey("message");
                            assertThat(map).containsKey("level");
                            assertThat(map.get("level")).isEqualTo("INFO");
                            assertThat((String) map.get("message")).contains("hello from fluent appender test");
                            return true;
                        }),
                        anyLong());
    }

    @Test
    void appNameFromXmlShouldOverrideSystemProperty() throws Exception {
        String original = System.getProperty("appname");
        try {
            System.setProperty("appname", "system-app");
            loadConfig("logback-fluent-test.xml");

            // XML sets appName="test-app", so tag_label should be "custom_tag.test_app" not "custom_tag.system_app"
            streamLoggerFactoryMock.verify(
                    () -> StreamLoggerFactory.getLogger(eq("queue"), eq("custom_tag.test_app"), anyString(), anyInt()));
        } finally {
            if (original != null) {
                System.setProperty("appname", original);
            } else {
                System.clearProperty("appname");
            }
        }
    }

    @Test
    void deployEnvFromXmlShouldBeUsed() throws Exception {
        loadConfig("logback-fluent-test.xml");

        Appender<ILoggingEvent> appender =
                loggerContext.getLogger(Logger.ROOT_LOGGER_NAME).getAppender("fluentd-app");

        assertThat(appender).isNotNull();
        assertThat(appender.isStarted()).isTrue();
    }
}
