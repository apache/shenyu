# 日志增强 (Logging)

## 技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| Logback | 1.5.x (Spring Boot 3.4 捆绑) | 日志框架 |



## 组件概览

| 组件 | 类型 | 作用 |
|------|------|------|
| `YeepayConsoleAppender` | ConsoleAppender 子类 | 缓冲控制台输出，减少高并发下 System.out 同步 IO 开销 |
| `YeepayFluentAppender` | UnsynchronizedAppenderBase 子类 | 将日志发送到 Fluentd，自动附加 APP/GUID/TRACE_ID 等上下文 |
| `ForceChangeLevelFilter` | TurboFilter | 运行时临时改变线程级日志级别，无需重启 |

---

## 使用方式

###  添加依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>logging</artifactId>
    <version>${yeepay.framework.version}</version>
</dependency>
```

### 引入预配置 XML（推荐）

`logback-spring.xml` 中一行引入：

```xml
<configuration>
    <include resource="com/yeepay/framework/logging/logback/base.xml"/>

    <!-- Fluentd 参数 -->
    <property name="FLUENTD_REMOTE_ADDRESS" value="app.logsync.yp:24324"/>
    <property name="FLUENTD_APP_NAME" value="${you app name}"/>


    <root level="INFO">
        <!--输出到控制台-->
        <appender-ref ref="CONSOLE"/>
        <!--通过日志sdk，发送日志-->
        <appender-ref ref="fluentd-app"/>
    </root>
</configuration>
```


## 全部配置

### Console Appender 配置

**XML 属性：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `immediateFlush` | boolean | `true` | 是否立即刷新。`false` + `bufferSize>128` 才启用缓冲 |
| `bufferSize` | int | `256` | 缓冲区字节数 |
| `flushInterval` | int | `30000` | 定时刷新间隔（毫秒），最小值 1000 |

**环境变量 / JVM 属性：**

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `CONSOLE_IMMEDIATE_FLUSH` | `false` | 是否立即刷新 |
| `CONSOLE_BUFFER_SIZE` | `4096` | 缓冲区大小 |
| `CONSOLE_FLUSH_INTERVAL` | `30000` | 刷新间隔（毫秒） |
| `CONSOLE_LOG_PATTERN` | 彩色格式 | 日志输出格式 |
| `CONSOLE_CHARSET` | `utf8` | 字符编码 |

### Fluentd Appender 配置

**XML 属性：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `remoteAddress` | String | `app.logsync.yp:24224` | Fluentd 地址，格式 `host:port` |
| `tag` | String | `java` | Fluentd tag，自动转小写 |
| `label` | String | `java.label` | label，`.` 替换为 `_` |
| `appName` | String | 系统属性 `appname` | 应用名 |
| `deployEnv` | String | 系统属性 `deploy_env` | 部署环境 |
| `layout` | Layout | — | PatternLayout，不配则用 `event.toString()` |

**环境变量 / JVM 属性：**

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `FLUENTD_REMOTE_ADDRESS` | `app.logsync.yp:24324` | Fluentd 地址 |
| `FLUENTD_TAG` | `java` | tag 前缀 |
| `FLUENTD_LABEL` | `java.label` | label |
| `FLUENTD_APP_NAME` | `${APP}` | 应用名（取自 spring.application.name） |
| `FLUENTD_DEPLOY_ENV` | 空 | 部署环境 |
| `FLUENTD_LOG_PATTERN` | `%date{HH:mm:ss.SSS} [%thread] %-5level %logger{15}#%line %msg` | 日志格式 |

### base.xml 全部变量

| 变量 | 默认值 | 来源 |
|------|--------|------|
| `APP` | `NOT_SET` | `spring.application.name` |
| `PROFILE` | `NOT_SET` | `spring.profiles.active` |
| `APP_NAME` | `NOT_SET` | 环境变量 |
| `ENV_NAME` | `NOT_SET` | 环境变量 |
| `HOSTNAME` | `NOT_SET` | 环境变量 |
| `BUILD_GIT_VERSION` | `NOT_SET` | 环境变量 |


---

## 动态设置配置设置

所有 Logback 配置在启动时加载，运行时无法修改 XML 属性。动态控制只能用以下几种方式：

### 1. 通过 JVM 属性 / 环境变量（启动时）

```bash
# 高吞吐模式 — 启用缓冲、增大缓冲区、延长刷新间隔
java -jar app.jar \
  -DCONSOLE_IMMEDIATE_FLUSH=false \
  -DCONSOLE_BUFFER_SIZE=16384 \
  -DCONSOLE_FLUSH_INTERVAL=30000 \
  -DFLUENTD_REMOTE_ADDRESS=fluentd.prod.yp:24324 \
  -DFLUENTD_DEPLOY_ENV=prod
```

```yaml
# Kubernetes ConfigMap 注入
env:
  - name: CONSOLE_IMMEDIATE_FLUSH
    value: "false"
  - name: CONSOLE_BUFFER_SIZE
    value: "8192"
  - name: FLUENTD_REMOTE_ADDRESS
    value: "fluentd.prod.svc:24324"
```

### 2. 直接在 logback-spring.xml 里面添加属性

在 `<include>` 之前声明 `<property>`，值会覆盖 `base.xml` 中的默认值：

```xml
<configuration>
    <!-- 在 include 之前设置，覆盖 base.xml 中的默认值 -->
    <property name="CONSOLE_IMMEDIATE_FLUSH" value="false"/>
    <property name="CONSOLE_BUFFER_SIZE" value="8192"/>
    <property name="CONSOLE_FLUSH_INTERVAL" value="10000"/>
    <property name="FLUENTD_REMOTE_ADDRESS" value="fluentd.prod.yp:24324"/>
    <property name="FLUENTD_DEPLOY_ENV" value="prod"/>

    <include resource="com/yeepay/framework/logging/logback/base.xml"/>

    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="fluentd-app"/>
    </root>
</configuration>
```

也可以使用 `<springProperty>` 从 Spring 环境读取：

```xml
<configuration>
    <!-- 从 Spring 环境变量读取 -->
    <springProperty name="FLUENTD_DEPLOY_ENV" source="deploy.env" defaultValue="dev"/>
    <springProperty name="CONSOLE_IMMEDIATE_FLUSH" source="console.immediateFlush" defaultValue="false"/>

    <include resource="com/yeepay/framework/logging/logback/base.xml"/>

    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
    </root>
</configuration>
```

> **优先级：** `<property>` 直接写死 > JVM 属性 `-D` > `base.xml` 默认值。`<springProperty>` 在 Logback 初始化时从 Spring `Environment` 取值。


## Fluentd 日志消息格式

每条发送到 Fluentd 的日志包含以下字段：

| 字段 | 来源 | 示例 |
|------|------|------|
| `level` | 日志事件 | `INFO` |
| `loggerName` | Logger 名 | `com.example.OrderService` |
| `thread` | 线程名 | `http-nio-8080-exec-1` |
| `message` | 拼接生成 | `APP[my-service] - GUID[abc123] - TYPE[SERVLET] - TRACE_ID[xxx] 原始日志内容` |

`message` 中自动附加的上下文：
- `APP` — 应用名
- `GUID` — 请求唯一 ID（ThreadContext）
- `TYPE` — 线程上下文类型（ThreadContext）
- `TRACE_ID` — 链路追踪 ID（MDC，可选）
- `TRACE_FLAGS` — 链路追踪标志（MDC，可选）



