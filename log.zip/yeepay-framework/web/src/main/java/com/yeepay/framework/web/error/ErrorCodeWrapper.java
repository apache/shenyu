package com.yeepay.framework.web.error;

import java.util.Objects;
import lombok.Getter;
import org.springframework.util.StringUtils;

/**
 * The type Error code wrapper.
 */
@Getter
public class ErrorCodeWrapper implements ErrorCode {

    /**
     * The Value.
     */
    private final Integer code;

    /**
     * The Key.
     */
    private final String key;

    /**
     * The Message.
     */
    private final String message;

    /**
     * 已处理过的错误消息，可直接在接口中返回.
     */
    private final String resolvedMessage;

    /**
     * Instantiates a new Error code wrapper.
     *
     * @param code the code
     * @param key the key
     * @param message the message
     */
    public ErrorCodeWrapper(Integer code, String key, String message) {
        this.code = Objects.requireNonNull(code);
        this.key = Objects.requireNonNull(key);
        this.message = Objects.requireNonNull(message);
        this.resolvedMessage = message;
    }

    /**
     * Instantiates a new Error code wrapper.
     *
     * @param code the code
     * @param key the key
     * @param resolvedMessage the resolved message
     */
    public ErrorCodeWrapper(ErrorCode code, String key, String resolvedMessage) {
        this.code = code.getCode();
        this.message = !StringUtils.hasText(resolvedMessage) ? code.getMessage() : resolvedMessage;
        this.key = Objects.requireNonNull(key);
        this.resolvedMessage = resolvedMessage;
    }
}
