package com.yeepay.framework.web.handler;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.yeepay.framework.common.utils.number.BigDecimalSafetyValidator;
import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.result.Failure;
import com.yeepay.framework.web.result.Result;
import com.yeepay.framework.web.utils.ParamErrorUtils;
import com.yeepay.framework.web.utils.PropertyPathUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentConversionNotSupportedException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.NoHandlerFoundException;

/**
 * The type Mvc exception handler.
 */
@ResponseBody
@ControllerAdvice
@ResponseStatus(HttpStatus.OK)
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class MvcExceptionHandler {

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public Result<?> handle(MissingServletRequestParameterException e) {
        return ParamErrorUtils.handle(e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(MethodArgumentConversionNotSupportedException.class)
    public Result<?> handle(MethodArgumentConversionNotSupportedException e) {
        return ParamErrorUtils.handle(e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public Result<?> handle(MethodArgumentTypeMismatchException e) {
        return ParamErrorUtils.handle(e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<?> handle(MethodArgumentNotValidException e) {
        return ParamErrorUtils.handle(e);
    }

    /**
     * Handle result.
     *
     * <p>增强了 BigDecimal 反序列化异常的处理：当 {@link BigDecimalSafetyValidator}
     * 校验数字超限时抛出 {@link IllegalStateException}，被 Jackson 包装为 {@link JsonMappingException}，
     * 再被 Spring MVC 包装为 {@link HttpMessageNotReadableException}。
     * 此处识别该异常链并记录具体字段名和原因。
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Result<?> handle(HttpMessageNotReadableException e) {
        if (e.getCause() instanceof JsonMappingException jsonMappingException) {
            Throwable rootCause = jsonMappingException.getCause();
            if (rootCause instanceof IllegalStateException) {
                String param = PropertyPathUtils.getPathString(jsonMappingException);
                log.warn("反序列化异常，字段: {}, 原因: {}", param, rootCause.getMessage());
            }
            return ParamErrorUtils.handle(jsonMappingException);
        }
        return new Failure(CommonError.NOT_IMPLEMENTED, e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public static Result<?> handle(HttpRequestMethodNotSupportedException e) {
        return new Failure(CommonError.NOT_IMPLEMENTED, e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public static Result<?> handle(HttpMediaTypeNotSupportedException e) {
        return new Failure(CommonError.NOT_IMPLEMENTED, e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
    public static Result<?> handle(HttpMediaTypeNotAcceptableException e) {
        return new Failure(CommonError.NOT_IMPLEMENTED, e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public static Result<?> handle(MaxUploadSizeExceededException e) {
        return new Failure(CommonError.PAYLOAD_TOO_LARGE, e);
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoHandlerFoundException.class)
    public static Result<?> handle(NoHandlerFoundException e) {
        return new Failure(CommonError.NOT_FOUND, e);
    }
}
