package com.yeepay.framework.web.constants;

/**
 * The type Web constant.
 */
public final class WebConstant {

    /**
     * The constant NOT_TRANSLATED.
     */
    public static final String NOT_TRANSLATED = "(NT)";

    private WebConstant() {}
}
