package com.yeepay.framework.web.convert;

import com.yeepay.framework.common.utils.number.BigDecimalSafetyValidator;
import java.math.BigDecimal;
import org.springframework.core.convert.converter.Converter;

/**
 * BigDecimal 字符串转换器，通过 {@link BigDecimalSafetyValidator} 做安全校验.
 *
 * <p>用于拦截 form data / query parameter 中的 BigDecimal 参数，
 * 防止超大数字攻击。JSON body 中的 BigDecimal 由 Jackson 的 {@code BigDecimalDeserializer} 处理。
 */
public class BigDecimalConverter implements Converter<String, BigDecimal> {

    private final BigDecimalSafetyValidator validator;

    public BigDecimalConverter(BigDecimalSafetyValidator validator) {
        this.validator = validator;
    }

    @Override
    public BigDecimal convert(String source) {
        return validator.parseBigDecimal(source);
    }
}
