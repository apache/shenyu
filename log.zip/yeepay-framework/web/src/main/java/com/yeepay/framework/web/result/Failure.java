package com.yeepay.framework.web.result;

import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorInfo;
import com.yeepay.framework.web.error.ErrorInfoEntity;
import com.yeepay.framework.web.error.ErrorInfoSimple;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * The type Failure.
 */
@Getter
@RequiredArgsConstructor
@SuppressWarnings({"unchecked", "rawtypes"})
public class Failure extends Empty {

    private final ErrorInfo error;

    /**
     * Instantiates a new Failure.
     *
     * @param code the code
     * @param cause the cause
     */
    public Failure(ErrorCode code, Throwable cause) {
        this(new ErrorInfoEntity(code, cause));
    }

    /**
     * Instantiates a new Failure.
     *
     * @param code the code
     * @param cause the cause
     * @param message the message
     * @param args the args
     */
    public Failure(ErrorCode code, Throwable cause, String message, Object... args) {
        this(new ErrorInfoEntity(code, cause, message, args));
    }

    /**
     * Instantiates a new Failure.
     *
     * @param code the code
     * @param message the message
     * @param args the args
     */
    public Failure(ErrorCode code, String message, Object... args) {
        this(code, null, message, args);
    }

    /**
     * Instantiates a new Failure.
     *
     * @param code the code
     * @param args the args
     */
    public Failure(ErrorCode code, Object... args) {
        this(code, null, null, args);
    }

    /**
     * Value of failure.
     *
     * @param error the error
     * @return the failure
     */
    public static Failure valueOf(ErrorCode error) {
        return new Failure(new ErrorInfoSimple(error));
    }

    /**
     * Value of failure.
     *
     * @param error the error
     * @return the failure
     */
    public static Failure valueOf(ErrorInfo error) {
        return new Failure(Objects.requireNonNull(error));
    }

    @Override
    public boolean isSuccess() {
        return false;
    }

    @Override
    public boolean isFailure() {
        return true;
    }

    @Override
    public Result ifFailure(Consumer consumer) {
        consumer.accept(error);
        return this;
    }

    @Override
    public Result ifEmptyAndSuccess(Result result) {
        return this;
    }

    @Override
    public Object getOrThrow(Function exceptionFactory) throws Throwable {
        throw (Throwable) exceptionFactory.apply(error);
    }

    @Override
    protected NoSuchElementException createNoSuchElementException() {
        NoSuchElementException exception = super.createNoSuchElementException();
        if (Objects.nonNull(error.getCause())) {
            exception.addSuppressed(error.getCause());
        }
        return exception;
    }
}
