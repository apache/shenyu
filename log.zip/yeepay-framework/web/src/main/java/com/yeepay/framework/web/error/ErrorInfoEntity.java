package com.yeepay.framework.web.error;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The type Error info entity.
 */
@Getter
@AllArgsConstructor
public class ErrorInfoEntity implements ErrorInfo {

    /**
     * The Code.
     */
    private final ErrorCode code;

    /**
     * The Cause.
     */
    private final Throwable cause;

    /**
     * The Detail.
     */
    private final String detail;

    /**
     * The Arguments.
     */
    private final Object[] arguments;

    /**
     * Instantiates a new Error info entity.
     *
     * @param code the code
     */
    public ErrorInfoEntity(ErrorCode code) {
        this(code, null, code.getMessage(), EMPTY_ARGS);
    }

    /**
     * Instantiates a new Error info entity.
     *
     * @param code the code
     * @param cause the cause
     */
    public ErrorInfoEntity(ErrorCode code, Throwable cause) {
        this(code, cause, code.getMessage(), EMPTY_ARGS);
    }

    @Override
    public String[] getMessageCodes() {
        ErrorCode code = getCode();
        if (Objects.isNull(cause)) {
            return new String[] {code.getKey(), String.valueOf(code.getCode())};
        }
        return new String[] {code.getKey(), cause.getClass().getName(), String.valueOf(code.getCode())};
    }
}
