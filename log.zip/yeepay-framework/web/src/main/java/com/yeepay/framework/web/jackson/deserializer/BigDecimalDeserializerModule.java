package com.yeepay.framework.web.jackson.deserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.yeepay.framework.common.utils.number.BigDecimalSafetyValidator;
import java.io.IOException;
import java.math.BigDecimal;
import lombok.RequiredArgsConstructor;

/**
 * The type Big decimal deserializer module.
 */
public class BigDecimalDeserializerModule extends SimpleModule {

    /**
     * Instantiates a new Big decimal deserializer module.
     *
     * @param validator the validator
     */
    public BigDecimalDeserializerModule(BigDecimalSafetyValidator validator) {
        super("BigDecimalDeserializerModule");
        // BigDecimal
        this.addDeserializer(BigDecimal.class, new BigDecimalDeserializer(validator));
    }

    /**
     * The type Big decimal deserializer.
     */
    @RequiredArgsConstructor
    public static class BigDecimalDeserializer extends JsonDeserializer<BigDecimal> {

        private final BigDecimalSafetyValidator validator;

        @Override
        public BigDecimal deserialize(final JsonParser jsonParser, final DeserializationContext deserializationContext)
                throws IOException {
            return validator.parseBigDecimal(jsonParser.getText());
        }
    }
}
