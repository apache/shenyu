package com.yeepay.framework.web.exception;

import jakarta.servlet.http.HttpServletRequest;
import lombok.Getter;

/**
 * The type Invalid uri exception.
 */
@Getter
public class InvalidUriException extends RuntimeException {

    private final HttpServletRequest request;

    /**
     * Instantiates a new Invalid uri exception.
     *
     * @param request the request
     */
    public InvalidUriException(HttpServletRequest request) {
        super(request.getRequestURI(), null, false, false);
        this.request = request;
    }
}
