package com.yeepay.framework.web.exception;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorResolvable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * The type Illegal enum argument exception.
 */
@Getter
@RequiredArgsConstructor
public class IllegalEnumArgumentException extends IllegalArgumentException implements ErrorResolvable {

    private final Class<? extends Enum<?>> type;

    private final Object argument;

    @Override
    public ErrorCode getCode() {
        return CommonError.BAD_REQUEST;
    }

    /**
     * 不查找. {@link ErrorCode#getKey}
     * ILLEGAL_PARAM 消息模板第一个参数应该是 param name
     *
     * @see IllegalParamArgumentException#getMessageCodes
     */
    @Override
    public String[] getMessageCodes() {
        return new String[] {type.getName(), String.valueOf(getCode().getCode())};
    }

    @Override
    public Object[] getArguments() {
        return new Object[] {argument};
    }
}
