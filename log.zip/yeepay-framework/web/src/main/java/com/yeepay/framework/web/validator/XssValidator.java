package com.yeepay.framework.web.validator;

import com.yeepay.framework.web.annotation.Xss;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.jsoup.safety.Safelist;

/**
 * The type Xss validator.
 */
public class XssValidator implements ConstraintValidator<Xss, String> {

    private static final Safelist SAFELIST = Safelist.relaxed();

    private static final String[] WHITELIST_ATTR = new String[] {
        "preload",
        "cursor:",
        "font-size:",
        "color",
        "text-decoration:",
        "joinstyle",
        "height",
        "heiti",
        "href",
        "outline:",
        "hiragino",
        "alt",
        "times",
        "border",
        "id",
        "size",
        "background-size:",
        "background-color:",
        "style",
        "color:",
        "o:title",
        "background:",
        "wenquanyi",
        "title",
        "word_img",
        "pingfang",
        "controls",
        ".",
        "width",
        "background-clip:",
        "background-repeat:",
        "text-decoration-line:",
        "rel",
        "eqn",
        "font-variant-numeric:",
        "coordsize",
        "stroked",
        "type",
        "o:preferrelative",
        "filled",
        "white-space:",
        "sans",
        "font-stretch:",
        "data-ke-src",
        "v:ext",
        "segoe",
        "background-origin:",
        "o:spid",
        "line-height:",
        "background-position:",
        "new",
        "path",
        "aspectratio",
        "_src",
        "class",
        "frameborder",
        "name",
        "lang",
        "src",
        "o:extrusionok",
        "background-image:",
        "target",
        "o:connecttype",
        "o:spt",
        "align",
        "background-attachment:",
        "data-setup",
        "face",
        "micro",
        "vspace",
        "allowfullscreen",
        "gradientshapeok",
        "iheight",
        "microsoft",
        "autoplay"
    };

    private static final String[] WHITELIST_TAG = new String[] {
        "v:stroke",
        "v:imagedata",
        "v:formulas",
        "v:shape",
        "v:f",
        "v:shapetype",
        "v:path",
        "o:lock",
        "o:p",
        "a",
        "source",
        "sup",
        "iframe",
        "div",
        "em",
        "pre",
        "strong",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "blockquote",
        "b",
        "li",
        "ul",
        "font",
        "style",
        "span",
        "p",
        "wbr",
        "br",
        "img",
        "video"
    };

    private Xss.Level level;

    static {
        for (String tag : WHITELIST_TAG) {
            SAFELIST.addTags(tag);
            for (String attr : WHITELIST_ATTR) {
                SAFELIST.addAttributes(tag, attr);
            }
        }
    }

    /**
     * Initialize.
     *
     * @param xss the xss
     */
    @Override
    public void initialize(Xss xss) {
        this.level = xss.level();
    }

    /**
     * Is valid boolean.
     *
     * @param value the value
     * @param context the context
     * @return the boolean
     */
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isBlank(value)) {
            return true;
        }
        String valueDecode = value.replace("!>_<!", "@");
        Document.OutputSettings settings = new Document.OutputSettings();
        settings.escapeMode(Entities.EscapeMode.xhtml);
        settings.prettyPrint(false);
        settings.outline(false);
        int valueOldLen = valueDecode.length();
        return switch (this.level) {
            case NONE -> Jsoup.clean(valueDecode, "", Safelist.none(), settings).length() == valueOldLen;
            case SIMPLE_TEXT ->
                Jsoup.clean(valueDecode, "", Safelist.simpleText(), settings).length() == valueOldLen;
            case BASIC ->
                Jsoup.clean(valueDecode, "", Safelist.basic(), settings).length() == valueOldLen;
            case BASIC_WITH_IMAGES ->
                Jsoup.clean(valueDecode, "", Safelist.basicWithImages(), settings)
                                .length()
                        == valueOldLen;
            case RELAXED ->
                Jsoup.clean(valueDecode, "", Safelist.relaxed(), settings).length() == valueOldLen;
            case HUOBI -> Jsoup.clean(valueDecode, "", SAFELIST, settings).length() == valueOldLen;
        };
    }
}
