package com.yeepay.framework.web.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorInfo;
import com.yeepay.framework.web.result.Result;

/**
 * The interface Response.
 *
 * @param <T> the type parameter
 */
public interface Response<T> {

    /**
     * The constant SUCCESS_CODE.
     */
    int SUCCESS_CODE = 200;

    /**
     * Gets code.
     *
     * @return the code
     */
    int getCode();

    /**
     * Gets data.
     *
     * @return the data
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    T getData();

    /**
     * Gets message.
     *
     * @return the message
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    String getMessage();

    /**
     * Sets message.
     *
     * @param message the message
     */
    void setMessage(String message);

    /**
     * Wrap response.
     *
     * @param <E> the type parameter
     * @param result the result
     * @return the response
     */
    static <E> Response<E> wrap(Result<E> result) {
        return new ResponseWrapper<>(result);
    }

    /**
     * Failure response.
     *
     * @param <E> the type parameter
     * @param code the code
     * @return the response
     */
    static <E> Response<E> failure(ErrorCode code) {
        return new ResponseWrapper<>(Result.failure(code));
    }

    /**
     * Failure response.
     *
     * @param <E> the type parameter
     * @param error the error
     * @return the response
     */
    static <E> Response<E> failure(ErrorInfo error) {
        return new ResponseWrapper<>(error);
    }

    /**
     * Failure response.
     *
     * @param <E> the type parameter
     * @param code the code
     * @return the response
     */
    static <E> Response<E> failure(int code) {
        return new ResponseWrapper<>(code, null);
    }

    /**
     * Failure response.
     *
     * @param <E> the type parameter
     * @param code the code
     * @param data the data
     * @return the response
     */
    static <E> Response<E> failure(int code, E data) {
        return new ResponseWrapper<>(code, data, null);
    }

    /**
     * Failure response.
     *
     * @param <E> the type parameter
     * @param code the code
     * @param message the message
     * @param data the data
     * @return the response
     */
    static <E> Response<E> failure(int code, String message, E data) {
        return new ResponseWrapper<>(code, data, message);
    }

    /**
     * Failure response.
     *
     * @param <E> the type parameter
     * @param code the code
     * @param message the message
     * @return the response
     */
    static <E> Response<E> failure(int code, String message) {
        return new ResponseWrapper<>(code, null, message);
    }

    /**
     * Success response.
     *
     * @param <E> the type parameter
     * @param data the data
     * @return the response
     */
    static <E> Response<E> success(E data) {
        return new ResponseWrapper<>(SUCCESS_CODE, data);
    }

    /**
     * Success response.
     *
     * @return the response
     */
    static Response<Void> success() {
        return new ResponseWrapper<>(SUCCESS_CODE, null);
    }
}
