package com.yeepay.framework.web.response;

import com.yeepay.framework.web.error.ErrorResolvable;
import com.yeepay.framework.web.i18n.I18nMessageSource;
import com.yeepay.framework.web.result.Result;
import java.util.Objects;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * The type Result body advice.
 */
@RestControllerAdvice
@Slf4j
public class ResponseAdvice implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(
            final MethodParameter returnType, final Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @SneakyThrows
    @Override
    public Object beforeBodyWrite(
            final Object body,
            final MethodParameter returnType,
            final MediaType mediaType,
            final Class<? extends HttpMessageConverter<?>> selectedConverterType,
            final ServerHttpRequest request,
            final ServerHttpResponse response) {
        Object result;
        if (body instanceof Result<?> tmp) {
            result = new ResponseWrapper<>(tmp);
        } else if (body instanceof ErrorResolvable tmp) {
            result = new ResponseWrapper<>(tmp);
        } else if (body instanceof Response) {
            // do nothing
            result = body;
        } else {
            result = body;
        }
        ErrorResolvable error;
        if (result instanceof final ResponseWrapper<?> wrapper) {
            error = wrapper.getError();
            if (Objects.nonNull(error)) {
                wrapper.setMessage(I18nMessageSource.getMessage(error));
            }
        }
        return result;
    }
}
