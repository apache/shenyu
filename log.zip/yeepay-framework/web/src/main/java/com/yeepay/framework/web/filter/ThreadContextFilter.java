package com.yeepay.framework.web.filter;

import com.yeepay.framework.common.constants.ThreadContextConstants;
import com.yeepay.framework.common.theadcontext.ThreadContextType;
import com.yeepay.framework.common.theadcontext.ThreadContextUtils;
import com.yeepay.framework.common.utils.UUIDGenerator;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;

/**
 * The type Thread context filter.
 */
public class ThreadContextFilter implements Filter {

    @Override
    public void doFilter(final ServletRequest req, final ServletResponse response, final FilterChain chain)
            throws ServletException, IOException {
        if (!(req instanceof final HttpServletRequest request)
                || !(response instanceof final HttpServletResponse resp)) {
            throw new ServletException("RequestContextFilter just supports HTTP requests");
        }
        try {
            if (ThreadContextUtils.contextInitialized()) {
                ThreadContextUtils.clearContext();
            }
            String guid = request.getHeader(ThreadContextConstants.HEADER_THREAD_UID);
            if (StringUtils.isBlank(guid)) {
                guid = UUIDGenerator.getUUID();
            }
            ThreadContextType contextType = ThreadContextType.WEB;
            String contentType = request.getContentType();
            if (ThreadContextConstants.CONTENT_TYPE_HESSIAN.equalsIgnoreCase(contentType)
                    || ThreadContextConstants.CONTENT_TYPE_JAVA_SERIALIZED.equalsIgnoreCase(contentType)) {
                contextType = ThreadContextType.INTERFACE;
            }
            String soaEnv = request.getHeader(ThreadContextConstants.HEADER_CDN_LANE);
            if (StringUtils.isBlank(soaEnv)) {
                soaEnv = request.getHeader(ThreadContextConstants.HEADER_SOA_ENV);
            }
            if (StringUtils.isBlank(soaEnv)) {
                soaEnv = System.getProperty(
                        ThreadContextConstants.PROP_DUBBO_APP_ENV, ThreadContextConstants.DEFAULT_SOA_ENV);
            }
            String soaContext = request.getHeader(ThreadContextConstants.HEADER_CDN_CONTEXT);
            if (StringUtils.isBlank(soaContext)) {
                soaContext = request.getHeader(ThreadContextConstants.HEADER_SOA_CONTEXT);
            }

            String srcSoaApp = request.getHeader(ThreadContextConstants.HEADER_SRC_SOA_APP);
            String transferLevel = request.getHeader(ThreadContextConstants.HEADER_TRANSFER_LEVEL);
            transferLevel =
                    StringUtils.isBlank(transferLevel) ? ThreadContextConstants.DEFAULT_TRANSFER_LEVEL : transferLevel;

            String appName = StringUtils.isNotBlank(request.getContextPath())
                    ? request.getContextPath().replace("/", "")
                    : "";

            ThreadContextUtils.initContext(
                    appName, guid, contextType, transferLevel, soaEnv, srcSoaApp, "", soaContext);
            chain.doFilter(request, response);
        } finally {
            ThreadContextUtils.clearContext();
        }
    }
}
