package com.yeepay.framework.web.exception;

import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorInfo;
import com.yeepay.framework.web.error.ErrorResolvable;
import lombok.experimental.Delegate;

/**
 * The type Error throwable.
 */
public class ErrorThrowable extends RuntimeException implements ErrorResolvable {

    private static final boolean WRITABLE_STACK_TRACE = false;

    @Delegate
    private final ErrorResolvable error;

    /**
     * Instantiates a new Error throwable.
     *
     * @param error the error
     * @param message the message
     * @param cause the cause
     */
    public ErrorThrowable(ErrorResolvable error, String message, Throwable cause) {
        super(message, cause, false, WRITABLE_STACK_TRACE);
        this.error = error;
    }

    /**
     * Instantiates a new Error throwable.
     *
     * @param error the error
     * @param message the message
     */
    public ErrorThrowable(ErrorResolvable error, String message) {
        this(error, message, null);
    }

    /**
     * Instantiates a new Error throwable.
     *
     * @param error the error
     * @param cause the cause
     */
    public ErrorThrowable(ErrorResolvable error, Throwable cause) {
        this(error, null, cause);
    }

    /**
     * Wrap error throwable.
     *
     * @param error the error
     * @return the error throwable
     */
    public static ErrorThrowable wrap(ErrorInfo error) {
        return new ErrorThrowable(error, error.getDetail(), error.getCause());
    }

    /**
     * Wrap error throwable.
     *
     * @param code the code
     * @param error the error
     * @return the error throwable
     */
    public static ErrorThrowable wrap(ErrorCode code, ErrorInfo error) {

        return new ErrorThrowable(error, error.getDetail(), error.getCause()) {
            @Override
            public ErrorCode getCode() {
                return code;
            }
        };
    }
}
