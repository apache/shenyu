package com.yeepay.framework.web.annotation;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import com.yeepay.framework.web.validator.XssValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * The interface Xss.
 */
@Target({METHOD, FIELD, ANNOTATION_TYPE, PARAMETER, CONSTRUCTOR})
@Retention(RUNTIME)
@Constraint(validatedBy = XssValidator.class)
@Documented
public @interface Xss {

    /**
     * Message string.
     *
     * @return the string
     */
    String message() default "输入不符合规范";

    /**
     * Groups class [ ].
     *
     * @return the class [ ]
     */
    Class<?>[] groups() default {};

    /**
     * Payload class [ ].
     *
     * @return the class [ ]
     */
    Class<? extends Payload>[] payload() default {};

    /**
     * Level level.
     *
     * @return the level
     */
    Level level() default Level.NONE;

    /**
     * The enum Level.
     */
    enum Level {

        /**
         * 不允许html代码.
         */
        NONE,

        /**
         * 只允许简单文本格式.
         */
        SIMPLE_TEXT,

        /**
         * 允许常用的html标签.
         * a, b, blockquote, br, cite, code, dd, dl, dt,
         * em, i, li, ol, p, pre, q, small, span, strike, strong, sub, sup, u, ul
         */
        BASIC,

        /**
         * 允许常用的html标签, 以及图片.
         */
        BASIC_WITH_IMAGES,

        /**
         * 允许宽松的html标签.
         * a, b, blockquote, br, caption, cite, code, col, colgroup, dd, div, dl,
         * dt, em, h1, h2, h3, h4, h5, h6, i, img, li, ol, p, pre,
         * q, small, span, strike, strong, sub, sup, table, tbody, td, tfoot, th, thead, tr, u, ul
         */
        RELAXED,

        /**
         * 允许所有html标签, 但会清除脚本等危险属性.
         */
        HUOBI;

        Level() {}
    }
}
