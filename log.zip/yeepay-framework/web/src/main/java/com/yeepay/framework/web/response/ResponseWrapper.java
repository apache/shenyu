package com.yeepay.framework.web.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorResolvable;
import com.yeepay.framework.web.result.Result;
import java.util.Objects;
import lombok.Data;

/**
 * The type Response wrapper.
 *
 * @param <T> the type parameter
 */
@Data
public class ResponseWrapper<T> implements Response<T> {

    @JsonIgnore
    private ErrorResolvable error;

    private T data;

    private int code = CommonError.SUCCESS.getCode();

    private String message;

    /**
     * Instantiates a new Response wrapper.
     *
     * @param error the error
     */
    public ResponseWrapper(ErrorResolvable error) {
        this.error = Objects.requireNonNull(error);
    }

    /**
     * Instantiates a new Response wrapper.
     *
     * @param result the result
     */
    public ResponseWrapper(Result<T> result) {
        this.data = result.getOrDefault(null);
        this.error = result.getError();
    }

    /**
     * Instantiates a new Response wrapper.
     *
     * @param data the data
     */
    public ResponseWrapper(T data) {
        this.data = data;
    }

    /**
     * Instantiates a new Response wrapper.
     *
     * @param code the code
     * @param message the message
     */
    public ResponseWrapper(int code, String message) {
        this(code, null, message);
    }

    /**
     * Instantiates a new Response wrapper.
     *
     * @param code the code
     * @param data the data
     */
    public ResponseWrapper(int code, T data) {
        this(code, data, null);
    }

    /**
     * Instantiates a new Response wrapper.
     *
     * @param code the code
     * @param data the data
     * @param message the message
     */
    public ResponseWrapper(int code, T data, String message) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    @Override
    public int getCode() {
        return Objects.isNull(error) ? code : error.getCode().getCode();
    }
}
