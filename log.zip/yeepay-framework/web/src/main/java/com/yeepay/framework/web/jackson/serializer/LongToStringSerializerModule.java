package com.yeepay.framework.web.jackson.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import java.io.IOException;
import java.util.Objects;

/**
 * 自定义 Jackson Module —— 将 Long/long 类型序列化为 String.
 * 解决前端 JavaScript 中 Number 类型最大安全整数为 2^53 - 1 = 9007199254740991，
 * 超过该值的 Long 型 ID 在前端会出现精度丢失的问题。
 */
public class LongToStringSerializerModule extends SimpleModule {

    /**
     * 构造方法，注册 Long → String 序列化器.
     */
    public LongToStringSerializerModule() {
        super("LongToStringSerializerModule");
        // Long 包装类
        this.addSerializer(Long.class, new LongToStringSerializer());
        // long 基本类型
        this.addSerializer(Long.TYPE, new LongToStringSerializer());
    }

    /**
     * Long → String 序列化器.
     */
    private static class LongToStringSerializer extends JsonSerializer<Long> {

        @Override
        public void serialize(Long value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
            if (Objects.isNull(value)) {
                gen.writeNull();
            } else {
                gen.writeString(value.toString());
            }
        }
    }
}
