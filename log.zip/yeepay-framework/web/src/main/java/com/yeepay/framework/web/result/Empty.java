package com.yeepay.framework.web.result;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorInfo;
import com.yeepay.framework.web.error.ErrorInfoSimple;
import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * The type Empty.
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class Empty implements Result {

    /**
     * The constant SINGLETON.
     */
    public static final Empty SINGLETON = new Empty();

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public boolean isSuccess() {
        return true;
    }

    @Override
    public boolean isFailure() {
        return false;
    }

    @Override
    public ErrorInfo getError() {
        return null;
    }

    @Override
    public Object getValue() throws NoSuchElementException {
        throw createNoSuchElementException();
    }

    @Override
    public Object getOrDefault(Object defaultValue) {
        return defaultValue;
    }

    @Override
    public Object getOrElse(Supplier defaultSupplier) {
        return defaultSupplier.get();
    }

    @Override
    public Object getOrThrow(Function exceptionFactory) throws Throwable {
        NoSuchElementException cause = createNoSuchElementException();
        ErrorInfo error = new ErrorInfoSimple(CommonError.INTERNAL_SERVER_ERROR, cause);
        throw (Throwable) exceptionFactory.apply(error);
    }

    @Override
    public Result filter(Predicate predicate) {
        return this;
    }

    @Override
    public Result ifPresent(Consumer consumer) {
        return this;
    }

    @Override
    public Result ifFailure(Consumer consumer) {
        return this;
    }

    @Override
    public Result ifEmptyAndSuccess(Result result) {
        return result;
    }

    @Override
    public Result map(Function mapper) {
        return this;
    }

    @Override
    public Result flatMap(Function mapper) {
        return this;
    }

    /**
     * Create no such element exception no such element exception.
     *
     * @return the no such element exception
     */
    protected NoSuchElementException createNoSuchElementException() {
        return new NoSuchElementException("No value present");
    }
}
