package com.yeepay.framework.web.error;

import static com.yeepay.framework.web.constants.WebConstant.NOT_TRANSLATED;

import com.yeepay.framework.common.enums.WithCode;
import com.yeepay.framework.web.exception.ErrorThrowable;
import javax.annotation.Nonnull;

/**
 * The interface Error code.
 */
public interface ErrorCode extends WithCode<Integer> {

    /**
     * 用于查找 MessageSource 的 key.
     *
     * @return the key
     */
    @Nonnull
    String getKey();

    /**
     * MessageSource 找不到时使用的默认值.
     *
     * @return the message
     */
    @Nonnull
    default String getMessage() {
        return getKey() + NOT_TRANSLATED;
    }

    /**
     * Create exception error throwable.
     *
     * @return the error throwable
     */
    default ErrorThrowable createException() {
        return ErrorThrowable.wrap(new ErrorInfoSimple(this));
    }
}
