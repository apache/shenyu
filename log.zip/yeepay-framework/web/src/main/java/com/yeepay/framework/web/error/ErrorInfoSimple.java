package com.yeepay.framework.web.error;

import java.util.Objects;
import lombok.Getter;

/**
 * The type Error info simple.
 */
public class ErrorInfoSimple implements ErrorInfo {

    /**
     * The Code.
     */
    @Getter
    private final ErrorCodeWrapper code;

    /**
     * Instantiates a new Error info simple.
     *
     * @param code the code
     */
    public ErrorInfoSimple(ErrorCode code) {
        this(code, code.getKey(), null);
    }

    /**
     * Instantiates a new Error info simple.
     *
     * @param code the code
     * @param e the e
     */
    public ErrorInfoSimple(ErrorCode code, Throwable e) {
        this(code, e.getClass().getName(), null);
    }

    /**
     * Instantiates a new Error info simple.
     *
     * @param code the code
     * @param messageResolved the message resolved
     */
    public ErrorInfoSimple(ErrorCode code, boolean messageResolved) {
        this(code, messageResolved ? code.getMessage() : null);
    }

    /**
     * Instantiates a new Error info simple.
     *
     * @param code the code
     * @param resolvedMessage the resolved message
     */
    public ErrorInfoSimple(ErrorCode code, String resolvedMessage) {
        this(code, code.getKey(), resolvedMessage);
    }

    /**
     * Instantiates a new Error info simple.
     *
     * @param code the code
     * @param key the key
     * @param resolvedMessage the resolved message
     */
    public ErrorInfoSimple(ErrorCode code, String key, String resolvedMessage) {
        this.code = new ErrorCodeWrapper(code, key, resolvedMessage);
    }

    /**
     * Instantiates a new Error info simple.
     *
     * @param code the code
     * @param key the key
     * @param resolvedMessage the resolved message
     */
    public ErrorInfoSimple(Integer code, String key, String resolvedMessage) {
        this.code = new ErrorCodeWrapper(code, key, resolvedMessage);
    }

    @Override
    public final String[] getMessageCodes() {
        if (Objects.nonNull(code.getResolvedMessage())) {
            // 不查询'错误码'对应的默认模板，直接使用 resolved message 作为默认消息
            return new String[] {code.getKey()};
        }
        return getMessageCodesInternal();
    }

    /**
     * Get message codes internal string [ ].
     *
     * @return the string [ ]
     */
    protected String[] getMessageCodesInternal() {
        return new String[] {code.getKey(), String.valueOf(code.getCode())};
    }
}
