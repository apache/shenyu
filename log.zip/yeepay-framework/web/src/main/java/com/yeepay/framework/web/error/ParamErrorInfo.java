package com.yeepay.framework.web.error;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.utils.PropertyPathUtils;
import java.util.Objects;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * @since 2019-11-24
 */
@Getter
@RequiredArgsConstructor
public class ParamErrorInfo implements ErrorInfo {

    private final ErrorCode code;

    private final Throwable cause;

    private final String param;

    private final Object value;

    /**
     * 来自校验注解的自定义消息，既可作为 i18n 消息码解析，也可作为字面量兜底.
     */
    private String validationMessage;

    public ParamErrorInfo(String param, Object value) {
        this.param = param;
        this.value = value;
        this.code = CommonError.BAD_REQUEST;
        this.cause = null;
    }

    public ParamErrorInfo(CommonError code, String param) {
        this(code, null, param, null);
    }

    public ParamErrorInfo(Throwable cause, String param) {
        this(CommonError.BAD_REQUEST, cause, param, null);
    }

    public ParamErrorInfo(Throwable cause, String param, Object value) {
        this(CommonError.BAD_REQUEST, cause, param, value);
    }

    public ParamErrorInfo(Throwable cause, String param, Object value, String validationMessage) {
        this(CommonError.BAD_REQUEST, cause, param, value);
        this.validationMessage = unwrapMessageKey(validationMessage);
    }

    @Override
    public String[] getMessageCodes() {
        if (Objects.isNull(cause)) {
            return new String[] {code.getKey(), String.valueOf(code.getCode())};
        }

        String exception = cause.getClass().getName();
        String param = PropertyPathUtils.removeIndexVariable(this.param);

        if (StringUtils.isNotBlank(validationMessage)) {
            return new String[] {exception + "." + param, validationMessage};
        }
        return new String[] {exception + "." + param, exception, code.getKey(), String.valueOf(code.getCode())};
    }

    @Override
    public Object[] getArguments() {
        return new Object[] {param, value};
    }

    @Override
    public String getDetail() {
        if (Objects.isNull(cause)) {
            return getDefaultMessage() + ", param=" + param;
        }
        return cause.getMessage();
    }

    @Override
    public String getDefaultMessage() {
        if (StringUtils.isNotBlank(validationMessage)) {
            return validationMessage;
        }
        return code.getMessage();
    }

    /**
     * 去除 Jakarta Validation 消息键的花括号包裹, 如 {@code "{example.order-status-error}"} → {@code "example.order-status-error"}.
     */
    private static String unwrapMessageKey(String message) {
        if (StringUtils.isNotBlank(message) && message.startsWith("{") && message.endsWith("}")) {
            return message.substring(1, message.length() - 1);
        }
        return message;
    }
}
