package com.yeepay.framework.web.utils;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * The type Property path utils.
 */
public class PropertyPathUtils {

    private static final Pattern INDEX = Pattern.compile("\\[^]]+]");

    private static final String INDEX_PLACEHOLDER = "[]";

    private static final char INDEX_OPEN = '[';

    private static final char INDEX_CLOSE = ']';

    private static final char PROPERTY_PATH_SEPARATOR = '.';

    /**
     * Remove index variable string.
     *
     * @param path the path
     * @return the string
     */
    public static String removeIndexVariable(String path) {
        return INDEX.matcher(path).replaceAll(INDEX_PLACEHOLDER);
    }

    /**
     * Gets path string.
     *
     * @param e the e
     * @return the path string
     * @see Reference#getDescription
     */
    public static String getPathString(JsonMappingException e) {
        StringBuilder builder = new StringBuilder();
        for (Reference reference : e.getPath()) {
            if (reference.getIndex() >= 0) {
                // array or collection
                builder.append(INDEX_OPEN).append(reference.getIndex()).append(INDEX_CLOSE);
                continue;
            }
            Object from = reference.getFrom();
            Class<?> cls = (from instanceof Class) ? (Class<?>) from : from.getClass();
            String field = reference.getFieldName();
            if (Map.class.isAssignableFrom(cls)) {
                builder.append(INDEX_OPEN).append(field).append(INDEX_CLOSE);
            } else {
                builder.append(PROPERTY_PATH_SEPARATOR).append(field);
            }
        }
        return trim(builder);
    }

    private static String trim(StringBuilder builder) {
        if (builder.length() <= 0) {
            return "";
        }
        if (builder.charAt(0) == PROPERTY_PATH_SEPARATOR) {
            return builder.substring(1);
        }
        return builder.toString();
    }
}
