package com.yeepay.framework.web.validator;

import com.yeepay.framework.web.annotation.ValidBy;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 通用静态方法委托校验器.
 *
 * <p>需要指定包含校验方法的类（不限于枚举），以及返回 boolean 值的静态校验方法。
 */
@Slf4j
public class ValidByValidator implements ConstraintValidator<ValidBy, Object> {

    private Class<?> targetClass;

    private String validationMethod;

    /**
     * 缓存校验方法，key 为参数类型.
     */
    private final Map<Class<?>, Method> methodCache = new ConcurrentHashMap<>();

    @Override
    public void initialize(ValidBy annotation) {
        this.targetClass = annotation.clazz();
        this.validationMethod = annotation.method();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (Objects.isNull(value) || StringUtils.isBlank(value.toString())) {
            return true;
        }
        if (Objects.isNull(targetClass) || Objects.isNull(validationMethod)) {
            return true;
        }
        Class<?> valueClass = value.getClass();

        Method method = resolveMethod(valueClass);
        if (Objects.isNull(method)) {
            log.error(
                    "ValidBy 校验注解, 必须提供一个签名为 public static boolean {}({}) 的方法!",
                    validationMethod,
                    valueClass.getName());
            return false;
        }
        try {
            Boolean result = (Boolean) method.invoke(null, value);
            return Objects.nonNull(result) && result;
        } catch (SecurityException e) {
            throw new IllegalArgumentException(
                    String.format(
                            "This %s(%s) method does not exist in the %s", validationMethod, valueClass, targetClass),
                    e);
        } catch (Exception e) {
            log.info("ValidBy 参数校验时发生异常:{}.{}({}:{})", this.targetClass, this.validationMethod, value, valueClass, e);
            return false;
        }
    }

    /**
     * 解析并缓存具体参数类型对应的校验方法.
     */
    private Method resolveMethod(Class<?> valueClass) {
        Method cached = methodCache.get(valueClass);
        if (Objects.nonNull(cached)) {
            return cached;
        }
        Method method = null;
        try {
            method = this.targetClass.getMethod(validationMethod, valueClass);
        } catch (NoSuchMethodException e) {
            log.info(
                    "This public static boolean {}({}) method does not exist in the {}",
                    validationMethod,
                    valueClass,
                    targetClass);
        }
        if (Objects.nonNull(method) && isValidSignature(method)) {
            methodCache.put(valueClass, method);
            return method;
        }
        return null;
    }

    /**
     * 校验方法是否为 public static 且返回 boolean.
     */
    private boolean isValidSignature(Method method) {
        if (!Boolean.TYPE.equals(method.getReturnType()) && !Boolean.class.equals(method.getReturnType())) {
            throw new IllegalArgumentException(String.format(
                    "%s method return is not boolean type in the %s class", validationMethod, targetClass));
        }
        if (!Modifier.isStatic(method.getModifiers())) {
            throw new IllegalArgumentException(
                    String.format("%s method is not static method in the %s class", validationMethod, targetClass));
        }
        return true;
    }
}
