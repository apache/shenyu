package com.yeepay.framework.web.utils;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Objects;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.servlet.HandlerMapping;

/**
 * The type Handler mapping utils.
 */
public class HandlerMappingUtils {

    private static final String NO_PATTERN = "NoPattern";

    /**
     * Gets request pattern.
     *
     * @param req the req
     * @return the request pattern
     */
    public static String getRequestPattern(NativeWebRequest req) {
        HttpServletRequest request = req.getNativeRequest(HttpServletRequest.class);
        return Objects.isNull(request) ? NO_PATTERN : getRequestPattern(request);
    }

    /**
     * Gets request pattern.
     *
     * @param req the req
     * @return the request pattern
     */
    public static String getRequestPattern(HttpServletRequest req) {
        Object pattern = req.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
        return Objects.nonNull(pattern) ? pattern.toString() : NO_PATTERN;
    }

    /**
     * Gets request path.
     *
     * @param req the req
     * @return the request path
     */
    public static String getRequestPath(HttpServletRequest req) {
        Object path = req.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
        return Objects.nonNull(path) ? path.toString() : req.getRequestURI();
    }
}
