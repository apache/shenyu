package com.yeepay.framework.web.error;

import javax.annotation.Nonnull;

/**
 * 自定义 Exception 可实现此接口，提供对外的错误信息.
 *
 * @since 2019-11-27
 */
@FunctionalInterface
public interface ErrorResolvable {

    /**
     * The constant EMPTY_ARGS.
     */
    Object[] EMPTY_ARGS = new Object[0];

    /**
     * Gets code.
     *
     * @return the code
     */
    @Nonnull
    ErrorCode getCode();

    /**
     * 错误信息参数，可用于替换消息模板中的变量.
     *
     * @return the object [ ]
     */
    @Nonnull
    default Object[] getArguments() {
        return EMPTY_ARGS;
    }

    /**
     * 错误消息码，支持多个依次查询，类似 MessageSourceResolvable.
     *
     * @return the string [ ]
     */
    @Nonnull
    default String[] getMessageCodes() {
        ErrorCode code = getCode();
        return new String[] {code.getKey(), String.valueOf(code.getCode())};
    }

    /**
     * Gets default message.
     *
     * @return the default message
     */
    @Nonnull
    default String getDefaultMessage() {
        return getCode().getMessage();
    }
}
