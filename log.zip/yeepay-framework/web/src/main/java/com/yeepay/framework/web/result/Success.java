package com.yeepay.framework.web.result;

import com.yeepay.framework.web.error.ErrorInfo;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import lombok.Getter;

/**
 * The type Success.
 *
 * @param <T> the type parameter
 */
@Getter
@SuppressWarnings({"unchecked", "rawtypes"})
public final class Success<T> implements Result<T> {

    private final T value;

    private Success(T value) {
        this.value = value;
    }

    /**
     * Value of result.
     *
     * @param <T> the type parameter
     * @param value the value
     * @return the result
     */
    public static <T> Result<T> valueOf(T value) {
        return Objects.isNull(value) ? Empty.SINGLETON : new Success(value);
    }

    @Override
    public ErrorInfo getError() {
        return null;
    }

    @Override
    public boolean isSuccess() {
        return true;
    }

    @Override
    public boolean isFailure() {
        return false;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public T getOrDefault(T defaultValue) {
        return value;
    }

    @Override
    public T getOrElse(Supplier<T> defaultSupplier) {
        return value;
    }

    @Override
    public <X extends Throwable> T getOrThrow(Function<ErrorInfo, ? extends X> exceptionSupplier) {
        return value;
    }

    @Override
    public Result<T> filter(Predicate<? super T> predicate) {
        return predicate.test(value) ? this : Empty.SINGLETON;
    }

    @Override
    public <U> Result<U> map(Function<? super T, ? extends U> mapper) {
        return valueOf(mapper.apply(value));
    }

    @Override
    public <U> Result<U> flatMap(Function<? super T, Result<U>> mapper) {
        return Objects.requireNonNull(mapper.apply(value));
    }

    @Override
    public Result<T> ifPresent(Consumer<? super T> consumer) {
        consumer.accept(value);
        return this;
    }

    @Override
    public Result<T> ifFailure(Consumer<ErrorInfo> consumer) {
        return this;
    }

    @Override
    public Result<T> ifEmpty(Function<ErrorInfo, Result<T>> mapper) {
        return this;
    }

    @Override
    public Result<T> ifEmptyAndSuccess(Result<T> result) {
        return this;
    }
}
