package com.yeepay.framework.web.i18n;

import com.yeepay.framework.web.error.ErrorResolvable;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.lang.Nullable;

/**
 * The type i18n message source.
 */
@Slf4j
public class I18nMessageSource {

    private static final ReloadableResourceBundleMessageSource MESSAGE_SOURCE;

    private static final String SUFFIX = ".properties";

    static {
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        List<String> names = new ArrayList<>();
        names.add("classpath:/i18n/messages");
        try {
            Resource[] resources = resolver.getResources("classpath*:/i18n/messages/*" + SUFFIX);
            for (Resource resource : resources) {
                String filename = resource.getFilename();
                if (Objects.requireNonNull(filename).indexOf('_') < 0) {
                    String basename = StringUtils.substringBeforeLast(filename, SUFFIX);
                    names.add("classpath:/i18n/messages/" + basename);
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        MESSAGE_SOURCE = new ReloadableResourceBundleMessageSource();
        MESSAGE_SOURCE.setBasenames(names.toArray(new String[0]));
        MESSAGE_SOURCE.setFallbackToSystemLocale(false);
        MESSAGE_SOURCE.setDefaultEncoding("UTF-8");
    }

    /**
     * Gets message.
     *
     * @param resolvable the resolvable
     * @return the message
     */
    public static String getMessage(MessageSourceResolvable resolvable) {
        return MESSAGE_SOURCE.getMessage(resolvable, LocaleContextHolder.getLocale());
    }

    /**
     * Gets message.
     *
     * @param code the code
     * @param args the args
     * @param defaultMessage the default message
     * @return the message
     */
    public static String getMessage(String code, @Nullable Object[] args, @Nullable String defaultMessage) {
        Locale locale = LocaleContextHolder.getLocale();
        return MESSAGE_SOURCE.getMessage(code, args, defaultMessage, locale);
    }

    /**
     * Gets message.
     *
     * @param error the error
     * @return the message
     */
    public static String getMessage(ErrorResolvable error) {
        Object[] args = error.getArguments();
        Locale locale = LocaleContextHolder.getLocale();
        for (String code : error.getMessageCodes()) {
            String message = getMessageIfPresent(code, args, locale);
            if (Objects.nonNull(message)) {
                return message;
            }
        }
        return error.getDefaultMessage();
    }

    /**
     * Gets message if present.
     *
     * @param code the code
     * @param args the args
     * @return the message if present
     */
    public static String getMessageIfPresent(String code, @Nullable Object[] args) {
        Locale locale = LocaleContextHolder.getLocale();
        return getMessageIfPresent(code, args, locale);
    }

    /**
     * Gets message if present.
     *
     * @param code the code
     * @param args the args
     * @param locale the locale
     * @return the message if present
     */
    public static String getMessageIfPresent(String code, @Nullable Object[] args, Locale locale) {
        try {
            return MESSAGE_SOURCE.getMessage(code, args, null, locale);
        } catch (IllegalArgumentException e) {
            log.error("illegal message format: {}", code, e);
            return null;
        }
    }
}
