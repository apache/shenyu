package com.yeepay.framework.web.exception;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorResolvable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * The type Illegal param argument exception.
 */
@Getter
@RequiredArgsConstructor
public class IllegalParamArgumentException extends IllegalArgumentException implements ErrorResolvable {

    private final String param;

    private final Object value;

    @Override
    public ErrorCode getCode() {
        return CommonError.BAD_REQUEST;
    }

    @Override
    public String[] getMessageCodes() {
        return new String[] {
            getClass().getName() + "." + param,
            getClass().getName(),
            getCode().getKey(),
            String.valueOf(getCode().getCode())
        };
    }

    @Override
    public Object[] getArguments() {
        return new Object[] {param, value};
    }
}
