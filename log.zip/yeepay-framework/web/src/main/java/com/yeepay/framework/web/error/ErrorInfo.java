package com.yeepay.framework.web.error;

import com.yeepay.framework.web.exception.ErrorThrowable;
import javax.annotation.Nullable;

/**
 * The interface Error info.
 */
public interface ErrorInfo extends ErrorResolvable {

    /**
     * 错误信息，用于日志等内部使用场景.
     *
     * <p>同 {@link ErrorThrowable#getMessage}
     *
     * @return the detail
     */
    @Nullable
    default String getDetail() {
        return getDefaultMessage();
    }

    /**
     * 同 {@link ErrorThrowable#getCause}.
     *
     * @return the cause
     */
    @Nullable
    default Throwable getCause() {
        return null;
    }

    /**
     * Create exception error throwable.
     *
     * @return the error throwable
     */
    default ErrorThrowable createException() {
        return ErrorThrowable.wrap(this);
    }

    /**
     * 替换返回的错误码，message 不变.
     *
     * @param code the code
     * @return the error throwable
     */
    default ErrorThrowable createException(ErrorCode code) {
        return ErrorThrowable.wrap(code, this);
    }
}
