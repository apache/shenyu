package com.yeepay.framework.web.result;

import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorInfo;
import com.yeepay.framework.web.exception.ErrorThrowable;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * The interface Result.
 *
 * @param <T> the type parameter
 */
public interface Result<T> {

    /**
     * Gets value.
     *
     * @return the value
     */
    T getValue();

    /**
     * Gets error.
     *
     * @return the error
     */
    ErrorInfo getError();

    /**
     * Is success boolean.
     *
     * @return the boolean
     */
    boolean isSuccess();

    /**
     * Is failure boolean.
     *
     * @return the boolean
     */
    boolean isFailure();

    /**
     * Is empty boolean.
     *
     * @return the boolean
     */
    boolean isEmpty();

    /**
     * Gets or default.
     *
     * @param defaultValue the default value
     * @return the or default
     */
    T getOrDefault(T defaultValue);

    /**
     * Gets or else.
     *
     * @param defaultSupplier the default supplier
     * @return the or else
     */
    T getOrElse(Supplier<T> defaultSupplier);

    /**
     * Gets or throw.
     *
     * @param <X> the type parameter
     * @param exceptionFactory the exception factory
     * @return the or throw
     * @throws X the x
     */
    <X extends Throwable> T getOrThrow(Function<ErrorInfo, ? extends X> exceptionFactory) throws X;

    /**
     * Gets or throw.
     *
     * @param <X> the type parameter
     * @return the or throw
     * @throws X the x
     */
    default <X extends Throwable> T getOrThrow() throws X {
        return getOrThrow(ErrorThrowable::wrap);
    }

    /**
     * Filter result.
     *
     * @param predicate the predicate
     * @return the result
     */
    Result<T> filter(Predicate<? super T> predicate);

    /**
     * Map result.
     *
     * @param <U> the type parameter
     * @param mapper the mapper
     * @return the result
     */
    <U> Result<U> map(Function<? super T, ? extends U> mapper);

    /**
     * Flat map result.
     *
     * @param <U> the type parameter
     * @param mapper the mapper
     * @return the result
     */
    <U> Result<U> flatMap(Function<? super T, Result<U>> mapper);

    /**
     * If present result.
     *
     * @param consumer the consumer
     * @return the result
     */
    Result<T> ifPresent(Consumer<? super T> consumer);

    /**
     * If failure result.
     *
     * @param consumer the consumer
     * @return the result
     */
    default Result<T> ifFailure(Consumer<ErrorInfo> consumer) {
        if (isFailure()) {
            consumer.accept(getError());
        }
        return this;
    }

    /**
     * If empty result.
     *
     * @param mapper the mapper
     * @return the result
     */
    default Result<T> ifEmpty(Function<ErrorInfo, Result<T>> mapper) {
        if (!isEmpty()) {
            return this;
        }
        return mapper.apply(getError());
    }

    /**
     * If empty and success result.
     *
     * @param result the result
     * @return the result
     */
    default Result<T> ifEmptyAndSuccess(Result<T> result) {
        if (isEmpty() && isSuccess()) {
            return result;
        }
        return this;
    }

    /**
     * Success result.
     *
     * @param <T> the type parameter
     * @return the result
     */
    static <T> Result<T> success() {
        return Empty.SINGLETON;
    }

    /**
     * Success result.
     *
     * @param <T> the type parameter
     * @param value the value
     * @return the result
     */
    static <T> Result<T> success(T value) {
        return Success.valueOf(value);
    }

    /**
     * Empty result.
     *
     * @param <T> the type parameter
     * @return the result
     */
    static <T> Result<T> empty() {
        return Empty.SINGLETON;
    }

    /**
     * Failure result.
     *
     * @param <T> the type parameter
     * @param error the error
     * @return the result
     */
    static <T> Result<T> failure(ErrorCode error) {
        return Failure.valueOf(error);
    }

    /**
     * Failure result.
     *
     * @param <T> the type parameter
     * @param error the error
     * @param args the args
     * @return the result
     */
    static <T> Result<T> failure(ErrorCode error, Object... args) {
        return new Failure(error, args);
    }
}
