package com.yeepay.framework.web.handler;

import com.yeepay.framework.web.enums.CommonError;
import com.yeepay.framework.web.error.ErrorInfoSimple;
import com.yeepay.framework.web.error.ErrorResolvable;
import com.yeepay.framework.web.utils.HandlerMappingUtils;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * The type Application exception handler.
 */
@ResponseBody
@ControllerAdvice
@ResponseStatus(HttpStatus.OK)
@Order
@Slf4j
public class ApplicationExceptionHandler {

    /**
     * Handle error resolvable.
     *
     * @param request the request
     * @param e the e
     * @return the error resolvable
     */
    @ExceptionHandler(Throwable.class)
    public ErrorResolvable handle(HttpServletRequest request, Throwable e) {
        if (e instanceof ErrorResolvable) {
            return (ErrorResolvable) e;
        }
        String error = e.getClass().getName();
        String path = HandlerMappingUtils.getRequestPath(request);
        if (e instanceof RuntimeException) {
            Throwable cause = e.getCause();
            if (Objects.nonNull(cause)) {
                error = cause.getClass().getName();
            }
        }
        log.warn("error: {}, path :{}, message: {}", error, path, e.getMessage(), e);
        return new ErrorInfoSimple(CommonError.INTERNAL_SERVER_ERROR, e);
    }
}
