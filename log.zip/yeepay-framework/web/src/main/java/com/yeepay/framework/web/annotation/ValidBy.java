package com.yeepay.framework.web.annotation;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import com.yeepay.framework.web.validator.ValidByValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * 通用静态方法委托校验注解.
 *
 * <p>通过指定任意类上的 {@code public static boolean} 方法来校验参数值。
 * 不限于枚举，任何拥有合法校验方法签名的类均可使用。
 *
 * <p>用法示例：
 * <pre>{@code
 * @ValidBy(clazz = OrderStatus.class, method = "isValid", message = "订单状态不合法")
 * private String status;
 * }</pre>
 */
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER})
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = ValidByValidator.class)
public @interface ValidBy {

    /**
     * 校验失败时的错误消息.
     *
     * @return the string
     */
    String message() default "参数校验不通过";

    /**
     * 包含校验方法的类, 可以是枚举或普通类.
     *
     * @return the class
     */
    Class<?> clazz();

    /**
     * 校验方法名, 方法签名必须为 {@code public static boolean methodName(参数类型)}.
     *
     * @return the string
     */
    String method() default "isValid";

    /**
     * Groups class [ ].
     *
     * @return the class [ ]
     */
    Class<?>[] groups() default {};

    /**
     * Payload class [ ].
     *
     * @return the class [ ]
     */
    Class<? extends Payload>[] payload() default {};
}
