package com.yeepay.framework.web.utils;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.yeepay.framework.web.error.ParamErrorInfo;
import com.yeepay.framework.web.result.Failure;
import com.yeepay.framework.web.result.Result;
import java.util.Objects;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.MethodArgumentConversionNotSupportedException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/**
 * The type Param error utils.
 */
public class ParamErrorUtils {

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    public static Result<?> handle(MissingServletRequestParameterException e) {
        String parameterName = e.getParameterName();
        return Failure.valueOf(new ParamErrorInfo(e, parameterName));
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    public static Result<?> handle(MethodArgumentConversionNotSupportedException e) {
        String param = e.getParameter().getParameterName();
        return Failure.valueOf(new ParamErrorInfo(e, param, e.getValue()));
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    public static Result<?> handle(MethodArgumentTypeMismatchException e) {
        String param = e.getParameter().getParameterName();
        return Failure.valueOf(new ParamErrorInfo(e, param, e.getValue()));
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    public static Result<?> handle(JsonMappingException e) {
        String param = PropertyPathUtils.getPathString(e);
        Object value = e instanceof InvalidFormatException ? ((InvalidFormatException) e).getValue() : null;
        return Failure.valueOf(new ParamErrorInfo(e, param, value));
    }

    /**
     * Handle result.
     *
     * @param e the e
     * @return the result
     */
    public static Result<?> handle(MethodArgumentNotValidException e) {
        FieldError fieldError = e.getBindingResult().getFieldError();
        if (Objects.nonNull(fieldError)) {
            return handleFieldError(fieldError, e);
        }

        String param =
                Objects.requireNonNull(e.getBindingResult().getGlobalError()).getObjectName();
        return Failure.valueOf(new ParamErrorInfo(e, param));
    }

    private static Result<?> handleFieldError(FieldError error, Throwable ex) {
        String param = error.getField();
        Object value = error.getRejectedValue();
        String validationMessage = error.getDefaultMessage();
        return Failure.valueOf(new ParamErrorInfo(ex, param, value, validationMessage));
    }
}
