package com.yeepay.framework.web.exception;

import com.yeepay.framework.web.error.ErrorCode;
import com.yeepay.framework.web.error.ErrorResolvable;
import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * The type Biz exception.
 */
@Getter
@RequiredArgsConstructor
public class BizException extends RuntimeException implements ErrorResolvable {

    private final ErrorCode errorCode;

    /**
     * 目前只支持集合和对象.
     */
    private final Object param;

    @Override
    public ErrorCode getCode() {
        return errorCode;
    }

    @Override
    public Object[] getArguments() {
        if (param instanceof List) {
            return ((List<?>) param).toArray();
        }
        return new Object[] {param};
    }
}
