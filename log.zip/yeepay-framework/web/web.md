# Web 请求追踪 (Web)

## 概述

Web 模块为每个 HTTP 请求提供全局异常封装、统一返回结构、XSS 防护、BigDecimal 安全校验、Jackson 定制化序列化、参数校验增强注解以及国际化（i18n）服务。

引入依赖后无需编写任何代码，`ThreadContextFilter` 自动拦截所有请求（`/*`）并初始化线程上下文，异常处理器和响应包装器自动生效。

## 快速开始

### 1. 添加依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-web</artifactId>
</dependency>
```

该 starter 会传递引入：
- `com.yeepay.framework:web` — 核心库
- `spring-boot-starter-web` — Spring MVC
- `spring-boot-starter-validation` — Jakarta Bean Validation

### 2. 配置

```yaml
yeepay:
  framework:
    web:
      enabled: true               # 默认 true，false 关闭所有 web 自动配置
      big-decimal-checker: true   # 默认 true，BigDecimal 安全校验开关
      big-decimal:
        exponent: 5                # 科学计数法最大指数（绝对值），默认 5
        max-length: 75             # 输入字符串最大长度，默认 75
      jackson:
        enabled: true              # 默认 true，Jackson 定制化开关
        long-to-string-serializer: false  # 默认 false，开启后 Long 序列化为字符串
```

## 功能详解

### 1. 统一返回结构

框架通过 `ResponseAdvice`（`@RestControllerAdvice`）自动包装 Controller 返回值，将 `Result<?>` 和 `ErrorResolvable` 统一转为标准 JSON 响应。

**成功响应：**
```json
{
  "code": 200,
  "data": { "id": 123, "name": "example" }
}
```

**失败响应：**
```json
{
  "code": 400,
  "data": null,
  "message": "参数错误: fieldName"
}
```

**包装规则：**
| Controller 返回类型 | 行为 |
|---|---|
| `Result<?>` | 包装为 `{code, data, message}` |
| `ErrorResolvable` | 包装为 `{code, message}`（data 为 null） |
| `Response` | 原样返回，不做处理 |
| 其他类型 | 原样返回 |

**核心类型说明：**

- **`Result<T>`** — 函数式结果类型，提供 `map()`、`flatMap()`、`filter()` 等单子操作。工厂方法：`Result.success(T)`、`Result.failure(ErrorCode)`、`Result.empty()`
- **`Response<T>`** — JSON 响应接口，直接面向 Controller 返回值。工厂方法：`Response.success(data)`、`Response.failure(ErrorCode)` 等
- **`ErrorCode`** — 错误码接口，定义 `getCode()`、`getKey()`（i18n 查找键）、`getMessage()`

### 2. 全局异常处理

框架注册了两个 `@ControllerAdvice`，所有异常都返回 **HTTP 200**（错误信息在响应体中），仅 `NoHandlerFoundException` 返回 404。

#### MvcExceptionHandler（`@Order(HIGHEST_PRECEDENCE)`）

处理 9 种 Spring MVC 异常，统一转为 `ParamErrorInfo`：

| 异常类型 | 说明 |
|---|---|
| `MissingServletRequestParameterException` | 缺少必填参数 |
| `MethodArgumentConversionNotSupportedException` | 参数类型转换不支持 |
| `MethodArgumentTypeMismatchException` | 参数类型不匹配 |
| `MethodArgumentNotValidException` | Jakarta Validation 校验失败 |
| `HttpMessageNotReadableException` | 请求体不可读（含 BigDecimal 反序列化错误识别） |
| `HttpRequestMethodNotSupportedException` | HTTP 方法不支持 |
| `HttpMediaTypeNotSupportedException` | Content-Type 不支持 |
| `HttpMediaTypeNotAcceptableException` | Accept 类型不支持 |
| `MaxUploadSizeExceededException` | 上传文件超限 |
| `NoHandlerFoundException` | 无匹配处理器（返回 404） |

#### ApplicationExceptionHandler

兜底处理器，捕获 `Throwable`：
- 若异常已实现 `ErrorResolvable`（如 `BizException`、`ErrorThrowable`），直接透传
- 其他异常包装为 `CommonError.INTERNAL_SERVER_ERROR`，记录 WARN 日志

### 3. 业务异常

```java
// 抛出业务异常，使用预定义错误码
throw new BizException(CommonError.FREQUENT_INVOKE, "param");

// 使用自定义 ErrorCode
throw new BizException(customErrorCode, arg1, arg2);
```

`BizException` 实现 `ErrorResolvable`，会被 `ApplicationExceptionHandler` 自动识别并返回对应的错误码和 i18n 消息。

**预定义错误码（`CommonError`）：**

| 枚举值 | Code | i18n Key |
|---|---|---|
| `BAD_REQUEST` | 400 | `common.bad-request` |
| `UNAUTHORIZED` | 401 | `common.unauthorized` |
| `FORBIDDEN` | 403 | `common.forbidden` |
| `NOT_FOUND` | 404 | `common.not-found` |
| `METHOD_NOT_ALLOWED` | 405 | `common.method-not-allowed` |
| `INTERNAL_SERVER_ERROR` | 500 | `common.internal-server-error` |
| `FREQUENT_INVOKE` | 512 | `common.frequent-invoke` |
| `RECORD_NON_EXISTENT` | 513 | `common.record-non-existent` |
| `OPERATE_ERROR` | 514 | `common.operate-error` |
| `BLACKLIST` | 515 | `common.blacklist` |

完整覆盖 HTTP 100-511 所有标准状态码。

### 4. XSS 防护

`@Xss` 注解支持对字符串字段进行 HTML/脚本注入过滤，基于 Jsoup `Safelist` 实现。

```java
public class CreateOrderRequest {

    @Xss(level = Xss.Level.SIMPLE_TEXT)
    private String description;

    @Xss  // 默认 NONE，不允许任何 HTML
    private String username;
}
```

**6 种过滤级别：**

| 级别 | 说明 |
|---|---|
| `NONE` | 不允许任何 HTML 标签 |
| `SIMPLE_TEXT` | 仅允许 `b, em, i, strong, u` |
| `BASIC` | 允许基本文本格式标签和链接 |
| `BASIC_WITH_IMAGES` | BASIC + 图片 |
| `RELAXED` | 允许大部分格式化标签 |
| `HUOBI` | 自定义宽松白名单，支持 VML/Office 标签 |

空值通过校验，仅非空字符串触发过滤。

### 5. 自定义校验注解 `@ValidBy`

将校验逻辑委托给任意类的 `public static boolean` 方法，不局限于枚举。

```java
public class OrderStatus {
    public static boolean isValid(String status) {
        return Set.of("PENDING", "SHIPPED", "DELIVERED").contains(status);
    }
}

public class UpdateOrderRequest {
    @ValidBy(clazz = OrderStatus.class, method = "isValid")
    private String status;
}
```

默认方法名为 `isValid`，方法必须为 `public static boolean methodName(字段类型)`。null/空值自动通过。

### 6. BigDecimal 安全校验

防止 BigDecimal 反序列化时传入极端值（超大指数、超长字符串）导致性能问题或拒绝服务。

- **JSON 反序列化**：通过 `BigDecimalDeserializerModule` 拦截 Jackson 的 `BigDecimal` 反序列化
- **表单/查询参数**：通过 `BigDecimalConverter`（Spring `Converter`）拦截字符串到 `BigDecimal` 的转换
- 校验不通过时抛出 `IllegalStateException`，被 `MvcExceptionHandler` 识别为参数错误

```yaml
yeepay:
  framework:
    web:
      big-decimal-checker: true   # 默认开启
      big-decimal:
        exponent: 5                # 最大科学计数法指数，如 1E+5
        max-length: 75             # 最大输入长度（字符数）
```

### 7. Jackson 定制化

#### Long 转 String 序列化

JavaScript 中 `Number` 类型仅能安全表示 ±2^53-1 以内的整数，超出会丢失精度。开启 `long-to-string-serializer` 后，所有 `Long`/`long` 类型字段序列化为 JSON 字符串。

```yaml
yeepay:
  framework:
    web:
      jackson:
        long-to-string-serializer: true   # Long ID 以字符串形式返回
```

效果对比：
```json
// 关闭时
{ "id": 1234567890123456789 }

// 开启后
{ "id": "1234567890123456789" }
```

#### ObjectMapper 定制

- `Jackson2ObjectMapperBuilderCustomizer` 自动注册 `BigDecimalDeserializerModule` 和 `LongToStringSerializerModule`
- `MappingJackson2HttpMessageConverter` 仅接受 `application/json` 媒体类型

### 8. 国际化（i18n）

框架自动扫描 `classpath*:/i18n/messages/*.properties` 下所有不含语言后缀的文件作为消息源基础名。

**内置消息文件：**

- `classpath:/i18n/messages/common.properties`（英文，默认回退）
- `classpath:/i18n/messages/common_zh_CN.properties`（中文）
- `classpath:/i18n/messages/common_en_US.properties`（英文）

**内置翻译键：**

| Key | 英文 | 中文 |
|---|---|---|
| `common.illegal-param` | Incorrect parameter: {0} | 参数错误: {0} |
| `common.param-missing` | Parameter is missing: {0} | 缺少参数: {0} |
| `common.operate-error` | {0} | {0} |
| `common.time-out` | Operation timeout, please try again | 操作超时，请重试 |

**扩展自定义消息：**

在 `src/main/resources/i18n/messages/` 下添加 `.properties` 文件即可自动加载：

```
src/main/resources/i18n/messages/
  order.properties          # 基础名（会被自动发现）
  order_zh_CN.properties     # 中文翻译
  order_en_US.properties     # 英文翻译
```

**消息解析优先级：**

`I18nMessageSource.getMessage(ErrorResolvable)` 按以下顺序查找：
1. `error.getMessageCodes()` 中最具体的消息码（如 `MethodArgumentNotValidException.fieldName`）
2. 依次回退到更通用的消息码（如 `MethodArgumentNotValidException` → `common.bad-request` → `400`）
3. 兜底使用 `error.getDefaultMessage()`（格式为 `key(NT)`，`(NT)` 表示未翻译）

**程序化使用：**

```java
ErrorCode myError = CommonError.BAD_REQUEST;
String message = I18nMessageSource.getMessage(new ErrorInfoSimple(myError));
```

### 9. 请求追踪（ThreadContextFilter）

`ThreadContextFilter` 注册在 `/*`，优先级为 `Ordered.HIGHEST_PRECEDENCE`，每个请求自动初始化线程上下文。

**初始化内容：**

| 上下文字段 | 来源 |
|---|---|
| GUID | 请求头 `X-Yeepay-UID`，不存在则自动生成 UUID |
| 上下文类型 | 默认 `WEB`；若 `Content-Type` 为 `application/x-hessian` 或 `application/x-java-serialized-object` 则为 `INTERFACE` |
| SOA 环境 | 请求头 `cdn-lane` > `x-soa-env` > 系统属性 `dubbo.application.env` |
| SOA 上下文 | 请求头 `cdn-context` > `x-soa-context` |
| 来源应用 | 请求头 `x-src-soa-app` |
| 传递层级 | 请求头 `x-transfer-level`，默认 `"1"` |
| 应用名 | `request.getContextPath()`（去掉前缀 `/`） |

请求结束后在 `finally` 块中自动清理上下文。

### 10. Result 单子 API

`Result<T>` 提供类似 Scala `Try`/`Either` 的函数式编程风格：

```java
// 创建
Result<String> success = Result.success("data");
Result<String> failure = Result.failure(CommonError.BAD_REQUEST);
Result<String> empty = Result.empty();

// 转换
Result<Integer> length = success.map(String::length);

// 条件过滤
Result<String> filtered = success.filter(s -> s.length() > 3);

// 链式调用
Result<User> user = userService.findById(id)
    .filter(u -> u.isActive())
    .map(u -> u.withStatus("VERIFIED"));

// 消费
result.ifPresent(value -> log.info("Got: {}", value));
result.ifFailure(error -> log.warn("Failed: {}", error.getMessage()));

// 解包
String value = result.getOrDefault("default");
String value = result.getOrElse(() -> loadFallback());
String value = result.getOrThrow(() -> new RuntimeException("required"));
```

`Empty` 是单例（`Empty.SINGLETON`），表示"成功但无数据"的状态——`isSuccess()=true`，`isEmpty()=true`，所有 `map`/`filter` 操作返回自身。

## 禁用 Web 模块

```yaml
yeepay:
  framework:
    web:
      enabled: false
```

设为 `false` 后，`ThreadContextFilter`、异常处理器、响应包装器、Jackson 定制化全部不生效。

## 完整配置参考

| 属性 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `yeepay.framework.web.enabled` | Boolean | `true` | 总开关 |
| `yeepay.framework.web.big-decimal-checker` | Boolean | `true` | BigDecimal 安全校验开关 |
| `yeepay.framework.web.big-decimal.exponent` | Integer | `5` | 科学计数法最大指数 |
| `yeepay.framework.web.big-decimal.max-length` | Integer | `75` | BigDecimal 输入最大长度 |
| `yeepay.framework.web.jackson.enabled` | Boolean | `true` | Jackson 定制化开关 |
| `yeepay.framework.web.jackson.long-to-string-serializer` | Boolean | `false` | Long 序列化为字符串 |
