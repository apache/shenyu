package com.yeepay.framework.springboot.starter.infra.jedis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

import com.yeepay.framework.infra.jedis.JedisClientFactory;
import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import redis.clients.jedis.UnifiedJedis;

class InfraJedisAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(ctx ->
                    ConfigurationPropertiesBindingPostProcessor.register((BeanDefinitionRegistry) ctx.getBeanFactory()))
            .withConfiguration(AutoConfigurations.of(InfraJedisAutoConfiguration.class));

    @Test
    void autoConfiguration_createsJedisConfigAndUnifiedJedis() {
        UnifiedJedis mockClient = mock(UnifiedJedis.class);
        try (MockedStatic<JedisClientFactory> factory = mockStatic(JedisClientFactory.class)) {
            factory.when(() -> JedisClientFactory.create(any(JedisConfig.class), any()))
                    .thenReturn(mockClient);

            contextRunner
                    .withPropertyValues(
                            InfraJedisAutoConfiguration.PREFIX + ".password=secret",
                            InfraJedisAutoConfiguration.PREFIX + ".single.host=127.0.0.1",
                            InfraJedisAutoConfiguration.PREFIX + ".single.port=6379")
                    .run(context -> {
                        assertThat(context).hasSingleBean(JedisConfig.class);
                        assertThat(context).hasSingleBean(UnifiedJedis.class);

                        JedisConfig jedisConfig = context.getBean(JedisConfig.class);
                        assertThat(jedisConfig.getPassword()).isEqualTo("secret");
                        assertThat(jedisConfig.getSingle().getHost()).isEqualTo("127.0.0.1");
                        assertThat(jedisConfig.getSingle().getPort()).isEqualTo(6379);

                        assertThat(context.getBean(UnifiedJedis.class)).isSameAs(mockClient);
                    });
        }
    }

    @Test
    void autoConfiguration_appliesCustomizerWhenPresent() {
        UnifiedJedis mockClient = mock(UnifiedJedis.class);
        try (MockedStatic<JedisClientFactory> factory = mockStatic(JedisClientFactory.class)) {
            factory.when(() -> JedisClientFactory.create(any(JedisConfig.class), any(JedisConfigCustomizer.class)))
                    .thenReturn(mockClient);

            contextRunner
                    .withUserConfiguration(CustomizerConfig.class)
                    .withPropertyValues(InfraJedisAutoConfiguration.PREFIX + ".single.host=127.0.0.1")
                    .run(context -> {
                        assertThat(context).hasSingleBean(UnifiedJedis.class);
                        assertThat(context).hasSingleBean(JedisConfigCustomizer.class);
                        assertThat(context.getBean(UnifiedJedis.class)).isSameAs(mockClient);

                        factory.verify(() ->
                                JedisClientFactory.create(any(JedisConfig.class), any(JedisConfigCustomizer.class)));
                    });
        }
    }

    @Test
    void autoConfiguration_backsOffWhenUserProvidesUnifiedJedis() {
        UnifiedJedis userClient = mock(UnifiedJedis.class);
        contextRunner.withBean(UnifiedJedis.class, () -> userClient).run(context -> {
            assertThat(context).hasSingleBean(UnifiedJedis.class);
            assertThat(context.getBean(UnifiedJedis.class)).isSameAs(userClient);
        });
    }

    @Test
    void autoConfiguration_failsWhenNoModeConfigured() {
        contextRunner
                .withPropertyValues(InfraJedisAutoConfiguration.PREFIX + ".password=secret")
                .run(context -> assertThat(context).hasFailed());
    }

    @Configuration
    static class CustomizerConfig {
        @Bean
        JedisConfigCustomizer jedisConfigCustomizer() {
            return jedis -> {};
        }
    }
}
