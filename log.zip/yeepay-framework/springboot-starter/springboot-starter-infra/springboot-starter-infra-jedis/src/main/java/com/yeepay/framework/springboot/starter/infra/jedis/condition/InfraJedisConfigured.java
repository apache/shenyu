package com.yeepay.framework.springboot.starter.infra.jedis.condition;

import com.yeepay.framework.springboot.starter.infra.jedis.InfraJedisAutoConfiguration;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * 当配置文件中存在 {@value InfraJedisAutoConfiguration#PREFIX} 前缀的属性时匹配.
 */
public class InfraJedisConfigured implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        return Binder.get(context.getEnvironment())
                .bind(InfraJedisAutoConfiguration.PREFIX, Bindable.mapOf(String.class, Object.class))
                .isBound();
    }
}
