package com.yeepay.framework.springboot.starter.infra.jedis;

import com.yeepay.framework.infra.jedis.JedisClientFactory;
import com.yeepay.framework.infra.jedis.config.JedisConfig;
import com.yeepay.framework.infra.jedis.config.JedisConfig.Model;
import com.yeepay.framework.infra.jedis.config.JedisConfigCustomizer;
import com.yeepay.framework.springboot.starter.infra.jedis.condition.InfraJedisConfigured;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import redis.clients.jedis.UnifiedJedis;

/**
 * Jedis 客户端自动配置.
 *
 * <p>支持两种配置模式：
 * <ul>
 *   <li>Spring 属性绑定：通过 {@code yeepay.framework.infra.jedis.*} 配置</li>
 *   <li>Classpath 文件加载：通过 {@code config-path} 和 {@code config-file} 指定本地配置文件</li>
 * </ul>
 *
 * <p>若容器中已存在 {@link UnifiedJedis} Bean，则跳过自动创建，
 * 允许用户完全自定义客户端。
 */
@AutoConfiguration
@Conditional(InfraJedisConfigured.class)
public class InfraJedisAutoConfiguration {

    public static final String PREFIX = "yeepay.framework.infra.jedis";

    /**
     * 创建 Jedis 配置对象.
     *
     * @return Jedis 配置
     */
    @Bean
    @ConfigurationProperties(prefix = PREFIX)
    public JedisConfig jedisConfig() {
        return new JedisConfig();
    }

    /**
     * Jedis client.
     *
     * @param jedisConfig Jedis 配置
     * @param customizers 可选的客户端定制器
     * @return Jedis 客户端
     */
    @Bean
    @ConditionalOnMissingBean
    public UnifiedJedis jedisClient(JedisConfig jedisConfig, ObjectProvider<JedisConfigCustomizer> customizers) {
        Model model = jedisConfig.getModel();
        if (model.getType().equals("yaml")) {
            return JedisClientFactory.create(jedisConfig, customizers.getIfAvailable());
        } else {
            if (StringUtils.isNotBlank(model.getPath()) && StringUtils.isNotBlank(model.getFileName())) {
                return JedisClientFactory.createFromClasspath(
                        model.getPath(), model.getFileName(), customizers.getIfAvailable());
            } else {
                return JedisClientFactory.createFromClasspath(customizers.getIfAvailable());
            }
        }
    }
}
