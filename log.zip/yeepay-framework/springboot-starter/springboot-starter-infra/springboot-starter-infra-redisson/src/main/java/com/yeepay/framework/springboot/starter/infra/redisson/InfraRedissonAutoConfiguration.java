package com.yeepay.framework.springboot.starter.infra.redisson;

import com.yeepay.framework.infra.redisson.RedissonClientFactory;
import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.Model;
import com.yeepay.framework.infra.redisson.config.RedissonConfigCustomizer;
import com.yeepay.framework.springboot.starter.infra.redisson.condition.InfraRedissonConfigured;
import org.apache.commons.lang3.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;

/**
 * Redisson 客户端自动配置.
 *
 * <p>支持两种配置模式：
 * <ul>
 *   <li>Spring 属性绑定：通过 {@code yeepay.framework.infra.redisson.*} 配置</li>
 *   <li>Classpath 文件加载：通过 {@code config-path} 和 {@code config-file} 指定本地配置文件</li>
 * </ul>
 */
@AutoConfiguration
@ConditionalOnClass({Redisson.class})
@Conditional(InfraRedissonConfigured.class)
public class InfraRedissonAutoConfiguration {

    /**
     * The constant PREFIX.
     */
    public static final String PREFIX = "yeepay.framework.infra.redisson";

    /**
     * 创建 Redisson 配置对象.
     *
     * @return Redisson 配置
     */
    @Bean
    @ConfigurationProperties(prefix = PREFIX)
    public RedissonConfig redissonConfig() {
        return new RedissonConfig();
    }

    /**
     * Redisson client.
     *
     * @param redissonConfig the Redisson config
     * @param customizers the customizers
     * @return the Redisson client
     */
    @Bean
    @ConditionalOnMissingBean(RedissonClient.class)
    public RedissonClient redissonClient(
            RedissonConfig redissonConfig, ObjectProvider<RedissonConfigCustomizer> customizers) {
        Model model = redissonConfig.getModel();
        if (model.getType().equals("yaml")) {
            return RedissonClientFactory.create(redissonConfig, customizers.getIfAvailable());
        } else {
            if (StringUtils.isNotBlank(model.getPath()) && StringUtils.isNotBlank(model.getFileName())) {
                return RedissonClientFactory.createFromClasspath(
                        model.getPath(), model.getFileName(), customizers.getIfAvailable());
            } else {
                return RedissonClientFactory.createFromClasspath(customizers.getIfAvailable());
            }
        }
    }
}
