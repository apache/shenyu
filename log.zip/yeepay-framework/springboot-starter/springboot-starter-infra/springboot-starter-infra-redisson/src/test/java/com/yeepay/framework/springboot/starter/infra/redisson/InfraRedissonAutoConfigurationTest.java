package com.yeepay.framework.springboot.starter.infra.redisson;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

import com.yeepay.framework.infra.redisson.RedissonClientFactory;
import com.yeepay.framework.infra.redisson.config.RedissonConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.BaseConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.CleanupConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.ClusterConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.ConnectionConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.ConnectionPoolConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.LockConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.MiscConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.PubSubConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SentinelConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SingleConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.SubscriptionConfig;
import com.yeepay.framework.infra.redisson.config.RedissonConfig.TcpConfig;
import com.yeepay.framework.infra.redisson.enums.CodecType;
import java.time.Duration;
import java.util.Objects;
import java.util.Properties;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Protocol;
import org.redisson.config.ReadMode;
import org.redisson.config.ShardedSubscriptionMode;
import org.redisson.config.SubscriptionMode;
import org.redisson.config.TransportMode;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.core.io.ClassPathResource;

class InfraRedissonAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(ctx ->
                    ConfigurationPropertiesBindingPostProcessor.register((BeanDefinitionRegistry) ctx.getBeanFactory()))
            .withConfiguration(AutoConfigurations.of(InfraRedissonAutoConfiguration.class));

    // ==================== YAML 加载工具 / YAML loading utility ====================

    /**
     * 从 classpath 加载 YAML 配置文件并转换为属性键值对数组，供 ApplicationContextRunner 使用。
     * Load a YAML config from classpath, convert to property key-value pairs for ApplicationContextRunner.
     */
    private String[] loadYaml(String classpathLocation) {
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource(classpathLocation));
        Properties properties = Objects.requireNonNull(yaml.getObject());
        return properties.entrySet().stream()
                .map(e -> e.getKey() + "=" + e.getValue())
                .toArray(String[]::new);
    }

    // ==================== 通用断言方法 / Common assertion helpers ====================

    /** 验证全局配置（threads, nettyThreads, transportMode, codec, protocol） */
    private void assertGlobalConfig(
            RedissonConfig config,
            int threads,
            int nettyThreads,
            TransportMode transportMode,
            CodecType codec,
            Protocol protocol) {
        assertThat(config.getThreads()).as("threads").isEqualTo(threads);
        assertThat(config.getNettyThreads()).as("nettyThreads").isEqualTo(nettyThreads);
        assertThat(config.getTransportMode()).as("transportMode").isEqualTo(transportMode);
        assertThat(config.getCodec()).as("codec").isEqualTo(codec);
        assertThat(config.getProtocol()).as("protocol").isEqualTo(protocol);
    }

    /** 验证分布式锁配置 */
    private void assertLockConfig(
            LockConfig lock,
            Duration watchdogTimeout,
            int watchdogBatchSize,
            Duration fairWaitTimeout,
            boolean checkSyncedSlaves,
            Duration slavesSyncTimeout) {
        assertThat(lock.getWatchdogTimeout()).as("lock.watchdogTimeout").isEqualTo(watchdogTimeout);
        assertThat(lock.getWatchdogBatchSize()).as("lock.watchdogBatchSize").isEqualTo(watchdogBatchSize);
        assertThat(lock.getFairWaitTimeout()).as("lock.fairWaitTimeout").isEqualTo(fairWaitTimeout);
        assertThat(lock.isCheckSyncedSlaves()).as("lock.checkSyncedSlaves").isEqualTo(checkSyncedSlaves);
        assertThat(lock.getSlavesSyncTimeout()).as("lock.slavesSyncTimeout").isEqualTo(slavesSyncTimeout);
    }

    /** 验证发布订阅配置 */
    private void assertPubSubConfig(PubSubConfig pubSub, boolean keepOrder, Duration reliableTopicWatchdogTimeout) {
        assertThat(pubSub.isKeepOrder()).as("pubSub.keepOrder").isEqualTo(keepOrder);
        assertThat(pubSub.getReliableTopicWatchdogTimeout())
                .as("pubSub.reliableTopicWatchdogTimeout")
                .isEqualTo(reliableTopicWatchdogTimeout);
    }

    /** 验证内存清理配置 */
    private void assertCleanupConfig(CleanupConfig cleanup, Duration minDelay, Duration maxDelay, int keysAmount) {
        assertThat(cleanup.getMinDelay()).as("cleanup.minDelay").isEqualTo(minDelay);
        assertThat(cleanup.getMaxDelay()).as("cleanup.maxDelay").isEqualTo(maxDelay);
        assertThat(cleanup.getKeysAmount()).as("cleanup.keysAmount").isEqualTo(keysAmount);
    }

    /** 验证其他配置 */
    private void assertMiscConfig(
            MiscConfig misc, boolean referenceEnabled, boolean useScriptCache, boolean lazyInitialization) {
        assertThat(misc.isReferenceEnabled()).as("misc.referenceEnabled").isEqualTo(referenceEnabled);
        assertThat(misc.isUseScriptCache()).as("misc.useScriptCache").isEqualTo(useScriptCache);
        assertThat(misc.isLazyInitialization()).as("misc.lazyInitialization").isEqualTo(lazyInitialization);
    }

    /** 验证连接池配置 */
    private void assertConnectionPoolConfig(
            String prefix,
            ConnectionPoolConfig pool,
            int minimumIdleSize,
            int poolSize,
            Duration reconnectionInterval) {
        assertThat(pool.getMinimumIdleSize()).as(prefix + ".minimumIdleSize").isEqualTo(minimumIdleSize);
        assertThat(pool.getPoolSize()).as(prefix + ".poolSize").isEqualTo(poolSize);
        assertThat(pool.getReconnectionInterval())
                .as(prefix + ".reconnectionInterval")
                .isEqualTo(reconnectionInterval);
    }

    /** 验证 BaseConfig 通用字段（clientName, username, password, database, beanNames） */
    private void assertBaseConfig(
            String prefix,
            BaseConfig base,
            String clientName,
            String username,
            String password,
            int database,
            String clientBeanName,
            String dataManagerBeanName,
            String lockBeanName) {
        assertThat(base.getClientName()).as(prefix + ".clientName").isEqualTo(clientName);
        assertThat(base.getUsername()).as(prefix + ".username").isEqualTo(username);
        assertThat(base.getPassword()).as(prefix + ".password").isEqualTo(password);
        assertThat(base.getDatabase()).as(prefix + ".database").isEqualTo(database);
        assertThat(base.getClientBeanName()).as(prefix + ".clientBeanName").isEqualTo(clientBeanName);
        assertThat(base.getDataManagerBeanName())
                .as(prefix + ".dataManagerBeanName")
                .isEqualTo(dataManagerBeanName);
        assertThat(base.getLockBeanName()).as(prefix + ".lockBeanName").isEqualTo(lockBeanName);
    }

    /** 验证连接配置 */
    private void assertConnectionConfig(
            String prefix,
            ConnectionConfig conn,
            Duration idleTimeout,
            Duration connectTimeout,
            Duration timeout,
            int retryAttempts,
            Duration pingInterval) {
        assertThat(conn.getIdleTimeout()).as(prefix + ".connection.idleTimeout").isEqualTo(idleTimeout);
        assertThat(conn.getConnectTimeout())
                .as(prefix + ".connection.connectTimeout")
                .isEqualTo(connectTimeout);
        assertThat(conn.getTimeout()).as(prefix + ".connection.timeout").isEqualTo(timeout);
        assertThat(conn.getRetryAttempts())
                .as(prefix + ".connection.retryAttempts")
                .isEqualTo(retryAttempts);
        assertThat(conn.getPingInterval())
                .as(prefix + ".connection.pingInterval")
                .isEqualTo(pingInterval);
    }

    /** 验证订阅配置 */
    private void assertSubscriptionConfig(String prefix, SubscriptionConfig sub, Duration timeout, int perConnection) {
        assertThat(sub.getTimeout()).as(prefix + ".subscription.timeout").isEqualTo(timeout);
        assertThat(sub.getPerConnection())
                .as(prefix + ".subscription.perConnection")
                .isEqualTo(perConnection);
    }

    /** 验证 TCP 配置 */
    private void assertTcpConfig(
            String prefix,
            TcpConfig tcp,
            boolean noDelay,
            boolean keepAlive,
            int keepAliveCount,
            Duration keepAliveIdle,
            Duration keepAliveInterval,
            Duration userTimeout) {
        assertThat(tcp.isNoDelay()).as(prefix + ".tcp.noDelay").isEqualTo(noDelay);
        assertThat(tcp.isKeepAlive()).as(prefix + ".tcp.keepAlive").isEqualTo(keepAlive);
        assertThat(tcp.getKeepAliveCount()).as(prefix + ".tcp.keepAliveCount").isEqualTo(keepAliveCount);
        assertThat(tcp.getKeepAliveIdle()).as(prefix + ".tcp.keepAliveIdle").isEqualTo(keepAliveIdle);
        assertThat(tcp.getKeepAliveInterval())
                .as(prefix + ".tcp.keepAliveInterval")
                .isEqualTo(keepAliveInterval);
        assertThat(tcp.getUserTimeout()).as(prefix + ".tcp.userTimeout").isEqualTo(userTimeout);
    }

    // ==================== 单机模式全量验证 / Single mode full validation ====================

    @Test
    void singleMode_allPropertiesBound() {
        // 加载 YAML: redisson-single-full.yml，验证单机模式下全部配置项的绑定
        RedissonClient mockClient = mock(RedissonClient.class);
        try (MockedStatic<RedissonClientFactory> factory = mockStatic(RedissonClientFactory.class)) {
            factory.when(() -> RedissonClientFactory.create(any(RedissonConfig.class)))
                    .thenReturn(mockClient);

            contextRunner
                    .withPropertyValues(loadYaml("redisson-single-full.yml"))
                    .run(context -> {
                        assertThat(context).hasSingleBean(RedissonConfig.class);
                        assertThat(context).hasSingleBean(RedissonClient.class);
                        RedissonConfig config = context.getBean(RedissonConfig.class);

                        // ---- 全局配置 / Global ----
                        assertGlobalConfig(config, 8, 16, TransportMode.NIO, CodecType.JSON_JACKSON, Protocol.RESP2);

                        // ---- 分布式锁 / Lock ----
                        assertLockConfig(
                                config.getLock(),
                                Duration.ofSeconds(25),
                                50,
                                Duration.ofMinutes(3),
                                false,
                                Duration.ofSeconds(45));

                        // ---- 发布订阅 / Pub/Sub ----
                        assertPubSubConfig(config.getPubSub(), false, Duration.ofMillis(20));

                        // ---- 内存清理 / Cleanup ----
                        assertCleanupConfig(config.getCleanup(), Duration.ofSeconds(10), Duration.ofMinutes(15), 200);

                        // ---- 其他 / Misc ----
                        assertMiscConfig(config.getMisc(), false, false, true);

                        // ---- 单机模式特有字段 / Single mode specific ----
                        SingleConfig single = config.getSingle();
                        assertThat(single).as("single config should be present").isNotNull();
                        assertThat(single.getAddress()).as("single.address").isEqualTo("redis://10.0.0.1:6379");

                        // ---- BaseConfig 通用字段 ----
                        assertBaseConfig(
                                "single",
                                single,
                                "my-single-client",
                                "admin",
                                "secret123",
                                2,
                                "myRedissonClient",
                                "myDataManager",
                                "myLock");

                        // ---- 普通连接池 / Normal pool ----
                        assertConnectionPoolConfig("single.pool", single.getPool(), 10, 50, Duration.ofSeconds(5));

                        // ---- 订阅连接池 / Subscription pool ----
                        assertConnectionPoolConfig(
                                "single.subscriptionPool", single.getSubscriptionPool(), 8, 32, Duration.ofSeconds(4));

                        // ---- DNS 监控 / DNS monitoring ----
                        assertThat(single.getDnsMonitoring().getInterval())
                                .as("single.dnsMonitoring.interval")
                                .isEqualTo(Duration.ofSeconds(10));

                        // ---- 连接配置 / Connection ----
                        assertConnectionConfig(
                                "single",
                                single.getConnection(),
                                Duration.ofSeconds(15),
                                Duration.ofSeconds(1),
                                Duration.ofMillis(200),
                                5,
                                Duration.ofSeconds(10));

                        // ---- 订阅配置 / Subscription ----
                        assertSubscriptionConfig("single", single.getSubscription(), Duration.ofSeconds(5), 10);

                        // ---- TCP 配置 / TCP ----
                        assertTcpConfig(
                                "single",
                                single.getTcp(),
                                false,
                                true,
                                5,
                                Duration.ofSeconds(60),
                                Duration.ofSeconds(15),
                                Duration.ofSeconds(2));

                        // ---- 确认其他模式未配置 / Confirm other modes not set ----
                        assertThat(config.getSentinel())
                                .as("sentinel should be null")
                                .isNull();
                        assertThat(config.getCluster())
                                .as("cluster should be null")
                                .isNull();
                    });
        }
    }

    // ==================== 哨兵模式全量验证 / Sentinel mode full validation ====================

    @Test
    void sentinelMode_allPropertiesBound() {
        // 加载 YAML: redisson-sentinel-full.yml，验证哨兵模式下全部配置项的绑定
        RedissonClient mockClient = mock(RedissonClient.class);
        try (MockedStatic<RedissonClientFactory> factory = mockStatic(RedissonClientFactory.class)) {
            factory.when(() -> RedissonClientFactory.create(any(RedissonConfig.class)))
                    .thenReturn(mockClient);

            contextRunner
                    .withPropertyValues(loadYaml("redisson-sentinel-full.yml"))
                    .run(context -> {
                        assertThat(context).hasSingleBean(RedissonConfig.class);
                        assertThat(context).hasSingleBean(RedissonClient.class);
                        RedissonConfig config = context.getBean(RedissonConfig.class);

                        // ---- 全局配置 / Global ----
                        assertGlobalConfig(config, 12, 24, TransportMode.NIO, CodecType.KRYO5, Protocol.RESP3);

                        // ---- 分布式锁 / Lock ----
                        assertLockConfig(
                                config.getLock(),
                                Duration.ofSeconds(20),
                                80,
                                Duration.ofMinutes(2),
                                true,
                                Duration.ofSeconds(30));

                        // ---- 发布订阅 / Pub/Sub ----
                        assertPubSubConfig(config.getPubSub(), true, Duration.ofMillis(15));

                        // ---- 内存清理 / Cleanup ----
                        assertCleanupConfig(config.getCleanup(), Duration.ofSeconds(8), Duration.ofMinutes(20), 150);

                        // ---- 其他 / Misc ----
                        assertMiscConfig(config.getMisc(), true, true, false);

                        // ---- 哨兵模式特有字段 / Sentinel mode specific ----
                        SentinelConfig sentinel = config.getSentinel();
                        assertThat(sentinel)
                                .as("sentinel config should be present")
                                .isNotNull();

                        // 哨兵节点地址列表 / Sentinel addresses
                        assertThat(sentinel.getSentinelAddresses())
                                .as("sentinel.sentinelAddresses")
                                .containsExactly(
                                        "redis://10.0.0.10:26379",
                                        "redis://10.0.0.11:26379",
                                        "redis://10.0.0.12:26379");

                        // 哨兵监控的主节点名称 / Master name
                        assertThat(sentinel.getMasterName())
                                .as("sentinel.masterName")
                                .isEqualTo("mymaster");

                        // 哨兵认证 / Sentinel authentication
                        assertThat(sentinel.getSentinelUsername())
                                .as("sentinel.sentinelUsername")
                                .isEqualTo("sentinel-admin");
                        assertThat(sentinel.getSentinelPassword())
                                .as("sentinel.sentinelPassword")
                                .isEqualTo("sentinel-secret");

                        // 哨兵行为开关 / Sentinel behavior flags
                        assertThat(sentinel.isCheckSentinelsList())
                                .as("sentinel.checkSentinelsList")
                                .isFalse();
                        assertThat(sentinel.isCheckSlaveStatusWithSyncing())
                                .as("sentinel.checkSlaveStatusWithSyncing")
                                .isFalse();
                        assertThat(sentinel.isSentinelsDiscovery())
                                .as("sentinel.sentinelsDiscovery")
                                .isFalse();

                        // ---- BaseConfig 通用字段 ----
                        assertBaseConfig(
                                "sentinel",
                                sentinel,
                                "my-sentinel-client",
                                "redis-admin",
                                "redis-secret",
                                3,
                                "sentinelRedissonClient",
                                "sentinelDataManager",
                                "sentinelLock");

                        // ---- 主节点连接池 / Master pool ----
                        assertConnectionPoolConfig(
                                "sentinel.masterPool", sentinel.getMasterPool(), 12, 48, Duration.ofSeconds(4));

                        // ---- 从节点连接池 / Slave pool ----
                        assertConnectionPoolConfig(
                                "sentinel.slavePool", sentinel.getSlavePool(), 16, 56, Duration.ofSeconds(5));

                        // ---- 订阅连接池 / Subscription pool ----
                        assertConnectionPoolConfig(
                                "sentinel.subscriptionPool",
                                sentinel.getSubscriptionPool(),
                                6,
                                24,
                                Duration.ofSeconds(3));

                        // ---- 读写模式 / Read/Write mode ----
                        assertThat(sentinel.getReadWriteMode().getReadMode())
                                .as("sentinel.readWriteMode.readMode")
                                .isEqualTo(ReadMode.MASTER_SLAVE);
                        assertThat(sentinel.getReadWriteMode().getSubscriptionMode())
                                .as("sentinel.readWriteMode.subscriptionMode")
                                .isEqualTo(SubscriptionMode.SLAVE);

                        // ---- DNS 监控 / DNS monitoring ----
                        assertThat(sentinel.getDnsMonitoring().getInterval())
                                .as("sentinel.dnsMonitoring.interval")
                                .isEqualTo(Duration.ofSeconds(8));

                        // ---- 集群拓扑扫描间隔 / Scan interval ----
                        assertThat(sentinel.getScanInterval())
                                .as("sentinel.scanInterval")
                                .isEqualTo(Duration.ofSeconds(2));

                        // ---- 连接配置 / Connection ----
                        assertConnectionConfig(
                                "sentinel",
                                sentinel.getConnection(),
                                Duration.ofSeconds(20),
                                Duration.ofMillis(800),
                                Duration.ofMillis(150),
                                4,
                                Duration.ofSeconds(8));

                        // ---- 订阅配置 / Subscription ----
                        assertSubscriptionConfig("sentinel", sentinel.getSubscription(), Duration.ofSeconds(6), 8);

                        // ---- TCP 配置 / TCP ----
                        assertTcpConfig(
                                "sentinel",
                                sentinel.getTcp(),
                                true,
                                true,
                                8,
                                Duration.ofSeconds(45),
                                Duration.ofSeconds(20),
                                Duration.ofSeconds(3));

                        // ---- 确认其他模式未配置 / Confirm other modes not set ----
                        assertThat(config.getSingle())
                                .as("single should be null")
                                .isNull();
                        assertThat(config.getCluster())
                                .as("cluster should be null")
                                .isNull();
                    });
        }
    }

    // ==================== 集群模式全量验证 / Cluster mode full validation ====================

    @Test
    void clusterMode_allPropertiesBound() {
        // 加载 YAML: redisson-cluster-full.yml，验证集群模式下全部配置项的绑定
        RedissonClient mockClient = mock(RedissonClient.class);
        try (MockedStatic<RedissonClientFactory> factory = mockStatic(RedissonClientFactory.class)) {
            factory.when(() -> RedissonClientFactory.create(any(RedissonConfig.class)))
                    .thenReturn(mockClient);

            contextRunner
                    .withPropertyValues(loadYaml("redisson-cluster-full.yml"))
                    .run(context -> {
                        assertThat(context).hasSingleBean(RedissonConfig.class);
                        assertThat(context).hasSingleBean(RedissonClient.class);
                        RedissonConfig config = context.getBean(RedissonConfig.class);

                        // ---- 全局配置 / Global ----
                        assertGlobalConfig(config, 20, 40, TransportMode.NIO, CodecType.STRING, Protocol.RESP2);

                        // ---- 分布式锁 / Lock ----
                        assertLockConfig(
                                config.getLock(),
                                Duration.ofSeconds(40),
                                120,
                                Duration.ofMinutes(10),
                                true,
                                Duration.ofMinutes(2));

                        // ---- 发布订阅 / Pub/Sub ----
                        assertPubSubConfig(config.getPubSub(), true, Duration.ofMillis(30));

                        // ---- 内存清理 / Cleanup ----
                        assertCleanupConfig(config.getCleanup(), Duration.ofSeconds(3), Duration.ofMinutes(45), 300);

                        // ---- 其他 / Misc ----
                        assertMiscConfig(config.getMisc(), true, true, false);

                        // ---- 集群模式特有字段 / Cluster mode specific ----
                        ClusterConfig cluster = config.getCluster();
                        assertThat(cluster)
                                .as("cluster config should be present")
                                .isNotNull();

                        // 集群节点地址列表 / Cluster node addresses
                        assertThat(cluster.getNodeAddresses())
                                .as("cluster.nodeAddresses")
                                .containsExactly(
                                        "redis://10.0.0.20:7000",
                                        "redis://10.0.0.21:7001",
                                        "redis://10.0.0.22:7002",
                                        "redis://10.0.0.23:7003",
                                        "redis://10.0.0.24:7004",
                                        "redis://10.0.0.25:7005");

                        // 集群行为开关 / Cluster behavior flags
                        assertThat(cluster.isCheckSlotsCoverage())
                                .as("cluster.checkSlotsCoverage")
                                .isFalse();
                        assertThat(cluster.isCheckMasterLinkStatus())
                                .as("cluster.checkMasterLinkStatus")
                                .isTrue();
                        assertThat(cluster.getShardedSubscriptionMode())
                                .as("cluster.shardedSubscriptionMode")
                                .isEqualTo(ShardedSubscriptionMode.AUTO);

                        // ---- BaseConfig 通用字段 ----
                        assertBaseConfig(
                                "cluster",
                                cluster,
                                "my-cluster-client",
                                "cluster-admin",
                                "cluster-secret",
                                0,
                                "clusterRedissonClient",
                                "clusterDataManager",
                                "clusterLock");

                        // ---- 主节点连接池 / Master pool ----
                        assertConnectionPoolConfig(
                                "cluster.masterPool", cluster.getMasterPool(), 20, 80, Duration.ofSeconds(2));

                        // ---- 从节点连接池 / Slave pool ----
                        assertConnectionPoolConfig(
                                "cluster.slavePool", cluster.getSlavePool(), 20, 80, Duration.ofSeconds(2));

                        // ---- 订阅连接池 / Subscription pool ----
                        assertConnectionPoolConfig(
                                "cluster.subscriptionPool",
                                cluster.getSubscriptionPool(),
                                10,
                                40,
                                Duration.ofSeconds(3));

                        // ---- 读写模式 / Read/Write mode ----
                        assertThat(cluster.getReadWriteMode().getReadMode())
                                .as("cluster.readWriteMode.readMode")
                                .isEqualTo(ReadMode.MASTER);
                        assertThat(cluster.getReadWriteMode().getSubscriptionMode())
                                .as("cluster.readWriteMode.subscriptionMode")
                                .isEqualTo(SubscriptionMode.MASTER);

                        // ---- DNS 监控 / DNS monitoring ----
                        assertThat(cluster.getDnsMonitoring().getInterval())
                                .as("cluster.dnsMonitoring.interval")
                                .isEqualTo(Duration.ofSeconds(3));

                        // ---- 集群拓扑扫描间隔 / Scan interval ----
                        assertThat(cluster.getScanInterval())
                                .as("cluster.scanInterval")
                                .isEqualTo(Duration.ofSeconds(5));

                        // ---- 连接配置 / Connection ----
                        assertConnectionConfig(
                                "cluster",
                                cluster.getConnection(),
                                Duration.ofSeconds(30),
                                Duration.ofSeconds(2),
                                Duration.ofMillis(500),
                                6,
                                Duration.ofSeconds(15));

                        // ---- 订阅配置 / Subscription ----
                        assertSubscriptionConfig("cluster", cluster.getSubscription(), Duration.ofSeconds(10), 12);

                        // ---- TCP 配置 / TCP ----
                        assertTcpConfig(
                                "cluster",
                                cluster.getTcp(),
                                true,
                                true,
                                15,
                                Duration.ofSeconds(90),
                                Duration.ofSeconds(45),
                                Duration.ofSeconds(5));

                        // ---- 确认其他模式未配置 / Confirm other modes not set ----
                        assertThat(config.getSingle())
                                .as("single should be null")
                                .isNull();
                        assertThat(config.getSentinel())
                                .as("sentinel should be null")
                                .isNull();
                    });
        }
    }

    // ==================== 条件装配测试 / Conditional auto-configuration tests ====================

    @Test
    void autoConfiguration_backsOffWhenUserProvidesRedissonClient() {
        // 当用户自定义 RedissonClient Bean 时，自动配置应退避
        RedissonClient userClient = mock(RedissonClient.class);
        contextRunner.withBean(RedissonClient.class, () -> userClient).run(context -> {
            assertThat(context).hasSingleBean(RedissonClient.class);
            assertThat(context.getBean(RedissonClient.class)).isSameAs(userClient);
        });
    }

    @Test
    void autoConfiguration_skippedWhenRedissonClassMissing() {
        // 当 classpath 中不存在 Redisson 类时，自动配置应跳过
        contextRunner.withClassLoader(new FilteredClassLoader(Redisson.class)).run(context -> {
            assertThat(context).doesNotHaveBean(InfraRedissonAutoConfiguration.class);
            assertThat(context).doesNotHaveBean(RedissonConfig.class);
            assertThat(context).doesNotHaveBean(RedissonClient.class);
        });
    }

    @Test
    void autoConfiguration_failsWhenNoModeConfigured() {
        // 当未配置任何连接模式（single/sentinel/cluster）时，启动应失败
        contextRunner
                .withPropertyValues(InfraRedissonAutoConfiguration.PREFIX + "=")
                .run(context -> assertThat(context).hasFailed());
    }
}
