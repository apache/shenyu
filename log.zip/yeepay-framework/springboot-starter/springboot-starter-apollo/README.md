# springboot-starter-apollo

基于 Apollo 配置中心客户端的Spring Boot Starter，提供以下核心能力：

1. **从 Apollo 获取配置** — 接入 Apollo 后，通过 `@Value`、`@ConfigurationProperties` 等方式获取 Apollo 中的配置，启动时从 Apollo 拉取，运行时动态刷新
2. **配置属性自动刷新** — 通过 `@ApolloAutoRefreshConfigComponent` 注解，让 `@ConfigurationProperties` Bean 在 Apollo 配置变更时自动刷新，无需手动编写 `ApolloConfigChangeListener`
3. **Logback 配置从 Apollo 加载** — 将 Logback 配置文件内容托管到 Apollo，支持动态下发和实时生效

## Apollo 属性配置说明

接入 Apollo 需要在 `application.yml`（或 `application.properties`）中配置以下属性。这些属性控制 Apollo 客户端的行为，包括是否启用、连接哪个 Config Service、要加载哪些 Namespace 等。

### 核心配置项

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `app.id` | `String` | 是 | 应用唯一标识，Apollo 用它将应用与配置关联。通常设为 `spring.application.name` |
| `apollo.bootstrap.enabled` | `boolean` | 是 | 是否启用 Apollo Bootstrap 流程。必须设为 `true`，本 Starter 依赖此机制感知配置变更 |
| `apollo.bootstrap.eagerLoad.enabled` | `boolean` | 否 | 是否在应用启动早期（Environment 初始化阶段）就加载配置。设为 `true` 可确保日志等底层组件提前拿到 Apollo 配置，推荐开启 |
| `apollo.bootstrap.namespaces` | `String` | 是 | 要加载的 Apollo Namespace 列表，多个用逗号分隔。**排在越前面的优先级越高**。例如 `application.properties,test.yaml`，当两个 Namespace 中存在同名 Key 时，`application.properties` 中的值生效 |
| `apollo.config-service` | `String` | 否 | Apollo Config Service 地址。例如 `http://127.0.0.1:8080`。如果不配置，Apollo 默认从 META-INF/app.properties 的 `apollo.meta` 或环境变量读取 |
| `apollo.cache-dir` | `String` | 否 | Apollo 本地缓存目录。Apollo 会将配置缓存到本地，当 Config Service 不可用时从缓存读取。例如 `./target/` |

### 典型配置

```yaml
app.id: ${spring.application.name}
apollo:
  bootstrap:
    enabled: true
    eagerLoad.enabled: true
    namespaces: application.properties,test.yaml
  cache-dir: "./target/"
  config-service: http://127.0.0.1:8080
```

> **注意**：`apollo.bootstrap.enabled` 必须为 `true`，`apollo.bootstrap.namespaces` 必须配置，两者缺一不可。

#### Namespace 优先级说明

`apollo.bootstrap.namespaces` 中排在前面的 Namespace 优先级更高。例如配置为 `application.properties,test.yaml`：

- 两个 Namespace 中都存在 `examples.custom.timeout`，则取 `application.properties` 中的值
- `test.yaml` 中独有的 Key 不受影响，正常读取

### 自动激活机制

引入本 Starter 后，`YeepayApolloAutoConfiguration` 自动生效（通过 `AutoConfiguration.imports` 注册）。激活条件：classpath 中存在 `RefreshScope`（即引入了 `spring-cloud-context` 依赖）。

---

## 快速开始

### Maven 依赖

```xml
<dependency>
    <groupId>com.yeepay.framework</groupId>
    <artifactId>springboot-starter-apollo</artifactId>
    <version>${yeepay-framework.version}</version>
</dependency>
```

> 该依赖会自动引入 `apollo-client`、`spring-cloud-context`、`logback-classic` 等必要组件。

---

## 功能一：从 Apollo 获取配置

### 功能说明

接入 Apollo 后，应用启动时会从 Apollo Config Service 拉取 `apollo.bootstrap.namespaces` 中指定的 Namespace 中的所有配置，并合并到 Spring 的 `Environment` 中。这意味着你可以像使用本地配置文件中的属性一样，使用 Apollo 中的配置。

### 方式一：@Value 注入单个属性

最简单的方式，适合获取少量配置项：

```java
@RestController
public class MyController {

    @Value("${myapp.timeout:5000}")
    private int timeout;

    @Value("${myapp.api.url}")
    private String apiUrl;

    @GetMapping("/timeout")
    public int getTimeout() {
        return timeout;
    }
}
```

- `${myapp.timeout:5000}` 中的 `:5000` 是默认值，当 Apollo 中没有该 Key 时使用
- 通过 `@Value` 注入的属性在应用启动时取值一次，**配置变更后不会自动更新**（除非该 Bean 是 Prototype 作用域或标注了 `@RefreshScope`）

### 方式二：@ConfigurationProperties 绑定配置组

适合将一组相关联的配置绑定到一个 Java 对象中，类型安全且支持嵌套结构：

**在 application.yml 中定义配置结构（或直接在 Apollo Namespace 中创建对应的 Key）：**

```yaml
# 这段配置在 Apollo Namespace 中:
examples.custom.resources[A].allow=["user1","user2"]
examples.custom.resources[A].forbid=["user3"]
examples.custom.resources[B].allow=["admin1"]
examples.custom.resources[B].forbid=[]
```

**定义配置类：**

```java
@Data
@ConfigurationProperties(prefix = "examples.custom")
public class CustomConfig {

    private Map<String, Auth> resources;

    @Data
    public static class Auth {
        private Set<String> allow;
        private Set<String> forbid;
    }
}
```

**注入使用：**

```java
@RestController
@RequiredArgsConstructor
public class MyController {

    private final CustomConfig customConfig;

    @GetMapping("/config")
    public CustomConfig getConfig() {
        return customConfig;
    }
}
```

---

## 功能二：配置属性自动刷新

### 功能说明

当一个 `@ConfigurationProperties` Bean 被 Apollo 配置变更影响时，通常需要手动刷新：

- 要么通过 `@RefreshScope` + 手动调用 `RefreshScope.refresh(beanName)`
- 要么手动编写 `@ApolloConfigChangeListener` 来监听配置变化

`@ApolloAutoRefreshConfigComponent` 注解将这两步简化为一 — 当 Apollo 中对应的配置发生变更时，框架自动刷新 Bean。

### 使用方法

**第 1 步**：在配置类上同时标注 `@ConfigurationProperties` 和 `@ApolloAutoRefreshConfigComponent`：

```java
@Data
@ConfigurationProperties(prefix = "examples.custom")
@ApolloAutoRefreshConfigComponent
public class CustomConfig {

    private Map<String, Auth> resources;

    @Data
    public static class Auth {
        private Set<String> allow;
        private Set<String> forbid;
    }
}
```

**第 2 步**：在需要的地方注入即可使用：

```java
@RestController
@RequiredArgsConstructor
public class MyController {

    private final CustomConfig customConfig;

    @GetMapping("/config")
    public String getConfig() {
        return customConfig.toString();
    }
}
```

当 Apollo 中 `examples.custom` 前缀下的任意配置项发生变更时，`CustomConfig` Bean 会自动刷新为最新值。

### @ApolloAutoRefreshConfigComponent 属性

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `value` | `String` | `""` | Bean 名称，等同于 `@Component("xxx")` |
| `logMethodName` | `String` | `""` | 刷新前后回调的方法名，用于打印日志或其他操作 |
| `retryTimes` | `int` | `3` | 刷新失败时的重试次数 |
| `retryDelayMs` | `long` | `100` | 每次重试之间的间隔（毫秒） |

#### logMethodName 用法示例

```java
@Data
@ConfigurationProperties(prefix = "myapp.cache")
@ApolloAutoRefreshConfigComponent(logMethodName = "printConfig")
public class CacheConfig {

    private int ttl;
    private int maxSize;

    public void printConfig() {
        log.info("current config: ttl={}, maxSize={}", ttl, maxSize);
    }
}
```

该方法会在刷新**前**（旧值）和刷新**后**（新值）各被调用一次，便于观察配置变更前后的状态。

### 工作原理

1. `ApolloAutoRefreshConfigComponentProcessor` 实现了 `BeanPostProcessor`，在 Spring 容器初始化结束后扫描所有 Bean
2. 发现同时标注了 `@ConfigurationProperties` 和 `@ApolloAutoRefreshConfigComponent` 的 Bean
3. 为这些 Bean 注册 Apollo `ConfigChangeListener`，监听 `apollo.bootstrap.namespaces` 配置的所有 Namespace 中的对应前缀
4. 配置变更时，通过 `RefreshScope.refresh(beanName)` 重新创建 Bean，附带重试机制
5. 如果配置了 `logMethodName`，在刷新前后分别调用该方法

### 对比：两种配置刷新方式

示例项目提供了两种配置刷新方式供参考：

**方式一：使用 @ApolloAutoRefreshConfigComponent（推荐）**

```java
@ConfigurationProperties(prefix = "examples.custom")
@Data
@ApolloAutoRefreshConfigComponent
public class CustomConfig { ... }
```

**方式二：手动使用 RefreshScope + ApolloConfigChangeListener**

```java
// 配置类
@ConfigurationProperties("user")
@Component("userConfig")
@RefreshScope
@Data
public class UserConfig { ... }

// 手动监听并刷新
@Component
@RequiredArgsConstructor
public class RefreshConfigService {
    private final RefreshScope refreshScope;

    @ApolloConfigChangeListener(
            value = {"application.properties", "test.yaml"},
            interestedKeyPrefixes = {"user."})
    public void refreshAuth(ConfigChangeEvent event) {
        refreshScope.refresh("userConfig");
    }
}
```

对于大多数场景，推荐使用 `@ApolloAutoRefreshConfigComponent`，减少样板代码。

---

## 功能三：Logback 配置从 Apollo 加载

### 功能说明

默认情况下，Logback 配置写在 `logback-spring.xml` 文件中，打包在应用内。要修改日志级别或 Appender，需要改代码、重新构建、重新部署。

本功能将 Logback 配置的内容托管到 Apollo，配置文件以 XML 文本的形式存放在 Apollo 的 Namespace 中。配置变更后实时生效，无需重启应用。

### 使用方法

**第 1 步**：在 Apollo 控制台创建一个 Namespace（默认为 `logback-spring.xml`），类型选择 `private`。

**第 2 步**：集成日志框架

* 新增日志框架的支持

```xml
      <dependency>
            <groupId>com.yeepay.framework</groupId>
            <artifactId>logging</artifactId>
            <version>${project.version}</version>
     </dependency>

```

* 在Namespace 中 添加 Logback XML 配置，详细看日志框架：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
   
   <!-- CONSOLE 参数，控制台是否立刻输出 -->
   <property name="CONSOLE_IMMEDIATE_FLUSH" value="true"/>

   <!-- Fluentd 参数 -->
   <property name="FLUENTD_REMOTE_ADDRESS" value="${发送的地址}"/>
   <property name="FLUENTD_APP_NAME" value="${你的应用名，索引}"/>

   <include resource="com/yeepay/framework/logging/logback/base.xml"/>
   

   <!-- 本地开发：仅控制台输出 -->
   <springProfile name="default | dev | local | test">
      <root level="INFO">
         <appender-ref ref="CONSOLE"/>
      </root>
   </springProfile>

   <!-- 非本地环境：通过 Fluentd发送出去 -->
   <springProfile name="!(default | dev | local | test)">
      <root level="INFO">
         <appender-ref ref="fluentd-app"/>
      </root>
   </springProfile>
</configuration>
```

**第 3 步**：启动应用。框架会自动从 Apollo 拉取 （ `logback-spring.xml`）的Namespace， 配置并加载为 Logback 配置。


### 自定义 Namespace 名称

默认从名为 `logback-spring.xml` 的 Namespace 加载，你可以通过以下方式自定义（优先级从高到低）：

| 方式 | 示例 |
|------|------|
| Spring Environment 属性 | `logging.apollo.namespace=my-logback.xml` |
| JVM 系统属性 | `-Dlogging.apollo.namespace=my-logback.xml` |
| 环境变量 | `export logging.apollo.namespace=my-logback.xml` |

### 禁用 Logback Apollo 配置

如果希望在某些环境下不使用 Apollo 管理 Logback 配置，可以通过以下方式禁用（优先级从高到低）：

| 方式 | 配置 |
|------|------|
| Spring Environment 属性 | `logging.apollo.disabled=true` |
| JVM 系统属性 | `-Dlogging.apollo.disabled=true` |
| 环境变量 | `export logging.apollo.disabled=true` |

禁用后，框架回退到 Spring Boot 默认的 `logback-spring.xml` 文件加载机制。

### 工作机制

1. `ApolloLogbackLoggingSystemFactory` 优先级为 `HIGHEST_PRECEDENCE`，会在 Spring Boot 默认的 `LogbackLoggingSystem` 之前创建 `ApolloLogbackLoggingSystem`
2. `ApolloLogbackLoggingSystem` 接管了 Logback 配置的加载流程（`loadDefaults`、`loadConfiguration`、`reinitialize`），优先从 Apollo 加载
3. `ApolloLogBackConfigLoader` 负责具体加载逻辑：
   - 从 Apollo 的指定 Namespace 中读取 `content` 键的值
   - 将内容通过 `LogBackConfigReLoader.reload()` 注入 Logback
   - 同时注册 `ConfigChangeListener`，当 Apollo 中 `content` 变更时自动重载
4. 如果 Apollo 未启用、被禁用或 `content` 为空，回退到 Spring Boot 默认机制

### 前置条件

- `apollo.bootstrap.enabled` 必须为 `true`
- Logback 在 classpath 中（`logback-classic`），Spring Boot 环境自动满足

---
