package com.yeepay.framework.springboot.starter.apollo.processor;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigService;
import com.ctrip.framework.apollo.spring.config.PropertySourcesConstants;
import com.yeepay.framework.common.utils.RetryUtils;
import com.yeepay.framework.springboot.starter.apollo.annotation.ApolloAutoRefreshConfigComponent;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.scope.refresh.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

/**
 * Apollo自动刷新配置组件处理器.
 */
@Slf4j
public class ApolloAutoRefreshConfigComponentProcessor
        implements BeanPostProcessor, ApplicationContextAware, EnvironmentAware {

    private final RefreshScope refreshScope;

    private Set<String> listeners = ConcurrentHashMap.newKeySet();

    private ApplicationContext applicationContext;

    private Environment environment;

    public ApolloAutoRefreshConfigComponentProcessor(RefreshScope refreshScope) {
        this.refreshScope = refreshScope;
    }

    @Override
    public Object postProcessAfterInitialization(final Object bean, final String beanName) throws BeansException {
        Class<?> cls = AopProxyUtils.ultimateTargetClass(bean);
        ConfigurationProperties cpAnnotation = cls.getAnnotation(ConfigurationProperties.class);
        ApolloAutoRefreshConfigComponent aarcAnnotation = cls.getAnnotation(ApolloAutoRefreshConfigComponent.class);
        if (Objects.nonNull(cpAnnotation) && Objects.nonNull(aarcAnnotation) && listeners.add(beanName)) {
            final String configPrefix = cpAnnotation.prefix();
            log.info("ConfigurationProperties listener add for bean:{}, prefix:{}", beanName, configPrefix);
            String namespaces = this.environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_NAMESPACES);
            if (!StringUtils.hasText(namespaces)) {
                log.error(
                        "namespaces is empty, please set namespaces in {}",
                        PropertySourcesConstants.APOLLO_BOOTSTRAP_NAMESPACES);
                return bean;
            }
            for (String n : namespaces.split(",")) {
                Config config = ConfigService.getConfig(n);
                config.addChangeListener(
                        changeEvent -> refreshBean(bean, beanName, configPrefix, aarcAnnotation),
                        null,
                        Set.of(configPrefix));
            }
        }
        return bean;
    }

    private synchronized void refreshBean(
            final Object bean,
            final String beanName,
            final String configPrefix,
            ApolloAutoRefreshConfigComponent aarcAnnotation) {
        log.info("refreshing bean:{}, prefix:{}", beanName, configPrefix);
        String logMethodName = aarcAnnotation.logMethodName();
        Method logMethod = null;
        if (StringUtils.hasText(logMethodName)) {
            try {
                logMethod = bean.getClass().getDeclaredMethod(logMethodName);
                logMethod.setAccessible(true);
            } catch (Throwable e) {
                log.error("class:{}, methodName:{} <UNK>", bean.getClass().getName(), logMethodName);
            }
        }
        if (Objects.nonNull(logMethod)) {
            try {
                Object before = applicationContext.getBean(beanName);
                logMethod.invoke(before);
            } catch (Throwable e) {
                log.error("before change invoke:{}.{} failed", bean.getClass().getName(), logMethodName);
            }
        }
        int retryTimes = aarcAnnotation.retryTimes();
        long retryDelayMs = aarcAnnotation.retryDelayMs();
        try {
            boolean success = RetryUtils.doRetry(retryTimes, retryDelayMs, () -> refreshScope.refresh(beanName));
            if (success) {
                log.info("refreshed bean:{}, prefix:{}", beanName, configPrefix);
            }
        } catch (Throwable e) {
            log.error("refresh bean:{} failed after {} retries, prefix:{}", beanName, retryTimes, configPrefix, e);
        }
        if (Objects.nonNull(logMethod)) {
            try {
                Object after = applicationContext.getBean(beanName);
                logMethod.invoke(after);
            } catch (Throwable e) {
                log.error("after change invoke:{}.{} failed", bean.getClass().getName(), logMethodName);
            }
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
}
