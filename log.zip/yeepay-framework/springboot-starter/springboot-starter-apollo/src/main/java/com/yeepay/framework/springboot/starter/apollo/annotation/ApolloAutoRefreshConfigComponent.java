package com.yeepay.framework.springboot.starter.apollo.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Component;

/**
 * A spring component supports refresh fields when apollo config changed.
 * i.e.
 * <pre>
 * {@code
 * @Data
 * @ConfigurationProperties(prefix = "yeepay.xxx")
 * @ApolloAutoRefreshConfigComponent
 * public class Config {
 *   private int field1;
 *   private String field2;
 *   ...
 * }
 * }***
 * </pre>
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
@RefreshScope
public @interface ApolloAutoRefreshConfigComponent {

    /**
     * Value string.
     *
     * @return the string
     */
    @AliasFor(annotation = Component.class)
    String value() default "";

    /**
     * 打印日志方法名.
     *
     * @return 日志方法名 string
     */
    String logMethodName() default "";

    /**
     * refresh bean 失败时候的重试次数.
     *
     * @return the int
     */
    int retryTimes() default 3;

    /**
     * refresh bean 失败时候的重试延迟.
     *
     * @return the long
     */
    long retryDelayMs() default 100;
}
