package com.yeepay.framework.springboot.starter.apollo.logback;

import ch.qos.logback.classic.LoggerContext;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigChangeListener;
import com.ctrip.framework.apollo.ConfigService;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.config.PropertySourcesConstants;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LoggingInitializationContext;
import org.springframework.boot.logging.logback.LogBackConfigReLoader;
import org.springframework.core.env.Environment;

/**
 * The type Log back config loader.
 */
public class ApolloLogBackConfigLoader implements ConfigChangeListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApolloLogBackConfigLoader.class);

    private static final String LOGGING_APOLLO_DISABLED = "logging.apollo.disabled";

    private static final String LOGGING_APOLLO_NAMESPACE = "logging.apollo.namespace";

    private static final String DEFAULT_NAMESPACE = "logback-spring.xml";

    private static final String KEY = "content";

    private LoggingInitializationContext initializationContext;

    private boolean initialized;

    /**
     * Init log boolean.
     *
     * @param initializationContext the initialization context
     * @param loggerContext         the logger context
     * @return the boolean
     */
    public synchronized boolean initLog(
            LoggingInitializationContext initializationContext, LoggerContext loggerContext) {
        this.initializationContext = initializationContext;
        try {
            Environment environment = initializationContext.getEnvironment();
            if (!environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false)) {
                LOGGER.info(
                        "Apollo bootstrap config is not enabled, see property: ${{}}",
                        PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED);
                return false;
            }
            String sDisable = getValue(environment, LOGGING_APOLLO_DISABLED, "false");
            boolean disable = Boolean.parseBoolean(sDisable);
            if (disable) {
                return false;
            }
            String namespace = getValue(environment, LOGGING_APOLLO_NAMESPACE, DEFAULT_NAMESPACE);
            Config config = ConfigService.getConfig(namespace);
            if (!initialized) {
                config.addChangeListener(this);
                initialized = true;
            }

            String content = config.getProperty(KEY, "");
            if (!Strings.isNullOrEmpty(content)) {
                LogBackConfigReLoader.reload(this.initializationContext, loggerContext, content);
                LOGGER.info("logback config loaded from apollo");
                return true;
            }
        } catch (Exception e) {
            LOGGER.error("init logback config failed! {}", e.getMessage(), e);
        }
        return false;
    }

    private String getValue(Environment environment, String key, String def) {
        String value = environment.getProperty(key);
        if (!Strings.isNullOrEmpty(value)) {
            return value;
        }
        value = System.getProperty(key);
        if (!Strings.isNullOrEmpty(value)) {
            return value;
        }

        value = System.getenv(key);
        if (!Strings.isNullOrEmpty(value)) {
            return value;
        }

        return def;
    }

    @Override
    public void onChange(ConfigChangeEvent changeEvent) {
        try {
            LogBackConfigReLoader.reload(
                    this.initializationContext, null, changeEvent.getChange(KEY).getNewValue());
        } catch (Exception e) {
            LOGGER.warn("update logback config failed! {}", e.getMessage(), e);
        }
    }
}
