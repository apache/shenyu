package com.yeepay.framework.springboot.starter.apollo.logback;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.jul.LevelChangePropagator;
import java.util.logging.Handler;
import java.util.logging.LogManager;
import org.slf4j.LoggerFactory;
import org.slf4j.bridge.SLF4JBridgeHandler;
import org.springframework.boot.logging.LogFile;
import org.springframework.boot.logging.LoggingInitializationContext;
import org.springframework.boot.logging.logback.LogbackLoggingSystem;
import org.springframework.util.ClassUtils;

/**
 * The type Apollo logback logging system.
 */
public class ApolloLogbackLoggingSystem extends LogbackLoggingSystem {

    private final ApolloLogBackConfigLoader logBackConfigLoader;

    /**
     * Instantiates a new Apollo logback logging system.
     *
     * @param classLoader the class loader
     */
    public ApolloLogbackLoggingSystem(ClassLoader classLoader) {
        super(classLoader);
        this.logBackConfigLoader = new ApolloLogBackConfigLoader();
    }

    @Override
    protected void loadDefaults(LoggingInitializationContext initializationContext, LogFile logFile) {
        LoggerContext context = getLoggerContext();
        stopAndReset(context);
        if (!this.logBackConfigLoader.initLog(initializationContext, context)) {
            super.loadDefaults(initializationContext, logFile);
        }
    }

    @Override
    protected void loadConfiguration(
            LoggingInitializationContext initializationContext, String location, LogFile logFile) {
        LoggerContext context = getLoggerContext();
        stopAndReset(context);
        if (!this.logBackConfigLoader.initLog(initializationContext, context)) {
            super.loadConfiguration(initializationContext, location, logFile);
        }
    }

    @Override
    protected void reinitialize(LoggingInitializationContext initializationContext) {
        LoggerContext loggerContext = getLoggerContext();
        loggerContext.reset();
        loggerContext.getStatusManager().clear();
        this.logBackConfigLoader.initLog(initializationContext, loggerContext);

        if (!this.logBackConfigLoader.initLog(initializationContext, loggerContext)) {
            super.reinitialize(initializationContext);
        }
    }

    private LoggerContext getLoggerContext() {
        return (LoggerContext) LoggerFactory.getILoggerFactory();
    }

    private void stopAndReset(LoggerContext loggerContext) {
        loggerContext.stop();
        loggerContext.reset();
        if (isBridgeHandlerInstalled()) {
            addLevelChangePropagator(loggerContext);
        }
    }

    private boolean isBridgeHandlerInstalled() {
        if (!ClassUtils.isPresent("org.slf4j.bridge.SLF4JBridgeHandler", super.getClassLoader())) {
            return false;
        }
        java.util.logging.Logger rootLogger = LogManager.getLogManager().getLogger("");
        Handler[] handlers = rootLogger.getHandlers();
        return handlers.length == 1 && handlers[0] instanceof SLF4JBridgeHandler;
    }

    private void addLevelChangePropagator(LoggerContext loggerContext) {
        LevelChangePropagator levelChangePropagator = new LevelChangePropagator();
        levelChangePropagator.setResetJUL(true);
        levelChangePropagator.setContext(loggerContext);
        loggerContext.addListener(levelChangePropagator);
    }
}
