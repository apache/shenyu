package com.yeepay.framework.springboot.starter.apollo;

import com.yeepay.framework.springboot.starter.apollo.processor.ApolloAutoRefreshConfigComponentProcessor;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cloud.context.scope.refresh.RefreshScope;
import org.springframework.context.annotation.Bean;

/**
 * The type Apollo auto configuration.
 */
@AutoConfiguration
@ConditionalOnClass(RefreshScope.class)
public class YeepayApolloAutoConfiguration {

    /**
     * Apollo auto refresh config component processor.
     *
     * @param refreshScope the refresh scope
     * @return the apollo auto refresh config component processor
     */
    @Bean
    public static ApolloAutoRefreshConfigComponentProcessor apolloAutoRefreshConfigComponentProcessor(
            RefreshScope refreshScope) {
        return new ApolloAutoRefreshConfigComponentProcessor(refreshScope);
    }
}
