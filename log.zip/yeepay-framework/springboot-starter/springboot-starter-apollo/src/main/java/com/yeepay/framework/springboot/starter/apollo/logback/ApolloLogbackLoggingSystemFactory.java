package com.yeepay.framework.springboot.starter.apollo.logback;

import org.springframework.boot.logging.LoggingSystem;
import org.springframework.boot.logging.LoggingSystemFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.util.ClassUtils;

/**
 * The type Apollo logback logging system factory.
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ApolloLogbackLoggingSystemFactory implements LoggingSystemFactory {

    private static final boolean PRESENT = ClassUtils.isPresent(
            "ch.qos.logback.classic.LoggerContext", ApolloLogbackLoggingSystemFactory.class.getClassLoader());

    @Override
    public LoggingSystem getLoggingSystem(ClassLoader classLoader) {
        if (PRESENT) {
            return new ApolloLogbackLoggingSystem(classLoader);
        }
        return null;
    }
}
