package org.springframework.boot.logging.logback;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.util.StatusPrinter2;
import java.io.Reader;
import java.io.StringReader;
import java.util.Objects;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LoggingInitializationContext;
import org.xml.sax.InputSource;

/**
 * LogBack配置重载器.
 */
public class LogBackConfigReLoader {

    private static final StatusPrinter2 STATUS_PRINTER = new StatusPrinter2();

    /**
     * 重载LogBack配置.
     *
     * @param initializationContext 日志初始化上下文
     * @param loggerContext         日志上下文
     * @param content               配置内容
     * @throws JoranException Joran异常
     */
    public static void reload(
            LoggingInitializationContext initializationContext, LoggerContext loggerContext, String content)
            throws JoranException {
        LoggerContext actualLoggerContext = loggerContext;
        if (Objects.isNull(actualLoggerContext)) {
            actualLoggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        }
        Reader reader = new StringReader(content);
        InputSource source = new InputSource(reader);
        JoranConfigurator configurator = new SpringBootJoranConfigurator(initializationContext);
        configurator.setContext(actualLoggerContext);
        actualLoggerContext.reset();
        configurator.doConfigure(source);
        STATUS_PRINTER.printInCaseOfErrorsOrWarnings(actualLoggerContext);
    }
}
