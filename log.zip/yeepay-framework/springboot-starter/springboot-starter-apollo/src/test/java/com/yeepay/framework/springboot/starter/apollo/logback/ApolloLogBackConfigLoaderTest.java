package com.yeepay.framework.springboot.starter.apollo.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.LoggerContext;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigChangeListener;
import com.ctrip.framework.apollo.ConfigService;
import com.ctrip.framework.apollo.model.ConfigChange;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.config.PropertySourcesConstants;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.boot.logging.LoggingInitializationContext;
import org.springframework.boot.logging.logback.LogBackConfigReLoader;
import org.springframework.core.env.Environment;

class ApolloLogBackConfigLoaderTest {

    private ApolloLogBackConfigLoader loader;
    private LoggingInitializationContext initContext;
    private Environment environment;
    private LoggerContext loggerContext;
    private Config config;
    private MockedStatic<ConfigService> configServiceMock;
    private MockedStatic<LogBackConfigReLoader> logBackConfigReLoaderMock;

    @BeforeEach
    void setUp() {
        loader = new ApolloLogBackConfigLoader();
        environment = mock(Environment.class);
        initContext = mock(LoggingInitializationContext.class);
        loggerContext = new LoggerContext();
        config = mock(Config.class);

        when(initContext.getEnvironment()).thenReturn(environment);

        configServiceMock = Mockito.mockStatic(ConfigService.class);
        logBackConfigReLoaderMock = Mockito.mockStatic(LogBackConfigReLoader.class);

        configServiceMock.when(() -> ConfigService.getConfig(any())).thenReturn(config);
    }

    @AfterEach
    void tearDown() {
        if (configServiceMock != null) {
            configServiceMock.close();
        }
        if (logBackConfigReLoaderMock != null) {
            logBackConfigReLoaderMock.close();
        }
    }

    @Test
    void initLog_whenApolloBootstrapNotEnabled_shouldReturnFalse() {
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(false);

        boolean result = loader.initLog(initContext, loggerContext);

        assertThat(result).isFalse();
    }

    @Test
    void initLog_whenDisabled_shouldReturnFalse() {
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn("true");

        boolean result = loader.initLog(initContext, loggerContext);

        assertThat(result).isFalse();
    }

    @Test
    void initLog_whenNoContent_shouldReturnFalse() {
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
        when(environment.getProperty("logging.apollo.namespace")).thenReturn(null);
        when(config.getProperty("content", "")).thenReturn("");

        boolean result = loader.initLog(initContext, loggerContext);

        assertThat(result).isFalse();
    }

    @Test
    void initLog_whenContentExists_shouldReturnTrue() {
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
        when(environment.getProperty("logging.apollo.namespace")).thenReturn(null);
        when(config.getProperty("content", "")).thenReturn("<configuration/>");

        boolean result = loader.initLog(initContext, loggerContext);

        assertThat(result).isTrue();
        logBackConfigReLoaderMock.verify(() -> LogBackConfigReLoader.reload(any(), any(), any()), times(1));
    }

    @Test
    void initLog_shouldRegisterChangeListenerOnlyOnce() {
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
        when(environment.getProperty("logging.apollo.namespace")).thenReturn(null);
        when(config.getProperty("content", "")).thenReturn("<configuration/>");

        loader.initLog(initContext, loggerContext);
        loader.initLog(initContext, loggerContext);

        verify(config, times(1)).addChangeListener(any(ConfigChangeListener.class));
    }

    @Test
    void initLog_whenExceptionOccurs_shouldReturnFalse() {
        when(initContext.getEnvironment()).thenThrow(new RuntimeException("test error"));

        boolean result = loader.initLog(initContext, loggerContext);

        assertThat(result).isFalse();
    }

    @Test
    void initLog_whenNamespaceFromSystemProperty_shouldUseIt() {
        System.setProperty("logging.apollo.namespace", "custom-logback.xml");
        try {
            when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                    .thenReturn(true);
            when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
            when(environment.getProperty("logging.apollo.namespace")).thenReturn(null);
            when(config.getProperty("content", "")).thenReturn("<configuration/>");

            loader.initLog(initContext, loggerContext);

            configServiceMock.verify(() -> ConfigService.getConfig("custom-logback.xml"), times(1));
        } finally {
            System.clearProperty("logging.apollo.namespace");
        }
    }

    @Test
    void initLog_whenNamespaceFromEnvVar_shouldUseIt() {
        // getValue checks env.property → system.property → system.env → default
        // Environment mock returns null, System property is null → falls to env var
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
        when(environment.getProperty("logging.apollo.namespace")).thenReturn("env-namespace.xml");
        when(config.getProperty("content", "")).thenReturn("<configuration/>");

        loader.initLog(initContext, loggerContext);

        configServiceMock.verify(() -> ConfigService.getConfig("env-namespace.xml"), times(1));
    }

    @Test
    void onChange_whenContentChanged_shouldReloadConfig() throws Exception {
        // First init to set up the initializationContext
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
        when(environment.getProperty("logging.apollo.namespace")).thenReturn(null);
        when(config.getProperty("content", "")).thenReturn("<configuration/>");
        loader.initLog(initContext, loggerContext);

        // Now trigger onChange
        ConfigChangeEvent changeEvent = mock(ConfigChangeEvent.class);
        ConfigChange configChange = mock(ConfigChange.class);
        when(changeEvent.getChange("content")).thenReturn(configChange);
        when(configChange.getNewValue()).thenReturn("<newConfiguration/>");

        logBackConfigReLoaderMock.reset();

        loader.onChange(changeEvent);

        logBackConfigReLoaderMock.verify(
                () -> LogBackConfigReLoader.reload(any(), any(), eq("<newConfiguration/>")), times(1));
    }

    @Test
    void onChange_whenExceptionOccurs_shouldNotThrow() {
        ConfigChangeEvent changeEvent = mock(ConfigChangeEvent.class);
        when(changeEvent.getChange("content")).thenThrow(new RuntimeException("test error"));

        // Should not throw
        loader.onChange(changeEvent);
    }

    @Test
    void initLog_whenDisabledViaSystemProperty_shouldReturnFalse() {
        System.setProperty("logging.apollo.disabled", "true");
        try {
            when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                    .thenReturn(true);
            when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);

            boolean result = loader.initLog(initContext, loggerContext);

            assertThat(result).isFalse();
        } finally {
            System.clearProperty("logging.apollo.disabled");
        }
    }

    @Test
    void initLog_callingGetValue_whenPropertyNotSet_returnsDefault() {
        when(environment.getProperty(PropertySourcesConstants.APOLLO_BOOTSTRAP_ENABLED, Boolean.class, false))
                .thenReturn(true);
        when(environment.getProperty("logging.apollo.disabled")).thenReturn(null);
        when(environment.getProperty("logging.apollo.namespace")).thenReturn(null);
        when(config.getProperty("content", "")).thenReturn("<configuration/>");

        loader.initLog(initContext, loggerContext);

        configServiceMock.verify(() -> ConfigService.getConfig("logback-spring.xml"), times(1));
    }

    private static String eq(String value) {
        return Mockito.eq(value);
    }
}
