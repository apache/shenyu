package com.yeepay.framework.springboot.starter.apollo.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ch.qos.logback.classic.LoggerContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LoggingInitializationContext;
import org.springframework.core.env.ConfigurableEnvironment;

class ApolloLogbackLoggingSystemTest {

    private ApolloLogbackLoggingSystem loggingSystem;
    private ApolloLogBackConfigLoader mockLoader;
    private LoggerContext loggerContext;
    private LoggingInitializationContext initContext;
    private MockedStatic<LoggerFactory> loggerFactoryMock;

    @BeforeEach
    void setUp() throws Exception {
        loggingSystem = spy(new ApolloLogbackLoggingSystem(getClass().getClassLoader()));
        mockLoader = mock(ApolloLogBackConfigLoader.class);
        loggerContext = new LoggerContext();

        java.lang.reflect.Field field = ApolloLogbackLoggingSystem.class.getDeclaredField("logBackConfigLoader");
        field.setAccessible(true);
        field.set(loggingSystem, mockLoader);

        initContext = new LoggingInitializationContext(mock(ConfigurableEnvironment.class));

        loggerFactoryMock = Mockito.mockStatic(LoggerFactory.class);
        loggerFactoryMock.when(LoggerFactory::getILoggerFactory).thenReturn(loggerContext);
    }

    @AfterEach
    void tearDown() {
        if (loggerFactoryMock != null) {
            loggerFactoryMock.close();
        }
    }

    @Test
    void constructor_shouldCreateLogBackConfigLoader() throws Exception {
        ApolloLogbackLoggingSystem system =
                new ApolloLogbackLoggingSystem(getClass().getClassLoader());
        java.lang.reflect.Field field = ApolloLogbackLoggingSystem.class.getDeclaredField("logBackConfigLoader");
        field.setAccessible(true);
        Object loader = field.get(system);

        assertThat(loader).isInstanceOf(ApolloLogBackConfigLoader.class);
    }

    @Test
    void loadDefaults_whenInitLogReturnsTrue_shouldNotCallSuper() {
        doReturn(true).when(mockLoader).initLog(any(), any());

        loggingSystem.loadDefaults(initContext, null);

        verify(mockLoader, times(1)).initLog(any(), any());
    }

    @Test
    void loadConfiguration_whenInitLogReturnsTrue_shouldNotCallSuper() {
        doReturn(true).when(mockLoader).initLog(any(), any());

        loggingSystem.loadConfiguration(initContext, "logback-spring.xml", null);

        verify(mockLoader, times(1)).initLog(any(), any());
    }

    @Test
    void reinitialize_whenInitLogReturnsTrue_shouldNotCallSuper() {
        doReturn(true).when(mockLoader).initLog(any(), any());

        loggingSystem.reinitialize(initContext);

        verify(mockLoader, times(2)).initLog(any(), any());
    }
}
