package com.yeepay.framework.springboot.starter.apollo.logback;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

class ApolloLogbackLoggingSystemFactoryTest {

    @Test
    void getLoggingSystem_shouldReturnApolloLogbackLoggingSystem() {
        ApolloLogbackLoggingSystemFactory factory = new ApolloLogbackLoggingSystemFactory();
        LoggingSystem system = factory.getLoggingSystem(getClass().getClassLoader());
        assertThat(system).isInstanceOf(ApolloLogbackLoggingSystem.class);
    }

    @Test
    void shouldHaveHighestPrecedenceOrder() {
        Order order = ApolloLogbackLoggingSystemFactory.class.getAnnotation(Order.class);
        assertThat(order).isNotNull();
        assertThat(order.value()).isEqualTo(Ordered.HIGHEST_PRECEDENCE);
    }
}
