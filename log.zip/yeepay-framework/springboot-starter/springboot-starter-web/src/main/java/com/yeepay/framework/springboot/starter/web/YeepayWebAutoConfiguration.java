package com.yeepay.framework.springboot.starter.web;

import com.yeepay.framework.common.utils.number.BigDecimalSafetyValidator;
import com.yeepay.framework.springboot.starter.web.config.BigDecimalConfig;
import com.yeepay.framework.springboot.starter.web.config.YeepayWebProperties;
import com.yeepay.framework.web.convert.BigDecimalConverter;
import com.yeepay.framework.web.filter.ThreadContextFilter;
import com.yeepay.framework.web.handler.ApplicationExceptionHandler;
import com.yeepay.framework.web.handler.MvcExceptionHandler;
import com.yeepay.framework.web.response.ResponseAdvice;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;

/**
 * Web模块自动配置.
 *
 * <p>自动注册 {@link ThreadContextFilter}，为每个HTTP请求初始化线程上下文。
 *
 * <p>通过 {@code yeepay.framework.web.enabled=false} 可关闭。
 */
@AutoConfiguration
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@EnableConfigurationProperties(YeepayWebProperties.class)
@ConditionalOnProperty(
        prefix = YeepayWebProperties.PREFIX,
        name = "enabled",
        havingValue = "true",
        matchIfMissing = true)
public class YeepayWebAutoConfiguration {

    /**
     * 注册 ThreadContextFilter.
     *
     * @return the filter registration bean
     */
    @Bean
    public FilterRegistrationBean<ThreadContextFilter> threadContextFilterRegistration() {
        FilterRegistrationBean<ThreadContextFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new ThreadContextFilter());
        registration.addUrlPatterns("/*");
        registration.setName("threadContextFilter");
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return registration;
    }

    /**
     * Mvc exception handler.
     *
     * @return the mvc exception handler
     */
    @Bean
    public MvcExceptionHandler mvcExceptionHandler() {
        return new MvcExceptionHandler();
    }

    /**
     * Application exception handler.
     *
     * @return the application exception handler
     */
    @Bean
    public ApplicationExceptionHandler applicationExceptionHandler() {
        return new ApplicationExceptionHandler();
    }

    /**
     * Response advice.
     *
     * @return the response advice
     */
    @Bean
    public ResponseAdvice responseAdvice() {
        return new ResponseAdvice();
    }

    /**
     * BigDecimal safety validator.
     *
     * @param config the htx web config
     * @return the big decimal safety validator
     */
    @Bean
    @ConditionalOnProperty(
            name = YeepayWebProperties.PREFIX + ".bigDecimalChecker",
            havingValue = "true",
            matchIfMissing = true)
    public BigDecimalSafetyValidator bigDecimalSafetyValidator(YeepayWebProperties config) {
        BigDecimalConfig bigDecimal = config.getBigDecimal();
        return new BigDecimalSafetyValidator(bigDecimal.getExponent(), bigDecimal.getMaxLength());
    }

    /**
     * BigDecimal converter for form data / query parameter binding.
     *
     * @param validator the BigDecimal safety validator
     * @return the BigDecimal converter bean
     */
    @Bean
    @ConditionalOnProperty(
            name = YeepayWebProperties.PREFIX + ".bigDecimalChecker",
            havingValue = "true",
            matchIfMissing = true)
    public BigDecimalConverter bigDecimalConverter(BigDecimalSafetyValidator validator) {
        return new BigDecimalConverter(validator);
    }
}
