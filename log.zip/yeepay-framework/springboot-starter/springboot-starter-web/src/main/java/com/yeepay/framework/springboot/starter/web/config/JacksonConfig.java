package com.yeepay.framework.springboot.starter.web.config;

import lombok.Data;

/**
 * Jackson 配置.
 */
@Data
public class JacksonConfig {

    /**
     * 是否开启 Jackson 自定义配置.
     */
    private boolean enabled = true;

    private boolean longToStringSerializer;
}
