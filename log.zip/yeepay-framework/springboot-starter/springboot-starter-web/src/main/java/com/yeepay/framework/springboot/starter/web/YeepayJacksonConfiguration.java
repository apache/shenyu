package com.yeepay.framework.springboot.starter.web;

import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yeepay.framework.common.utils.number.BigDecimalSafetyValidator;
import com.yeepay.framework.springboot.starter.web.config.YeepayWebProperties;
import com.yeepay.framework.web.jackson.deserializer.BigDecimalDeserializerModule;
import com.yeepay.framework.web.jackson.serializer.LongToStringSerializerModule;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

/**
 * The type Yee pay jackson configuration.
 */
@AutoConfiguration(after = YeepayWebAutoConfiguration.class)
@ConditionalOnClass(Jackson2ObjectMapperBuilder.class)
@ConditionalOnProperty(
        prefix = YeepayWebProperties.PREFIX + ".jackson",
        name = "enabled",
        havingValue = "true",
        matchIfMissing = true)
public class YeepayJacksonConfiguration {

    /**
     * Mapping jackson 2 http message converter mapping jackson 2 http message converter.
     *
     * @param objectMapper the object mapper
     * @return the mapping jack-son2 http message converter
     */
    @Bean
    @ConditionalOnMissingBean(MappingJackson2HttpMessageConverter.class)
    @ConditionalOnBean(ObjectMapper.class)
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter(ObjectMapper objectMapper) {
        MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter =
                new MappingJackson2HttpMessageConverter();
        mappingJackson2HttpMessageConverter.setObjectMapper(objectMapper);
        // 设置中文编码格式
        List<MediaType> list = new ArrayList<>();
        list.add(MediaType.APPLICATION_JSON);
        mappingJackson2HttpMessageConverter.setSupportedMediaTypes(list);
        return mappingJackson2HttpMessageConverter;
    }

    /**
     * Jackson base configurer jackson2 object mapper builder customizer.
     *
     * @param validator the big decimal safety validator
     * @param config the htx web config
     * @return the jack-son2 object mapper builder customizer
     */
    @Bean
    @ConditionalOnMissingBean(name = "jacksonBaseConfigurer")
    @ConditionalOnBean(YeepayWebProperties.class)
    public Jackson2ObjectMapperBuilderCustomizer jacksonBaseConfigurer(
            final ObjectProvider<BigDecimalSafetyValidator> validator, final YeepayWebProperties config) {
        return builder -> {
            List<Module> modules = new ArrayList<>();
            if (config.isBigDecimalChecker()) {
                validator.ifAvailable(v -> modules.add(new BigDecimalDeserializerModule(v)));
            }
            if (config.getJackson().isLongToStringSerializer()) {
                modules.add(new LongToStringSerializerModule());
            }
            builder.modules(list -> list.addAll(modules));
        };
    }
}
