package com.yeepay.framework.springboot.starter.web.config;

import static com.yeepay.framework.springboot.starter.web.config.YeepayWebProperties.PREFIX;

import com.yeepay.framework.common.constants.CommonConstants;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * Web模块配置属性.
 */
@ConfigurationProperties(prefix = PREFIX)
@Data
public class YeepayWebProperties {

    public static final String PREFIX = CommonConstants.PREFIX + ".web";

    private boolean enabled = true;

    private boolean bigDecimalChecker = true;

    @NestedConfigurationProperty
    private JacksonConfig jackson = new JacksonConfig();

    @NestedConfigurationProperty
    private BigDecimalConfig bigDecimal = new BigDecimalConfig();
}
