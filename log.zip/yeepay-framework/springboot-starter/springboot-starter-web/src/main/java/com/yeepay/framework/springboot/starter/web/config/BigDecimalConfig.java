package com.yeepay.framework.springboot.starter.web.config;

import lombok.Data;

/**
 * BigDecimal 安全校验配置.
 *
 * @since 1.2.20
 */
@Data
public class BigDecimalConfig {

    /**
     * 科学计数法允许的最大指数绝对值，防止 {@code 5e+300}、{@code 1e9999} 等超大指数攻击.
     *
     * <p>例如设置为 5 表示指数范围为 [-5, 5]，即 {@code e5} 合法，{@code e+6} 不合法.
     */
    private int exponent = 5;

    /**
     * 输入字符串的最大总长度，防止超长字符串消耗内存.
     */
    private int maxLength = 75;
}
