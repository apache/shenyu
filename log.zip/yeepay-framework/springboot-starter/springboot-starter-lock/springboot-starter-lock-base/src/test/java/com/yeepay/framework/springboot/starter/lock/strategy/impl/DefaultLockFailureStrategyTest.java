package com.yeepay.framework.springboot.starter.lock.strategy.impl;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.exeception.LockRuntimeException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DefaultLockFailureStrategyTest {

    @Mock
    private ProceedingJoinPoint joinPoint;

    private final DefaultLockFailureStrategy strategy = new DefaultLockFailureStrategy();

    @Test
    void execute_throwsLockRuntimeException_withKeyAndWaitTime() {
        LockEntity entity =
                LockEntity.builder().keyName("order-lock").waitTime(3000L).build();
        assertThatThrownBy(() -> strategy.execute(entity, joinPoint))
                .isInstanceOf(LockRuntimeException.class)
                .hasMessageContaining("order-lock")
                .hasMessageContaining("3000");
    }

    @Test
    void execute_throwsLockRuntimeException_alwaysThrows() {
        LockEntity entity = LockEntity.builder().keyName("k").waitTime(0L).build();
        assertThatThrownBy(() -> strategy.execute(entity, joinPoint)).isInstanceOf(LockRuntimeException.class);
    }
}
