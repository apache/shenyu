package com.yeepay.framework.springboot.starter.lock;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.springboot.starter.lock.aspect.YeepayLockAspect;
import com.yeepay.framework.springboot.starter.lock.config.YeepayLockProperties;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.LockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.BeanResolver;

class LockAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(ctx ->
                    ConfigurationPropertiesBindingPostProcessor.register((BeanDefinitionRegistry) ctx.getBeanFactory()))
            .withConfiguration(AutoConfigurations.of(LockAutoConfiguration.class))
            .withBean(LockTemplate.class, () -> mock(LockTemplate.class));

    @Test
    void autoConfiguration_registersDefaultStrategiesAndAspect() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(YeepayLockProperties.class);
            assertThat(context).hasSingleBean(LockKeyStrategy.class);
            assertThat(context).hasSingleBean(LockFailureStrategy.class);
            assertThat(context).hasSingleBean(ReleaseTimeoutStrategy.class);
            assertThat(context).hasSingleBean(YeepayLockAspect.class);

            assertThat(context.getBean(LockKeyStrategy.class)).isInstanceOf(DefaultLockKeyStrategy.class);
            assertThat(context.getBean(LockFailureStrategy.class)).isInstanceOf(DefaultLockFailureStrategy.class);
            assertThat(context.getBean(ReleaseTimeoutStrategy.class)).isInstanceOf(DefaultReleaseTimeoutStrategy.class);
        });
    }

    @Test
    void autoConfiguration_bindsLockPropertiesFromYaml() {
        contextRunner
                .withPropertyValues("yeepay.framework.lock.retry-interval=200")
                .run(context -> {
                    YeepayLockProperties props = context.getBean(YeepayLockProperties.class);
                    assertThat(props.getRetryInterval()).isEqualTo(200L);
                    assertThat(props.isEnabled()).isTrue();
                });
    }

    @Test
    void autoConfiguration_skippedWhenEnabledFalse() {
        contextRunner.withPropertyValues("yeepay.framework.lock.enabled=false").run(context -> {
            assertThat(context).doesNotHaveBean(LockAutoConfiguration.class);
            assertThat(context).doesNotHaveBean(YeepayLockAspect.class);
            assertThat(context).doesNotHaveBean(LockKeyStrategy.class);
        });
    }

    @Test
    void autoConfiguration_activeWhenEnabledMissing_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(LockAutoConfiguration.class);
            assertThat(context).hasSingleBean(YeepayLockAspect.class);
        });
    }

    @Test
    void autoConfiguration_picksUpBeanResolverForKeyStrategy() {
        BeanResolver beanResolver = mock(BeanResolver.class);
        contextRunner.withBean(BeanResolver.class, () -> beanResolver).run(context -> {
            assertThat(context).hasSingleBean(LockKeyStrategy.class);
            assertThat(context.getBean(LockKeyStrategy.class)).isInstanceOf(DefaultLockKeyStrategy.class);
        });
    }

    @Test
    void autoConfiguration_aspectAggregatesAllStrategyBeans() {
        contextRunner.withUserConfiguration(ExtraStrategyConfig.class).run(context -> {
            assertThat(context).hasSingleBean(YeepayLockAspect.class);
            assertThat(context.getBeansOfType(LockKeyStrategy.class)).hasSize(2);
            assertThat(context.getBeansOfType(LockFailureStrategy.class)).hasSize(2);
            assertThat(context.getBeansOfType(ReleaseTimeoutStrategy.class)).hasSize(2);
        });
    }

    @Configuration
    static class ExtraStrategyConfig {
        @Bean
        LockKeyStrategy extraKeyStrategy() {
            return (joinPoint, keys) -> "extra";
        }

        @Bean
        LockFailureStrategy extraFailureStrategy() {
            return (lockEntity, point) -> null;
        }

        @Bean
        ReleaseTimeoutStrategy extraReleaseTimeoutStrategy() {
            return lockEntity -> {};
        }
    }
}
