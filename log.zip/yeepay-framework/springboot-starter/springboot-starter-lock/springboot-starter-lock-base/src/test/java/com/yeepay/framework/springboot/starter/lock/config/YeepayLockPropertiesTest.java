package com.yeepay.framework.springboot.starter.lock.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class YeepayLockPropertiesTest {

    @Test
    void defaults_enabledTrueAndRetryInterval50() {
        YeepayLockProperties props = new YeepayLockProperties();
        assertThat(props.isEnabled()).isTrue();
        assertThat(props.getRetryInterval()).isEqualTo(50L);
    }

    @Test
    void setEnabled_false_updatesField() {
        YeepayLockProperties props = new YeepayLockProperties();
        props.setEnabled(false);
        assertThat(props.isEnabled()).isFalse();
    }

    @Test
    void setRetryInterval_updatesField() {
        YeepayLockProperties props = new YeepayLockProperties();
        props.setRetryInterval(200L);
        assertThat(props.getRetryInterval()).isEqualTo(200L);
    }
}
