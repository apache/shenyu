package com.yeepay.framework.springboot.starter.lock.strategy.impl;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.exeception.LockRuntimeException;
import org.junit.jupiter.api.Test;

class DefaultReleaseTimeoutStrategyTest {

    private final DefaultReleaseTimeoutStrategy strategy = new DefaultReleaseTimeoutStrategy();

    @Test
    void execute_throwsLockRuntimeException_withLeaseTime() {
        LockEntity entity = LockEntity.builder().keyName("k").leaseTime(5000L).build();
        assertThatThrownBy(() -> strategy.execute(entity))
                .isInstanceOf(LockRuntimeException.class)
                .hasMessageContaining("5000");
    }

    @Test
    void execute_alwaysThrows() {
        LockEntity entity = LockEntity.builder().keyName("k").leaseTime(1000L).build();
        assertThatThrownBy(() -> strategy.execute(entity)).isInstanceOf(LockRuntimeException.class);
    }
}
