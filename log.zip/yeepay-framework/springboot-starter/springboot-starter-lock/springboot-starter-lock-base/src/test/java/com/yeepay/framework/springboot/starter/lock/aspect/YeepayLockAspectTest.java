package com.yeepay.framework.springboot.starter.lock.aspect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.annotation.YeepayLock;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.LockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import java.lang.reflect.Method;
import java.util.List;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class YeepayLockAspectTest {

    @Mock
    private LockTemplate lockTemplate;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @Mock
    private MethodSignature methodSignature;

    private final DefaultLockKeyStrategy defaultKeyStrategy = new DefaultLockKeyStrategy(null);
    private final DefaultLockFailureStrategy defaultFailureStrategy = new DefaultLockFailureStrategy();
    private final DefaultReleaseTimeoutStrategy defaultReleaseStrategy = new DefaultReleaseTimeoutStrategy();

    // ── custom strategy implementations ────────────────────────────────────

    static class CustomKeyStrategy implements LockKeyStrategy {
        @Override
        public String buildKey(JoinPoint joinPoint, String[] keys) {
            return "custom-key";
        }
    }

    static class CustomFailureStrategy implements LockFailureStrategy {
        @Override
        public Object execute(LockEntity lockEntity, ProceedingJoinPoint point) {
            return "custom-failure";
        }
    }

    static class CustomReleaseTimeoutStrategy implements ReleaseTimeoutStrategy {
        @Override
        public void execute(LockEntity lockEntity) {}
    }

    // ── annotated test methods for annotation instances ────────────────────

    static class TestService {
        @YeepayLock(name = "test", waitTime = 1000L, leaseTime = 2000L)
        public void defaultAnnotated() {}

        @YeepayLock(
                name = "custom",
                keyStrategy = CustomKeyStrategy.class,
                failStrategy = CustomFailureStrategy.class,
                releaseTimeoutStrategy = CustomReleaseTimeoutStrategy.class)
        public void customAnnotated() {}
    }

    private YeepayLockAspect aspect;

    @BeforeEach
    void setUp() throws Exception {
        aspect = new YeepayLockAspect(
                lockTemplate,
                List.of(defaultKeyStrategy),
                List.of(defaultFailureStrategy),
                List.of(defaultReleaseStrategy));
        aspect.afterPropertiesSet();
    }

    // ── default strategies ──────────────────────────────────────────────────

    @Test
    void aroundCounter_withDefaultStrategies_buildsKeyAndInvokesTemplate() throws Exception {
        Method method = TestService.class.getDeclaredMethod("defaultAnnotated");
        YeepayLock lock = method.getAnnotation(YeepayLock.class);

        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.TestService");
        when(methodSignature.getMethod()).thenReturn(method);
        when(lockTemplate.invoke(any(), any(), any(), any())).thenReturn("result");

        Object result = aspect.aroundCounter(joinPoint, lock);

        assertThat(result).isEqualTo("result");
        ArgumentCaptor<LockEntity> entityCaptor = ArgumentCaptor.forClass(LockEntity.class);
        verify(lockTemplate)
                .invoke(
                        eq(joinPoint),
                        any(DefaultLockFailureStrategy.class),
                        any(DefaultReleaseTimeoutStrategy.class),
                        entityCaptor.capture());
        LockEntity entity = entityCaptor.getValue();
        assertThat(entity.getKeyName()).startsWith("yeepay-locktest#");
        assertThat(entity.getWaitTime()).isEqualTo(1000L);
        assertThat(entity.getLeaseTime()).isEqualTo(2000L);
    }

    // ── custom strategies ──────────────────────────────────────────────────

    @Test
    void aroundCounter_withCustomStrategies_selectsCorrectStrategiesFromMap() throws Exception {
        CustomKeyStrategy customKey = new CustomKeyStrategy();
        CustomFailureStrategy customFailure = new CustomFailureStrategy();
        CustomReleaseTimeoutStrategy customRelease = new CustomReleaseTimeoutStrategy();

        YeepayLockAspect aspectWithCustom = new YeepayLockAspect(
                lockTemplate,
                List.of(defaultKeyStrategy, customKey),
                List.of(defaultFailureStrategy, customFailure),
                List.of(defaultReleaseStrategy, customRelease));
        aspectWithCustom.afterPropertiesSet();

        Method method = TestService.class.getDeclaredMethod("customAnnotated");
        YeepayLock lock = method.getAnnotation(YeepayLock.class);

        when(lockTemplate.invoke(any(), any(), any(), any())).thenReturn("custom-result");

        Object result = aspectWithCustom.aroundCounter(joinPoint, lock);

        assertThat(result).isEqualTo("custom-result");
        verify(lockTemplate)
                .invoke(
                        eq(joinPoint),
                        any(CustomFailureStrategy.class),
                        any(CustomReleaseTimeoutStrategy.class),
                        any(LockEntity.class));
    }

    @Test
    void aroundCounter_lockEntityContainsCorrectKeyPrefix() throws Exception {
        Method method = TestService.class.getDeclaredMethod("defaultAnnotated");
        YeepayLock lock = method.getAnnotation(YeepayLock.class);

        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.SomeService");
        when(methodSignature.getMethod()).thenReturn(method);
        when(lockTemplate.invoke(any(), any(), any(), any())).thenReturn(null);

        aspect.aroundCounter(joinPoint, lock);

        ArgumentCaptor<LockEntity> captor = ArgumentCaptor.forClass(LockEntity.class);
        verify(lockTemplate).invoke(any(), any(), any(), captor.capture());
        assertThat(captor.getValue().getKeyName())
                .isEqualTo("yeepay-locktest#com.example.SomeService.defaultAnnotated");
    }

    @Test
    void strategyHolder_setters_workCorrectly() {
        YeepayLockAspect.StrategyHolder holder =
                YeepayLockAspect.StrategyHolder.builder().build();
        holder.setLockKeyStrategy(defaultKeyStrategy);
        holder.setLockFailureStrategy(defaultFailureStrategy);
        holder.setReleaseTimeoutStrategy(defaultReleaseStrategy);
        assertThat(holder.getLockKeyStrategy()).isSameAs(defaultKeyStrategy);
        assertThat(holder.getLockFailureStrategy()).isSameAs(defaultFailureStrategy);
        assertThat(holder.getReleaseTimeoutStrategy()).isSameAs(defaultReleaseStrategy);
    }

    @Test
    void strategyHolder_equalsAndHashCode_workCorrectly() {
        YeepayLockAspect.StrategyHolder h1 = YeepayLockAspect.StrategyHolder.builder()
                .lockKeyStrategy(defaultKeyStrategy)
                .lockFailureStrategy(defaultFailureStrategy)
                .releaseTimeoutStrategy(defaultReleaseStrategy)
                .build();
        YeepayLockAspect.StrategyHolder h2 = YeepayLockAspect.StrategyHolder.builder()
                .lockKeyStrategy(defaultKeyStrategy)
                .lockFailureStrategy(defaultFailureStrategy)
                .releaseTimeoutStrategy(defaultReleaseStrategy)
                .build();
        assertThat(h1).isEqualTo(h2);
        assertThat(h1.hashCode()).isEqualTo(h2.hashCode());
        assertThat(h1.toString()).contains("StrategyHolder");
    }

    @Test
    void builderStrategyHolder_withNullStrategies_picksDefaults() throws Exception {
        java.lang.reflect.Method method = YeepayLockAspect.class.getDeclaredMethod(
                "builderStrategyHolder", Class.class, Class.class, Class.class);
        method.setAccessible(true);

        Object holder = method.invoke(aspect, null, null, null);
        assertThat(holder).isInstanceOf(YeepayLockAspect.StrategyHolder.class);
        YeepayLockAspect.StrategyHolder sh = (YeepayLockAspect.StrategyHolder) holder;
        assertThat(sh.getLockKeyStrategy()).isSameAs(defaultKeyStrategy);
        assertThat(sh.getLockFailureStrategy()).isSameAs(defaultFailureStrategy);
        assertThat(sh.getReleaseTimeoutStrategy()).isSameAs(defaultReleaseStrategy);
    }
}
