package com.yeepay.framework.springboot.starter.lock.strategy.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.expression.BeanResolver;

@ExtendWith(MockitoExtension.class)
class DefaultLockKeyStrategyTest {

    @Mock
    private BeanResolver beanResolver;

    @Mock
    private JoinPoint joinPoint;

    @Mock
    private MethodSignature methodSignature;

    private DefaultLockKeyStrategy strategy;

    static class TestService {
        public String process(String name, int count) {
            return name + count;
        }
    }

    interface TestInterface {
        String hello(String name);
    }

    static class TestImpl implements TestInterface {
        @Override
        public String hello(String name) {
            return name;
        }
    }

    @BeforeEach
    void setUp() {
        strategy = new DefaultLockKeyStrategy(beanResolver);
    }

    // ── empty / null keys → class.method ───────────────────────────────────

    @Test
    void buildKey_emptyKeys_returnsClassDotMethod() throws Exception {
        Method method = TestService.class.getDeclaredMethod("process", String.class, int.class);
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.TestService");
        when(methodSignature.getMethod()).thenReturn(method);

        String key = strategy.buildKey(joinPoint, new String[] {});
        assertThat(key).isEqualTo("com.example.TestService.process");
    }

    @Test
    void buildKey_nullKeys_returnsClassDotMethod() throws Exception {
        Method method = TestService.class.getDeclaredMethod("process", String.class, int.class);
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.TestService");
        when(methodSignature.getMethod()).thenReturn(method);

        String key = strategy.buildKey(joinPoint, null);
        assertThat(key).isEqualTo("com.example.TestService.process");
    }

    // ── SpEL expression keys ────────────────────────────────────────────────

    @Test
    void buildKey_spelSingleParam_evaluatesExpression() throws Exception {
        Method method = TestService.class.getDeclaredMethod("process", String.class, int.class);
        TestService target = new TestService();
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getMethod()).thenReturn(method);
        when(joinPoint.getThis()).thenReturn(target);
        when(joinPoint.getArgs()).thenReturn(new Object[] {"alice", 3});

        String key = strategy.buildKey(joinPoint, new String[] {"#name"});
        assertThat(key).isEqualTo("alice");
    }

    @Test
    void buildKey_spelMultipleKeys_joinsWithDot() throws Exception {
        Method method = TestService.class.getDeclaredMethod("process", String.class, int.class);
        TestService target = new TestService();
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getMethod()).thenReturn(method);
        when(joinPoint.getThis()).thenReturn(target);
        when(joinPoint.getArgs()).thenReturn(new Object[] {"bob", 5});

        String key = strategy.buildKey(joinPoint, new String[] {"#name", "#count"});
        assertThat(key).isEqualTo("bob.5");
    }

    @Test
    void buildKey_emptyStringKey_skipsEmptyKey() throws Exception {
        Method method = TestService.class.getDeclaredMethod("process", String.class, int.class);
        TestService target = new TestService();
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getMethod()).thenReturn(method);
        when(joinPoint.getThis()).thenReturn(target);
        when(joinPoint.getArgs()).thenReturn(new Object[] {"carol", 1});

        // empty string in keys array is skipped
        String key = strategy.buildKey(joinPoint, new String[] {"", "#name"});
        assertThat(key).isEqualTo("carol");
    }

    // ── interface method → resolved to impl class ──────────────────────────

    @Test
    void buildKey_interfaceMethod_resolvesToImplMethod() throws Exception {
        Method interfaceMethod = TestInterface.class.getDeclaredMethod("hello", String.class);
        TestImpl impl = new TestImpl();
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.TestInterface");
        when(methodSignature.getMethod()).thenReturn(interfaceMethod);
        when(methodSignature.getName()).thenReturn("hello");
        when(joinPoint.getTarget()).thenReturn(impl);

        String key = strategy.buildKey(joinPoint, new String[] {});
        assertThat(key).isEqualTo("com.example.TestInterface.hello");
    }

    @Test
    void buildKey_interfaceMethod_spelEvaluatesOnImpl() throws Exception {
        Method interfaceMethod = TestInterface.class.getDeclaredMethod("hello", String.class);
        TestImpl impl = new TestImpl();
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getMethod()).thenReturn(interfaceMethod);
        when(methodSignature.getName()).thenReturn("hello");
        when(joinPoint.getThis()).thenReturn(impl);
        when(joinPoint.getTarget()).thenReturn(impl);
        when(joinPoint.getArgs()).thenReturn(new Object[] {"world"});

        String key = strategy.buildKey(joinPoint, new String[] {"#name"});
        assertThat(key).isEqualTo("world");
    }
}
