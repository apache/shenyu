package com.yeepay.framework.springboot.starter.lock.strategy;

import com.yeepay.framework.lock.api.entity.LockEntity;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * The interface Lock timeout strategy.
 */
public interface LockFailureStrategy {

    /**
     * Execute.
     *
     * @param lockEntity the lock entity
     * @param point      the point
     * @return the object
     */
    Object execute(LockEntity lockEntity, ProceedingJoinPoint point);
}
