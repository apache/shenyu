package com.yeepay.framework.springboot.starter.lock.annotation;

import com.yeepay.framework.lock.api.enums.LockType;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.LockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The interface Lock.
 */
@Target(value = ElementType.METHOD)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface YeepayLock {

    /**
     * Name string.
     *
     * @return the string
     */
    String name() default "";

    /**
     * Lock type.
     *
     * @return the lock type
     */
    LockType lockType() default LockType.REENTRANT;

    /**
     * Wait time long.
     * default 3000L
     *
     * @return the long
     */
    long waitTime() default 3000L;

    /**
     * Lease time long.
     * default 3000L
     *
     * @return the long
     */
    long leaseTime() default 3000L;

    /**
     * Keys string [ ].
     *
     * @return the string [ ]
     */
    String[] keys() default {};

    /**
     * Fail strategy class.
     *
     * @return the class
     */
    Class<? extends LockFailureStrategy> failStrategy() default LockFailureStrategy.class;

    /**
     * Key strategy class.
     *
     * @return the class
     */
    Class<? extends LockKeyStrategy> keyStrategy() default LockKeyStrategy.class;

    /**
     * Release timeout strategy.
     * default FAIL_FAST
     *
     * @return the release timeout strategy
     */
    Class<? extends ReleaseTimeoutStrategy> releaseTimeoutStrategy() default ReleaseTimeoutStrategy.class;

    /**
     * Auto release boolean.
     *
     * @return the boolean
     */
    boolean autoRelease() default true;
}
