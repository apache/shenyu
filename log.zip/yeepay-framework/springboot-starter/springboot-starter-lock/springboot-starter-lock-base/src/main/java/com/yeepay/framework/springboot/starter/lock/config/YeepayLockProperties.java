package com.yeepay.framework.springboot.starter.lock.config;

import static com.yeepay.framework.springboot.starter.lock.config.YeepayLockProperties.PREFIX;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Lock 锁专属配置项.
 *
 * <p>示例（application.yml）：
 * <pre>
 * yeepay:
 *   framework:
 *     lock:
 *         type: jedis            # 同时依赖两个 starter 时必填（jedis / redisson）
 *         retry-interval: 100
 * </pre>
 */
@Data
@ConfigurationProperties(prefix = PREFIX)
public class YeepayLockProperties {

    public static final String PREFIX = "yeepay.framework.lock";

    private boolean enabled = true;

    /**
     * 分布式锁实现类型：{@code jedis} 或 {@code redisson}.
     *
     * <p>单独依赖时无需设置，自动激活；
     * 同时依赖 lock-jedis 和 lock-redisson 时必须指定，否则启动报 duplicate bean 错误。
     */
    private String type;

    /** 获取锁失败后的轮询重试间隔（毫秒），默认 50ms. */
    private long retryInterval = 50L;
}
