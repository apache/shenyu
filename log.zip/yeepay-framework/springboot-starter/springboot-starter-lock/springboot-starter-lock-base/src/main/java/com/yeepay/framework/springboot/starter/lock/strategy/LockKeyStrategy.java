package com.yeepay.framework.springboot.starter.lock.strategy;

import org.aspectj.lang.JoinPoint;

/**
 * The interface Lock key strategy.
 */
public interface LockKeyStrategy {

    /**
     * Build key string.
     *
     * @param joinPoint the join point
     * @param keys      the keys
     * @return the string
     */
    String buildKey(JoinPoint joinPoint, String[] keys);
}
