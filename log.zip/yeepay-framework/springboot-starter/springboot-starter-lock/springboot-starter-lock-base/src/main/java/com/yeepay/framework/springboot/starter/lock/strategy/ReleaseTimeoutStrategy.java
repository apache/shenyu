package com.yeepay.framework.springboot.starter.lock.strategy;

import com.yeepay.framework.lock.api.entity.LockEntity;

/**
 * The enum Release timeout strategy.
 */
public interface ReleaseTimeoutStrategy {

    /**
     * Execute.
     *
     * @param lockEntity the lock entity
     */
    void execute(LockEntity lockEntity);
}
