package com.yeepay.framework.springboot.starter.lock.aspect;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.annotation.YeepayLock;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.LockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.InitializingBean;

/**
 * The type Yeepay Lock aspect.
 */
@Aspect
@RequiredArgsConstructor
public class YeepayLockAspect implements InitializingBean {

    private final Map<Class<? extends LockKeyStrategy>, LockKeyStrategy> keyStrategyMap = new LinkedHashMap<>();

    private final Map<Class<? extends LockFailureStrategy>, LockFailureStrategy> failureStrategyMap =
            new LinkedHashMap<>();

    private final Map<Class<? extends ReleaseTimeoutStrategy>, ReleaseTimeoutStrategy> releaseTimeoutStrategyMap =
            new LinkedHashMap<>();

    private final LockTemplate lockTemplate;

    private final List<LockKeyStrategy> keyStrategyList;

    private final List<LockFailureStrategy> failureStrategyList;

    private final List<ReleaseTimeoutStrategy> releaseTimeoutStrategyList;

    /**
     * Around counter object.
     *
     * @param joinPoint the join point
     * @param lock      the lock
     * @return the object
     */
    @SneakyThrows
    @Around(value = "@annotation(lock)")
    public Object aroundCounter(final ProceedingJoinPoint joinPoint, final YeepayLock lock) {
        StrategyHolder strategyHolder =
                builderStrategyHolder(lock.keyStrategy(), lock.failStrategy(), lock.releaseTimeoutStrategy());
        String key = "yeepay-lock" + lock.name() + "#"
                + strategyHolder.getLockKeyStrategy().buildKey(joinPoint, lock.keys());
        LockEntity entity = LockEntity.builder()
                .keyName(key)
                .waitTime(lock.waitTime())
                .leaseTime(lock.leaseTime())
                .type(lock.lockType())
                .autoRelease(lock.autoRelease())
                .build();
        return lockTemplate.invoke(
                joinPoint, strategyHolder.getLockFailureStrategy(), strategyHolder.getReleaseTimeoutStrategy(), entity);
    }

    @Override
    public void afterPropertiesSet() {
        keyStrategyMap.putAll(keyStrategyList.stream()
                .collect(Collectors.toMap(LockKeyStrategy::getClass, keyStrategy -> keyStrategy)));
        failureStrategyMap.putAll(failureStrategyList.stream()
                .collect(Collectors.toMap(LockFailureStrategy::getClass, failureStrategy -> failureStrategy)));
        releaseTimeoutStrategyMap.putAll(releaseTimeoutStrategyList.stream()
                .collect(Collectors.toMap(
                        ReleaseTimeoutStrategy::getClass, releaseTimeoutStrategy -> releaseTimeoutStrategy)));
    }

    private StrategyHolder builderStrategyHolder(
            final Class<? extends LockKeyStrategy> keyStrategy,
            final Class<? extends LockFailureStrategy> failStrategy,
            final Class<? extends ReleaseTimeoutStrategy> releaseStrategy) {
        StrategyHolder.StrategyHolderBuilder builder = StrategyHolder.builder();
        if (Objects.isNull(keyStrategy) || keyStrategy == LockKeyStrategy.class) {
            builder.lockKeyStrategy(keyStrategyMap.get(DefaultLockKeyStrategy.class));
        } else {
            builder.lockKeyStrategy(keyStrategyMap.get(keyStrategy));
        }
        if (Objects.isNull(failStrategy) || failStrategy == LockFailureStrategy.class) {
            builder.lockFailureStrategy(failureStrategyMap.get(DefaultLockFailureStrategy.class));
        } else {
            builder.lockFailureStrategy(failureStrategyMap.get(failStrategy));
        }
        if (Objects.isNull(releaseStrategy) || releaseStrategy == ReleaseTimeoutStrategy.class) {
            builder.releaseTimeoutStrategy(releaseTimeoutStrategyMap.get(DefaultReleaseTimeoutStrategy.class));
        } else {
            builder.releaseTimeoutStrategy(releaseTimeoutStrategyMap.get(releaseStrategy));
        }
        return builder.build();
    }

    /**
     * 策略持有者，聚合切面所需的三种策略.
     */
    @Data
    @Builder
    public static class StrategyHolder {

        private LockKeyStrategy lockKeyStrategy;

        private LockFailureStrategy lockFailureStrategy;

        private ReleaseTimeoutStrategy releaseTimeoutStrategy;
    }
}
