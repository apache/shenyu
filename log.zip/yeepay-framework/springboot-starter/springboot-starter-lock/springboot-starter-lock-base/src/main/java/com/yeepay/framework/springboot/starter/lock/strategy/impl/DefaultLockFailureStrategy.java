package com.yeepay.framework.springboot.starter.lock.strategy.impl;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.exeception.LockRuntimeException;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * The type Default lock failure strategy.
 */
public class DefaultLockFailureStrategy implements LockFailureStrategy {

    @Override
    public Object execute(final LockEntity lockEntity, final ProceedingJoinPoint point) {
        String errorMsg = String.format(
                "Fail to acquire lock is : %s ,the wait time is %s", lockEntity.getKeyName(), lockEntity.getWaitTime());
        throw new LockRuntimeException(errorMsg);
    }
}
