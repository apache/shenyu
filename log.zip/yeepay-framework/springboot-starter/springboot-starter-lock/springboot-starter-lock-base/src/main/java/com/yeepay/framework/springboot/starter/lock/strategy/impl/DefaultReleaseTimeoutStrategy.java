package com.yeepay.framework.springboot.starter.lock.strategy.impl;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.api.exeception.LockRuntimeException;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;

/**
 * The type Default release timeout strategy.
 */
public class DefaultReleaseTimeoutStrategy implements ReleaseTimeoutStrategy {

    @Override
    public void execute(final LockEntity lockEntity) {
        String errorMsg = String.format(
                "Lock: %s already been released while lock lease time is %s",
                lockEntity.getLeaseTime(), lockEntity.getLeaseTime());
        throw new LockRuntimeException(errorMsg);
    }
}
