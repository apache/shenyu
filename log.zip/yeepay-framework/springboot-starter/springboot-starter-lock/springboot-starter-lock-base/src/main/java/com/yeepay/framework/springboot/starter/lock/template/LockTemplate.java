package com.yeepay.framework.springboot.starter.lock.template;

import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * The interface Lock template.
 */
public interface LockTemplate {

    /**
     * Invoke object.
     *
     * @param joinPoint              the join point
     * @param lockFailureStrategy    the lock failure strategy
     * @param releaseTimeoutStrategy the release timeout strategy
     * @param lockEntity             the lock entity
     * @return the object
     */
    Object invoke(
            ProceedingJoinPoint joinPoint,
            LockFailureStrategy lockFailureStrategy,
            ReleaseTimeoutStrategy releaseTimeoutStrategy,
            LockEntity lockEntity);
}
