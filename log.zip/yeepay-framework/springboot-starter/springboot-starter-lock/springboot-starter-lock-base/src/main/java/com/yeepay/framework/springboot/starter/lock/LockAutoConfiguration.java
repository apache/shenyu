package com.yeepay.framework.springboot.starter.lock;

import com.yeepay.framework.springboot.starter.lock.aspect.YeepayLockAspect;
import com.yeepay.framework.springboot.starter.lock.config.YeepayLockProperties;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.LockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultLockKeyStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.impl.DefaultReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import java.util.List;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.expression.BeanResolver;

/**
 * 分布式锁公共自动配置.
 *
 * <p>通过 {@code yeepay.framework.lock.enabled=false} 可一键关闭所有锁功能。
 */
@AutoConfiguration
@EnableConfigurationProperties(YeepayLockProperties.class)
@ConditionalOnProperty(prefix = "yeepay.framework.lock", name = "enabled", havingValue = "true", matchIfMissing = true)
public class LockAutoConfiguration {

    /**
     * Default lock key strategy.
     *
     * @param beanResolver the bean resolver
     * @return the lock key strategy
     */
    @Bean
    public LockKeyStrategy defaultLockKeyStrategy(final ObjectProvider<BeanResolver> beanResolver) {
        return new DefaultLockKeyStrategy(beanResolver.getIfAvailable());
    }

    /**
     * Default lock failure strategy.
     *
     * @return the lock failure strategy
     */
    @Bean
    public LockFailureStrategy defaultLockFailureStrategy() {
        return new DefaultLockFailureStrategy();
    }

    /**
     * Default release timeout strategy.
     *
     * @return the release timeout strategy
     */
    @Bean
    public ReleaseTimeoutStrategy defaultReleaseTimeoutStrategy() {
        return new DefaultReleaseTimeoutStrategy();
    }

    /**
     * Lock aspect.
     *
     * @param lockTemplate             the lock template
     * @param keyStrategies            the key strategies
     * @param lockFailureStrategies    the lock failure strategies
     * @param releaseTimeoutStrategies the release timeout strategies
     * @return the lock aspect
     */
    @Bean
    public YeepayLockAspect lockAspect(
            final ObjectProvider<LockTemplate> lockTemplate,
            final ObjectProvider<List<LockKeyStrategy>> keyStrategies,
            final ObjectProvider<List<LockFailureStrategy>> lockFailureStrategies,
            final ObjectProvider<List<ReleaseTimeoutStrategy>> releaseTimeoutStrategies) {
        return new YeepayLockAspect(
                lockTemplate.getIfAvailable(),
                keyStrategies.getIfAvailable(),
                lockFailureStrategies.getIfAvailable(),
                releaseTimeoutStrategies.getIfAvailable());
    }
}
