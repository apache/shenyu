package com.yeepay.framework.springboot.starter.lock.jedis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.LockManager;
import com.yeepay.framework.lock.jedis.JedisLockExecutor;
import com.yeepay.framework.springboot.starter.lock.LockAutoConfiguration;
import com.yeepay.framework.springboot.starter.lock.config.YeepayLockProperties;
import com.yeepay.framework.springboot.starter.lock.jedis.template.JedisTemplate;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import redis.clients.jedis.UnifiedJedis;

class LockJedisAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(ctx ->
                    ConfigurationPropertiesBindingPostProcessor.register((BeanDefinitionRegistry) ctx.getBeanFactory()))
            .withConfiguration(AutoConfigurations.of(LockAutoConfiguration.class, LockJedisAutoConfiguration.class))
            .withUserConfiguration(MockJedisAndPropertiesConfig.class);

    @Test
    void autoConfiguration_wiresExecutorManagerAndTemplate() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(LockExecutor.class);
            assertThat(context).hasSingleBean(LockManager.class);
            assertThat(context).hasSingleBean(LockTemplate.class);

            assertThat(context.getBean(LockExecutor.class)).isInstanceOf(JedisLockExecutor.class);
            assertThat(context.getBean(LockTemplate.class)).isInstanceOf(JedisTemplate.class);
            assertThat(context.getBean(LockManager.class)).isInstanceOf(LockManager.class);
        });
    }

    @Test
    void autoConfiguration_failsWithoutUnifiedJedisBean() {
        new ApplicationContextRunner()
                .withInitializer(ctx -> ConfigurationPropertiesBindingPostProcessor.register(
                        (BeanDefinitionRegistry) ctx.getBeanFactory()))
                .withConfiguration(AutoConfigurations.of(LockAutoConfiguration.class, LockJedisAutoConfiguration.class))
                .run(context -> assertThat(context).hasFailed());
    }

    @Test
    void autoConfiguration_executorReceivesRetryIntervalFromProperties() {
        contextRunner
                .withPropertyValues("yeepay.framework.lock.retry-interval=250")
                .run(context -> {
                    YeepayLockProperties props = context.getBean(YeepayLockProperties.class);
                    assertThat(props.getRetryInterval()).isEqualTo(250L);
                    assertThat(context.getBean(LockExecutor.class)).isInstanceOf(JedisLockExecutor.class);
                });
    }

    @Configuration
    static class MockJedisAndPropertiesConfig {
        @Bean
        UnifiedJedis unifiedJedis() {
            return mock(UnifiedJedis.class);
        }
    }
}
