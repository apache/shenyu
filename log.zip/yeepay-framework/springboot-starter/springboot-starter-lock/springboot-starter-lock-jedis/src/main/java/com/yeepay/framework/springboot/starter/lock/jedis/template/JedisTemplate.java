package com.yeepay.framework.springboot.starter.lock.jedis.template;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.lock.jedis.JedisLock;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 基于 Jedis 的 {@link LockTemplate} 实现，供 {@code @YeepayLock} 切面使用.
 */
@Slf4j
@RequiredArgsConstructor
public class JedisTemplate implements LockTemplate {

    private final LockExecutor<JedisLock> lockExecutor;

    @SneakyThrows
    @Override
    public Object invoke(
            final ProceedingJoinPoint joinPoint,
            final LockFailureStrategy lockFailureStrategy,
            final ReleaseTimeoutStrategy releaseTimeoutStrategy,
            final LockEntity lockEntity) {
        JedisLock lock = null;
        try {
            lock = lockExecutor.tryLock(lockEntity);
            if (Objects.nonNull(lock)) {
                return joinPoint.proceed();
            }
            return lockFailureStrategy.execute(lockEntity, joinPoint);
        } finally {
            if (Objects.nonNull(lock) && lockEntity.isAutoRelease()) {
                boolean success = lockExecutor.unlock(lock);
                if (!success) {
                    releaseTimeoutStrategy.execute(lockEntity);
                }
            }
        }
    }
}
