package com.yeepay.framework.springboot.starter.lock.jedis;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.LockManager;
import com.yeepay.framework.lock.jedis.JedisLock;
import com.yeepay.framework.lock.jedis.JedisLockExecutor;
import com.yeepay.framework.springboot.starter.lock.LockAutoConfiguration;
import com.yeepay.framework.springboot.starter.lock.config.YeepayLockProperties;
import com.yeepay.framework.springboot.starter.lock.jedis.template.JedisTemplate;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import redis.clients.jedis.UnifiedJedis;

/**
 * Jedis 分布式锁自动配置.
 *
 * <p>单独依赖时自动激活；同时依赖 lock-redisson 时需设置 {@code yeepay.framework.lock.type=jedis}。
 * {@code yeepay.framework.lock.enabled=false} 时整体关闭。
 */
@AutoConfiguration(after = LockAutoConfiguration.class)
@ConditionalOnBean(LockAutoConfiguration.class)
@ConditionalOnProperty(name = YeepayLockProperties.PREFIX + ".type", havingValue = "jedis", matchIfMissing = true)
public class LockJedisAutoConfiguration {

    /**
     * 创建 Jedis 分布式锁执行器.
     *
     * @param jedisClient Jedis 客户端
     * @param props       锁专属配置
     * @return 锁执行器
     */
    @Bean
    public LockExecutor<JedisLock> lockExecutor(final UnifiedJedis jedisClient, final YeepayLockProperties props) {
        return new JedisLockExecutor(jedisClient, props.getRetryInterval());
    }

    /**
     * 创建分布式锁管理器.
     *
     * @param lockExecutor 锁执行器
     * @return 锁管理器
     */
    @Bean
    public LockManager lockManager(final LockExecutor<JedisLock> lockExecutor) {
        return new LockManager(lockExecutor);
    }

    /**
     * 创建 Jedis 锁模板，供切面调用.
     *
     * @param lockExecutor 锁执行器
     * @return 锁模板
     */
    @Bean
    public LockTemplate lockTemplate(final LockExecutor<JedisLock> lockExecutor) {
        return new JedisTemplate(lockExecutor);
    }
}
