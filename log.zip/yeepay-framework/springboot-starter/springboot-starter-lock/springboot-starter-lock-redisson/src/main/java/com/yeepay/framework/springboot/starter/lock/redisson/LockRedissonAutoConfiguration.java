package com.yeepay.framework.springboot.starter.lock.redisson;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.LockManager;
import com.yeepay.framework.lock.redission.RedissonLockExecutor;
import com.yeepay.framework.springboot.starter.lock.LockAutoConfiguration;
import com.yeepay.framework.springboot.starter.lock.config.YeepayLockProperties;
import com.yeepay.framework.springboot.starter.lock.redisson.template.RedissonTemplate;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/**
 * Lock-Redisson 自动配置.
 *
 * <p>单独依赖时自动激活；同时依赖 lock-jedis 时需设置 {@code yeepay.framework.lock.type=redisson}。
 * {@code yeepay.framework.lock.enabled=false} 时整体关闭。
 */
@AutoConfiguration(after = LockAutoConfiguration.class)
@ConditionalOnBean(LockAutoConfiguration.class)
@ConditionalOnProperty(name = YeepayLockProperties.PREFIX + ".type", havingValue = "redisson", matchIfMissing = true)
public class LockRedissonAutoConfiguration {

    /**
     * Lock executor for redisson .
     *
     * @param redissonClient the redisson client
     * @return the lock executor
     */
    @Bean
    public LockExecutor<RLock> lockExecutor(final ObjectProvider<RedissonClient> redissonClient) {
        return new RedissonLockExecutor(redissonClient.getIfAvailable());
    }

    /**
     * Lock manager.
     *
     * @param lockExecutor the lock executor
     * @return the lock manager
     */
    @Bean
    public LockManager lockManager(final LockExecutor<RLock> lockExecutor) {
        return new LockManager(lockExecutor);
    }

    /**
     * Lock template.
     *
     * @param lockExecutor the lock executor
     * @return the lock template
     */
    @Bean
    public LockTemplate lockTemplate(final LockExecutor<RLock> lockExecutor) {
        return new RedissonTemplate(lockExecutor);
    }
}
