package com.yeepay.framework.springboot.starter.lock.redisson.template;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.redisson.api.RLock;

/**
 * The type Redisson template.
 */
@RequiredArgsConstructor
@Slf4j
public class RedissonTemplate implements LockTemplate {

    private final LockExecutor<RLock> lockExecutor;

    @SneakyThrows
    @Override
    public Object invoke(
            final ProceedingJoinPoint joinPoint,
            final LockFailureStrategy lockFailureStrategy,
            final ReleaseTimeoutStrategy releaseTimeoutStrategy,
            final LockEntity lockEntity) {
        RLock lock = null;
        try {
            lock = lockExecutor.tryLock(lockEntity);
            if (Objects.nonNull(lock)) {
                return joinPoint.proceed();
            }
            return lockFailureStrategy.execute(lockEntity, joinPoint);
        } finally {
            if (Objects.nonNull(lock) && lockEntity.isAutoRelease()) {
                boolean success = lockExecutor.unlock(lock);
                if (!success) {
                    releaseTimeoutStrategy.execute(lockEntity);
                }
            }
        }
    }
}
