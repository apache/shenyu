package com.yeepay.framework.springboot.starter.lock.redisson;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.LockManager;
import com.yeepay.framework.lock.redission.RedissonLockExecutor;
import com.yeepay.framework.springboot.starter.lock.LockAutoConfiguration;
import com.yeepay.framework.springboot.starter.lock.redisson.template.RedissonTemplate;
import com.yeepay.framework.springboot.starter.lock.template.LockTemplate;
import org.junit.jupiter.api.Test;
import org.redisson.api.RedissonClient;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

class LockRedissonAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(LockAutoConfiguration.class, LockRedissonAutoConfiguration.class));

    @Test
    void autoConfiguration_wiresExecutorManagerAndTemplate_withClient() {
        RedissonClient redissonClient = mock(RedissonClient.class);
        contextRunner.withBean(RedissonClient.class, () -> redissonClient).run(context -> {
            assertThat(context).hasSingleBean(LockExecutor.class);
            assertThat(context).hasSingleBean(LockManager.class);
            assertThat(context).hasSingleBean(LockTemplate.class);

            assertThat(context.getBean(LockExecutor.class)).isInstanceOf(RedissonLockExecutor.class);
            assertThat(context.getBean(LockTemplate.class)).isInstanceOf(RedissonTemplate.class);
            assertThat(context.getBean(LockManager.class)).isInstanceOf(LockManager.class);
        });
    }

    @Test
    void autoConfiguration_stillCreatesBeans_whenClientMissing_dueToObjectProvider() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(LockExecutor.class);
            assertThat(context).hasSingleBean(LockManager.class);
            assertThat(context).hasSingleBean(LockTemplate.class);

            assertThat(context.getBean(LockExecutor.class)).isInstanceOf(RedissonLockExecutor.class);
        });
    }
}
