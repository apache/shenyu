package com.yeepay.framework.springboot.starter.lock.redisson.template;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.lock.api.LockExecutor;
import com.yeepay.framework.lock.api.entity.LockEntity;
import com.yeepay.framework.springboot.starter.lock.strategy.LockFailureStrategy;
import com.yeepay.framework.springboot.starter.lock.strategy.ReleaseTimeoutStrategy;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.redisson.api.RLock;

@ExtendWith(MockitoExtension.class)
class RedissonTemplateTest {

    @Mock
    private LockExecutor<RLock> lockExecutor;

    @Mock
    private LockFailureStrategy lockFailureStrategy;

    @Mock
    private ReleaseTimeoutStrategy releaseTimeoutStrategy;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @Mock
    private RLock mockLock;

    private RedissonTemplate template;

    @BeforeEach
    void setUp() {
        template = new RedissonTemplate(lockExecutor);
    }

    private LockEntity entity(boolean autoRelease) {
        return LockEntity.builder().keyName("k").autoRelease(autoRelease).build();
    }

    // ── lock acquired ───────────────────────────────────────────────────────

    @Test
    void invoke_lockAcquired_proceedsAndUnlocks() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        when(joinPoint.proceed()).thenReturn("result");
        when(lockExecutor.unlock(mockLock)).thenReturn(true);

        Object result = template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(true));
        assertThat(result).isEqualTo("result");
        verify(lockExecutor).unlock(mockLock);
        verify(releaseTimeoutStrategy, never()).execute(any());
    }

    @Test
    void invoke_lockAcquiredAutoReleaseFalse_doesNotUnlock() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        when(joinPoint.proceed()).thenReturn(null);

        template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(false));
        verify(lockExecutor, never()).unlock(any());
        verify(releaseTimeoutStrategy, never()).execute(any());
    }

    @Test
    void invoke_lockAcquiredUnlockFails_callsReleaseTimeoutStrategy() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        when(joinPoint.proceed()).thenReturn(null);
        when(lockExecutor.unlock(mockLock)).thenReturn(false);

        template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(true));
        verify(releaseTimeoutStrategy).execute(any());
    }

    @Test
    void invoke_lockAcquiredProceedReturnsNull_returnsNull() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        when(joinPoint.proceed()).thenReturn(null);
        when(lockExecutor.unlock(mockLock)).thenReturn(true);

        Object result = template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(true));
        assertThat(result).isNull();
    }

    // ── lock not acquired ───────────────────────────────────────────────────

    @Test
    void invoke_lockNotAcquired_callsFailureStrategy() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(null);
        when(lockFailureStrategy.execute(any(), any())).thenReturn("fallback");

        Object result = template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(true));
        assertThat(result).isEqualTo("fallback");
        verify(lockExecutor, never()).unlock(any());
        verify(joinPoint, never()).proceed();
    }

    // ── exception propagation (finally block exceptional path) ──────────────

    @Test
    void invoke_lockAcquiredProceedThrows_unlockSucceeds_exceptionPropagates() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        when(joinPoint.proceed()).thenThrow(new RuntimeException("boom"));
        when(lockExecutor.unlock(mockLock)).thenReturn(true);

        assertThatThrownBy(() -> template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(true)))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("boom");
        verify(lockExecutor).unlock(mockLock);
        verify(releaseTimeoutStrategy, never()).execute(any());
    }

    @Test
    void invoke_lockAcquiredProceedThrows_unlockFails_callsReleaseTimeoutAndExceptionPropagates() throws Throwable {
        when(lockExecutor.tryLock(any())).thenReturn(mockLock);
        when(joinPoint.proceed()).thenThrow(new RuntimeException("boom"));
        when(lockExecutor.unlock(mockLock)).thenReturn(false);

        assertThatThrownBy(() -> template.invoke(joinPoint, lockFailureStrategy, releaseTimeoutStrategy, entity(true)))
                .isInstanceOf(RuntimeException.class);
        verify(releaseTimeoutStrategy).execute(any());
    }
}
