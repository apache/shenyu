package com.yeepay.framework.springboot.starter.smartcache.config;

import com.yeepay.g3.utils.smartcache.enums.CacheTypeEnum;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Smart-Cache configuration properties.
 *
 * <p>Example (application.yml):
 * <pre>
 * yeepay:
 *  framework
 *   smart-cache:
 *     enabled: true
 *     app-name: myapp
 *     l1-cache-type: EHCACHE
 *     l2-cache-type: REDIS
 *     redis:
 *       mode: standalone
 *       sentinels: 127.0.0.1:6379
 *       max-total: 30
 *     zookeeper:
 *       servers: 127.0.0.1:2181
 * </pre>
 */
@Data
@ConfigurationProperties(prefix = YeepaySmartCacheProperties.PREFIX)
public class YeepaySmartCacheProperties {

    public static final String PREFIX = "yeepay.framework.smart-cache";

    /** Enable smart-cache auto-configuration. */
    private boolean enabled = true;

    /** Application name for cache key prefix. */
    private String appName = "defaultApp";

    /** Default cache group. */
    private String group = "defaultGroup";

    /** Level 1 cache type (EHCACHE or REDIS). */
    private CacheTypeEnum l1CacheType;

    /** Level 2 cache type (EHCACHE or REDIS), optional. */
    private CacheTypeEnum l2CacheType;

    /** Redis configuration. */
    private Redis redis = new Redis();

    /** Zookeeper configuration. */
    private Zookeeper zookeeper = new Zookeeper();

    /**
     * Redis connection configuration.
     */
    @Data
    public static class Redis {

        /** Connection mode: standalone, sentinel, cluster, or codis. */
        private String mode;

        /** Comma-separated list of host:port pairs. */
        private String sentinels;

        /** Sentinel master name (required for sentinel mode). */
        private String masterName;

        /** Maximum total connections in the pool. */
        private int maxTotal = 30;

        /** Maximum idle connections in the pool. */
        private int maxIdle = 30;

        /** Maximum wait time in milliseconds for a connection. */
        private int maxWaitMillis = 100;

        /** Connection timeout in milliseconds. */
        private int timeout = 2000;

        /** AES-encrypted password. */
        private String password;

        /** Maximum consecutive failures before circuit breaker opens. */
        private int maxFailCount = -1;

        /** Slow log threshold for connection acquisition (ms). */
        private int connectSlowLogTime = 40;

        /** Slow log threshold for command execution (ms). */
        private int handleSlowLogTime = 40;

        /** Whether the Redis server is a newer version. */
        private boolean newVersion;
    }

    /**
     * Zookeeper connection configuration.
     */
    @Data
    public static class Zookeeper {

        /** Zookeeper server addresses. */
        private String servers;

        /** Session timeout in milliseconds. */
        private int sessionTimeout = 30000;

        /** Connection timeout in milliseconds. */
        private int connectionTimeout = 20000;
    }
}
