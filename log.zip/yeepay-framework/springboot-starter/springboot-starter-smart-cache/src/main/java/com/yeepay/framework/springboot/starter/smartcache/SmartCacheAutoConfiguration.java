package com.yeepay.framework.springboot.starter.smartcache;

import com.yeepay.framework.springboot.starter.smartcache.config.YeepaySmartCacheProperties;
import com.yeepay.g3.utils.smartcache.SmartCacheInterceptor;
import com.yeepay.g3.utils.smartcache.SmartCacheManager;
import com.yeepay.g3.utils.smartcache.annotation.SmartCache;
import com.yeepay.g3.utils.smartcache.config.RedisConfig;
import com.yeepay.g3.utils.smartcache.config.SmartCacheConfig;
import com.yeepay.g3.utils.smartcache.config.ZkConfig;
import com.yeepay.g3.utils.smartcache.utils.RedisClientUtils;
import com.yeepay.g3.utils.smartcache.utils.ZkClientUtils;
import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.Advisor;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Smart-Cache auto-configuration.
 *
 * <p>Auto-registers {@link SmartCacheInterceptor} and AOP Advisor,
 * making {@link SmartCache @SmartCache} annotation work.
 *
 * <p>Disabled via {@code yeepay.smart-cache.enabled=false}.
 */
@AutoConfiguration
@EnableConfigurationProperties(YeepaySmartCacheProperties.class)
@ConditionalOnProperty(
        prefix = YeepaySmartCacheProperties.PREFIX,
        name = "enabled",
        havingValue = "true",
        matchIfMissing = true)
public class SmartCacheAutoConfiguration {

    /**
     * Build SmartCacheConfig from YAML properties.
     *
     * @param properties the bound YAML properties
     * @return SmartCacheConfig for initializing cache components
     */
    @Bean
    public SmartCacheConfig smartCacheConfig(YeepaySmartCacheProperties properties) {
        SmartCacheConfig config = new SmartCacheConfig();
        config.setAppName(properties.getAppName());
        config.setGroup(properties.getGroup());
        config.setL1CacheType(properties.getL1CacheType());
        config.setL2CacheType(properties.getL2CacheType());

        YeepaySmartCacheProperties.Redis r = properties.getRedis();
        if (StringUtils.isNotBlank(r.getSentinels())) {
            RedisConfig redisConfig = new RedisConfig();
            redisConfig.setMode(r.getMode());
            redisConfig.setSentinels(r.getSentinels());
            redisConfig.setMasterName(r.getMasterName());
            redisConfig.setMaxTotal(r.getMaxTotal());
            redisConfig.setMaxIdle(r.getMaxIdle());
            redisConfig.setMaxWaitMillis(r.getMaxWaitMillis());
            redisConfig.setTimeout(r.getTimeout());
            redisConfig.setPassword(r.getPassword());
            redisConfig.setMaxFailCount(r.getMaxFailCount());
            redisConfig.setConnectSlowLogTime(r.getConnectSlowLogTime());
            redisConfig.setHandleSlowLogTime(r.getHandleSlowLogTime());
            redisConfig.setNewVersion(r.isNewVersion());
            config.setRedis(redisConfig);
        }

        YeepaySmartCacheProperties.Zookeeper z = properties.getZookeeper();
        if (StringUtils.isNotBlank(z.getServers())) {
            ZkConfig zkConfig = new ZkConfig();
            zkConfig.setServers(z.getServers());
            zkConfig.setSessionTimeout(z.getSessionTimeout());
            zkConfig.setConnectionTimeout(z.getConnectionTimeout());
            config.setZookeeper(zkConfig);
        }

        return config;
    }

    /**
     * Initialize SmartCacheManager singleton.
     *
     * @param config the smart-cache configuration
     * @return the singleton SmartCacheManager instance
     */
    @Bean
    public SmartCacheManager smartCacheManager(SmartCacheConfig config) {
        if (Objects.nonNull(config.getRedis())) {
            RedisClientUtils.init(config.getRedis());
        }
        if (Objects.nonNull(config.getZookeeper())) {
            ZkClientUtils.init(config.getZookeeper());
        }
        SmartCacheManager manager = SmartCacheManager.getInstance();
        manager.init(config);
        return manager;
    }

    /**
     * Create SmartCacheInterceptor with injected cache manager.
     *
     * @return the interceptor bean
     */
    @Bean
    public SmartCacheInterceptor smartCacheInterceptor() {
        return new SmartCacheInterceptor();
    }

    /**
     * Register AOP advisor for @SmartCache methods.
     *
     * @param smartCacheInterceptor the interceptor
     * @return the AOP advisor
     */
    @Bean
    public Advisor smartCacheAdvisor(SmartCacheInterceptor smartCacheInterceptor) {
        AnnotationMatchingPointcut pointcut = new AnnotationMatchingPointcut(null, SmartCache.class);
        return new DefaultPointcutAdvisor(pointcut, smartCacheInterceptor);
    }
}
