package com.yeepay.framework.springboot.starter.global.id.redis;

import com.yeepay.framework.global.id.api.UidGenerator;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.core.UidGeneratorFactory;
import com.yeepay.framework.global.id.redis.RedisWorkerIdAssigner;
import com.yeepay.framework.global.id.redis.config.RedisWorkerIdConfig;
import com.yeepay.framework.springboot.starter.global.id.redis.condition.OnRedisGlobalIdConfigured;
import com.yeepay.framework.springboot.starter.global.id.redis.config.RedisGlobalIdConfig;
import com.yeepay.framework.springboot.starter.infra.redisson.InfraRedissonAutoConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;

/**
 * Redis 方式全局 ID 自动配置（<b>推荐方案</b>）.
 *
 * <p>当配置文件中存在 {@value RedisGlobalIdConfig#PREFIX} 前缀的属性，
 * 且容器中有 {@link RedissonClient} Bean 时自动激活.
 *
 * <p>相比 Database 和 ZooKeeper 方案，Redis 在万级节点规模下综合表现最优：
 * 分配与心跳均为微秒级，无全量扫描开销，且大多数基础设施已具备 Redis 集群.
 */
@Slf4j
@AutoConfiguration(after = InfraRedissonAutoConfiguration.class)
@Conditional(OnRedisGlobalIdConfigured.class)
@EnableConfigurationProperties({RedisGlobalIdConfig.class})
public class YeepayRedisGlobalIdAutoConfiguration {

    @Value("${spring.application.name:}")
    private String applicationName;

    /**
     * 创建 UID 生成器.
     *
     * @param globalIdConfig   全局 ID 配置
     * @param workerIdAssigner workerId 分配器
     * @return UID 生成器
     */
    @Bean
    public UidGenerator uidGenerator(
            RedisGlobalIdConfig globalIdConfig, WorkerIdAssigner<RedisWorkerIdConfig> workerIdAssigner) {
        GlobalIdConfig global = globalIdConfig.getGlobal();
        global.setWorkerName(resolveWorkName(global.getWorkerName()));
        return UidGeneratorFactory.create(global, workerIdAssigner);
    }

    /**
     * 创建 Redis workerId 分配器.
     *
     * @param globalIdConfig 全局 ID 配置
     * @param redissonClient Redisson 客户端
     * @return workerId 分配器
     */
    @Bean(destroyMethod = "close")
    public WorkerIdAssigner<RedisWorkerIdConfig> redisWorkerIdAssigner(
            RedisGlobalIdConfig globalIdConfig, final ObjectProvider<RedissonClient> redissonClient) {
        RedisWorkerIdAssigner assigner = new RedisWorkerIdAssigner(redissonClient.getIfAvailable());
        assigner.init(globalIdConfig.getConfig());
        return assigner;
    }

    private String resolveWorkName(String workName) {
        if (StringUtils.isNotBlank(workName)) {
            return workName;
        }
        if (StringUtils.isBlank(applicationName)) {
            throw new IllegalStateException("global-id workName 未配置: 请设置 " + RedisGlobalIdConfig.PREFIX
                    + ".global.worker-name 或 spring.application.name");
        }
        log.info("global-id workName 使用 spring.application.name 默认值: {}", applicationName);
        return applicationName;
    }
}
