package com.yeepay.framework.springboot.starter.global.id.redis.config;

import static com.yeepay.framework.springboot.starter.global.id.redis.config.RedisGlobalIdConfig.PREFIX;

import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.redis.config.RedisWorkerIdConfig;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * Redis 方式全局 ID 的 Spring Boot 配置属性.
 * <b>推荐方案</b>：万级节点规模下综合性能最优，优先选用.
 */
@Data
@ConfigurationProperties(prefix = PREFIX)
public class RedisGlobalIdConfig {

    public static final String PREFIX = "yeepay.framework.global-id.redis";

    @NestedConfigurationProperty
    private GlobalIdConfig global = new GlobalIdConfig();

    @NestedConfigurationProperty
    private RedisWorkerIdConfig config = new RedisWorkerIdConfig();
}
