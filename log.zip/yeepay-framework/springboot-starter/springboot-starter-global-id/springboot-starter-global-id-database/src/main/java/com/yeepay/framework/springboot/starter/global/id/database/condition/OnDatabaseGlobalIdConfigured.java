package com.yeepay.framework.springboot.starter.global.id.database.condition;

import com.yeepay.framework.springboot.starter.global.id.database.config.DatabaseGlobalIdConfig;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * 当配置文件中存在 {@value DatabaseGlobalIdConfig#PREFIX} 前缀的属性时匹配.
 */
public class OnDatabaseGlobalIdConfigured implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        return Binder.get(context.getEnvironment())
                .bind(DatabaseGlobalIdConfig.PREFIX, Bindable.mapOf(String.class, Object.class))
                .isBound();
    }
}
