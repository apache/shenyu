package com.yeepay.framework.springboot.starter.global.id.database;

import com.yeepay.framework.global.id.api.UidGenerator;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.core.UidGeneratorFactory;
import com.yeepay.framework.global.id.database.DatabaseWorkerIdAssigner;
import com.yeepay.framework.global.id.database.config.DatabaseConfig;
import com.yeepay.framework.springboot.starter.global.id.database.condition.OnDatabaseGlobalIdConfigured;
import com.yeepay.framework.springboot.starter.global.id.database.config.DatabaseGlobalIdConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;

/**
 * Database 方式全局 ID 自动配置.
 *
 * <p>当配置文件中存在 {@value DatabaseGlobalIdConfig#PREFIX} 前缀的属性时自动激活.
 */
@Slf4j
@AutoConfiguration
@Conditional(OnDatabaseGlobalIdConfigured.class)
@EnableConfigurationProperties({DatabaseGlobalIdConfig.class})
public class YeepayDatabaseGlobalIdAutoConfiguration {

    @Value("${spring.application.name:}")
    private String applicationName;

    /**
     * Uid generator.
     *
     * @param globalIdConfig   the global id config
     * @param workerIdAssigner the worker id assigner
     * @return the uid generator
     */
    @Bean
    @ConditionalOnMissingBean(UidGenerator.class)
    public UidGenerator uidGenerator(
            DatabaseGlobalIdConfig globalIdConfig, WorkerIdAssigner<DatabaseConfig> workerIdAssigner) {
        GlobalIdConfig global = globalIdConfig.getGlobal();
        global.setWorkerName(resolveWorkName(global.getWorkerName()));
        return UidGeneratorFactory.create(global, workerIdAssigner);
    }

    /**
     * Database worker id assigner. Spring 容器关闭时通过 destroyMethod=close 触发资源释放
     * （停心跳 + 关连接池）.
     *
     * @param globalIdConfig the global id config
     * @return the worker id assigner
     */
    @Bean(destroyMethod = "close")
    public WorkerIdAssigner<DatabaseConfig> databaseWorkerIdAssigner(DatabaseGlobalIdConfig globalIdConfig) {
        WorkerIdAssigner<DatabaseConfig> workerIdAssigner = new DatabaseWorkerIdAssigner();
        workerIdAssigner.init(globalIdConfig.getConfig());
        return workerIdAssigner;
    }

    private String resolveWorkName(String workName) {
        if (StringUtils.isNotBlank(workName)) {
            return workName;
        }
        if (StringUtils.isBlank(applicationName)) {
            throw new IllegalStateException("global-id workName 未配置: 请设置 " + DatabaseGlobalIdConfig.PREFIX
                    + ".global.worker-name 或 spring.application.name");
        }
        log.info("global-id workName 使用 spring.application.name 默认值: {}", applicationName);
        return applicationName;
    }
}
