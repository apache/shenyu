package com.yeepay.framework.springboot.starter.global.id.database.config;

import static com.yeepay.framework.springboot.starter.global.id.database.config.DatabaseGlobalIdConfig.PREFIX;

import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.database.config.DatabaseConfig;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * Database 方式全局 ID 的 Spring Boot 配置属性.
 */
@Data
@ConfigurationProperties(prefix = PREFIX)
public class DatabaseGlobalIdConfig {

    public static final String PREFIX = "yeepay.framework.global-id.database";

    @NestedConfigurationProperty
    private GlobalIdConfig global = new GlobalIdConfig();

    @NestedConfigurationProperty
    private DatabaseConfig config = new DatabaseConfig();
}
