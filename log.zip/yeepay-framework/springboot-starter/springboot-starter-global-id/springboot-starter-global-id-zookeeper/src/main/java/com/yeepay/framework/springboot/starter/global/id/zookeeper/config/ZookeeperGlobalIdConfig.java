package com.yeepay.framework.springboot.starter.global.id.zookeeper.config;

import static com.yeepay.framework.springboot.starter.global.id.zookeeper.config.ZookeeperGlobalIdConfig.PREFIX;

import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.zookeeper.config.ZookeeperConfig;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * ZooKeeper 方式全局 ID 的 Spring Boot 配置属性.
 */
@Data
@ConfigurationProperties(prefix = PREFIX)
public class ZookeeperGlobalIdConfig {

    public static final String PREFIX = "yeepay.framework.global-id.zookeeper";

    @NestedConfigurationProperty
    private GlobalIdConfig global = new GlobalIdConfig();

    @NestedConfigurationProperty
    private ZookeeperConfig config = new ZookeeperConfig();
}
