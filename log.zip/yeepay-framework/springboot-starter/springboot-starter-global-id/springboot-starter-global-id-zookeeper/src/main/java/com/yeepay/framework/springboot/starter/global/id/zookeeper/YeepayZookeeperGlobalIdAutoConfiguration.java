package com.yeepay.framework.springboot.starter.global.id.zookeeper;

import com.yeepay.framework.global.id.api.UidGenerator;
import com.yeepay.framework.global.id.api.WorkerIdAssigner;
import com.yeepay.framework.global.id.api.config.GlobalIdConfig;
import com.yeepay.framework.global.id.core.UidGeneratorFactory;
import com.yeepay.framework.global.id.zookeeper.ZookeeperWorkerIdAssigner;
import com.yeepay.framework.global.id.zookeeper.config.ZookeeperConfig;
import com.yeepay.framework.springboot.starter.global.id.zookeeper.condition.OnZookeeperGlobalIdConfigured;
import com.yeepay.framework.springboot.starter.global.id.zookeeper.config.ZookeeperGlobalIdConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;

/**
 * ZooKeeper 方式全局 ID 自动配置.
 *
 * <p>当配置文件中存在 {@value ZookeeperGlobalIdConfig#PREFIX} 前缀的属性时自动激活.
 */
@Slf4j
@AutoConfiguration
@Conditional(OnZookeeperGlobalIdConfigured.class)
@EnableConfigurationProperties({ZookeeperGlobalIdConfig.class})
public class YeepayZookeeperGlobalIdAutoConfiguration {

    @Value("${spring.application.name:}")
    private String applicationName;

    /**
     * 创建 UID 生成器.
     *
     * @param globalIdConfig   全局 ID 配置
     * @param workerIdAssigner workerId 分配器
     * @return UID 生成器
     */
    @Bean
    @ConditionalOnMissingBean(UidGenerator.class)
    public UidGenerator uidGenerator(
            ZookeeperGlobalIdConfig globalIdConfig, WorkerIdAssigner<ZookeeperConfig> workerIdAssigner) {
        GlobalIdConfig global = globalIdConfig.getGlobal();
        global.setWorkerName(resolveWorkName(global.getWorkerName()));
        return UidGeneratorFactory.create(global, workerIdAssigner);
    }

    /**
     * 创建 ZooKeeper workerId 分配器.
     *
     * @param globalIdConfig 全局 ID 配置
     * @return workerId 分配器
     */
    @Bean(destroyMethod = "close")
    public WorkerIdAssigner<ZookeeperConfig> zookeeperWorkerIdAssigner(ZookeeperGlobalIdConfig globalIdConfig) {
        ZookeeperWorkerIdAssigner assigner = new ZookeeperWorkerIdAssigner();
        assigner.init(globalIdConfig.getConfig());
        return assigner;
    }

    private String resolveWorkName(String workName) {
        if (StringUtils.isNotBlank(workName)) {
            return workName;
        }
        if (StringUtils.isBlank(applicationName)) {
            throw new IllegalStateException("global-id workName 未配置: 请设置 " + ZookeeperGlobalIdConfig.PREFIX
                    + ".global.worker-name 或 spring.application.name");
        }
        log.info("global-id workName 使用 spring.application.name 默认值: {}", applicationName);
        return applicationName;
    }
}
