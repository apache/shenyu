package com.yeepay.framework.springboot.starter.application.config;

import lombok.Data;

/**
 * The type Application info.
 */
@Data
public class ApplicationInfo {

    private String name;

    private String env;
}
