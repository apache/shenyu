package com.yeepay.framework.springboot.starter.application;

import com.yeepay.framework.springboot.starter.application.config.ApplicationInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.util.StringUtils;

/**
 * The type Application info auto configuration.
 */
@Slf4j
@AutoConfiguration
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ApplicationAutoConfiguration {

    private static final String BEAN_NAME = "applicationInfo";

    private static final String APP_NAME_KEY = "appname";

    private static final String DEPLOY_ENV_KEY = "deploy_env";

    @Value("${spring.application.name:}")
    private String appName;

    @Value("${spring.profiles.active:}")
    private String envName;

    /**
     * Default application info.
     *
     * @return the application info
     */
    @Bean(BEAN_NAME)
    @ConditionalOnMissingBean({ApplicationInfo.class})
    public ApplicationInfo defaultApplicationInfo() {
        ApplicationInfo applicationInfo = new ApplicationInfo();
        applicationInfo.setName(resolveProperty(APP_NAME_KEY, this.appName));
        applicationInfo.setEnv(resolveProperty(DEPLOY_ENV_KEY, this.envName));
        return applicationInfo;
    }

    private static String resolveProperty(String key, String fallback) {
        String value = System.getenv(key);
        if (!StringUtils.hasText(value)) {
            value = System.getProperty(key);
        }
        if (!StringUtils.hasText(value)) {
            value = fallback;
        }
        return value;
    }
}
