package com.yeepay.framework.springboot.starter.application;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * The type Htx spring application.
 */
@Slf4j
public class YeepaySpringApplication {

    /**
     * Run configurable application context.
     *
     * @param springApplicationBuilder the spring application builder
     * @param args                     the args
     * @return the configurable application context
     */
    public static ConfigurableApplicationContext run(SpringApplicationBuilder springApplicationBuilder, String[] args) {
        try {
            log.info("Application begin run...");
            String[] keys = {"java.version", "java.vendor.version"};
            for (String key : keys) {
                log.info("{} : {}", key, System.getProperty(key));
            }
            ConfigurableApplicationContext context = springApplicationBuilder.run(args);
            log.info("Application started successfully...");
            return context;
        } catch (Throwable e) {
            log.error("Application startup failed error, error = {}", e.getMessage(), e);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ignored) {

            }
        }
        return null;
    }
}
