package com.yeepay.framework.springboot.starter.disruptor;

import com.yeepay.framework.disruptor.collector.DisruptorMetricsCollector;
import com.yeepay.framework.disruptor.config.DisruptorProperties;
import com.yeepay.framework.disruptor.consumer.CommonConsumerExecutorFactory;
import com.yeepay.framework.disruptor.consumer.QueueConsumerFactory;
import com.yeepay.framework.disruptor.publish.DisruptorPublisher;
import com.yeepay.framework.disruptor.subsriber.ExecutorSubscriber;
import com.yeepay.framework.disruptor.thread.CommonThreadSelectionFactory;
import com.yeepay.framework.disruptor.thread.ThreadSelectionFactory;
import com.yeepay.framework.disruptor.thread.ThreadSelectionStrategy;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * The type Disruptor configuration.
 */
@AutoConfiguration
@ConditionalOnProperty(name = DisruptorProperties.PREFIX + ".enabled", matchIfMissing = true, havingValue = "true")
public class DisruptorAutoConfiguration {

    /**
     * Disruptor properties.
     *
     * @return the disruptor properties
     */
    @Bean
    @ConfigurationProperties(prefix = DisruptorProperties.PREFIX)
    public DisruptorProperties disruptorProperties() {
        return new DisruptorProperties();
    }

    /**
     * Queue consumer factory queue consumer factory.
     *
     * @param <T> the type parameter
     * @return the queue consumer factory
     */
    @Bean
    @ConditionalOnMissingBean(QueueConsumerFactory.class)
    public <T> QueueConsumerFactory<T> queueConsumerFactory() {
        return new CommonConsumerExecutorFactory<>();
    }

    /**
     * Thread selection factory thread selection factory.
     *
     * @param <T> the type parameter
     * @param strategyProvider the strategy provider
     * @return the thread selection factory
     */
    @Bean
    @ConditionalOnMissingBean(ThreadSelectionFactory.class)
    public <T> ThreadSelectionFactory<T> threadSelectionFactory(
            ObjectProvider<List<ThreadSelectionStrategy<T>>> strategyProvider) {
        return new CommonThreadSelectionFactory<>(strategyProvider.getIfAvailable(ArrayList::new));
    }

    /**
     * Disruptor publisher.
     *
     * @param <T> the type parameter
     * @param factory the factory
     * @param subscriberList the subscriber list
     * @param config the disruptor config
     * @param meterRegistry the meter registry
     * @param selectionFactory the selection factory
     * @return the disruptor publisher
     */
    @Bean(destroyMethod = "destroy")
    public <T> DisruptorPublisher<T> disruptorPublisher(
            final QueueConsumerFactory<T> factory,
            final ObjectProvider<List<ExecutorSubscriber<T>>> subscriberList,
            final DisruptorProperties config,
            final ObjectProvider<MeterRegistry> meterRegistry,
            final ThreadSelectionFactory<T> selectionFactory) {
        if (config.isMonitor() && Objects.nonNull(meterRegistry.getIfAvailable())) {
            DisruptorMetricsCollector.getInstance().init(meterRegistry.getIfAvailable());
        }
        return new DisruptorPublisher<>(
                factory, selectionFactory, subscriberList.getIfAvailable(ArrayList::new), config);
    }
}
