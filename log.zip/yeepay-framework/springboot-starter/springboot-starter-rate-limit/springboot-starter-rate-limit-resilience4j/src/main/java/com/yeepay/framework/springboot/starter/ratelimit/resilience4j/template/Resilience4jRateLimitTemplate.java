package com.yeepay.framework.springboot.starter.ratelimit.resilience4j.template;

import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 基于 Resilience4j 的 {@link RateLimitTemplate} 实现.
 */
@RequiredArgsConstructor
public class Resilience4jRateLimitTemplate implements RateLimitTemplate {

    private final YeepayRateLimiter rateLimiter;

    @SneakyThrows
    @Override
    public Object invoke(
            final ProceedingJoinPoint joinPoint,
            final RateLimitFailureStrategy failureStrategy,
            final RateLimitEntity entity) {
        RateLimitResult result = rateLimiter.isAllowed(entity);
        if (result.isAllowed()) {
            try {
                return joinPoint.proceed();
            } finally {
                rateLimiter.release(entity);
            }
        }
        return failureStrategy.execute(entity.getKey(), result, joinPoint);
    }
}
