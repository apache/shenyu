package com.yeepay.framework.springboot.starter.ratelimit.resilience4j;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.resilience4j.Resilience4jRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.config.YeepayRateLimitProperties;
import com.yeepay.framework.springboot.starter.ratelimit.resilience4j.template.Resilience4jRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/**
 * Resilience4j 限流自动配置.
 *
 * <p>单独依赖时自动激活；同时依赖其他实现时需设置 {@code yeepay.framework.rate-limit.type=resilience4j}。
 */
@AutoConfiguration(after = RateLimitAutoConfiguration.class)
@ConditionalOnBean(RateLimitAutoConfiguration.class)
@ConditionalOnProperty(
        name = YeepayRateLimitProperties.PREFIX + ".type",
        havingValue = "resilience4j",
        matchIfMissing = true)
public class RateLimitResilience4jAutoConfiguration {

    /**
     * 创建 Resilience4j 限流器.
     *
     * @return the yeepay rate limiter
     */
    @Bean
    public Resilience4jRateLimiter yeepayRateLimiter() {
        return new Resilience4jRateLimiter();
    }

    /**
     * 创建限流管理器.
     *
     * @param rateLimiter the rate limiter
     * @return the rate limiter manager
     */
    @Bean
    public RateLimiterManager rateLimiterManager(final YeepayRateLimiter rateLimiter) {
        return new RateLimiterManager(rateLimiter);
    }

    /**
     * 创建 Resilience4j 限流模板.
     *
     * @param rateLimiter the rate limiter
     * @return the rate limit template
     */
    @Bean
    public RateLimitTemplate rateLimitTemplate(final YeepayRateLimiter rateLimiter) {
        return new Resilience4jRateLimitTemplate(rateLimiter);
    }
}
