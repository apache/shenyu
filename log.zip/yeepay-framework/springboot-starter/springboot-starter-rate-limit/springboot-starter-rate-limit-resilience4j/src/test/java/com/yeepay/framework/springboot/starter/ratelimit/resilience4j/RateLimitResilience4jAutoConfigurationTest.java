package com.yeepay.framework.springboot.starter.ratelimit.resilience4j;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.resilience4j.Resilience4jRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.resilience4j.template.Resilience4jRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

class RateLimitResilience4jAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(
                    RateLimitAutoConfiguration.class, RateLimitResilience4jAutoConfiguration.class));

    @Test
    void autoConfiguration_wiresRateLimiterManagerAndTemplate() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimiter.class);
            assertThat(context).hasSingleBean(RateLimiterManager.class);
            assertThat(context).hasSingleBean(RateLimitTemplate.class);

            assertThat(context.getBean(YeepayRateLimiter.class)).isInstanceOf(Resilience4jRateLimiter.class);
            assertThat(context.getBean(RateLimitTemplate.class)).isInstanceOf(Resilience4jRateLimitTemplate.class);
        });
    }

    @Test
    void autoConfiguration_activeByDefault_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(RateLimitResilience4jAutoConfiguration.class);
        });
    }

    @Test
    void autoConfiguration_activeWhenTypeResilience4j() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=resilience4j")
                .run(context -> {
                    assertThat(context).hasSingleBean(RateLimitResilience4jAutoConfiguration.class);
                    assertThat(context).hasSingleBean(YeepayRateLimiter.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenTypeGuava() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=guava")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitResilience4jAutoConfiguration.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenRateLimitDisabled() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitResilience4jAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(YeepayRateLimiter.class);
                });
    }
}
