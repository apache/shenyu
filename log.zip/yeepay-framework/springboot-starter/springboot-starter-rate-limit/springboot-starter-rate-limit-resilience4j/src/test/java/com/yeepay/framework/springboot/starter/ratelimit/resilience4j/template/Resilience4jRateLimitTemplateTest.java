package com.yeepay.framework.springboot.starter.ratelimit.resilience4j.template;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import java.util.List;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class Resilience4jRateLimitTemplateTest {

    @Mock
    private YeepayRateLimiter rateLimiter;

    @Mock
    private RateLimitFailureStrategy failureStrategy;

    @Mock
    private ProceedingJoinPoint joinPoint;

    private Resilience4jRateLimitTemplate template;

    @BeforeEach
    void setUp() {
        template = new Resilience4jRateLimitTemplate(rateLimiter);
    }

    private RateLimitEntity entity() {
        return RateLimitEntity.builder().key("test-key").build();
    }

    private RateLimitEntity concurrentEntity() {
        return RateLimitEntity.builder()
                .key("test-key")
                .algorithm(RateLimitAlgorithm.CONCURRENT_REQUEST)
                .build();
    }

    @Test
    void invoke_allowed_proceedsAndReturnsResult() throws Throwable {
        RateLimitResult result = new RateLimitResult(true, 10L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(joinPoint.proceed()).thenReturn("success");

        Object actual = template.invoke(joinPoint, failureStrategy, entity());

        assertThat(actual).isEqualTo("success");
        verify(joinPoint).proceed();
        verify(failureStrategy, never()).execute(any(), any(), any());
    }

    @Test
    void invoke_notAllowed_callsFailureStrategy() throws Throwable {
        RateLimitResult result = new RateLimitResult(false, 0L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(failureStrategy.execute(any(), any(), any())).thenReturn("fallback");

        Object actual = template.invoke(joinPoint, failureStrategy, entity());

        assertThat(actual).isEqualTo("fallback");
        verify(joinPoint, never()).proceed();
        verify(failureStrategy).execute("test-key", result, joinPoint);
    }

    @Test
    void invoke_allowed_returnsNull_whenProceedReturnsNull() throws Throwable {
        RateLimitResult result = new RateLimitResult(true, 5L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(joinPoint.proceed()).thenReturn(null);

        Object actual = template.invoke(joinPoint, failureStrategy, entity());

        assertThat(actual).isNull();
    }

    @Test
    void invoke_allowed_propagatesException() throws Throwable {
        RateLimitResult result = new RateLimitResult(true, 5L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(joinPoint.proceed()).thenThrow(new RuntimeException("boom"));

        assertThatThrownBy(() -> template.invoke(joinPoint, failureStrategy, entity()))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("boom");
    }

    @Test
    void invoke_allowed_callsReleaseAfterProceed() throws Throwable {
        RateLimitEntity entity = entity();
        RateLimitResult result = new RateLimitResult(true, 10L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(joinPoint.proceed()).thenReturn("done");

        template.invoke(joinPoint, failureStrategy, entity);

        verify(rateLimiter).release(entity);
    }

    @Test
    void invoke_allowed_callsReleaseEvenOnException() throws Throwable {
        RateLimitEntity entity = concurrentEntity();
        RateLimitResult result = new RateLimitResult(true, 2L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(joinPoint.proceed()).thenThrow(new RuntimeException("error"));

        assertThatThrownBy(() -> template.invoke(joinPoint, failureStrategy, entity))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("error");
        verify(rateLimiter).release(entity);
    }

    @Test
    void invoke_notAllowed_doesNotCallRelease() throws Throwable {
        RateLimitEntity entity = concurrentEntity();
        RateLimitResult result = new RateLimitResult(false, 0L, List.of("test-key"));
        when(rateLimiter.isAllowed(any())).thenReturn(result);
        when(failureStrategy.execute(any(), any(), any())).thenReturn("limited");

        template.invoke(joinPoint, failureStrategy, entity);

        verify(rateLimiter, never()).release(any());
    }
}
