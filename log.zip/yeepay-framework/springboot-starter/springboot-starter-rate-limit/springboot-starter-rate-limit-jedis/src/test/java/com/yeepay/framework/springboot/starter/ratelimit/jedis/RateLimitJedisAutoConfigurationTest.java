package com.yeepay.framework.springboot.starter.ratelimit.jedis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.jedis.JedisRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.jedis.template.JedisRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import redis.clients.jedis.UnifiedJedis;

class RateLimitJedisAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(
                    AutoConfigurations.of(RateLimitAutoConfiguration.class, RateLimitJedisAutoConfiguration.class));

    @Test
    void autoConfiguration_wiresRateLimiterManagerAndTemplate_withClient() {
        UnifiedJedis jedisClient = mock(UnifiedJedis.class);
        contextRunner.withBean(UnifiedJedis.class, () -> jedisClient).run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimiter.class);
            assertThat(context).hasSingleBean(RateLimiterManager.class);
            assertThat(context).hasSingleBean(RateLimitTemplate.class);

            assertThat(context.getBean(YeepayRateLimiter.class)).isInstanceOf(JedisRateLimiter.class);
            assertThat(context.getBean(RateLimitTemplate.class)).isInstanceOf(JedisRateLimitTemplate.class);
        });
    }

    @Test
    void autoConfiguration_stillCreatesBeans_whenClientMissing_dueToObjectProvider() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimiter.class);
            assertThat(context).hasSingleBean(RateLimiterManager.class);
            assertThat(context).hasSingleBean(RateLimitTemplate.class);

            assertThat(context.getBean(YeepayRateLimiter.class)).isInstanceOf(JedisRateLimiter.class);
        });
    }

    @Test
    void autoConfiguration_activeByDefault_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(RateLimitJedisAutoConfiguration.class);
        });
    }

    @Test
    void autoConfiguration_activeWhenTypeJedis() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=jedis")
                .run(context -> {
                    assertThat(context).hasSingleBean(RateLimitJedisAutoConfiguration.class);
                    assertThat(context).hasSingleBean(YeepayRateLimiter.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenTypeGuava() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=guava")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitJedisAutoConfiguration.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenRateLimitDisabled() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitJedisAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(YeepayRateLimiter.class);
                });
    }
}
