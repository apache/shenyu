package com.yeepay.framework.springboot.starter.ratelimit.jedis;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.jedis.JedisRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.config.YeepayRateLimitProperties;
import com.yeepay.framework.springboot.starter.ratelimit.jedis.template.JedisRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import redis.clients.jedis.UnifiedJedis;

/**
 * Jedis 限流自动配置.
 *
 * <p>单独依赖时自动激活；同时依赖其他实现时需设置 {@code yeepay.framework.rate-limit.type=jedis}。
 */
@AutoConfiguration(after = RateLimitAutoConfiguration.class)
@ConditionalOnBean(RateLimitAutoConfiguration.class)
@ConditionalOnProperty(name = YeepayRateLimitProperties.PREFIX + ".type", havingValue = "jedis", matchIfMissing = true)
public class RateLimitJedisAutoConfiguration {

    /**
     * 创建 Jedis 限流器.
     *
     * @param jedisClient the jedis client
     * @return the yeepay rate limiter
     */
    @Bean
    public YeepayRateLimiter yeepayRateLimiter(final ObjectProvider<UnifiedJedis> jedisClient) {
        return new JedisRateLimiter(jedisClient.getIfAvailable());
    }

    /**
     * 创建限流管理器.
     *
     * @param rateLimiter the rate limiter
     * @return the rate limiter manager
     */
    @Bean
    public RateLimiterManager rateLimiterManager(final YeepayRateLimiter rateLimiter) {
        return new RateLimiterManager(rateLimiter);
    }

    /**
     * 创建 Jedis 限流模板.
     *
     * @param rateLimiter the rate limiter
     * @return the rate limit template
     */
    @Bean
    public RateLimitTemplate rateLimitTemplate(final YeepayRateLimiter rateLimiter) {
        return new JedisRateLimitTemplate(rateLimiter);
    }
}
