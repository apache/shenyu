package com.yeepay.framework.springboot.starter.ratelimit.guava;

import static org.assertj.core.api.Assertions.assertThat;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.guava.GuavaRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.guava.template.GuavaRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

class RateLimitGuavaAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(
                    AutoConfigurations.of(RateLimitAutoConfiguration.class, RateLimitGuavaAutoConfiguration.class));

    @Test
    void autoConfiguration_wiresRateLimiterManagerAndTemplate() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimiter.class);
            assertThat(context).hasSingleBean(RateLimiterManager.class);
            assertThat(context).hasSingleBean(RateLimitTemplate.class);

            assertThat(context.getBean(YeepayRateLimiter.class)).isInstanceOf(GuavaRateLimiter.class);
            assertThat(context.getBean(RateLimitTemplate.class)).isInstanceOf(GuavaRateLimitTemplate.class);
        });
    }

    @Test
    void autoConfiguration_activeByDefault_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(RateLimitGuavaAutoConfiguration.class);
        });
    }

    @Test
    void autoConfiguration_activeWhenTypeGuava() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=guava")
                .run(context -> {
                    assertThat(context).hasSingleBean(RateLimitGuavaAutoConfiguration.class);
                    assertThat(context).hasSingleBean(YeepayRateLimiter.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenTypeRedisson() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=redisson")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitGuavaAutoConfiguration.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenRateLimitDisabled() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitGuavaAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(YeepayRateLimiter.class);
                });
    }
}
