package com.yeepay.framework.springboot.starter.ratelimit.config;

import static com.yeepay.framework.springboot.starter.ratelimit.config.YeepayRateLimitProperties.PREFIX;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * RateLimit 限流专属配置项.
 *
 * <p>示例（application.yml）：
 * <pre>
 * yeepay:
 *   framework:
 *     rate-limit:
 *         type: guava            # 同时依赖多个 starter 时必填（guava / redisson / resilience4j）
 *         replenish-rate: 10
 *         burst-capacity: 20
 * </pre>
 */
@Data
@ConfigurationProperties(prefix = PREFIX)
public class YeepayRateLimitProperties {

    public static final String PREFIX = "yeepay.framework.rate-limit";

    private boolean enabled = true;

    /**
     * 限流实现类型：{@code guava}、{@code redisson} 或 {@code resilience4j}.
     *
     * <p>单独依赖时无需设置，自动激活；
     * 同时依赖多个实现时必须指定，否则启动报 duplicate bean 错误。
     */
    private String type;
}
