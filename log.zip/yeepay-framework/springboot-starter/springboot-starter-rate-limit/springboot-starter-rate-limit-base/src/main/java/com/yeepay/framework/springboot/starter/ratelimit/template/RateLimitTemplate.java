package com.yeepay.framework.springboot.starter.ratelimit.template;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 限流模板接口，由具体实现模块提供.
 */
public interface RateLimitTemplate {

    /**
     * 执行限流逻辑.
     *
     * @param joinPoint      切入点
     * @param failureStrategy 限流失败策略
     * @param entity         限流实体
     * @return the object
     */
    Object invoke(ProceedingJoinPoint joinPoint, RateLimitFailureStrategy failureStrategy, RateLimitEntity entity);
}
