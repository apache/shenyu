package com.yeepay.framework.springboot.starter.ratelimit;

import com.yeepay.framework.springboot.starter.ratelimit.aspect.YeepayRateLimitAspect;
import com.yeepay.framework.springboot.starter.ratelimit.config.YeepayRateLimitProperties;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import java.util.List;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.expression.BeanResolver;

/**
 * 限流公共自动配置.
 *
 * <p>通过 {@code yeepay.framework.rate-limit.enabled=false} 可一键关闭所有限流功能。
 */
@AutoConfiguration
@EnableConfigurationProperties(YeepayRateLimitProperties.class)
@ConditionalOnProperty(
        prefix = "yeepay.framework.rate-limit",
        name = "enabled",
        havingValue = "true",
        matchIfMissing = true)
public class RateLimitAutoConfiguration {

    /**
     * 默认限流 key 生成策略.
     *
     * @param beanResolver the bean resolver
     * @return the rate limit key strategy
     */
    @Bean
    public RateLimitKeyStrategy defaultRateLimitKeyStrategy(final ObjectProvider<BeanResolver> beanResolver) {
        return new DefaultRateLimitKeyStrategy(beanResolver.getIfAvailable());
    }

    /**
     * 默认限流失败策略.
     *
     * @return the rate limit failure strategy
     */
    @Bean
    public RateLimitFailureStrategy defaultRateLimitFailureStrategy() {
        return new DefaultRateLimitFailureStrategy();
    }

    /**
     * 限流切面.
     *
     * @param rateLimitTemplate  the rate limit template
     * @param keyStrategies      the key strategies
     * @param failureStrategies  the failure strategies
     * @return the rate limit aspect
     */
    @Bean
    public YeepayRateLimitAspect rateLimitAspect(
            final ObjectProvider<RateLimitTemplate> rateLimitTemplate,
            final ObjectProvider<List<RateLimitKeyStrategy>> keyStrategies,
            final ObjectProvider<List<RateLimitFailureStrategy>> failureStrategies) {
        return new YeepayRateLimitAspect(
                rateLimitTemplate.getIfAvailable(), keyStrategies.getIfAvailable(), failureStrategies.getIfAvailable());
    }
}
