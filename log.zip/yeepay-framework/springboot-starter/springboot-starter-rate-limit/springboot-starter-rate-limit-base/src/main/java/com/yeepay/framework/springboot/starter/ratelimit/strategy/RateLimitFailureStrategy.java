package com.yeepay.framework.springboot.starter.ratelimit.strategy;

import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 限流失败策略，当请求被限流时执行.
 */
public interface RateLimitFailureStrategy {

    /**
     * 限流失败时执行.
     *
     * @param key    限流 key
     * @param result 限流结果
     * @param point  切入点
     * @return the object
     */
    Object execute(String key, RateLimitResult result, ProceedingJoinPoint point);
}
