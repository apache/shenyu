package com.yeepay.framework.springboot.starter.ratelimit.annotation;

import com.yeepay.framework.rate.limit.api.enums.RateLimitAlgorithm;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 声明式限流注解.
 */
@Target(value = ElementType.METHOD)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface YeepayRateLimit {

    /**
     * 限流名称前缀.
     *
     * @return the string
     */
    String name() default "";

    /**
     * 限流算法，默认令牌桶.
     *
     * @return the rate limit algorithm
     */
    RateLimitAlgorithm algorithm() default RateLimitAlgorithm.TOKEN_BUCKET;

    /**
     * 令牌补充速率（个/秒），默认 10.
     *
     * @return the double
     */
    double replenishRate() default 10;

    /**
     * 最大容量，默认 20.
     *
     * @return the double
     */
    double burstCapacity() default 20;

    /**
     * 单次请求消耗令牌数，默认 1.
     *
     * @return the double
     */
    double requestCount() default 1;

    /**
     * SpEL 表达式，用于动态构建限流 key.
     *
     * @return the string [ ]
     */
    String[] keys() default {};

    /**
     * 限流 key 生成策略.
     *
     * @return the class
     */
    Class<? extends RateLimitKeyStrategy> keyStrategy() default RateLimitKeyStrategy.class;

    /**
     * 限流失败策略.
     *
     * @return the class
     */
    Class<? extends RateLimitFailureStrategy> failStrategy() default RateLimitFailureStrategy.class;
}
