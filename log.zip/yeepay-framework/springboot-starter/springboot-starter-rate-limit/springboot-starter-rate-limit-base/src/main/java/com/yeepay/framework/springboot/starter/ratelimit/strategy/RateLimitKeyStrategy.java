package com.yeepay.framework.springboot.starter.ratelimit.strategy;

import org.aspectj.lang.JoinPoint;

/**
 * 限流 key 生成策略.
 */
public interface RateLimitKeyStrategy {

    /**
     * 构建限流 key.
     *
     * @param joinPoint the join point
     * @param keys      SpEL 表达式数组
     * @return the string
     */
    String buildKey(JoinPoint joinPoint, String[] keys);
}
