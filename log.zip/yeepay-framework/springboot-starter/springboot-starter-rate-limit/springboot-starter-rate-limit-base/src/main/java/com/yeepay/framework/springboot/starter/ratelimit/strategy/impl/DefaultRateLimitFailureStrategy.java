package com.yeepay.framework.springboot.starter.ratelimit.strategy.impl;

import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 默认限流失败策略：抛出运行时异常.
 */
public class DefaultRateLimitFailureStrategy implements RateLimitFailureStrategy {

    @Override
    public Object execute(final String key, final RateLimitResult result, final ProceedingJoinPoint point) {
        String errorMsg = String.format(
                "Rate limit exceeded for key: %s, tokens remaining: %s", key, result.getTokensRemaining());
        throw new RuntimeException(errorMsg);
    }
}
