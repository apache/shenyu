package com.yeepay.framework.springboot.starter.ratelimit.aspect;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.springboot.starter.ratelimit.annotation.YeepayRateLimit;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.InitializingBean;

/**
 * 限流切面.
 */
@Aspect
@RequiredArgsConstructor
public class YeepayRateLimitAspect implements InitializingBean {

    private final Map<Class<? extends RateLimitKeyStrategy>, RateLimitKeyStrategy> keyStrategyMap =
            new LinkedHashMap<>();

    private final Map<Class<? extends RateLimitFailureStrategy>, RateLimitFailureStrategy> failureStrategyMap =
            new LinkedHashMap<>();

    private final RateLimitTemplate rateLimitTemplate;

    private final List<RateLimitKeyStrategy> keyStrategyList;

    private final List<RateLimitFailureStrategy> failureStrategyList;

    /**
     * 限流环绕通知.
     *
     * @param joinPoint the join point
     * @param rateLimit the rate limit annotation
     * @return the object
     */
    @SneakyThrows
    @Around(value = "@annotation(rateLimit)")
    public Object aroundRateLimit(final ProceedingJoinPoint joinPoint, final YeepayRateLimit rateLimit) {
        StrategyHolder strategyHolder = buildStrategyHolder(rateLimit.keyStrategy(), rateLimit.failStrategy());
        String key = "yeepay-rate-limit@" + rateLimit.name() + "#"
                + strategyHolder.getRateLimitKeyStrategy().buildKey(joinPoint, rateLimit.keys());
        RateLimitEntity entity = RateLimitEntity.builder()
                .key(key)
                .replenishRate(rateLimit.replenishRate())
                .burstCapacity(rateLimit.burstCapacity())
                .requestCount(rateLimit.requestCount())
                .algorithm(rateLimit.algorithm())
                .build();
        return rateLimitTemplate.invoke(joinPoint, strategyHolder.getRateLimitFailureStrategy(), entity);
    }

    @Override
    public void afterPropertiesSet() {
        keyStrategyMap.putAll(keyStrategyList.stream()
                .collect(Collectors.toMap(RateLimitKeyStrategy::getClass, keyStrategy -> keyStrategy)));
        failureStrategyMap.putAll(failureStrategyList.stream()
                .collect(Collectors.toMap(RateLimitFailureStrategy::getClass, failureStrategy -> failureStrategy)));
    }

    private StrategyHolder buildStrategyHolder(
            final Class<? extends RateLimitKeyStrategy> keyStrategy,
            final Class<? extends RateLimitFailureStrategy> failStrategy) {
        StrategyHolder.StrategyHolderBuilder builder = StrategyHolder.builder();
        if (Objects.isNull(keyStrategy) || keyStrategy == RateLimitKeyStrategy.class) {
            builder.rateLimitKeyStrategy(keyStrategyMap.get(DefaultRateLimitKeyStrategy.class));
        } else {
            builder.rateLimitKeyStrategy(keyStrategyMap.get(keyStrategy));
        }
        if (Objects.isNull(failStrategy) || failStrategy == RateLimitFailureStrategy.class) {
            builder.rateLimitFailureStrategy(failureStrategyMap.get(DefaultRateLimitFailureStrategy.class));
        } else {
            builder.rateLimitFailureStrategy(failureStrategyMap.get(failStrategy));
        }
        return builder.build();
    }

    /**
     * 策略持有者，聚合切面所需的策略.
     */
    @Data
    @Builder
    public static class StrategyHolder {

        private RateLimitKeyStrategy rateLimitKeyStrategy;

        private RateLimitFailureStrategy rateLimitFailureStrategy;
    }
}
