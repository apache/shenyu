package com.yeepay.framework.springboot.starter.ratelimit.strategy.impl;

import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.expression.MethodBasedEvaluationContext;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.expression.BeanResolver;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

/**
 * 默认限流 key 生成策略.
 */
@RequiredArgsConstructor
public class DefaultRateLimitKeyStrategy implements RateLimitKeyStrategy {

    private static final ParameterNameDiscoverer NAME_DISCOVERER = new DefaultParameterNameDiscoverer();

    private static final ExpressionParser PARSER = new SpelExpressionParser();

    private final BeanResolver beanResolver;

    @Override
    public String buildKey(final JoinPoint joinPoint, final String[] keys) {
        if (ObjectUtils.isEmpty(keys)) {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            return String.format(
                    "%s.%s",
                    signature.getDeclaringTypeName(), getMethod(joinPoint).getName());
        }
        return getDefinitionKey(keys, joinPoint.getThis(), getMethod(joinPoint), joinPoint.getArgs());
    }

    private String getDefinitionKey(
            final String[] keys, final Object obj, final Method method, final Object[] parameterValues) {
        List<String> definitionKeyList = new ArrayList<>();
        for (String key : keys) {
            if (!ObjectUtils.isEmpty(key)) {
                StandardEvaluationContext context =
                        new MethodBasedEvaluationContext(obj, method, parameterValues, NAME_DISCOVERER);
                context.setBeanResolver(beanResolver);
                Object objKey = PARSER.parseExpression(key).getValue(context);
                definitionKeyList.add(ObjectUtils.nullSafeToString(objKey));
            }
        }
        return StringUtils.collectionToDelimitedString(definitionKeyList, ".", "", "");
    }

    @SneakyThrows
    private Method getMethod(final JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        if (method.getDeclaringClass().isInterface()) {
            method =
                    joinPoint.getTarget().getClass().getDeclaredMethod(signature.getName(), method.getParameterTypes());
        }
        return method;
    }
}
