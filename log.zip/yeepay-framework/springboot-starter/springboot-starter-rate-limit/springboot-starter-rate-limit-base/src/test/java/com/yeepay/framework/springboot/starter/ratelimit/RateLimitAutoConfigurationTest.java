package com.yeepay.framework.springboot.starter.ratelimit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.springboot.starter.ratelimit.aspect.YeepayRateLimitAspect;
import com.yeepay.framework.springboot.starter.ratelimit.config.YeepayRateLimitProperties;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.BeanResolver;

class RateLimitAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(ctx ->
                    ConfigurationPropertiesBindingPostProcessor.register((BeanDefinitionRegistry) ctx.getBeanFactory()))
            .withConfiguration(AutoConfigurations.of(RateLimitAutoConfiguration.class))
            .withBean(RateLimitTemplate.class, () -> mock(RateLimitTemplate.class));

    @Test
    void autoConfiguration_registersDefaultStrategiesAndAspect() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimitProperties.class);
            assertThat(context).hasSingleBean(RateLimitKeyStrategy.class);
            assertThat(context).hasSingleBean(RateLimitFailureStrategy.class);
            assertThat(context).hasSingleBean(YeepayRateLimitAspect.class);

            assertThat(context.getBean(RateLimitKeyStrategy.class)).isInstanceOf(DefaultRateLimitKeyStrategy.class);
            assertThat(context.getBean(RateLimitFailureStrategy.class))
                    .isInstanceOf(DefaultRateLimitFailureStrategy.class);
        });
    }

    @Test
    void autoConfiguration_bindsPropertiesFromYaml() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=guava")
                .run(context -> {
                    YeepayRateLimitProperties props = context.getBean(YeepayRateLimitProperties.class);
                    assertThat(props.getType()).isEqualTo("guava");
                    assertThat(props.isEnabled()).isTrue();
                });
    }

    @Test
    void autoConfiguration_skippedWhenEnabledFalse() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(YeepayRateLimitAspect.class);
                    assertThat(context).doesNotHaveBean(RateLimitKeyStrategy.class);
                });
    }

    @Test
    void autoConfiguration_activeWhenEnabledMissing_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(RateLimitAutoConfiguration.class);
            assertThat(context).hasSingleBean(YeepayRateLimitAspect.class);
        });
    }

    @Test
    void autoConfiguration_picksUpBeanResolverForKeyStrategy() {
        BeanResolver beanResolver = mock(BeanResolver.class);
        contextRunner.withBean(BeanResolver.class, () -> beanResolver).run(context -> {
            assertThat(context).hasSingleBean(RateLimitKeyStrategy.class);
            assertThat(context.getBean(RateLimitKeyStrategy.class)).isInstanceOf(DefaultRateLimitKeyStrategy.class);
        });
    }

    @Test
    void autoConfiguration_aspectAggregatesAllStrategyBeans() {
        contextRunner.withUserConfiguration(ExtraStrategyConfig.class).run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimitAspect.class);
            assertThat(context.getBeansOfType(RateLimitKeyStrategy.class)).hasSize(2);
            assertThat(context.getBeansOfType(RateLimitFailureStrategy.class)).hasSize(2);
        });
    }

    @Test
    void autoConfiguration_aspectCreatedWithoutRateLimitTemplateBean() {
        new ApplicationContextRunner()
                .withInitializer(ctx -> ConfigurationPropertiesBindingPostProcessor.register(
                        (BeanDefinitionRegistry) ctx.getBeanFactory()))
                .withConfiguration(AutoConfigurations.of(RateLimitAutoConfiguration.class))
                .run(context -> {
                    assertThat(context).hasSingleBean(YeepayRateLimitAspect.class);
                });
    }

    @Configuration
    static class ExtraStrategyConfig {
        @Bean
        RateLimitKeyStrategy extraKeyStrategy() {
            return (joinPoint, keys) -> "extra";
        }

        @Bean
        RateLimitFailureStrategy extraFailureStrategy() {
            return (key, result, point) -> null;
        }
    }
}
