package com.yeepay.framework.springboot.starter.ratelimit.strategy.impl;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import java.util.List;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.Test;

class DefaultRateLimitFailureStrategyTest {

    private final DefaultRateLimitFailureStrategy strategy = new DefaultRateLimitFailureStrategy();

    @Test
    void execute_throwsRuntimeException_withKeyAndTokensRemaining() {
        RateLimitResult result = new RateLimitResult(false, 0L, List.of("test-key"));
        ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);

        assertThatThrownBy(() -> strategy.execute("order:create", result, joinPoint))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Rate limit exceeded for key: order:create")
                .hasMessageContaining("tokens remaining: 0");
    }

    @Test
    void execute_throwsRuntimeException_withNonZeroTokens() {
        RateLimitResult result = new RateLimitResult(false, 5L, List.of("key"));
        ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);

        assertThatThrownBy(() -> strategy.execute("user:api", result, joinPoint))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("tokens remaining: 5");
    }
}
