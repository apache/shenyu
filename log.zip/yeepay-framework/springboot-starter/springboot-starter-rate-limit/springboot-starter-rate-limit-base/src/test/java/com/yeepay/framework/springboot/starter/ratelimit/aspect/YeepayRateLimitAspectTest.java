package com.yeepay.framework.springboot.starter.ratelimit.aspect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.yeepay.framework.rate.limit.api.entity.RateLimitEntity;
import com.yeepay.framework.rate.limit.api.result.RateLimitResult;
import com.yeepay.framework.springboot.starter.ratelimit.annotation.YeepayRateLimit;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.RateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitFailureStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.strategy.impl.DefaultRateLimitKeyStrategy;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import java.lang.reflect.Method;
import java.util.List;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class YeepayRateLimitAspectTest {

    @Mock
    private RateLimitTemplate rateLimitTemplate;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @Mock
    private MethodSignature methodSignature;

    private final DefaultRateLimitKeyStrategy defaultKeyStrategy = new DefaultRateLimitKeyStrategy(null);
    private final DefaultRateLimitFailureStrategy defaultFailureStrategy = new DefaultRateLimitFailureStrategy();

    static class CustomKeyStrategy implements RateLimitKeyStrategy {
        @Override
        public String buildKey(JoinPoint joinPoint, String[] keys) {
            return "custom-key";
        }
    }

    static class CustomFailureStrategy implements RateLimitFailureStrategy {
        @Override
        public Object execute(String key, RateLimitResult result, ProceedingJoinPoint point) {
            return "custom-failure";
        }
    }

    static class TestService {
        @YeepayRateLimit(name = "test", replenishRate = 5, burstCapacity = 10, requestCount = 2)
        public void defaultAnnotated() {}

        @YeepayRateLimit(
                name = "custom",
                keyStrategy = CustomKeyStrategy.class,
                failStrategy = CustomFailureStrategy.class)
        public void customAnnotated() {}
    }

    private YeepayRateLimitAspect aspect;

    @BeforeEach
    void setUp() {
        aspect = new YeepayRateLimitAspect(
                rateLimitTemplate, List.of(defaultKeyStrategy), List.of(defaultFailureStrategy));
        aspect.afterPropertiesSet();
    }

    @Test
    void aroundRateLimit_withDefaultStrategies_buildsKeyAndInvokesTemplate() throws Exception {
        Method method = TestService.class.getDeclaredMethod("defaultAnnotated");
        YeepayRateLimit rateLimit = method.getAnnotation(YeepayRateLimit.class);

        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.TestService");
        when(methodSignature.getMethod()).thenReturn(method);
        when(rateLimitTemplate.invoke(any(), any(), any())).thenReturn("result");

        Object result = aspect.aroundRateLimit(joinPoint, rateLimit);

        assertThat(result).isEqualTo("result");
        ArgumentCaptor<RateLimitEntity> entityCaptor = ArgumentCaptor.forClass(RateLimitEntity.class);
        verify(rateLimitTemplate)
                .invoke(eq(joinPoint), any(DefaultRateLimitFailureStrategy.class), entityCaptor.capture());
        RateLimitEntity entity = entityCaptor.getValue();
        assertThat(entity.getKey()).startsWith("yeepay-rate-limit@test#");
        assertThat(entity.getReplenishRate()).isEqualTo(5);
        assertThat(entity.getBurstCapacity()).isEqualTo(10);
        assertThat(entity.getRequestCount()).isEqualTo(2);
    }

    @Test
    void aroundRateLimit_withCustomStrategies_selectsCorrectStrategiesFromMap() throws Exception {
        CustomKeyStrategy customKey = new CustomKeyStrategy();
        CustomFailureStrategy customFailure = new CustomFailureStrategy();

        YeepayRateLimitAspect aspectWithCustom = new YeepayRateLimitAspect(
                rateLimitTemplate,
                List.of(defaultKeyStrategy, customKey),
                List.of(defaultFailureStrategy, customFailure));
        aspectWithCustom.afterPropertiesSet();

        Method method = TestService.class.getDeclaredMethod("customAnnotated");
        YeepayRateLimit rateLimit = method.getAnnotation(YeepayRateLimit.class);

        when(rateLimitTemplate.invoke(any(), any(), any())).thenReturn("custom-result");

        Object result = aspectWithCustom.aroundRateLimit(joinPoint, rateLimit);

        assertThat(result).isEqualTo("custom-result");
        verify(rateLimitTemplate).invoke(eq(joinPoint), any(CustomFailureStrategy.class), any(RateLimitEntity.class));
    }

    @Test
    void aroundRateLimit_entityContainsCorrectKeyPrefix() throws Exception {
        Method method = TestService.class.getDeclaredMethod("defaultAnnotated");
        YeepayRateLimit rateLimit = method.getAnnotation(YeepayRateLimit.class);

        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringTypeName()).thenReturn("com.example.SomeService");
        when(methodSignature.getMethod()).thenReturn(method);
        when(rateLimitTemplate.invoke(any(), any(), any())).thenReturn(null);

        aspect.aroundRateLimit(joinPoint, rateLimit);

        ArgumentCaptor<RateLimitEntity> captor = ArgumentCaptor.forClass(RateLimitEntity.class);
        verify(rateLimitTemplate).invoke(any(), any(), captor.capture());
        assertThat(captor.getValue().getKey())
                .isEqualTo("yeepay-rate-limit@test#com.example.SomeService.defaultAnnotated");
    }

    @Test
    void strategyHolder_setters_workCorrectly() {
        YeepayRateLimitAspect.StrategyHolder holder =
                YeepayRateLimitAspect.StrategyHolder.builder().build();
        holder.setRateLimitKeyStrategy(defaultKeyStrategy);
        holder.setRateLimitFailureStrategy(defaultFailureStrategy);
        assertThat(holder.getRateLimitKeyStrategy()).isSameAs(defaultKeyStrategy);
        assertThat(holder.getRateLimitFailureStrategy()).isSameAs(defaultFailureStrategy);
    }

    @Test
    void strategyHolder_equalsAndHashCode_workCorrectly() {
        YeepayRateLimitAspect.StrategyHolder h1 = YeepayRateLimitAspect.StrategyHolder.builder()
                .rateLimitKeyStrategy(defaultKeyStrategy)
                .rateLimitFailureStrategy(defaultFailureStrategy)
                .build();
        YeepayRateLimitAspect.StrategyHolder h2 = YeepayRateLimitAspect.StrategyHolder.builder()
                .rateLimitKeyStrategy(defaultKeyStrategy)
                .rateLimitFailureStrategy(defaultFailureStrategy)
                .build();
        assertThat(h1).isEqualTo(h2);
        assertThat(h1.hashCode()).isEqualTo(h2.hashCode());
        assertThat(h1.toString()).contains("StrategyHolder");
    }

    @Test
    void buildStrategyHolder_withNullStrategies_picksDefaults() throws Exception {
        java.lang.reflect.Method method =
                YeepayRateLimitAspect.class.getDeclaredMethod("buildStrategyHolder", Class.class, Class.class);
        method.setAccessible(true);

        Object holder = method.invoke(aspect, null, null);
        assertThat(holder).isInstanceOf(YeepayRateLimitAspect.StrategyHolder.class);
        YeepayRateLimitAspect.StrategyHolder sh = (YeepayRateLimitAspect.StrategyHolder) holder;
        assertThat(sh.getRateLimitKeyStrategy()).isSameAs(defaultKeyStrategy);
        assertThat(sh.getRateLimitFailureStrategy()).isSameAs(defaultFailureStrategy);
    }

    @Test
    void buildStrategyHolder_withInterfaceClassAsDefault_picksDefaults() throws Exception {
        java.lang.reflect.Method method =
                YeepayRateLimitAspect.class.getDeclaredMethod("buildStrategyHolder", Class.class, Class.class);
        method.setAccessible(true);

        Object holder = method.invoke(aspect, RateLimitKeyStrategy.class, RateLimitFailureStrategy.class);
        YeepayRateLimitAspect.StrategyHolder sh = (YeepayRateLimitAspect.StrategyHolder) holder;
        assertThat(sh.getRateLimitKeyStrategy()).isSameAs(defaultKeyStrategy);
        assertThat(sh.getRateLimitFailureStrategy()).isSameAs(defaultFailureStrategy);
    }
}
