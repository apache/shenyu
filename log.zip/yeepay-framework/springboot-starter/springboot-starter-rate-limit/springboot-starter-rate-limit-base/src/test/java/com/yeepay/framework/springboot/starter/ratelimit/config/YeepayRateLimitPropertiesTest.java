package com.yeepay.framework.springboot.starter.ratelimit.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class YeepayRateLimitPropertiesTest {

    @Test
    void defaults_enabledTrueAndTypeNull() {
        YeepayRateLimitProperties props = new YeepayRateLimitProperties();
        assertThat(props.isEnabled()).isTrue();
        assertThat(props.getType()).isNull();
    }

    @Test
    void setEnabled_false_updatesField() {
        YeepayRateLimitProperties props = new YeepayRateLimitProperties();
        props.setEnabled(false);
        assertThat(props.isEnabled()).isFalse();
    }

    @Test
    void setType_updatesField() {
        YeepayRateLimitProperties props = new YeepayRateLimitProperties();
        props.setType("guava");
        assertThat(props.getType()).isEqualTo("guava");
    }

    @Test
    void prefix_matchesExpectedValue() {
        assertThat(YeepayRateLimitProperties.PREFIX).isEqualTo("yeepay.framework.rate-limit");
    }

    @Test
    void equalsAndHashCode_workCorrectly() {
        YeepayRateLimitProperties p1 = new YeepayRateLimitProperties();
        YeepayRateLimitProperties p2 = new YeepayRateLimitProperties();
        assertThat(p1).isEqualTo(p2);
        assertThat(p1.hashCode()).isEqualTo(p2.hashCode());
    }

    @Test
    void toString_containsClassName() {
        YeepayRateLimitProperties props = new YeepayRateLimitProperties();
        assertThat(props.toString()).contains("YeepayRateLimitProperties");
    }
}
