package com.yeepay.framework.springboot.starter.ratelimit.redisson;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.redisson.RedissonRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.config.YeepayRateLimitProperties;
import com.yeepay.framework.springboot.starter.ratelimit.redisson.template.RedissonRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/**
 * Redisson 限流自动配置.
 *
 * <p>单独依赖时自动激活；同时依赖其他实现时需设置 {@code yeepay.framework.rate-limit.type=redisson}。
 */
@AutoConfiguration(after = RateLimitAutoConfiguration.class)
@ConditionalOnBean(RateLimitAutoConfiguration.class)
@ConditionalOnProperty(
        name = YeepayRateLimitProperties.PREFIX + ".type",
        havingValue = "redisson",
        matchIfMissing = true)
public class RateLimitRedissonAutoConfiguration {

    /**
     * 创建 Redisson 限流器.
     *
     * @param redissonClient the redisson client
     * @return the yeepay rate limiter
     */
    @Bean
    public YeepayRateLimiter yeepayRateLimiter(final ObjectProvider<RedissonClient> redissonClient) {
        return new RedissonRateLimiter(redissonClient.getIfAvailable());
    }

    /**
     * 创建限流管理器.
     *
     * @param rateLimiter the rate limiter
     * @return the rate limiter manager
     */
    @Bean
    public RateLimiterManager rateLimiterManager(final YeepayRateLimiter rateLimiter) {
        return new RateLimiterManager(rateLimiter);
    }

    /**
     * 创建 Redisson 限流模板.
     *
     * @param rateLimiter the rate limiter
     * @return the rate limit template
     */
    @Bean
    public RateLimitTemplate rateLimitTemplate(final YeepayRateLimiter rateLimiter) {
        return new RedissonRateLimitTemplate(rateLimiter);
    }
}
