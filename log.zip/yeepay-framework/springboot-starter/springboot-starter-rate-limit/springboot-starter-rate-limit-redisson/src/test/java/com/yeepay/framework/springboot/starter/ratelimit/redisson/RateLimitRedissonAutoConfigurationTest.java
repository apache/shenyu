package com.yeepay.framework.springboot.starter.ratelimit.redisson;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.rate.limit.api.RateLimiterManager;
import com.yeepay.framework.rate.limit.api.YeepayRateLimiter;
import com.yeepay.framework.rate.limit.redisson.RedissonRateLimiter;
import com.yeepay.framework.springboot.starter.ratelimit.RateLimitAutoConfiguration;
import com.yeepay.framework.springboot.starter.ratelimit.redisson.template.RedissonRateLimitTemplate;
import com.yeepay.framework.springboot.starter.ratelimit.template.RateLimitTemplate;
import org.junit.jupiter.api.Test;
import org.redisson.api.RedissonClient;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

class RateLimitRedissonAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(
                    AutoConfigurations.of(RateLimitAutoConfiguration.class, RateLimitRedissonAutoConfiguration.class));

    @Test
    void autoConfiguration_wiresRateLimiterManagerAndTemplate_withClient() {
        RedissonClient redissonClient = mock(RedissonClient.class);
        contextRunner.withBean(RedissonClient.class, () -> redissonClient).run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimiter.class);
            assertThat(context).hasSingleBean(RateLimiterManager.class);
            assertThat(context).hasSingleBean(RateLimitTemplate.class);

            assertThat(context.getBean(YeepayRateLimiter.class)).isInstanceOf(RedissonRateLimiter.class);
            assertThat(context.getBean(RateLimitTemplate.class)).isInstanceOf(RedissonRateLimitTemplate.class);
        });
    }

    @Test
    void autoConfiguration_stillCreatesBeans_whenClientMissing_dueToObjectProvider() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(YeepayRateLimiter.class);
            assertThat(context).hasSingleBean(RateLimiterManager.class);
            assertThat(context).hasSingleBean(RateLimitTemplate.class);

            assertThat(context.getBean(YeepayRateLimiter.class)).isInstanceOf(RedissonRateLimiter.class);
        });
    }

    @Test
    void autoConfiguration_activeByDefault_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(RateLimitRedissonAutoConfiguration.class);
        });
    }

    @Test
    void autoConfiguration_activeWhenTypeRedisson() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=redisson")
                .run(context -> {
                    assertThat(context).hasSingleBean(RateLimitRedissonAutoConfiguration.class);
                    assertThat(context).hasSingleBean(YeepayRateLimiter.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenTypeGuava() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.type=guava")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitRedissonAutoConfiguration.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenRateLimitDisabled() {
        contextRunner
                .withPropertyValues("yeepay.framework.rate-limit.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(RateLimitRedissonAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(YeepayRateLimiter.class);
                });
    }
}
