package com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 用于跟踪方法并发执行数的注解.
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Gauge {

    /**
     * 指标名称.
     *
     * @return 指标名称
     */
    String value() default "";
}
