package com.yeepay.framework.springboot.starter.metrics.prometheus.aspect;

import com.yeepay.framework.metrics.api.StatsDClient;
import com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion.Count;
import com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion.Gauge;
import com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion.Time;
import java.lang.reflect.Method;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;

/**
 * 指标切面，用于统计方法执行时间、调用次数和并发执行数.
 */
@Slf4j
@Aspect
public class MetricsAspect {

    public static final String AND = ".";

    private final StatsDClient statsd;

    public MetricsAspect(StatsDClient statsd) {
        this.statsd = statsd;
    }

    /**
     * 环绕通知，统计被@Time注解标记的方法执行时间.
     *
     * @param pjp  连接点
     * @param time Time注解
     * @return 方法执行结果
     * @throws Exception 异常
     */
    @Around("@annotation(time)")
    public Object proceedWithTime(ProceedingJoinPoint pjp, Time time) throws Exception {
        String metricName = resolveMetricName(pjp, time.value());

        long start = System.nanoTime();
        boolean successful = false;
        try {
            Object result = pjp.proceed();
            successful = true;
            return result;
        } catch (Exception e) {
            throw e;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } finally {
            long end = System.nanoTime();
            double elapsed = end - start;
            statsd.histogram(metricName, elapsed, "successful:" + successful);
        }
    }

    /**
     * 环绕通知，统计被@Count注解标记的方法调用次数.
     *
     * @param pjp   连接点
     * @param count Count注解
     * @return 方法执行结果
     * @throws Exception 异常
     */
    @Around("@annotation(count)")
    public Object proceedWithCount(ProceedingJoinPoint pjp, Count count) throws Exception {
        String metricName = resolveMetricName(pjp, count.value());
        boolean successful = false;
        try {
            Object result = pjp.proceed();
            successful = true;
            return result;
        } catch (Exception e) {
            throw e;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } finally {
            statsd.increment(metricName, "successful:" + successful);
        }
    }

    /**
     * 环绕通知，跟踪被@Gauge注解标记的方法并发执行数.
     *
     * @param pjp   连接点
     * @param gauge Gauge注解
     * @return 方法执行结果
     * @throws Exception 异常
     */
    @Around("@annotation(gauge)")
    public Object proceedWithGauge(ProceedingJoinPoint pjp, Gauge gauge) throws Exception {
        String metricName = resolveMetricName(pjp, gauge.value());
        boolean successful = false;
        try {
            Object result = pjp.proceed();
            successful = true;
            return result;
        } catch (Exception e) {
            throw e;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } finally {
            statsd.gauge(metricName, 1, "successful:" + successful);
        }
    }

    private String resolveMetricName(ProceedingJoinPoint pjp, String annotationValue) {
        Method method = ((MethodSignature) pjp.getSignature()).getMethod();
        String className = getClassName(pjp);
        String metricName = annotationValue.isEmpty() ? className + AND + method.getName() : annotationValue;
        if (metricName.contains("-")) {
            metricName = metricName.replace("-", "_");
        }
        return metricName;
    }

    private String getClassName(ProceedingJoinPoint pjp) {
        try {
            return pjp.getTarget().getClass().getSimpleName();
        } catch (Exception e) {
            return "";
        }
    }
}
