package com.yeepay.framework.springboot.starter.metrics.prometheus.config;

import com.yeepay.framework.metrics.api.config.MetricsConfig;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * HTX指标配置属性类.
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ConfigurationProperties(prefix = MetricsProperties.PREFIX)
public class MetricsProperties extends MetricsConfig {

    public static final String PREFIX = "yeepay.framework.metrics";
}
