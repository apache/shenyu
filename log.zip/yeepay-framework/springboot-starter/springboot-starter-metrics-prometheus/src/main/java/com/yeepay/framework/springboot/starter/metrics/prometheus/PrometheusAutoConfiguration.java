package com.yeepay.framework.springboot.starter.metrics.prometheus;

import com.yeepay.framework.metrics.api.CommonTagCustom;
import com.yeepay.framework.metrics.api.StatsDClient;
import com.yeepay.framework.metrics.api.tag.CommonTags;
import com.yeepay.framework.springboot.starter.application.config.ApplicationInfo;
import com.yeepay.framework.springboot.starter.metrics.prometheus.aspect.MetricsAspect;
import com.yeepay.framework.springboot.starter.metrics.prometheus.config.MetricsProperties;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.config.MeterFilter;
import io.micrometer.prometheusmetrics.PrometheusConfig;
import io.micrometer.prometheusmetrics.PrometheusMeterRegistry;
import io.micrometer.prometheusmetrics.PrometheusNamingConvention;
import io.micrometer.prometheusmetrics.YeepayPrometheusMeterRegistry;
import io.micrometer.prometheusmetrics.YeepayPrometheusProxy;
import io.prometheus.metrics.model.registry.PrometheusRegistry;
import io.prometheus.metrics.tracer.common.SpanContext;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

/**
 * Prometheus自动配置类.
 */
@Slf4j
@AutoConfiguration
@AutoConfigureBefore({PrometheusMetricsExportAutoConfiguration.class})
@AutoConfigureAfter(MetricsAutoConfiguration.class)
@ConditionalOnBean(Clock.class)
@ConditionalOnClass(PrometheusMeterRegistry.class)
@EnableConfigurationProperties({MetricsProperties.class})
@ConditionalOnProperty(prefix = MetricsProperties.PREFIX, name = "enabled", havingValue = "true", matchIfMissing = true)
public class PrometheusAutoConfiguration {

    /**
     * Common tags.
     *
     * @param applicationInfo the application info
     * @param providers the providers
     * @return the common tags
     */
    @Bean
    public CommonTags commonTags(
            ObjectProvider<ApplicationInfo> applicationInfo, ObjectProvider<List<CommonTagCustom>> providers) {
        ApplicationInfo info = applicationInfo.getIfAvailable();
        Map<String, String> tags = new HashMap<>();
        tags.put("app", Objects.requireNonNull(info).getName());
        tags.put("env", info.getEnv());
        List<CommonTagCustom> commonTagCustomList = providers.getIfAvailable();
        if (!CollectionUtils.isEmpty(commonTagCustomList)) {
            for (CommonTagCustom commonTagCustom : commonTagCustomList) {
                commonTagCustom.custom(tags);
            }
        }
        return new CommonTags(tags);
    }

    /**
     * 配置Micrometer的通用标签.
     *
     * @param commonTags 通用标签
     * @return MeterRegistry自定义器
     */
    @Bean
    public MeterRegistryCustomizer<MeterRegistry> metricsCommonTags(CommonTags commonTags) {
        return registry -> {
            MeterRegistry.Config config = registry.config();
            for (Map.Entry<String, String> entry : commonTags.getTags().entrySet()) {
                config.commonTags(entry.getKey(), entry.getValue());
            }
        };
    }

    /**
     * 创建Prometheus指标注册表Bean.
     *
     * @param prometheusConfig Prometheus配置
     * @param collectorRegistry 收集器注册表
     * @param clock 时钟
     * @return Prometheus指标注册表
     */
    @Bean
    @ConditionalOnMissingBean
    public PrometheusMeterRegistry prometheusMeterRegistry(
            PrometheusConfig prometheusConfig, PrometheusRegistry collectorRegistry, Clock clock) {
        PrometheusMeterRegistry prometheusMeterRegistry =
                new YeepayPrometheusMeterRegistry(prometheusConfig, collectorRegistry, clock);
        prometheusMeterRegistry.config().namingConvention(new PrometheusNamingConvention());
        return prometheusMeterRegistry;
    }

    /**
     * 创建StatsD客户端Bean.
     *
     * @param config Prometheus配置
     * @param clock 时钟
     * @param spanContext Span上下文
     * @param prometheusMeterRegistry Prometheus指标注册表
     * @param properties 属性
     * @param collectorRegistry 收集器注册表
     * @param commonTags 通用标签
     * @return StatsD客户端
     */
    @Bean
    public StatsDClient statsDClient(
            ObjectProvider<PrometheusConfig> config,
            ObjectProvider<Clock> clock,
            ObjectProvider<SpanContext> spanContext,
            PrometheusMeterRegistry prometheusMeterRegistry,
            MetricsProperties properties,
            ObjectProvider<PrometheusRegistry> collectorRegistry,
            CommonTags commonTags) {
        Map<String, String> globalTags = new HashMap<>();
        globalTags.putAll(commonTags.getTags());
        globalTags.putAll(properties.getTags());
        String prefix = properties.getPrefix();
        Field filtersField = ReflectionUtils.findField(MeterRegistry.class, "filters");
        MeterFilter[] filters = null;
        if (Objects.nonNull(filtersField)) {
            filtersField.setAccessible(true);
            filters = (MeterFilter[]) ReflectionUtils.getField(filtersField, prometheusMeterRegistry);
        }
        log.info("StatsDClient init with PrometheusProxy");
        return new YeepayPrometheusProxy(
                Objects.requireNonNull(config.getIfAvailable()),
                clock.getIfAvailable(),
                spanContext.getIfAvailable(),
                prometheusMeterRegistry,
                properties,
                collectorRegistry.getIfAvailable(),
                globalTags,
                filters,
                prefix);
    }

    /**
     * 创建指标切面Bean.
     *
     * @param statsDClient StatsD客户端
     * @return 指标切面
     */
    @Bean
    @ConditionalOnBean(StatsDClient.class)
    public MetricsAspect metricsAspect(StatsDClient statsDClient) {
        return new MetricsAspect(statsDClient);
    }
}
