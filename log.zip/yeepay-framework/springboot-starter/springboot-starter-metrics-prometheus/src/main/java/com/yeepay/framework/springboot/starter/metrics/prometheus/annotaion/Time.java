package com.yeepay.framework.springboot.starter.metrics.prometheus.annotaion;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 用于标记方法执行时间的注解.
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Time {

    /**
     * 指标名称.
     *
     * @return 指标名称
     */
    String value() default "";

    /**
     * 是否是长时间任务.
     *
     * @return 是否是长时间任务
     */
    boolean longTask() default false;
}
