package com.yeepay.framework.springboot.starter.metrics.prometheus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import com.yeepay.framework.metrics.api.CommonTagCustom;
import com.yeepay.framework.metrics.api.StatsDClient;
import com.yeepay.framework.metrics.api.tag.CommonTags;
import com.yeepay.framework.springboot.starter.application.config.ApplicationInfo;
import com.yeepay.framework.springboot.starter.metrics.prometheus.config.MetricsProperties;
import io.micrometer.core.instrument.Clock;
import io.micrometer.prometheusmetrics.PrometheusConfig;
import io.micrometer.prometheusmetrics.PrometheusMeterRegistry;
import io.micrometer.prometheusmetrics.YeepayPrometheusMeterRegistry;
import io.micrometer.prometheusmetrics.YeepayPrometheusProxy;
import io.prometheus.metrics.model.registry.PrometheusRegistry;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

class PrometheusAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(ctx ->
                    ConfigurationPropertiesBindingPostProcessor.register((BeanDefinitionRegistry) ctx.getBeanFactory()))
            .withConfiguration(AutoConfigurations.of(PrometheusAutoConfiguration.class))
            .withBean(Clock.class, () -> Clock.SYSTEM)
            .withBean(PrometheusConfig.class, () -> PrometheusConfig.DEFAULT)
            .withBean(PrometheusRegistry.class, PrometheusRegistry::new)
            .withBean(ApplicationInfo.class, () -> {
                ApplicationInfo info = new ApplicationInfo();
                info.setName("test-app");
                info.setEnv("test");
                return info;
            });

    @Test
    void autoConfiguration_registersAllBeans() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(CommonTags.class);
            assertThat(context).hasSingleBean(PrometheusMeterRegistry.class);
            assertThat(context).hasSingleBean(StatsDClient.class);
            assertThat(context.getBean(PrometheusMeterRegistry.class))
                    .isInstanceOf(YeepayPrometheusMeterRegistry.class);
            assertThat(context.getBean(StatsDClient.class)).isInstanceOf(YeepayPrometheusProxy.class);
        });
    }

    @Test
    void autoConfiguration_bindsProperties() {
        contextRunner
                .withPropertyValues(
                        "yeepay.framework.metrics.prefix=test_prefix",
                        "yeepay.framework.metrics.tags-limit=500",
                        "yeepay.framework.metrics.schedule-threads=2")
                .run(context -> {
                    MetricsProperties props = context.getBean(MetricsProperties.class);
                    assertThat(props.getPrefix()).isEqualTo("test_prefix");
                    assertThat(props.getTagsLimit()).isEqualTo(500);
                    assertThat(props.getScheduleThreads()).isEqualTo(2);
                });
    }

    @Test
    void autoConfiguration_skippedWhenEnabledFalse() {
        contextRunner
                .withPropertyValues("yeepay.framework.metrics.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(PrometheusAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(StatsDClient.class);
                    assertThat(context).doesNotHaveBean(CommonTags.class);
                });
    }

    @Test
    void autoConfiguration_activeWhenEnabledMissing_dueToMatchIfMissing() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(PrometheusAutoConfiguration.class);
            assertThat(context).hasSingleBean(StatsDClient.class);
        });
    }

    @Test
    void autoConfiguration_userProvidedMeterRegistryTakesPrecedence() {
        PrometheusMeterRegistry userRegistry = mock(PrometheusMeterRegistry.class, "userRegistry");
        contextRunner
                .withBean(PrometheusMeterRegistry.class, () -> userRegistry)
                .run(context -> {
                    assertThat(context).hasSingleBean(PrometheusMeterRegistry.class);
                    assertThat(context.getBean(PrometheusMeterRegistry.class)).isSameAs(userRegistry);
                });
    }

    @Test
    void autoConfiguration_commonTagsIncludeAppAndEnv() {
        contextRunner.run(context -> {
            CommonTags commonTags = context.getBean(CommonTags.class);
            assertThat(commonTags.getTags()).containsEntry("app", "test-app");
            assertThat(commonTags.getTags()).containsEntry("env", "test");
        });
    }

    @Test
    void autoConfiguration_commonTagCustomExtensionAddsCustomTags() {
        contextRunner.withUserConfiguration(CustomTagConfig.class).run(context -> {
            CommonTags commonTags = context.getBean(CommonTags.class);
            assertThat(commonTags.getTags()).containsEntry("app", "test-app");
            assertThat(commonTags.getTags()).containsEntry("env", "test");
            assertThat(commonTags.getTags()).containsEntry("region", "cn-north");
        });
    }

    @Test
    void autoConfiguration_skippedWhenPrometheusMeterRegistryNotOnClasspath() {
        contextRunner
                .withClassLoader(new FilteredClassLoader(PrometheusMeterRegistry.class))
                .run(context -> {
                    assertThat(context).doesNotHaveBean(PrometheusAutoConfiguration.class);
                    assertThat(context).doesNotHaveBean(StatsDClient.class);
                });
    }

    @Test
    void autoConfiguration_skippedWhenClockBeanMissing() {
        new ApplicationContextRunner()
                .withInitializer(ctx -> ConfigurationPropertiesBindingPostProcessor.register(
                        (BeanDefinitionRegistry) ctx.getBeanFactory()))
                .withConfiguration(AutoConfigurations.of(PrometheusAutoConfiguration.class))
                .run(context -> {
                    assertThat(context).doesNotHaveBean(PrometheusAutoConfiguration.class);
                });
    }

    @Configuration
    static class CustomTagConfig {
        @Bean
        CommonTagCustom regionTag() {
            return tags -> tags.put("region", "cn-north");
        }
    }
}
