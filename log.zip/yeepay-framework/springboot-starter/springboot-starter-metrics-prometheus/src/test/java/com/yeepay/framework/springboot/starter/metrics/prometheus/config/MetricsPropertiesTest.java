package com.yeepay.framework.springboot.starter.metrics.prometheus.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import org.junit.jupiter.api.Test;

class MetricsPropertiesTest {

    @Test
    void prefix_constant() {
        assertThat(MetricsProperties.PREFIX).isEqualTo("yeepay.framework.metrics");
    }

    @Test
    void defaultValues() {
        MetricsProperties props = new MetricsProperties();
        assertThat(props.getPrefix()).isNull();
        assertThat(props.getSuffix()).isNull();
        assertThat(props.getTags()).isEmpty();
        assertThat(props.getScheduleThreads()).isEqualTo(1);
        assertThat(props.getPublishFrequency()).isEqualTo(Duration.ofSeconds(30));
        assertThat(props.getTagsLimit()).isEqualTo(1000);
        assertThat(props.getKeepAlive()).isEqualTo(Duration.ofMinutes(2));
    }
}
