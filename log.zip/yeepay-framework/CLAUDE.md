# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Test Commands

```bash
# Full build (includes checkstyle, spotbugs, spotless checks)
mvn clean package

# Build skipping all checks (fast iteration)
mvn clean package -Dcheckstyle.skip -Dspotbugs.skip -Dspotless.check.skip

# Run all tests
mvn test

# Run a single test class
mvn test -pl lock/lock-api -Dtest=LockManagerTest

# Run a single test method
mvn test -pl lock/lock-api -Dtest=LockManagerTest#testLockSuccess

# Format code (Palantir Java Format via Spotless)
mvn spotless:apply

# Checkstyle only
mvn checkstyle:check

# SpotBugs only
mvn spotbugs:check
```

No build wrapper (`mvnw`) exists — use system `mvn`. Requires Java 17.

## Architecture

This is a multi-module Java framework (`com.yeepay.framework`, version `1.0.0-SNAPSHOT`) built on Spring Boot 3.4.12. It provides six main capabilities to downstream services: distributed locking, rate limiting, global unique ID generation, infrastructure client wrappers, metrics/reporting, and smart caching, plus shared utilities for logging, web request tracing, and thread management.

### Module Dependency Layers

```
springboot-starter (auto-configuration)
    ├── springboot-starter-lock (base + jedis | redisson)
    ├── springboot-starter-rate-limit (base + guava | jedis | redisson | resilience4j)
    ├── springboot-starter-global-id (database | redis | zookeeper)
    ├── springboot-starter-infra (jedis | redisson)
    ├── springboot-starter-metrics-prometheus
    ├── springboot-starter-smart-cache
    ├── springboot-starter-web
    └── springboot-starter-application
         │
    lock (lock-api ← lock-jedis, lock-redission)
    rate-limit (rate-limit-api ← rate-limit-guava, rate-limit-jedis, rate-limit-redisson, rate-limit-resilience4j)
    global-id (global-id-api ← global-id-core ← database, redis, zookeeper)
    infra (infra-jedis, infra-redisson, infra-zookeeper)
    metrics (metrics-api ← metrics-prometheus)
         │
    common (ThreadContext, thread pools, Result, UUID generator, utilities)
    web (ThreadContextFilter for servlet request tracing)
    logging (custom Logback appenders, dynamic level filter)
    bom (version alignment for downstream consumers)
    shared-resources (checkstyle/spotbugs rule files)
```

### Key Design Patterns

**SPI-style pluggability**: `lock`, `rate-limit`, `global-id`, and `metrics` all follow an API/impl split. Core interfaces (`LockExecutor`, `YeepayRateLimiter`, `UidGenerator`, `WorkerIdAssigner`, `StatsDClient`) live in `-api` modules; implementations live in backend-specific modules (jedis, redisson, guava, resilience4j, database, redis, zookeeper, prometheus). The `springboot-starter-*` modules wire the chosen backend via conditional auto-configuration using `AutoConfiguration.imports`.

**Distributed Lock** (`lock/`): `LockExecutor<T>` is the SPI. `LockManager` wraps it with a business-friendly API (Runnable/Supplier callbacks with auto-unlock). The `@YeepayLock` annotation + `YeepayLockAspect` provides declarative locking with pluggable strategies for key generation, failure handling, and release timeout.

**Global ID** (`global-id/`): Snowflake-based UID generation. `DefaultUidGenerator` is the basic implementation; `CachedUidGenerator` adds a RingBuffer pre-fill mechanism. Worker ID assignment is pluggable — backed by database (with heartbeat/zombie detection), Redis, or ZooKeeper.

**Rate Limiting** (`rate-limit/`): `YeepayRateLimiter` is the SPI. `RateLimiterManager` wraps it with a business-friendly API (`isAllowed` checks and `tryAcquire` with Runnable/Supplier callbacks). The `@YeepayRateLimit` annotation + `YeepayRateLimitAspect` provides declarative rate limiting with pluggable strategies for key generation (`RateLimitKeyStrategy`, supports SpEL expressions) and failure handling (`RateLimitFailureStrategy`). Supports token bucket, sliding window, leaky bucket, and concurrent request algorithms. Four backends: Guava (local), Jedis (distributed via Redis Lua scripts), Redisson (distributed via Redis), and Resilience4j (local).

**Infrastructure Clients** (`infra/`): Factory-pattern wrappers for Jedis, Redisson, and Curator (ZooKeeper) that support single/sentinel/cluster topologies via config properties.

**Logging** (`logging/`): Custom Logback extensions. `YeepayConsoleAppender` wraps `System.out` with a buffer for high-throughput console output. `YeepayFluentAppender` ships log events to Fluentd with automatic host/app/environment detection and thread context metadata. `ForceChangeLevelFilter` is a `TurboFilter` that dynamically changes log levels per-thread via `ForceChangeLevelFilter.changeLevel(level, runnable)`.

**Metrics** (`metrics/`): `StatsDClient` is the SPI — a DataDog/StatsD-style interface for counters, gauges, timers, and histograms. `YeepayPrometheusProxy` implements it using Micrometer's `PrometheusMeterRegistry`. `MetricsAspect` provides `@Time`, `@Count`, and `@Gauge` annotations for declarative method-level metrics. `CommonTagCustom` is an SPI for injecting custom global tags (e.g., app version). Tag cardinality is capped via `tagsLimit` and stale meters expire via `keepAlive`.

**Smart Cache** (`springboot-starter/springboot-starter-smart-cache/`): Auto-configuration for the external `yeepay-smartcache` library. Registers `SmartCacheInterceptor` and applies it to all `@SmartCache`-annotated methods via AOP pointcut.

**Web Request Context** (`web/` + `springboot-starter-web/`): `ThreadContextFilter` initializes per-request thread context (GUID, trace IDs, app metadata) at `HIGHEST_PRECEDENCE`. The `common` module provides `ThreadContext`, `ThreadContextUtils`, and context-propagating executors (`ThreadContextPoolExecutor`, `ScheduledThreadContextPoolExecutor`) that carry context across async boundaries.

### Configuration Namespace

All framework config lives under `yeepay.framework.*`:

| Namespace | Purpose |
|-----------|---------|
| `yeepay.framework.lock.*` | Lock type selection, retry interval |
| `yeepay.framework.rate-limit.*` | Rate limit type (guava/jedis/redisson/resilience4j), enabled flag |
| `yeepay.framework.global-id.*` | Snowflake bit allocation, worker backend config |
| `yeepay.framework.infra.jedis.*` | Jedis pool config (single/sentinel/cluster) |
| `yeepay.framework.infra.redisson.*` | Redisson config (single/sentinel/cluster) |
| `yeepay.framework.infra.zookeeper.*` | ZooKeeper connection config |
| `yeepay.framework.metrics.*` | Metrics prefix/suffix, publish frequency, tags limit, keep-alive |
| `yeepay.framework.smart-cache.*` | Smart cache enabled flag |
| `yeepay.framework.web.*` | Web filter enabled flag |

See `examples/` for full working YAML configs.

## Code Quality

- **Formatter**: Palantir Java Format (enforced via `spotless-maven-plugin` at `process-sources` phase)
- **Static analysis**: Checkstyle (`shared-resources/codestyle/yeepay_checkstyle.xml`) runs at `validate` phase; SpotBugs with FindSecBugs runs at `package` phase — both fail the build on violation
- **Testing**: JUnit 5 + Mockito + AssertJ. Tests exist primarily in `lock/`, `rate-limit/`, `infra/`, `logging/`, and `springboot-starter/` modules
- Always run `mvn spotless:apply` before committing to avoid format check failures
